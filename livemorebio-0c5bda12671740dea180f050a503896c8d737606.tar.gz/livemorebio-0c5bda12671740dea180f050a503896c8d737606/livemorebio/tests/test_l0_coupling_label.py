"""L0-R15 (walk finding L0W-2): the unsourced coupling's label is on every output it changes.

``metabolic_cardiac_hyperglycemia_to_ikr`` adds a glucose-dependent IKr block to
every live-twin cardiac computation. Its slope has no admitted source, so every
output whose value it changes carries ``HYPOTHESIS_UNSOURCED``: the ventricular
trace and its time axis, APD90, the calcium peak, the IKr block and the coupling's
share of it, the multiscale nodes, time axes and summaries built from them, the
scenario comparisons, the Biology heart's IKr input, and every console view that
shows them. Outputs it does not change (glucose, insulin, heart rate, HRV) do not
carry it, and a label names only fields its output contains (round 1).

Technical reference twins only; no person, measurement or service.
"""
from __future__ import annotations

import json
import math
import re

from fastapi.testclient import TestClient
import pytest

from livemorebio.aegle import server
from livemorebio.aegle.model_source import ModelSourceAuthority
from livemorebio.aegle.observation_state import ObservationState
from livemorebio.aegle.runtime import AegleTwin

LABEL = "HYPOTHESIS_UNSOURCED"
COUPLING = "metabolic_cardiac_hyperglycemia_to_ikr"
# Keys whose value the coupling changes wherever they appear in a runtime output.
COUPLED_KEYS = ("apd90_ms", "vpeak", "vrest", "cai_peak_uM")
COUPLED_NODES = {"channel.ikr", "cell.cardiomyocyte", "tissue.ventricular"}
UNCOUPLED_NODES = {"organ.heart", "system.endocrine", "system.cardiovascular", "whole_body.homeostasis"}


def labelled(value: dict, *fields: str) -> bool:
    return (value.get("coupling_claim_state") == LABEL and value.get("coupling_id") == COUPLING
            and set(fields) <= set(value.get("coupled_fields") or ()))


def unlabelled(value, path: str = "$") -> list[str]:
    """Every place in an output that holds a coupled value without the label."""
    missing = []
    if isinstance(value, dict):
        coupled = [key for key in COUPLED_KEYS if value.get(key) is not None]
        if "ikr_block" in value and "apd90_ms" in value:
            coupled.append("ikr_block")  # the cardiac readout's total block includes the coupling's share
        if value.get("id") in COUPLED_NODES and value.get("value") is not None:
            coupled.append("value")
        if coupled and not labelled(value, *coupled):
            missing.append(f"{path}: {', '.join(coupled)}")
        quantity = value.get("ventricular_apd90")
        if isinstance(quantity, dict) and quantity.get("value") is not None and not labelled(quantity, "value"):
            missing.append(f"{path}.ventricular_apd90: value")
        for key, item in value.items():
            missing += unlabelled(item, f"{path}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            missing += unlabelled(item, f"{path}[{index}]")
    return missing


@pytest.fixture
def selection(monkeypatch):
    twin = AegleTwin("healthy")
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-l0-coupling-token")
    monkeypatch.setattr(server, "_model_source_authority", ModelSourceAuthority())
    monkeypatch.setattr(server, "_workspace_actions", [])
    monkeypatch.setattr(server, "_state", {"tw": twin, "subject": None, "initialized": True,
                                          "observation_state": ObservationState()})
    monkeypatch.setattr(server, "_snapshot_twin", lambda *args: None)
    client = TestClient(server.app, raise_server_exceptions=False,
                        headers={"Authorization": "Bearer technical-l0-coupling-token"})
    return twin, client


def test_a_meal_moves_the_coupled_outputs_and_every_one_carries_the_label(selection, pinned_cardiac_asset):
    twin, client = selection
    live = client.get("/api/state")
    assert live.status_code == 200, live.text
    live = live.json()
    assert unlabelled(live) == []
    cardiac = live["cardiac"]
    assert labelled(cardiac, "apd90_ms", "ikr_block", "v", "cai", "vrest", "vpeak", "cai_peak_uM")
    assert 0 <= cardiac["ikr_block_from_coupling"] <= cardiac["ikr_block"]

    meal = {"kind": "meal", "params": {"grams": 60, "minute": 0}}
    stimulated = client.post("/api/stimulate", json=meal)
    assert stimulated.status_code == 200, stimulated.text
    scenario = stimulated.json()
    assert scenario["scenario"]["code"] == "ISOLATED_SCENARIO"
    assert unlabelled(scenario) == []
    # The meal acts through the coupling: more glucose, more coupled block, longer APD90.
    assert scenario["cardiac"]["ikr_block_from_coupling"] > cardiac["ikr_block_from_coupling"]
    assert scenario["cardiac"]["apd90_ms"] > cardiac["apd90_ms"]

    action = client.post("/api/workspace/actions", json=meal)
    assert action.status_code == 200, action.text
    workspace = action.json()["workspace"]
    assert unlabelled(workspace) == []
    for snapshot in (workspace, client.get("/api/workspace").json()):
        multiscale = snapshot["multiscale"]
        nodes = {node["id"]: node for node in multiscale["active_execution"]["nodes"]}
        assert {node for node in nodes if labelled(nodes[node], "value")} == COUPLED_NODES
        assert UNCOUPLED_NODES <= set(nodes) and not any("coupling_claim_state" in nodes[n] for n in UNCOUPLED_NODES)
        assert labelled(multiscale["active_execution"]["summary"], "apd90_ms")
        assert labelled(multiscale["comparison"]["baseline"], "apd90_ms")
        assert labelled(multiscale["comparison"]["treated"], "apd90_ms")
        cardiovascular = next(item for item in multiscale["systems"] if item["system_id"] == "cardiovascular")
        assert labelled(cardiovascular["state"]["ventricular_apd90"], "value")
        assert "coupling_claim_state" not in cardiovascular["state"]["heart_rate"]
    # Each output that does not use the coupling stays unlabelled.
    assert "coupling_claim_state" not in live["metabolic"]

    biology = client.get("/api/biology")
    assert biology.status_code == 200, biology.text
    heart = next(organ for organ in biology.json()["organs"] if organ["cell"].get("render") == "cardiac")
    # Round 1: the heart reports the cell's whole IKr input, coupling included, with the label;
    # the cell carries no label for a trace this response does not contain.
    assert labelled(heart, "value", "ikr_block_from_coupling")
    assert heart["value"] == round(cardiac["ikr_block"], 3)
    assert "coupling_claim_state" not in heart["cell"] and LABEL in heart["cell"]["note"]


def test_the_label_names_the_coupling_the_release_declares():
    from livemorebio.engines.coupling import labels, metabolic_cardiac
    from livemorebio.foundation import whole_human_manifest

    assert labels.HYPOTHESIS_UNSOURCED == metabolic_cardiac.CLAIM_STATE == LABEL
    declared = {coupling["id"]: coupling["claim_state"] for system in whole_human_manifest()["systems"]
                for coupling in system.get("implemented_couplings", [])}
    assert declared == {labels.METABOLIC_CARDIAC_COUPLING_ID: LABEL}


def test_without_the_cardiac_file_the_coupled_ikr_block_still_carries_its_label(monkeypatch, tmp_path):
    from livemorebio import model_assets

    from livemorebio.engines.biology import biology_state
    from livemorebio.multiscale import multiscale_state

    monkeypatch.setattr(model_assets, "_cardiac_path", lambda: tmp_path / "absent-technical.cellml")
    twin = AegleTwin("healthy")
    state = twin.state()
    cardiac = state["cardiac"]
    assert cardiac["reason_code"] == "CARDIAC_MODEL_NOT_INSTALLED" and cardiac["apd90_ms"] is None
    assert labelled(cardiac, "ikr_block") and cardiac["coupled_fields"] == ["ikr_block", "ikr_block_from_coupling"]
    assert unlabelled(state) == []
    # No trace is shown without the file, so the Biology heart claims no coupled value.
    heart = next(organ for organ in biology_state(twin)["organs"] if organ.get("reason_code"))
    assert heart["value"] is None and "coupling_claim_state" not in heart and "coupling_claim_state" not in heart["cell"]
    axes = {axis["id"]: axis for axis in multiscale_state(twin)["biological_time"]["axes"]}
    assert axes["cardiac"]["values"] == [] and "coupling_claim_state" not in axes["cardiac"]


def _outputs(twin) -> dict:
    from livemorebio.engines.biology import biology_state
    from livemorebio.multiscale import multiscale_state

    return {"state": twin.state(), "multiscale": multiscale_state(twin), "biology": biology_state(twin)}


def _leaves(value, path=()):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from _leaves(item, (*path, key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from _leaves(item, (*path, index))
    else:
        yield path, value


def _at(value, path):
    for step in path:
        value = value[step]
    return value


def _covered(outputs: dict, path: tuple) -> bool:
    """The nearest labelled object above a leaf names the field the leaf belongs to."""
    for depth in range(len(path) - 1, -1, -1):
        container = _at(outputs, path[:depth])
        if isinstance(container, dict) and container.get("coupling_claim_state") == LABEL:
            return container.get("coupling_id") == COUPLING and path[depth] in (container.get("coupled_fields") or ())
    return False


def test_the_label_is_on_every_output_the_coupling_changes(pinned_cardiac_asset, monkeypatch):
    """Round 1: run a T2D twin with the coupling and with its share set to zero; every value that differs is labelled."""
    from livemorebio.aegle import runtime

    coupled = _outputs(AegleTwin("type-2-diabetes"))
    monkeypatch.setattr(runtime, "hyperglycemia_to_ikr_block", lambda mean_glucose: 0.0)
    uncoupled = _outputs(AegleTwin("type-2-diabetes"))
    before, after = dict(_leaves(coupled)), dict(_leaves(uncoupled))
    changed = sorted({path for path in before if before.get(path) != after.get(path)} | (set(before) ^ set(after)),
                     key=str)
    missing = sorted({re.sub(r"\d+", "#", ".".join(map(str, path))) for path in changed
                      if path in before and not _covered(coupled, path)})
    assert missing == [], missing
    families = {re.sub(r"\d+", "#", ".".join(map(str, path))) for path in changed}
    # Not vacuous: the coupling's share, the trace and its time axis, the projections and Biology all move.
    assert {"state.cardiac.ikr_block_from_coupling", "state.cardiac.t_ms.#", "state.cardiac.v.#",
            "multiscale.biological_time.axes.#.values.#", "multiscale.active_execution.nodes.#.value"} <= families
    assert any(family.startswith("biology.organs.#.value") for family in families), families


def test_every_labelled_ventricular_field_is_one_the_ikr_block_can_change(pinned_cardiac_asset):
    """L0-R19: check unrounded quantities, without changing displayed or recorded values.

    Each labelled field moves when the
    coupling's share alone moves the IKr block (0 to 0.2 is a mean glucose of about 157 mg/dL; 0 to 0.5
    adds a drug's block) at a cycle length the twin reaches (470 ms is a resting 128 bpm, within the
    heart-rate model's 44 to 135 bpm for some conditions; 710.9 ms is the T2D reference twin)."""
    twin = AegleTwin("healthy")
    cardiac = twin.state()["cardiac"]
    fields = set(cardiac["coupled_fields"])
    assert {"t_ms", "v", "cai", "vrest", "vpeak", "apd90_ms", "cai_peak_uM", "ikr_block",
            "ikr_block_from_coupling"} == fields
    keys = {"t_ms": "t"}
    runs = [(_unrounded_cardiac_values(twin.heart.simulate(beats=6, ikr_block=low, cl_ms=cl)),
             _unrounded_cardiac_values(twin.heart.simulate(beats=6, ikr_block=high, cl_ms=cl)))
            for cl, low, high in ((470.0, 0.0, 0.2), (710.9, 0.0, 0.5))]
    for field in sorted(fields - {"ikr_block", "ikr_block_from_coupling"}):
        key = keys.get(field, field)
        moves = any(json.dumps(_plain(a[key])) != json.dumps(_plain(b[key])) for a, b in runs)
        assert moves, f"{field} is labelled but the IKr block does not change it"


def _unrounded_cardiac_values(result):
    """Reconstruct summaries from the engine's own raw trace by its unchanged rules.

    CardiacCell exposes raw t/v/cai arrays, but no unrounded scalar summaries.
    This mirrors action_potential._metrics and simulate's calcium conversion,
    omitting only their presentation rounding (mV, ms and micromol/L).
    """
    t, v, cai = result["t"], result["v"], result["cai"]
    vrest, vpeak = float(v.min()), float(v.max())
    threshold = vpeak - 0.9 * (vpeak - vrest)
    above = t[v >= threshold]
    apd90_ms = float(above.max() - above.min()) if len(above) > 1 else float("nan")
    values = {"vrest": vrest, "vpeak": vpeak, "apd90_ms": apd90_ms,
              "cai_peak_uM": float(cai.max() * 1e3)}
    assert all(math.isfinite(value) for value in values.values()), "unrounded cardiac metrics must be finite"
    return dict(values, t=t, v=v, cai=cai)


def _plain(value):
    return [float(item) for item in value] if hasattr(value, "__len__") and not isinstance(value, str) else value


def test_label_movement_uses_unrounded_trace_when_display_summaries_coincide(monkeypatch):
    """L0-R19: presentation rounding must not determine the coupling's label."""
    import numpy as np
    from types import SimpleNamespace
    from livemorebio.engines.cardiac.action_potential import _metrics

    class TechnicalCell:
        def simulate(self, *, beats, ikr_block, cl_ms):
            assert beats == 6 and cl_ms in (470.0, 710.9)
            t = np.array([0.0, 1.0, 2.0, 3.0]) * (1.0 + ikr_block * 0.0001)
            v = np.array([-80.0, 20.0, 10.0, -80.0]) + ikr_block * 0.01
            cai = np.array([0.0001, 0.0002, 0.00015, 0.0001]) * (1.0 + ikr_block * 0.0001)
            summaries = _metrics(t, v)
            summaries["cai_peak_uM"] = round(float(cai.max() * 1e3), 3)
            assert summaries == {"vrest": -80.0, "vpeak": 20.0, "amplitude": 100.0,
                                 "apd90_ms": 1.0, "cai_peak_uM": 0.2}
            return dict(summaries, t=t, v=v, cai=cai)

    fields = ["t_ms", "v", "cai", "vrest", "vpeak", "apd90_ms", "cai_peak_uM",
              "ikr_block", "ikr_block_from_coupling"]
    twin = SimpleNamespace(heart=TechnicalCell(), state=lambda: {"cardiac": {"coupled_fields": fields}})
    monkeypatch.setattr(f"{__name__}.AegleTwin", lambda base: twin)
    test_every_labelled_ventricular_field_is_one_the_ikr_block_can_change(None)


def test_label_movement_rejects_constant_raw_trace_despite_different_summaries(monkeypatch):
    """Changing a rounded summary alone cannot satisfy the computed-output check."""
    import numpy as np
    from types import SimpleNamespace

    class TechnicalCell:
        def simulate(self, *, beats, ikr_block, cl_ms):
            return {"t": np.array([0.0, 1.0, 2.0, 3.0]),
                    "v": np.array([-80.0, 20.0, 10.0, -80.0]),
                    "cai": np.array([0.0001, 0.0002, 0.00015, 0.0001]),
                    "vrest": -80.0 + ikr_block, "vpeak": 20.0 + ikr_block,
                    "apd90_ms": 1.0 + ikr_block, "cai_peak_uM": 0.2 + ikr_block}

    fields = ["t_ms", "v", "cai", "vrest", "vpeak", "apd90_ms", "cai_peak_uM",
              "ikr_block", "ikr_block_from_coupling"]
    twin = SimpleNamespace(heart=TechnicalCell(), state=lambda: {"cardiac": {"coupled_fields": fields}})
    monkeypatch.setattr(f"{__name__}.AegleTwin", lambda base: twin)
    with pytest.raises(AssertionError, match="is labelled but the IKr block does not change it"):
        test_every_labelled_ventricular_field_is_one_the_ikr_block_can_change(None)


def test_biology_heart_reports_the_cells_whole_ikr_input(pinned_cardiac_asset):
    """Round 1: the Biology heart's 'IKr block input' is the input the cell runs with, coupling included."""
    from livemorebio.engines.biology import biology_state

    twin = AegleTwin("type-2-diabetes")
    twin.stimulate("cardiac_drug", ikr_block=0.2)
    cardiac = twin.state()["cardiac"]
    heart = next(organ for organ in biology_state(twin)["organs"] if organ["id"] == "heart")
    assert heart["value"] == cardiac["ikr_block"] > 0.2
    assert heart["ikr_block_from_coupling"] == cardiac["ikr_block_from_coupling"] > 0
    assert heart["ikr_block_from_drug"] == 0.2
    assert labelled(heart, "value", "ikr_block_from_coupling")


# ---------------------------------------------------------------- console

def _workspace_program(program: str) -> None:
    from .test_workspace_stream_ui import javascript
    javascript(program)


LABELLED_FIXTURE = r'''
function labelled(){
  const label={coupling_id:'metabolic_cardiac_hyperglycemia_to_ikr',coupling_claim_state:'HYPOTHESIS_UNSOURCED'};
  const w=fixture();
  w.multiscale.active_execution.nodes=[
    {id:'system.endocrine',scale:'system',label:'mean glucose',value:120,unit:'mg/dL',engine:'bergman-glucose-insulin',evidence_state:'MODELED'},
    {id:'channel.ikr',scale:'ion_channel',label:'IKr block',value:0.07,unit:'1',engine:'ohara-rudy-cipa-2017',evidence_state:'MODELED',...label,coupled_fields:['value']},
    {id:'cell.cardiomyocyte',scale:'cell',label:'calcium peak',value:0.4,unit:'umol/L',engine:'ohara-rudy-cipa-2017',evidence_state:'MODELED',...label,coupled_fields:['value']},
    {id:'tissue.ventricular',scale:'tissue',label:'ventricular APD90',value:272,unit:'ms',engine:'ohara-rudy-cipa-2017',evidence_state:'MODELED',...label,coupled_fields:['value']},
    {id:'organ.heart',scale:'organ',label:'heart rate',value:70,unit:'bpm',engine:'livemore-heart-rate',evidence_state:'MODELED'},
    {id:'system.cardiovascular',scale:'system',label:'HRV',value:40,unit:'ms',engine:'livemore-heart-rate',evidence_state:'MODELED'}];
  w.multiscale.active_execution.edges=[{source:'system.endocrine',target:'cell.cardiomyocyte',mechanism:'bounded_hyperglycemia_to_ikr_coupling',claim_state:'HYPOTHESIS_UNSOURCED'}];
  for(const side of ['baseline','treated'])Object.assign(w.multiscale.comparison[side],label,{coupled_fields:['apd90_ms']});
  w.multiscale.comparison.treated.apd90_ms=272;w.multiscale.comparison.baseline.apd90_ms=270;
  return {w,label};
}
'''


def test_workspace_views_that_show_coupled_values_show_the_label():
    _workspace_program(LABELLED_FIXTURE + r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();
function el(id){if(!nodes.has(id))nodes.set(id,{id,textContent:'',innerHTML:'',hidden:false,dataset:{},attrs:{},
 className:'',setAttribute(k,v){this.attrs[k]=v},replaceChildren(){this.innerHTML='';this.textContent=''},after(x){nodes.set('#'+x.id,x)}});return nodes.get(id)}
const {w,label}=labelled();
const context={document:{body:{dataset:{}},querySelector:s=>s==='#isolated-scenario-result'?(nodes.get(s)||null):el(s),querySelectorAll:()=>[],
 createElement:()=>({textContent:'',attrs:{},setAttribute(k,v){this.attrs[k]=v}})},URLSearchParams,technical:w,
 escapeHTML:x=>String(x),fmt:(value,digits)=>Number(value).toFixed(digits)};
vm.runInNewContext(PROJECTIONS+'\n'+CONTROLLER,context);
vm.runInNewContext('drawChart=()=>{};WORKSPACE=technical;',context);
vm.runInNewContext('renderMechanism()',context);
a.match(el('#mechanism-caption').textContent,/HYPOTHESIS_UNSOURCED/,'mechanism caption');
for(const id of ['channel.ikr','cell.cardiomyocyte','tissue.ventricular'])
  a.match(el('#mechanism-loop').innerHTML,new RegExp(id.replace('.','\\.')+'"[^]*?HYPOTHESIS_UNSOURCED'),id);
vm.runInNewContext('renderComparison()',context);
a.match(el('#key-metrics').innerHTML,/Ventricular APD90[^]*?HYPOTHESIS_UNSOURCED/,'APD90 key metric');
a(!/Heart rate<\/span>[^]*?HYPOTHESIS_UNSOURCED[^]*?Ventricular APD90/.test(el('#key-metrics').innerHTML),'heart rate labelled');
a.match(el('#chart-provenance').textContent,/HYPOTHESIS_UNSOURCED/,'chart provenance');
vm.runInNewContext('SELECTED_NODE="tissue.ventricular";EVIDENCE_TAB="modeled";renderFocus();renderEvidence()',context);
a.match(el('#focus-readout').innerHTML,/HYPOTHESIS_UNSOURCED/,'focus readout');
a.match(el('#evidence-content').innerHTML,/HYPOTHESIS_UNSOURCED/,'evidence: modeled');
vm.runInNewContext('SELECTED_NODE="whole_body.homeostasis";renderEvidence()',context);
a.match(el('#evidence-content').innerHTML,/HYPOTHESIS_UNSOURCED/,'evidence: default view states the coupling boundary');
vm.runInNewContext('SELECTED_NODE="tissue.ventricular";EVIDENCE_TAB="reference";renderEvidence()',context);
a.match(el('#evidence-content').innerHTML,/HYPOTHESIS_UNSOURCED/,'evidence: reference');
vm.runInNewContext('SELECTED_NODE="organ.heart";EVIDENCE_TAB="modeled";renderFocus()',context);
a(!/HYPOTHESIS_UNSOURCED/.test(el('#focus-readout').innerHTML),'uncoupled heart rate labelled');
const result={action:{kind:'meal',status:'COMPLETED',transitions:['QUEUED','RUNNING','COMPLETED']},
 scenario:{code:'ISOLATED_SCENARIO',source_generation:'a'.repeat(32),live_twin_unchanged:true},
 workspace:{twin:{metabolic:{mean_glucose:125},cardiac:{hr_bpm:70,apd90_ms:272,...label,coupled_fields:['apd90_ms']}},
 multiscale:{comparison:{baseline:{mean_glucose_mg_dL:90,heart_rate_bpm:68,apd90_ms:270,...label,coupled_fields:['apd90_ms']}}}}};
vm.runInNewContext('renderIsolatedScenario',context)(result);
a.match(nodes.get('#isolated-scenario-result').textContent,/APD90 \(ms\): captured baseline 270\.0; scenario 272\.0\. APD90 is HYPOTHESIS_UNSOURCED/,'isolated scenario APD90');
a(!/Heart rate \(bpm\)[^A]*HYPOTHESIS_UNSOURCED/.test(nodes.get('#isolated-scenario-result').textContent),'heart rate labelled');
''')


def test_advanced_console_cardiac_card_shows_the_label():
    from pathlib import Path
    from ._node import require_node, run_node
    from .test_legacy_preview_recovery_clients import preview

    html = (Path(__file__).parents[1] / "aegle/console/index.html").read_text(encoding="utf-8")
    prefix = "const $=" + html.split("<script>\nconst $=", 1)[1].split("// ===== Experiment / perturbation builder =====", 1)[0]
    render = "function render(){" + html.split("function render(){", 1)[1].split("// --- reactive metabolic curves ---", 1)[0]
    state = preview()
    state["cardiac"].update(coupling_id=COUPLING, coupling_claim_state=LABEL, ikr_block_from_coupling=0.07,
                            coupled_fields=["ikr_block", "v", "cai", "vrest", "vpeak", "apd90_ms", "cai_peak_uM"])
    program = r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',title:'',hidden:false,style:{},dataset:{},width:1,height:1,
 classList:{toggle(){},remove(){}},setAttribute(){},addEventListener(){},replaceChildren(){},
 getContext:()=>({clearRect(){}}),querySelector:()=>({setAttribute(){}})});return nodes.get(id)}
const context={document:{getElementById:el,querySelectorAll:()=>[]},window:{addEventListener(){}},
 requestAnimationFrame(){},drawCell(){},drawTrace(){},console,technical:@@STATE@@};vm.createContext(context);
vm.runInContext(@@PREFIX@@,context);context.drawMetab=()=>{};context.paintBody=()=>{};
vm.runInContext('let LASTRUN=null,t0=0;function renderExtract(){};'+@@RENDER@@,context);
vm.runInContext('S=technical;render()',context);
a.match(el('cardNote').textContent||el('cardNote').innerHTML,/HYPOTHESIS_UNSOURCED/,'cardiac card note');
a.match(el('cardNote').textContent||el('cardNote').innerHTML,/glucose-to-IKr/,'cardiac card names the coupling');
a.match(el('mApdBox').title,/HYPOTHESIS_UNSOURCED/,'APD90 tile');
'''
    for marker, value in {"@@STATE@@": state, "@@PREFIX@@": prefix, "@@RENDER@@": render}.items():
        program = program.replace(marker, json.dumps(value))
    result = run_node([require_node(), "--eval", program], capture_output=True, text=True, encoding="utf-8", timeout=15)
    assert result.returncode == 0, result.stderr


def test_biology_view_shows_the_label_on_the_hearts_ikr_input_and_its_replayed_trace():
    """Round 1: the Biology view shows the label read from the data, on the heart and on the cell's trace."""
    from .test_biology_context_reconciliation_ui import run_controller

    run_controller(r'''
const label={coupling_id:'metabolic_cardiac_hyperglycemia_to_ikr',coupling_claim_state:'HYPOTHESIS_UNSOURCED'};
const coupledHeart={...heart,status:'parameter',metric:'Ventricular-cell IKr block input',value:0.313,unit:'fraction',
  evidence_state:'MODEL_PARAMETER',ikr_block_from_coupling:0.313,ikr_block_from_drug:0,...label,coupled_fields:['value','ikr_block_from_coupling'],
  cell:{...heart.cell,render:'cardiac',process:'technical action potential',evidence_state:'MODELED_BIOPHYSICAL',note:'technical note'}};
payload=state('a'.repeat(64),[coupledHeart,kidney]);
const trace={context_id:payload.context_id,cardiac:{v:[-80,20,-80],cai:[0.0001,0.0002,0.0001],t_ms:[0,100,200],...label,
  coupled_fields:['t_ms','v','cai']}};
context.fetch=async(path)=>{calls.push(path);if(path==='/api/biology')return{ok:true,status:200,json:async()=>payload};
  if(path==='/api/state')return{ok:true,json:async()=>trace};throw Error('UNEXPECTED_REQUEST')};
await mount();
a.match(el('panel').innerHTML,/IKr block input[^]*?HYPOTHESIS_UNSOURCED/,'overview: heart IKr input');
a(!/Technical reference kidney[^]*?HYPOTHESIS_UNSOURCED/.test(el('panel').innerHTML),'uncoupled kidney labelled');
context.window._sel('heart');
a.match(el('panel').innerHTML,/HYPOTHESIS_UNSOURCED[^]*?glucose-to-IKr/,'detail: heart IKr input');
await context.window._cell('heart');await flush();
a.match(el('cell-data-status').textContent,/HYPOTHESIS_UNSOURCED/,'cell: replayed trace');
''')


def test_advanced_console_refused_experiment_keeps_its_code():
    """Round 1: a refused experiment in the advanced console shows the service's typed code."""
    from pathlib import Path
    from ._node import require_node, run_node

    html = (Path(__file__).parents[1] / "aegle/console/index.html").read_text(encoding="utf-8")
    functions = {}
    for name in ("showBanner", "refusedCode", "stim", "runVia"):
        if f"function {name}(" not in html:
            continue  # absent before round 1: the test then fails on the missing code, as intended
        start = html.index(f"function {name}(")
        start = html.rfind("async ", start - 6, start) if html[start - 6:start] == "async " else start
        depth, index = 0, html.index("{", start)
        while True:
            depth += {"{": 1, "}": -1}.get(html[index], 0)
            index += 1
            if depth == 0:
                break
        functions[name] = html[start:index]
    program = r'''
const a=require('node:assert/strict'),vm=require('node:vm');
const banner={dataset:{},textContent:'',hidden:true,setAttribute(){}};
let reply;
const context={document:{getElementById:()=>banner},fetch:async()=>reply,render(){},logExperiment(){},focusReadout(){},
 legacyPreviewRecovery:{beginNumericalAction:()=>({}),failNumericalAction:()=>true,finishNumericalAction(){},isCurrent:()=>true}};
vm.createContext(context);vm.runInContext(@@SOURCE@@,context);
(async()=>{
for(const call of ["runVia('/api/stimulate',{kind:'cardiac_drug',params:{ikr_block:.5}},{readout:'cardiac'})",
                   "stim('cardiac_drug',{ikr_block:.5})"]){
  reply={ok:false,status:422,json:async()=>({error:'Isolated biological scenario could not be completed.',code:'CARDIAC_MODEL_NOT_INSTALLED'})};
  await vm.runInContext(call,context);
  a.match(banner.textContent,/CARDIAC_MODEL_NOT_INSTALLED/,call);
  reply={ok:false,status:422,json:async()=>({error:'x',code:'<b>not a code</b>'})};
  await vm.runInContext(call,context);
  a(!/not a code/.test(banner.textContent),'a malformed code was shown');
  reply={ok:false,status:503,json:async()=>{throw Error('no body')}};
  await vm.runInContext(call,context);
  a.match(banner.textContent,/not confirmed/,'an unconfirmed failure keeps its notice');
}
})().catch(e=>{console.error(e);process.exitCode=1});
'''
    program = program.replace("@@SOURCE@@", json.dumps("\n".join(functions.values())))
    result = run_node([require_node(), "--eval", program], capture_output=True, text=True, encoding="utf-8", timeout=15)
    assert result.returncode == 0, result.stderr
