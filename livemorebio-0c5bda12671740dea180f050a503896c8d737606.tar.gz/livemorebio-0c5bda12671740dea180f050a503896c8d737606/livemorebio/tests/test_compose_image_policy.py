"""Compose's shared local image must be built once without Docker Hub lookup."""
from pathlib import Path
import re

from ._source_tree import require_source_tree, source_tree_only

ROOT = Path(__file__).resolve().parents[2]
pytestmark = source_tree_only("docker-compose.yml")


def test_image_only_services_never_pull_the_locally_built_image():
    require_source_tree("docker-compose.yml")
    text = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    services = {match.group(1): match.group(2) for match in re.finditer(
        r"(?ms)^  (life|aegle|cendos):\n(.*?)(?=^  [a-z][a-z0-9_-]*:|^volumes:|\Z)", text)}
    assert set(services) == {"life", "aegle", "cendos"}
    assert re.findall(r"(?m)^    build: (.+)$", text) == ["."]
    image = re.search(r"(?m)^    image: (.+)$", services["life"]).group(1)
    for service in ("aegle", "cendos"):
        assert not re.search(r"(?m)^    build:", services[service])
        assert re.search(r"(?m)^    image: (.+)$", services[service]).group(1) == image
        assert re.search(r"(?m)^    pull_policy: never$", services[service]), service
