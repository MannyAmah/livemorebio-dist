"""Run actual passive authorization UI; no browser, credentials or transport."""
import json
from pathlib import Path
import re
import subprocess

import pytest
from ._node import NODE, run_node as _run_node


CONSOLE = Path(__file__).resolve().parents[1] / "aegle/console"
AUTH = CONSOLE / "lib/auth.js"


def run(body: str, *, ready: str = "complete") -> None:
    program = r"""
const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const calls=[],nodes=[],events=new Map();let reloads=0;
const native=async(input,init)=>{calls.push({input,init});return {status:401,ok:false};};
function element(tag){return {tag,type:'',id:'',textContent:'',title:'',listeners:new Map(),
 addEventListener(name,fn){this.listeners.set(name,fn);}};}
const document={readyState:READY,body:{appendChild(el){nodes.push(el);}},
 createElement:element,getElementById(id){return nodes.find(el=>el.id===id)||null;},
 addEventListener(name,fn,options){events.set(name,{fn,options});}};
Object.defineProperty(document,'cookie',{get(){throw Error('cookie read');},set(){throw Error('cookie write');}});
const window={fetch:native,location:{reload(){reloads++;}}};
for(const name of ['localStorage','sessionStorage'])Object.defineProperty(window,name,{get(){throw Error('storage read');}});
const context={window,document,Request,AbortController,URL,DOMException,
 location:new URL('http://127.0.0.1:8850/patch'),
 setTimeout(){throw Error('timer created');},setInterval(){throw Error('poll created');},
 console:{log(){throw Error('log');},error(){throw Error('log');},warn(){throw Error('log');}}};
const source=fs.readFileSync(AUTH,'utf8');
vm.runInNewContext(source,context);
(async()=>{BODY})().catch(e=>{console.error(e);process.exitCode=1;});
""".replace("READY", json.dumps(ready)).replace("AUTH", json.dumps(str(AUTH))).replace("BODY", body)
    result = _run_node([NODE, "--eval", program], capture_output=True,
                            text=True, timeout=10, check=False, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_SEC_3_auth_is_passive_and_recovery_points_to_launcher():
    run("""
assert.equal(window.fetch,native);assert.equal(calls.length,0);assert.equal(reloads,0);
assert.equal(window.lmbEnsureLocalSession,undefined);assert.equal(nodes.length,1);
const button=nodes[0];assert.equal(button.type,'button');
assert.equal(button.textContent,'Reload console');
assert(button.title.includes('livemore open'));
assert.equal(button.id,'local-session-reopen');
""")


def test_explicit_button_reloads_same_document_without_request_or_replay():
    run("""
assert.equal(calls.length,0);assert.equal(reloads,0);
nodes[0].listeners.get('click')();
assert.equal(reloads,1);assert.equal(calls.length,0);
""")


def test_head_script_waits_for_dom_without_network_or_duplicate_controls():
    run("""
assert.equal(nodes.length,0);assert.equal(calls.length,0);
assert.equal(events.get('DOMContentLoaded').options.once,true);
events.get('DOMContentLoaded').fn();assert.equal(nodes.length,1);
document.readyState='complete';vm.runInNewContext(source,context);
assert.equal(nodes.length,1);assert.equal(calls.length,0);assert.equal(reloads,0);
""", ready="loading")


@pytest.mark.parametrize("signal", ["undefined", "null", "controller.signal"])
def test_request_body_signal_and_options_are_not_touched(signal):
    run("""
const controller=new AbortController();
const input=new Request('http://127.0.0.1:8850/api/technical',{method:'POST',body:'TECHNICAL_BODY',signal:controller.signal});
const options={signal:SIGNAL,credentials:'omit',headers:{'X-Technical':'preserved'}};
assert.equal(window.fetch,native);
const response=await window.fetch(input,options);controller.abort();
assert.equal(response.status,401);assert.equal(calls.length,1);
assert.equal(calls[0].input,input);assert.equal(calls[0].init,options);
assert.equal(input.bodyUsed,false);assert.equal(reloads,0);
""".replace("SIGNAL", signal))


def test_foreign_request_is_untouched_and_401_has_no_session_side_effect():
    run("""
assert.equal(window.fetch,native);
const url=new URL('https://public.invalid/technical'),options={credentials:'omit'};
const response=await window.fetch(url,options);
assert.equal(response.status,401);assert.equal(calls.length,1);
assert.equal(calls[0].input,url);assert.equal(calls[0].init,options);
assert.equal(reloads,0);assert.equal(window.fetch,native);
""")


def test_patch_recovery_is_one_reload_not_read_or_mutation():
    page = (CONSOLE / "patch.html").read_text(encoding="utf-8")
    match = re.search(r"async function retryAuthorization\(\)\{[\s\S]*?\n\}", page)
    assert match
    run("""
context.load=()=>{throw Error('hidden read or replay');};context.AUTH_PAUSED=true;
vm.runInNewContext(FUNCTION,context);await vm.runInNewContext('retryAuthorization()',context);
assert.equal(reloads,1);assert.equal(calls.length,0);assert.equal(context.AUTH_PAUSED,true);
""".replace("FUNCTION", json.dumps(match.group(0))))


@pytest.mark.parametrize("file,marker", [("workspace.js", "new EventSource(\"/api/workspace/stream\")"),
                                        ("protocol_biology.js", "run = await getJSON(")])
def test_explicit_consumers_no_longer_depend_on_bootstrap(file, marker):
    source = (CONSOLE / "lib" / file).read_text(encoding="utf-8")
    assert marker in source
    assert "lmbEnsureLocalSession" not in source
    assert "/api/session/bootstrap" not in source
