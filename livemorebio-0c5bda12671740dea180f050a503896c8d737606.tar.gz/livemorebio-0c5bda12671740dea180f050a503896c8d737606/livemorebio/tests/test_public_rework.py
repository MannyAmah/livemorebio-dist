"""Fail-closed publication boundaries and frozen historical-source regression."""
from __future__ import annotations
import io
import json
from pathlib import Path
import hashlib
import tarfile

import pytest

ROOT = Path(__file__).resolve().parents[2]


# Reviewed stable-6588707 SHA-256 values preserve historical research evidence.
# Constants let shallow CI and source archives verify bytes without Git tags.
FROZEN_SHA256 = {
    'livemorebio/tests/test_beard_conversion.py': 'f317d7da9641bc86af4211ad552dadc9770b28a36ebc02a0ca2f5464b9b93cb2',
    'livemorebio/tests/test_beard_mathml.py': '64aa905ed290b1870a033fa0ba183e139a436da620fedb2f52f072f5ef4f9ebc',
    'livemorebio/tests/test_beard_native_worker.py': '69c5851f5b6d34fdf353768c549472dc5e956cca3fb011a66c79cbc5df431333',
    'livemorebio/tests/test_beard_precision_analysis.py': 'ddb61731f478b950fec604bbc77c219fcd9d228c85eb1c140a4d333876421638',
    'livemorebio/tests/test_beard_precision_execution.py': 'bec693e7d0eee76a456b06255aa1655c1b58a047ddc1cbb0f87e216aea6a03b7',
    'livemorebio/tests/test_beard_precision_supervision.py': '45bc2c78a0cad9366ff53c6b2d80a918b9723191be77d13e10291a5d5dc08a9c',
    'livemorebio/tests/test_beard_source_analysis.py': '9930a7ec4be3ad463ba4f91d1c16f035ade28e83aff6e68a974b20a8b3dbee77',
    'livemorebio/tests/test_beard_source_contract.py': 'e20c3135becc92f611480f2619079c8b6da58474fe420617745547c6cb259d66',
    'livemorebio/tests/test_beard_source_execution.py': '73cc82ea047c2f6ced4ae319833d43bf7baf165729fedea99ade65f005006e4e',
    'livemorebio/tests/test_build_tracker.py': '0e0ce9ae9b945e8a6b7bfb22e3c032494b0484ae1755585249e508bfc471cafa',
    'livemorebio/tests/test_osp_dotnet_native_build_stage.py': 'e1415bc6787a6c7e7bbd6b2e780a03d4290dd98b0b53ef2947d16de76cda24b0',
    'livemorebio/tests/test_osp_dotnet_observation_bytes.py': '966d5f5e2fe157a49992a134ab61f750f49bcee4e9618cfb4992c2cd2ddf4a94',
    'livemorebio/tests/test_osp_dotnet_parent.py': 'e80657b5e09c69ccfcc0f2e60125c67aa12c24e018971216cabb6e99c8136ba0',
    'livemorebio/tests/test_osp_dotnet_parent_execution.py': '9d2e768306f7560170698c52f38e046c37461082d14c45dbe494b6f017fc9b99',
    'livemorebio/tests/test_osp_dotnet_toolchain.py': 'e8c024fb3ed95d0ec6ed15e2afa97b66dba1646e88dbada38efa9efa0f36df05',
    'livemorebio/tests/test_osp_inspector_budget.py': '7130d7fb301b671b6c95eee78f7014667bc10b463b74d42ab5f93cbe25061a8e',
    'livemorebio/tests/test_osp_r_initialization.py': '74de813a574c0a7144aa9385e6efe9735747fdea4dd7c168cc29a85dc196605b',
    'livemorebio/tests/test_osp_rejected_process_evidence.py': '6a7796e30da70c3aac33f8d9f7ca179162bd39bf77695fe1051e42af20829c2c',
    'livemorebio/tests/test_osp_semantic_probes.py': '5c4d29106391b97f429d1f66969e3262c8d35395678b11947d94d74a08951b09',
    'livemorebio/tests/test_osp_semantic_supervisor.py': 'f4527a2d6ff5a7f31f19fd220765acfc42ac35e04470891bba619ff37d1b1d0b',
    'livemorebio/tests/test_osp_source_admission.py': '80f373e9234e3c73dc0c9dce14aee420f3c4e135e4560bfbcc16bd0972ed157c',
    'livemorebio/tests/test_osp_stage_b.py': '2a41e8b1de67bdcef617ef6619f0c78943da3cefb9d183828a2238176575eb58',
    'livemorebio/tests/test_osp_stage_b_analysis.py': '1c1cb48e32c63b714fc7ad8b8653723543344763299f8089e9278496095f5332',
    'livemorebio/tests/test_osp_vmmap_format_contract.py': 'e00132655ef15c9ba4b7f3a4f5c5d5fb95abe525f15e7abce6be1329e2e91865',
    'tools/beard_conversion.py': '4bc7da58422a1a66cbcc22d057818a04252a97b969f8af16d588fed0d04dc3e6',
    'tools/beard_cvode_worker.c': '427139375707d6f4ddf9e94b552957199d0572989d044ded861a77003f122f06',
    'tools/beard_mathml.py': '35ef2274454626274e72b57ccfaedd172dd31add8ea6911f0b8e9183f934871c',
    'tools/beard_native_worker.py': 'e0e80716e3bfa4fb6bdf74499036c575501dfb3877c2085cab09842580c4d1c9',
    'tools/beard_precision_analysis.py': '4e0a85fcba44192c4a0c345bb59f740ee6ebceaa76a37a17f4bd23de998863a6',
    'tools/beard_precision_execution.py': '45e7442b9e9872a2a62a67c47c0f7b77d1ae170c5ea0e9bd986ab187d251853d',
    'tools/beard_precision_worker.c': '7624b4e43be9c7512fc3f4b8de8bcfe912219f64209abc7d74f63cdfd1a2fffc',
    'tools/beard_source_analysis.py': '67b1c7bcb479c1c668139530bb4c201a8503cbc9cb06dc2d843579673450c3f4',
    'tools/beard_source_contract.py': '9aff3da96e6c3797f2ab7b0098538593a9abee60e63039bdf2f8d583f71af036',
    'tools/beard_source_execution.py': '057b6a822a0f6002a2eb48e0b3c0ad84c5ab38bb2784a39d6aae6c52fe97d74b',
    'tools/beard_source_worker.c': 'b0be2b4d5bdbd8bf91e7df5a0f255422cfee46e1c451956d829055b1d05a3018',
    'tools/build_tracker.py': '6a1cdf56c6393caa57e606ef2741641d0d22d3218e0a1250aa468de682c1cfed',
    'tools/build_tracker/index.html': '6c4ac52d7cade1fe24dd74f6aeb0b7c5c34be0c37f7fa1750a759065c415ad11',
    'tools/build_tracker/progress.json': '3b8b9f01bd8665dfdd2884b2a312c0d10160126c0d7a24558f366238e6630a14',
    'tools/build_tracker/tracker.css': '398c47700d76b07efab6030ebbee83d4bb7a456d56df00f035d65fbb8fc757c4',
    'tools/build_tracker/tracker.js': '2f9c2c758b739f1836a596106e5058b76a395e4b78e957bc89b17d087cae5568',
    'tools/osp_dotnet_worker.py': '8b158726c891f36a6ac90f329d7ef22f5bc750d2b3ea14bc0ecdcab7ada0e0d5',
    'tools/osp_dotnet_worker/Directory.Build.props': 'a898e7887757dac65f120a3132097fbad1b1d785cf7c9c05c2aad6880f159cad',
    'tools/osp_dotnet_worker/Fixtures.json': '15ab95179ea2c2beb5dfbc9181bfddc0f7f109cd9fe5715d2a93f871ae408023',
    'tools/osp_dotnet_worker/NativeSimulation.cs': '23b17fe78f781d8f3bd54c9efd50386cb143cdd7ad4e52fe505fb323f1720364',
    'tools/osp_dotnet_worker/NuGet.Config': '673a6f41c924adb00f8bee519a0539cb2b33b9784d5569362d1e3e5b6fb941cb',
    'tools/osp_dotnet_worker/Worker.cs': '2f07a2e808dbad5c718b68f40785153a98a1b1b0c813904ef07b2d5977654ddc',
    'tools/osp_dotnet_worker/Worker.csproj': '9993975f483ca566f1f61f8d34185a15851c312d34f68f36844adb0a4099290a',
    'tools/osp_dotnet_worker/build_fake.py': 'fd2ddd259edeb6c479ce09be1aef40a9e15fe7b541cf234f45d5ec3d22dfcbe7',
    'tools/osp_dotnet_worker/global.json': '8fe9f4e7c811472092c6264a786c677dbe383a521b82a3982b257443defcc805',
    'tools/osp_dotnet_worker/prepare_toolchain.py': 'f0bc0acfa26f6d70d2311b8ffba47ea947ec36f9847f3350cd76d7f7db93649f',
    'tools/osp_dotnet_worker/tests/FakeTests.cs': 'bc99180830bf97d7083d45e29ce0702dce50c98d063691cbd0571fcae531969d',
    'tools/osp_dotnet_worker/tests/FakeTests.csproj': '44305da42e7bca05f65bc0ad16061ba97e7509ae6d89625c211cc15bad174023',
    'tools/osp_semantic_probes.R': 'e108ff061e0f15a030eac3a2f80e0279edc12783eca866e210518c1da8fdd7c7',
    'tools/osp_semantic_probes.py': '12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7',
    'tools/osp_semantic_supervisor.py': 'c3f5ec38a25be726a4d939c55f9a22b9fd41e45e9f21c7af43cb1b8a5ab67923',
    'tools/osp_source_admission.py': 'f6b5d2daf5d90c5b6949ae35f2089fd75a12b2b935e060b7ac96ce8ead321821',
    'tools/osp_stage_b.py': 'a1bb8ac68aa746066f6ecdf9b45e27f77384465c1a114bc250eea96f35e1e0cc',
    'tools/osp_stage_b_analysis.py': 'baa13b3c8dac922c4e87896af2bce9d9892072ddd5a62249a774a021ebafab15',
    'tools/osp_stage_b_native.R': '6a16df63980de72b06c39b21b200de10a7bd04f54405a06c7bf5512a64dc1f37',
}

def test_research_tools_and_pins_are_exact_stable_bytes():
    from livemorebio.tests.private_reference_helpers import require_private_reference_data
    missing = []
    for name, expected in FROZEN_SHA256.items():
        path = ROOT / name
        if path.exists():
            assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
        else:
            missing.append(path)
    require_private_reference_data(*missing, root=ROOT)


def test_public_projection_contains_no_policy_private_files():
    import os
    from .private_reference_helpers import assert_public_projection_has_no_private_files
    # L0-R2: installed layouts acquire this pinned asset after archive checks.
    assert_public_projection_has_no_private_files(
        ROOT, installed_cardiac=os.environ.get('LIVEMORE_TEST_CARDIAC') == '1')


def test_public_documentation_is_an_allowlist():
    from tools.public_distribution import is_private_only
    assert is_private_only('docs/HANDOFF.md')
    assert is_private_only('docs/new-internal-review.md')
    assert is_private_only('livemorebio/discovery/data/new-book-extract.json')
    assert is_private_only('tools/osp_stage_b.py')
    assert is_private_only('livemorebio/tests/test_beard_precision_execution.py')
    assert not is_private_only('docs/LAUNCH_GUIDE.md')


def test_public_filter_removes_empty_directories_and_writes_marker():
    from tools.build_release import _filter_tar
    prefix = 'test/'
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w') as handle:
        for name in ('test', 'test/trials', 'test/docs'):
            entry = tarfile.TarInfo(name); entry.type = tarfile.DIRTYPE
            handle.addfile(entry)
        entry = tarfile.TarInfo(prefix + 'README.md'); entry.size = 2
        handle.addfile(entry, io.BytesIO(b'ok'))
    output, _ = _filter_tar(raw.getvalue(), prefix)
    with tarfile.open(fileobj=io.BytesIO(output)) as handle:
        assert prefix + 'trials' not in handle.getnames()
        assert prefix + 'docs' not in handle.getnames()
        assert json.load(handle.extractfile(prefix + '.livemore-distribution.json'))['audience'] == 'public'


def test_private_reference_helper_fails_missing_private_file(tmp_path, monkeypatch):
    from livemorebio.tests import private_reference_helpers as helper
    monkeypatch.setattr(helper, 'REPOSITORY_ROOT', tmp_path)
    path = tmp_path / 'docs' / 'solutions' / 'absent.md'
    assert not helper.is_public_projection(tmp_path)
    assert not helper.private_reference_is_omitted(path, root=tmp_path)
    try:
        with pytest.raises(AssertionError, match='PRIVATE_REFERENCE_MISSING'):
            helper.require_private_reference_data(path)
    except pytest.skip.Exception:
        pytest.fail('a missing private file must fail outside a public projection')


def test_private_reference_helper_skips_only_explicit_public_projection(tmp_path, monkeypatch):
    from livemorebio.tests import private_reference_helpers as helper
    monkeypatch.setattr(helper, 'REPOSITORY_ROOT', tmp_path)
    (tmp_path / '.livemore-distribution.json').write_text(json.dumps({'schema':'livemore.distribution.v1','audience':'public'}), encoding="utf-8")
    with pytest.raises(pytest.skip.Exception, match='REFERENCE_DATA_NOT_DISTRIBUTED'):
        helper.require_private_reference_data(tmp_path / 'docs' / 'solutions' / 'absent.md')
    try:
        with pytest.raises(AssertionError, match='not a private reference'):
            helper.require_private_reference_data(tmp_path / 'README.md')
    except pytest.skip.Exception:
        pytest.fail('a missing carried file must fail, not skip')


@pytest.mark.parametrize('check', ['reference', 'pin'])
def test_missing_carried_file_guards_fail_instead_of_skipping_under_policy_mutant(tmp_path, monkeypatch, check):
    from . import private_reference_helpers as helper
    from .test_frozen_tool_hashes import test_public_pin_boundary_rejects_a_lost_carried_file
    monkeypatch.setattr(helper, 'is_private_only', lambda relative: True)
    try:
        with pytest.raises(pytest.fail.Exception, match='a missing carried file must fail'):
            if check == 'reference':
                test_private_reference_helper_skips_only_explicit_public_projection(tmp_path, monkeypatch)
            else:
                test_public_pin_boundary_rejects_a_lost_carried_file(tmp_path)
    except pytest.skip.Exception:
        pytest.fail('the negative control escaped as a skip')


def test_optional_private_assets_do_not_fork_product_source_identity(tmp_path):
    from livemorebio.build_info import source_fingerprint
    package = tmp_path / 'livemorebio'; package.mkdir()
    (package / '__init__.py').write_text('', encoding="utf-8")
    before = source_fingerprint(package)
    data = package / 'discovery' / 'data'; data.mkdir(parents=True)
    (data / 'optional.json').write_text('{"private":true}', encoding="utf-8")
    assert source_fingerprint(package) == before


def test_a_marker_with_extra_keys_is_not_a_publisher_projection(tmp_path):
    from .private_reference_helpers import is_public_projection
    (tmp_path / '.livemore-distribution.json').write_text(json.dumps({
        'schema': 'livemore.distribution.v1', 'audience': 'public', 'note': 'unexpected'}), encoding="utf-8")
    assert not is_public_projection(tmp_path)


@pytest.mark.parametrize('relative', [
    'tools/beard_source_execution.py', 'tools/osp_dotnet_worker/Worker.cs',
    'docs/solutions/synthetic-record.md', 'docs/HANDOFF.md',
    'trials/synthetic.json', 'livemorebio/discovery/data/synthetic.json',
])
def test_public_boundary_rejects_every_kind_of_retained_private_file(tmp_path, relative):
    from .private_reference_helpers import assert_public_projection_has_no_private_files
    (tmp_path / '.livemore-distribution.json').write_text(json.dumps({
        'schema': 'livemore.distribution.v1', 'audience': 'public'}), encoding="utf-8")
    path = tmp_path / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('technical fixture', encoding="utf-8")
    with pytest.raises(AssertionError, match='PUBLIC_PRIVATE_FILE_RETAINED'):
        assert_public_projection_has_no_private_files(tmp_path)


@pytest.mark.parametrize('schema_root', [
    '.venv/lib/python3.11/site-packages/jupyterlab/schemas/@jupyterlab',
    '.venv/share/jupyter/lab/schemas/@jupyterlab',
])
@pytest.mark.parametrize('private_shape', ['file', 'file-symlink', 'directory-symlink'])
def test_installed_jupyter_schemas_are_not_private_notebook_runtime(tmp_path, schema_root, private_shape):
    from .private_reference_helpers import assert_public_projection_has_no_private_files

    (tmp_path / '.livemore-distribution.json').write_text(json.dumps({
        'schema': 'livemore.distribution.v1', 'audience': 'public'}), encoding='utf-8')
    schema = tmp_path / schema_root / 'notebook-extension' / 'tracker.json'
    schema.parent.mkdir(parents=True)
    schema.write_text('{}', encoding='utf-8')
    assert_public_projection_has_no_private_files(tmp_path)

    # Installed dependencies do not exempt real credentials, including links.
    runtime = tmp_path / schema_root / ('notebook-' + 'a' * 32)
    if private_shape == 'directory-symlink':
        runtime.symlink_to(schema.parent, target_is_directory=True)
    else:
        runtime.mkdir()
        token = runtime / 'token'
        if private_shape == 'file-symlink':
            token.symlink_to(schema)
        else:
            token.write_text('technical credential fixture', encoding='utf-8')
    with pytest.raises(AssertionError, match='PUBLIC_PRIVATE_FILE_RETAINED'):
        assert_public_projection_has_no_private_files(tmp_path)


@pytest.mark.parametrize('relative', [
    'notebook-' + 'a' * 32,
    'notebook-' + 'a' * 32 + '/token',
    'technical-stack/notebook-' + 'a' * 32 + '/codes/code.json',
    'TECHNICAL-STACK/NOTEBOOK-' + 'A' * 32 + '/TOKEN',
])
def test_notebook_runtime_policy_includes_directories_and_nested_credentials(relative):
    from tools.public_distribution import is_private_only

    assert is_private_only(relative)


def test_frozen_audit_hashes_present_files_before_omission_can_skip(tmp_path, monkeypatch):
    (tmp_path / '.livemore-distribution.json').write_text(json.dumps({
        'schema': 'livemore.distribution.v1', 'audience': 'public'}), encoding="utf-8")
    relative = list(FROZEN_SHA256)[-1]
    path = tmp_path / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('altered technical fixture', encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=['ROOT']), 'ROOT', tmp_path)
    from . import private_reference_helpers
    monkeypatch.setattr(private_reference_helpers, 'REPOSITORY_ROOT', tmp_path)
    try:
        with pytest.raises(AssertionError, match=relative):
            test_research_tools_and_pins_are_exact_stable_bytes()
    except pytest.skip.Exception:
        pytest.fail('the frozen audit skipped before hashing a retained file')


def test_landing_document_cannot_skip_when_a_private_checkout_loses_it(tmp_path, monkeypatch):
    from . import test_public_distribution as distribution
    from . import _source_tree, private_reference_helpers
    (tmp_path / '.git').mkdir()
    monkeypatch.setattr(_source_tree, 'REPOSITORY_ROOT', tmp_path)
    monkeypatch.delenv(_source_tree.TREE_ENV, raising=False)
    monkeypatch.setattr(distribution, 'REPOSITORY_ROOT', tmp_path)
    monkeypatch.setattr(private_reference_helpers, 'REPOSITORY_ROOT', tmp_path)
    try:
        with pytest.raises(AssertionError, match='PRIVATE_REFERENCE_MISSING'):
            distribution.test_distribution_landing_document_uses_final_client_language()
    except pytest.skip.Exception:
        pytest.fail('a lost private landing document must fail, never skip')


def test_landing_document_omitted_by_image_uses_source_tree_rule(tmp_path, monkeypatch):
    from . import _source_tree, private_reference_helpers, test_public_distribution as distribution
    monkeypatch.setattr(_source_tree, 'REPOSITORY_ROOT', tmp_path)
    monkeypatch.setattr(distribution, 'REPOSITORY_ROOT', tmp_path)
    monkeypatch.setattr(private_reference_helpers, 'REPOSITORY_ROOT', tmp_path)
    monkeypatch.setenv(_source_tree.TREE_ENV, _source_tree.CONTAINER_IMAGE)
    with pytest.raises(pytest.skip.Exception, match='SOURCE_TREE_ONLY'):
        distribution.test_distribution_landing_document_uses_final_client_language()


def test_session_keeps_anatomy_and_reference_caches_inside_its_data_directory():
    import os
    for name in ('LIVEMORE_ANATOMY_DIR', 'LIVEMORE_CACHE'):
        assert name in os.environ, name
        assert Path(os.environ[name]).is_relative_to(Path(os.environ['LIVEMORE_DATA_DIR'])), name


def test_wheel_verification_builds_only_in_a_private_source_copy(tmp_path, monkeypatch):
    from . import test_wheel_runtime_data as wheel_test
    class BuildCommandSeen(Exception):
        pass
    def inspect_build(command, **kwargs):
        source = Path(command[command.index('wheel') + 1])
        assert source.is_relative_to(tmp_path) and source != ROOT
        assert (source / 'pyproject.toml').read_bytes() == (ROOT / 'pyproject.toml').read_bytes()
        assert '--no-index' in command
        raise BuildCommandSeen
    monkeypatch.setattr(wheel_test.subprocess, 'run', inspect_build)
    with pytest.raises(BuildCommandSeen):
        wheel_test.test_installed_wheel_can_load_whole_human_manifest(tmp_path)


@pytest.fixture
def technical_public_installed_layout(tmp_path, monkeypatch):
    """Technical bytes and test-only pins, never a physiological model or a person."""
    from dataclasses import replace
    from livemorebio import model_assets

    root = tmp_path / 'technical-installed-public'
    root.mkdir()
    (root / '.livemore-distribution.json').write_text(json.dumps({
        'schema': 'livemore.distribution.v1', 'audience': 'public'}), encoding='utf-8')
    monkeypatch.setattr(model_assets, '__file__', str(root / 'livemorebio' / 'model_assets.py'))
    payload = b'technical installed cardiac fixture; no biological or person value'
    technical_asset = replace(model_assets._CARDIAC_ASSET,
                              sha256=hashlib.sha256(payload).hexdigest(), size_bytes=len(payload))
    monkeypatch.setattr(model_assets, '_CARDIAC_ASSET', technical_asset)
    path = root / 'models' / 'cardiac' / technical_asset.filename
    path.parent.mkdir(parents=True)
    path.write_bytes(payload)
    return root, path, model_assets


def test_installed_public_layout_requires_explicit_verified_cardiac(technical_public_installed_layout):
    from .private_reference_helpers import assert_public_projection_has_no_private_files

    root, _, _ = technical_public_installed_layout
    with pytest.raises(AssertionError, match='PUBLIC_PRIVATE_FILE_RETAINED'):
        assert_public_projection_has_no_private_files(root)
    assert_public_projection_has_no_private_files(root, installed_cardiac=True)


def test_installed_public_layout_still_rejects_every_other_private_file(technical_public_installed_layout):
    from .private_reference_helpers import assert_public_projection_has_no_private_files

    root, _, _ = technical_public_installed_layout
    relative = next(name for name in FROZEN_SHA256 if name.startswith('tools/'))
    private = root / relative
    private.parent.mkdir(parents=True, exist_ok=True)
    private.write_text('technical private-file negative control', encoding='utf-8')
    with pytest.raises(AssertionError, match='PUBLIC_PRIVATE_FILE_RETAINED') as failure:
        assert_public_projection_has_no_private_files(root, installed_cardiac=True)
    assert relative in str(failure.value)


@pytest.mark.parametrize('damage', ['mismatch', 'symlink', 'hardlink', 'writable'])
def test_installed_public_layout_refuses_unverified_cardiac(technical_public_installed_layout, damage):
    from .private_reference_helpers import assert_public_projection_has_no_private_files

    root, path, model_assets = technical_public_installed_layout
    if damage == 'mismatch':
        path.write_bytes(b'technical mismatched installed-model negative control')
    elif damage == 'symlink':
        target = root / 'technical-linked-model'
        path.rename(target)
        path.symlink_to(target)
    elif damage == 'hardlink':
        (root / 'technical-hardlink').hardlink_to(path)
    else:
        path.chmod(0o666)
    code = 'CARDIAC_MODEL_HASH_MISMATCH' if damage == 'mismatch' else 'CARDIAC_MODEL_UNSAFE_PATH'
    with pytest.raises(model_assets.ModelAssetError) as failure:
        assert_public_projection_has_no_private_files(root, installed_cardiac=True)
    assert failure.value.code == code


def test_installed_public_layout_refuses_redirected_package_before_asset_read(technical_public_installed_layout, monkeypatch):
    from .private_reference_helpers import assert_public_projection_has_no_private_files

    root, _, model_assets = technical_public_installed_layout
    monkeypatch.setattr(model_assets, '__file__', str(root.parent / 'technical-other-package' / 'livemorebio' / 'model_assets.py'))
    monkeypatch.setattr(model_assets, 'verified_cardiac_path', lambda: pytest.fail('must not read a redirected package asset'))
    with pytest.raises(AssertionError, match='PUBLIC_INSTALLED_MODEL_ROOT_MISMATCH'):
        assert_public_projection_has_no_private_files(root, installed_cardiac=True)


@pytest.mark.parametrize('opt_in', [None, '0', 'unexpected', '1'])
def test_public_layout_audit_enables_only_explicit_installed_asset_mode(technical_public_installed_layout, monkeypatch, opt_in):
    from . import private_reference_helpers
    from . import test_public_rework

    root, _, _ = technical_public_installed_layout
    monkeypatch.setattr(test_public_rework, 'ROOT', root)
    if opt_in is None:
        monkeypatch.delenv('LIVEMORE_TEST_CARDIAC', raising=False)
    else:
        monkeypatch.setenv('LIVEMORE_TEST_CARDIAC', opt_in)
    captured = []
    monkeypatch.setattr(private_reference_helpers, 'assert_public_projection_has_no_private_files',
                        lambda actual, *, installed_cardiac=False: captured.append((actual, installed_cardiac)))
    test_public_rework.test_public_projection_contains_no_policy_private_files()
    assert captured == [(root, opt_in == '1')]
