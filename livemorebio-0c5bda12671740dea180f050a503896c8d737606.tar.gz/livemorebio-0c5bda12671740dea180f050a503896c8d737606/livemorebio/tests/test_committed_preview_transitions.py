"""Explicit preview swaps, authored ASGI doubles only; no extractor or model."""
from copy import deepcopy
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_committed_source_transitions import transition  # noqa: F401


@pytest.fixture
def preview(transition, monkeypatch):
    from livemorebio.aegle.execution_api import _creation_lock
    from livemorebio.aegle.subjects import SubjectRegistryError
    from livemorebio.life_system import extract, population, synthetic_human

    t = transition
    t.scenario["action"] = "preview"
    technical_human = object()

    def unlocked():
        assert not t.authority._lock._is_owned()
        assert not t.manager._lock._is_owned() and not _creation_lock._is_owned()

    class Registry:
        def prepare_preview_clear(self, *, request_id):
            assert t.authority._lock._is_owned()
            assert not t.manager._lock._is_owned() and not _creation_lock._is_owned()
            UUID(request_id)
            t.assert_original_source()
            t.calls.append(("prepare", "clear_for_preview"))
            return SimpleNamespace(kind="clear_for_preview", record=None,
                target_before=None, active_before=deepcopy(t.old_state["subject"]),
                active_after=None, selected=False, request_id=request_id)

        def commit_prepared_transition(self, prepared):
            assert t.authority._lock._is_owned()
            assert t.manager._lock._is_owned() and _creation_lock._is_owned()
            assert t.authority.generation == t.original_generation
            assert prepared.kind == "clear_for_preview"
            t.assert_original_source()
            t.calls.append(("commit", "clear_for_preview"))
            if t.scenario["outcome"] != "rollback":
                t.mark_committed()
            if t.scenario["outcome"] in {"rollback", "uncertain"}:
                code = ("SELECTION_COMMIT_UNCONFIRMED" if t.scenario["outcome"] == "uncertain"
                        else "TWIN_VERSION_CONFLICT")
                raise SubjectRegistryError(code, "Authored clear outcome")
            return ("COMMITTED_CLEANUP_UNCONFIRMED" if t.scenario["outcome"] == "close_failure"
                    else "COMMITTED")

    registry = Registry()

    def get_registry():
        unlocked()
        return registry

    def candidate(*args, **kwargs):
        unlocked()
        assert ("prepare", "clear_for_preview") in t.calls
        t.calls.append(("construct_preview", None))
        if t.scenario["outcome"] == "changed_generation":
            with t.authority.commit_guard():
                t.authority.install_generation("technical-later-preview-generation")
        return t.candidate

    def human(*args, **kwargs):
        unlocked()
        assert ("prepare", "clear_for_preview") in t.calls
        t.calls.append(("authored_human", None))
        return technical_human

    class Extractor:
        def __init__(self):
            unlocked()

        def to_synthetic_human(self, note, *, hid):
            assert note == "AUTHORED TECHNICAL PREVIEW; NOT A CLINICAL NOTE"
            return human(), {"data_class": "AUTHORED_TEST_ONLY"}

    monkeypatch.setattr(t.server, "_subject_registry", get_registry)
    monkeypatch.setattr(t.server, "AegleTwin", candidate)
    monkeypatch.setattr(extract, "ClinicalExtractor", Extractor)
    monkeypatch.setattr(population, "LifeSystem", lambda: SimpleNamespace(generate=lambda *a, **k: [human()]))
    monkeypatch.setattr(synthetic_human, "SyntheticHuman", human)
    return t


def request_preview(t, kind):
    if kind == "note":
        return t.client.post("/api/ingest_note", json={
            "text": "AUTHORED TECHNICAL PREVIEW; NOT A CLINICAL NOTE"})
    return t.client.post("/api/stimulate", json={"kind": kind,
        "params": {"base": "healthy"} if kind == "base" else {"mode": "carrier"}})


# L0-R15: the note route refuses before the preview protocol, so these use the technical routes;
# test_l0_clinical_note_gate.py holds the note route's refusal.
@pytest.mark.parametrize("kind", ["base", "life_system"])
@pytest.mark.parametrize("outcome", ["COMMITTED", "rollback", "uncertain", "close_failure"])
def test_explicit_preview_replaces_subject_only_after_confirmed_clear(preview, kind, outcome):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.model_contexts import model_availability

    t = preview
    t.scenario["outcome"] = outcome
    result = request_preview(t, kind)
    if outcome == "rollback":
        assert result.status_code == 409
        t.assert_original_source()
        assert t.authority.generation == t.original_generation == t.manager.permitted
        assert not any(name in {"invalidate", "publish"} for name, _ in t.calls)
        return
    if outcome == "uncertain":
        assert result.status_code == 503
        assert result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        assert t.authority.permitted_generation is DENY_ALL and t.manager.permitted is DENY_ALL
        assert not any(name == "publish" for name, _ in t.calls)
    else:
        assert result.status_code == (200 if outcome == "COMMITTED" else 503)
        if outcome == "close_failure":
            assert result.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        assert t.authority.generation != t.original_generation
        assert t.manager.permitted == t.authority.generation
        assert t.server._state["tw"] is t.candidate
        assert t.server._state["subject"] is None
        assert t.server._state["initialized"] is True
        assert t.server._state["model_availability"] == model_availability(
            None, source_generation=t.authority.generation)
        assert t.server._state["observation_state"] is not t.old_observations
        assert t.server._state["observation_state"].observations == {}
        assert t.server._workspace_actions == [] and t.server._workspace_actions is not t.old_actions
    assert [value for name, value in t.calls if name == "invalidate"] == [t.original_generation]
    assert [value for name, value in t.calls if name == "commit"] == ["clear_for_preview"]
    assert t.calls.index(("prepare", "clear_for_preview")) < t.calls.index(("construct_preview", None))
    assert t.calls.index(("construct_preview", None)) < t.calls.index(("state", "new-model"))
    assert t.calls.index(("state", "new-model")) < t.calls.index(("commit", "clear_for_preview"))


@pytest.mark.parametrize("kind", ["base", "life_system"])
def test_superseded_preview_does_not_clear_selected_subject(preview, kind):
    t = preview
    t.scenario["outcome"] = "changed_generation"
    response = request_preview(t, kind)
    assert response.status_code == 409 and response.json()["code"] == "MODEL_SOURCE_CHANGED"
    t.assert_original_source()
    assert t.authority.generation == t.manager.permitted == "technical-later-preview-generation"
    assert not any(name in {"commit", "invalidate", "publish"} for name, _ in t.calls)
