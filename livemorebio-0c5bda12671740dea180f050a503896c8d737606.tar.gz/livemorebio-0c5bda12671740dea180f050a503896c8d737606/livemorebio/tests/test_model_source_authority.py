"""Model source capture and observation attachment have different lifecycles."""
from concurrent.futures import ThreadPoolExecutor
import threading

import pytest
from ._timing import wait_seconds


def test_capture_is_detached_and_observations_preserve_generation():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    authority = ModelSourceAuthority()
    source = {"parameters": [90, 9], "observation": None}
    initial = authority.generation
    captured = authority.capture(lambda: source, expected_generation=initial)
    authority.observe(lambda: source.update(observation=100))
    assert authority.generation == initial
    source["parameters"][0] = 110
    assert captured["parameters"] == [90, 9]
    assert captured["observation"] is None


def test_change_fences_before_mutation_and_stale_capture_rejects():
    from livemorebio.aegle.model_source import ModelSourceAuthority, SourceGenerationConflict

    seen = []
    authority = ModelSourceAuthority(lambda generation, reason: seen.append((generation, reason)))
    initial = authority.generation
    with authority.mutation("subject_changed"):
        assert seen == [(initial, "subject_changed")]
        assert authority.generation != initial
    with pytest.raises(SourceGenerationConflict):
        authority.capture(lambda: pytest.fail("stale source was read"), expected_generation=initial)


def test_failed_fence_never_allows_mutation():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    def fail(*args):
        raise RuntimeError("technical fence failure")
    authority = ModelSourceAuthority(fail)
    initial = authority.generation
    with pytest.raises(RuntimeError):
        with authority.mutation("model_changed"):
            pytest.fail("mutation ran after failed fence")
    assert authority.generation == initial


def test_failed_mutation_does_not_reuse_the_invalidated_generation():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    authority = ModelSourceAuthority()
    initial = authority.generation
    with pytest.raises(ValueError):
        with authority.mutation("model_changed"):
            raise ValueError("technical partial failure")
    assert authority.generation != initial


def test_capture_cannot_observe_a_half_changed_source():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    authority = ModelSourceAuthority()
    source = {"subject": "first", "parameters": 1}
    halfway, finish, reading = threading.Event(), threading.Event(), threading.Event()
    def change():
        with authority.mutation("subject_changed"):
            source["subject"] = "second"
            halfway.set()
            assert finish.wait(3)
            source["parameters"] = 2
    def read():
        reading.set()
        return authority.capture(lambda: source)
    with ThreadPoolExecutor(2) as workers:
        changing = workers.submit(change)
        assert halfway.wait(3)
        captured = workers.submit(read)
        assert reading.wait(3)
        assert not captured.done()
        finish.set()
        changing.result(timeout=wait_seconds(3))
        assert captured.result(timeout=wait_seconds(3)) == {"subject": "second", "parameters": 2}


def test_server_template_switch_fences_the_actual_runtime(monkeypatch, tmp_path):
    from dataclasses import asdict
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, T2D

    seen = []
    authority = ModelSourceAuthority()
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_invalidate_model_source", lambda old, reason: seen.append((old, reason)))
    monkeypatch.setattr(server, "_execution_manager_instance", None)
    monkeypatch.setattr(server, "_workspace_actions", [])
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "model-authority-technical-test-token")
    class Twin:
        def __init__(self, base):
            self.base = base
        def state(self):
            return {"base": self.base, "profile_params": asdict(T2D if self.base == "t2d" else HEALTHY)}
    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"t" * 32)
    monkeypatch.setattr(server, "AegleTwin", Twin)
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    monkeypatch.setattr(server, "_snapshot_twin", lambda *a: None)
    original = Twin("healthy")
    monkeypatch.setattr(server, "_state", {"tw": original, "subject": None, "initialized": True,
                                          "observation_state": ObservationState()})
    old = authority.generation
    response = TestClient(server.app).post("/api/stimulate", json={"kind": "base", "params": {"base": "t2d"}},
        headers={"Authorization": "Bearer model-authority-technical-test-token"})
    assert response.status_code == 200, response.text
    assert seen == [(old, "subject_changed")]
    assert authority.generation != old
    assert server._state["tw"].base == "t2d"
    assert server._state["tw"] is not original and original.base == "healthy"
    assert response.json()["profile_params"] == asdict(T2D)
    assert response.json()["model_availability"]["source_generation"] == authority.generation
    assert registry.active_twin() is None


@pytest.fixture
def activation_context(monkeypatch):
    from fastapi.testclient import TestClient
    from types import SimpleNamespace
    from livemorebio.aegle import server
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "model-authority-technical-test-token")
    authority = ModelSourceAuthority()
    initial = {"tw": None, "subject": None, "initialized": True,
               "observation_state": ObservationState()}
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", None)
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", [])
    monkeypatch.setattr(server, "_snapshot_twin", lambda *a: pytest.fail("Rejected selection published"))
    client = TestClient(server.app, headers={"Authorization": "Bearer model-authority-technical-test-token"})
    yield SimpleNamespace(server=server, authority=authority, initial=initial,
                          generation=authority.generation, client=client, calls=[])
    client.close()


def test_server_activation_build_failure_does_not_activate_registry(monkeypatch, activation_context):
    from types import SimpleNamespace
    from uuid import UUID

    t = activation_context
    after = {"twin_id": "technical", "subject_id": "authored-not-a-participant",
        "source_class": "SYNTHETIC", "display_label": "Authored construction failure",
        "lifecycle": "ACTIVE", "version": 2}

    class Registry:
        def prepare_activation(self, identifier, *, expected_version, request_id):
            assert identifier == "technical" and type(expected_version) is int and expected_version == 1
            UUID(request_id)
            t.calls.append("prepare")
            return SimpleNamespace(record=dict(after), active_before=None)

        def build_twin(self, record):
            assert record == after
            t.calls.append("build")
            raise ValueError("technical model load failure")

        def commit_prepared_transition(self, *a, **k):
            pytest.fail("registry changed before model could load")

    monkeypatch.setattr(t.server, "_subject_registry", Registry)
    response = t.client.post("/api/twins/technical/activate", json={"expected_version": 1})
    assert response.status_code == 503
    assert response.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert "technical model load failure" not in response.text
    assert t.calls == ["prepare", "build"]
    assert t.server._state is t.initial and t.authority.generation == t.generation


def test_activation_cannot_build_a_version_other_than_the_requested_snapshot(monkeypatch, activation_context):
    from uuid import UUID
    from livemorebio.aegle.subjects import SubjectRegistryError

    t = activation_context

    class Registry:
        def prepare_activation(self, identifier, *, expected_version, request_id):
            assert identifier == "technical" and type(expected_version) is int and expected_version == 2
            UUID(request_id)
            t.calls.append("prepare")
            raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored stored version is 1")

        def build_twin(self, *_):
            pytest.fail("activation built a source version different from expected_version")

        def commit_prepared_transition(self, *a, **k):
            pytest.fail("activation admitted a different snapshot")

    monkeypatch.setattr(t.server, "_subject_registry", Registry)
    response = t.client.post("/api/twins/technical/activate", json={"expected_version": 2})
    assert response.status_code == 409
    assert response.json()["code"] == "TWIN_VERSION_CONFLICT"
    assert t.calls == ["prepare"]
    assert t.server._state is t.initial and t.authority.generation == t.generation
