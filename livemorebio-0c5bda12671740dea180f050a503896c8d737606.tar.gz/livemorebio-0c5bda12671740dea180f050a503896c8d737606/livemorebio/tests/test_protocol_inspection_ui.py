"""Exercise actual run-inspector handlers without requiring optional WebGL."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess

from .biology_ui_fixtures import biology_controller_script
from ._node import require_node, run_node as _run_node

CONSOLE = Path(__file__).parents[1] / "aegle/console"


def test_pxr_structure_stage_control_uses_the_frozen_inspector_owner():
    node = require_node()
    projections = (CONSOLE / "lib/biological_projection.js").read_text(encoding="utf-8").replace("export function", "function")
    controller = re.sub(r"^import .*?;\n", "", (CONSOLE / "lib/protocol_biology.js").read_text(encoding="utf-8"), flags=re.M)
    program = r'''
const assert=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map(),opens=[],requests=[];
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',value:'',hidden:false,handlers:{},dataset:{},setAttribute(){},addEventListener(k,fn){this.handlers[k]=fn},scrollIntoView(){this.scrolled=true},querySelector:el,querySelectorAll:all});return nodes.get(id)}
function all(){return ['response','structure','downstream'].map(id=>{const n=el('stage-'+id);n.dataset.processStage=id;return n})}
const run={run_id:'protocol-'+'b'.repeat(32),protocol_id:'cendos.garcinoic-acid-pxr.v1',
 evidence_state:'STRUCTURE_AND_IN_VITRO_BACKED_MODEL',qualification_state:'NOT_QUALIFIED',
 cohort:{cohort_id:'technical-pxr',name:'Technical PXR'},compound:{form:'technical garcinoic acid'},
 structure:{pdb_id:'6P2B'},binding:{target:'NR1I2',kd_um:1,ec50_um:1},
 target_engagement:[{concentration_um:1,members:[{member_id:'technical-member',occupancy:.5,expression_factor:1,relative_pxr_activation:.5}]}]};
let selection;
const context={URLSearchParams,location:{search:'?run_id='+run.run_id},document:{querySelector:el},
 mountMemberPicker(){},mountRunAnatomy:(_host,view)=>{selection=view;return{setInspection:view=>{selection=view},openFrozenStructure(){opens.push(structuredClone(selection))},dispose(){}}},
 esc:x=>String(x??''),fmt:x=>String(x??'unavailable'),getJSON:async url=>{requests.push(url);return run},clearInterval(){},console};
(async()=>{
vm.runInNewContext(PROJECTIONS+'\n'+CONTROLLER,context);for(let i=0;i<8;i++)await new Promise(setImmediate);
assert(el('#protocol-workspace').innerHTML.includes('id="protocol-open-structure"'),'PXR structure control is absent');
assert.equal(el('#protocol-open-structure').hidden,true);
el('stage-structure').handlers.click();assert.equal(el('#protocol-open-structure').hidden,false);
assert(el('#protocol-open-structure').textContent.includes('6P2B'));
el('#protocol-open-structure').handlers.click();assert.equal(opens.length,1);
assert.equal(el('#run-anatomy').scrolled,true);
assert.equal(opens[0].stage.id,'structure');assert.equal(opens[0].provenance.structure.pdb_id,'6P2B');
assert.equal(opens[0].binding.member_id,'technical-member');
el('stage-downstream').handlers.click();assert.equal(el('#protocol-open-structure').hidden,true);
assert.deepEqual(requests,['/api/cendos/protocols/'+run.run_id]);
})().catch(e=>{console.error(e);process.exit(1)});
'''.replace("PROJECTIONS", json.dumps(projections)).replace("CONTROLLER", json.dumps(controller))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_stage_quantity_and_time_handlers_share_the_selected_frozen_context():
    node = require_node()
    projections = (CONSOLE / "lib/biological_projection.js").read_text(encoding="utf-8").replace("export function", "function")
    controller = re.sub(r"^import .*?;\n", "", (CONSOLE / "lib/protocol_biology.js").read_text(encoding="utf-8"), flags=re.M)
    member_picker = (CONSOLE / "lib/member_picker.js").read_text(encoding="utf-8").replace("export function", "function")
    controller = "const {mountMemberPicker}=(()=>{" + member_picker + ";return {mountMemberPicker};})();\n" + controller
    program = r'''
const vm=require('node:vm'),nodes=new Map();let requests=[];
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',value:'',hidden:false,disabled:false,handlers:{},dataset:{},attrs:{},setAttribute(k,v){this.attrs[k]=v},addEventListener(k,fn){this.handlers[k]=fn},classList:{toggle(){}},querySelector:el,querySelectorAll:all});return nodes.get(id)}
function all(){return ['response','exposure','cellular','tissue'].map(id=>{const n=el('stage-'+id);n.dataset.processStage=id;return n})}
const trajectory={t_min:[0,2.5,9],units:{t_min:'min',glucose:'mg/dL',insulin:'uU/mL',insulin_action:'1/min'},baseline:{glucose:[90,120,95],insulin:[8,20,10],insulin_action:[0,.003,.001]},treated:{glucose:[90,130,95],insulin:[8,21,10],insulin_action:[0,.002,.001]}};
const member={member_id:'member-a',source_lineage:{id:'source-a'},trajectory,baseline:{mean:100},treated:{mean:105},individualization:{},delta_mean:5};
const run={run_id:'protocol-'+'a'.repeat(32),protocol_id:'cendos.metformin-cohort-comparison.v1',evidence_state:'MODELED_MECHANISTIC',qualification_state:'NOT_QUALIFIED',intervention:{dose_mg:500,ogtt_grams:75},cohorts:[{cohort_id:'cohort-a',name:'Technical reference',reference_source:{id:'cohort-source'},members:[member,{...member,member_id:'member-b',source_lineage:{id:'source-b'}}]}]};
const anatomySelections=[];
const context={URLSearchParams,location:{search:'?run_id='+run.run_id},document:{hidden:false,querySelector:el,querySelectorAll:all},window:{addEventListener(){}},mountRunAnatomy:(_host,view)=>{anatomySelections.push(view);return{setInspection:view=>anatomySelections.push(view),dispose(){}}},esc:x=>String(x??''),fmt:(x,n=3)=>typeof x==='number'?String(Number(x.toFixed(n))):'unavailable',getJSON:async url=>{requests.push(url);return run},setInterval:()=>1,clearInterval(){},console};
(async()=>{
vm.runInNewContext(PROJECTIONS+'\n'+CONTROLLER,context);for(let i=0;i<8;i++)await new Promise(setImmediate);
if(!el('#protocol-workspace').innerHTML.includes('protocol-stage-title'))throw Error('missing visible process inspector');
el('#protocol-quantity').handlers.change({target:{value:'insulin_action'}});
el('#protocol-time-slider').handlers.input({target:{value:'1'}});
let source=JSON.parse(el('#protocol-source').textContent);
if(source.selection.quantity.id!=='insulin_action'||source.selection.quantity.treated!==.002||source.selection.axis.value!==2.5)throw Error('quantity/time did not bind source and values');
if(!el('#protocol-selected-quantity').innerHTML.includes('0.002'))throw Error('selected insulin action not visible');
el('stage-cellular').handlers.click();source=JSON.parse(el('#protocol-source').textContent);
if(source.selection.stage.status!=='UNAVAILABLE'||source.selection.quantity!==null)throw Error('unsupported cellular stage borrowed values');
if(!el('#protocol-plot').hidden||!el('#protocol-stage-status').textContent.includes('UNAVAILABLE'))throw Error('unsupported stage hid its boundary');
el('stage-response').handlers.click();el('[data-member-results]').handlers.change({target:{value:'member-b'}});
source=JSON.parse(el('#protocol-source').textContent);
if(source.selection.binding.member_id!=='member-b'||source.selection.provenance.member_source_lineage.id!=='source-b'||source.selection.axis.index!==0)throw Error('member change retained previous context');
if(anatomySelections.at(-1).binding.member_id!=='member-b')throw Error('anatomy did not receive the same selected member');
if(requests.length!==1||!requests[0].startsWith('/api/cendos/protocols/'))throw Error('inspection fetched unrelated data or executed biology');
process.stdout.write('ok');
})().catch(e=>{console.error(e);process.exit(1)});
'''.replace("PROJECTIONS", json.dumps(projections)).replace("CONTROLLER", json.dumps(controller))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"


def test_atlas_remains_whole_person_with_a_separate_inspection_link():
    html = (CONSOLE / "workspace.html").read_text(encoding="utf-8")
    assert 'id="atlas-reference-host"' in html
    assert 'id="living-body"' not in html
    assert 'id="open-biology-context"' in html
    assert "assembled" not in re.sub(r"<[^>]+>", "", html).lower()
    assert "createAnatomyExplorer" not in (CONSOLE / "lib/workspace.js").read_text(encoding="utf-8")


def test_linked_anatomy_rejects_changed_context_instead_of_displaying_another_twin():
    node = require_node()
    script = biology_controller_script()
    program = r'''
const vm=require('node:vm'),nodes=new Map(),listeners={};let current='a'.repeat(64);
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',style:{},dataset:{},handlers:{},addEventListener(k,v){this.handlers[k]=v}});return nodes.get(id)}
const heart={id:'heart',name:'Heart',status:'parameter',metric:'IKr block',value:0,ratio:null,unit:'fraction',targets:[],pathways:[],cell:{type:'Myocyte'}};
const context={URLSearchParams,AbortController,location:{search:'?context_id='+current+'&organ_id=heart'},window:{},document:{hidden:false,getElementById:el,querySelector:el,createElement:()=>({getContext:()=>null}),addEventListener:(k,v)=>listeners[k]=v},console:{warn(){}},fetch:async()=>({ok:true,json:async()=>({context_id:current,twin:{profile:'healthy',human:current==='a'.repeat(64)?'technical-a':'other-private-person',conditions:[]},organs:[heart]})}),setTimeout:()=>1,clearTimeout(){},performance:{now:()=>0}};
async function flush(){for(let i=0;i<8;i++)await new Promise(setImmediate)}
(async()=>{context.addEventListener=()=>{};await vm.runInNewContext('(async()=>{'+SCRIPT+'})()',context);await flush();
if(!el('panel').innerHTML.includes('Heart'))throw Error('matching linked anatomy failed');
current='b'.repeat(64);listeners.visibilitychange();await flush();
if(!el('biology-status').textContent.includes('context changed'))throw Error('context switch was silently accepted');
if(el('panel').innerHTML.includes('other-private-person')||el('panel').innerHTML.includes('Ventricular-cell'))throw Error('different subject readouts were shown');
process.stdout.write('ok');})().catch(e=>{console.error(e);process.exit(1)});
'''.replace("SCRIPT", json.dumps(script))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"
