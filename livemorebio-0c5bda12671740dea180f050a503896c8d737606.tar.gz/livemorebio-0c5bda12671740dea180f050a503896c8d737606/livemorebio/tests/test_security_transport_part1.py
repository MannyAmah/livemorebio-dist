"""SEC-1/SEC-2 regressions; all records, certificates and tokens are technical fixtures."""
from __future__ import annotations

from contextlib import contextmanager
import ast
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import ssl
import subprocess
import threading
from types import SimpleNamespace
import urllib.request
import urllib.error

import pytest

from livemorebio.tests._source_tree import source_tree_only
from livemorebio.service_identity import IdentitySnapshot, encode_identity_key, proof_response

TOKEN = "technical-fixture-token-not-a-real-credential"
RECORD = {"fixture": "technical transport record, not observed physical data"}
TECHNICAL_IDENTITY_KEY = bytes(range(32))


@contextmanager
def _server(*, response=RECORD, redirect=None, tls=None, role="aegle"):
    received = []

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, *args):
            pass

        def do_CONNECT(self):
            received.append((self.command, self.path, self.headers.get("Authorization")))
            self.send_error(502, "technical collector refuses tunnels")

        def do_GET(self):
            received.append((self.command, self.path, self.headers.get("Authorization")))
            if redirect is not None:
                self.send_response(302)
                self.send_header("Location", redirect)
                raw = b""
            else:
                self.send_response(200)
                raw = json.dumps(response).encode()
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_POST(self):
            body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
            if self.path == "/api/stack/prove":
                assert self.headers.get("Authorization") is None and len(body) == 32
                authority = f"{'https' if tls else 'http'}://127.0.0.1:{self.server.server_port}"
                raw = proof_response(IdentitySnapshot(TECHNICAL_IDENTITY_KEY, role, authority),
                                     body, b"i" * 32, b"s" * 32)
                self.send_response(200)
                for name, value in {"Content-Type": "application/octet-stream", "Content-Length": "96",
                                    "Cache-Control": "no-store", "Referrer-Policy": "no-referrer"}.items():
                    self.send_header(name, value)
                self.end_headers()
                self.wfile.write(raw)
                self.wfile.flush()
                return
            self.do_GET()

    try:
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    except PermissionError:
        pytest.skip("sandbox denies loopback bind; socket-free real urllib handler regression runs separately")
    assert server.server_port not in {8850, 8851, 8852}
    if tls is not None:
        server.socket = tls.wrap_socket(server.socket, server_side=True)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
    thread.start()
    try:
        yield f"{'https' if tls else 'http'}://127.0.0.1:{server.server_port}", received
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
        assert not thread.is_alive()


@pytest.fixture
def isolated_transport(monkeypatch, tmp_path):
    for key, directory in (("HOME", "home"), ("TMPDIR", "tmp"), ("LIVEMORE_DATA_DIR", "data")):
        path = tmp_path / directory
        path.mkdir()
        monkeypatch.setenv(key, str(path))
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    monkeypatch.setenv("LIVEMORE_SERVICE_IDENTITY_KEY", encode_identity_key(TECHNICAL_IDENTITY_KEY))
    for name in ("LIVEMORE_AEGLE_IDENTITY_AUTHORITY", "LIVEMORE_LIFE_IDENTITY_AUTHORITY"):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("LIVEMORE_CACHE", str(tmp_path / "cache"))
    # L0-R16: these tests exercise the licensed transports beneath the egress check against local
    # technical servers on 127.0.0.1, which are not third-party destinations. The check itself is
    # held by test_l0_egress.py; every other address still goes through it here.
    from livemorebio import egress
    checked = egress.check_request
    monkeypatch.setattr(egress, "check_request", lambda url, **kwargs: "technical-loopback"
                        if urllib.parse.urlsplit(url).hostname == "127.0.0.1" else checked(url, **kwargs))
    for key in ("http_proxy", "HTTP_PROXY", "https_proxy", "HTTPS_PROXY", "all_proxy", "ALL_PROXY"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("no_proxy", "")
    monkeypatch.setenv("NO_PROXY", "")
    monkeypatch.delenv("REQUEST_METHOD", raising=False)
    # Do not let another test's cached global urllib opener hide environment changes.
    monkeypatch.setattr(urllib.request, "_opener", None)
    return tmp_path


@pytest.fixture
def technical_tls(isolated_transport, monkeypatch):
    root = isolated_transport
    config = root / "technical-cert.cnf"
    config.write_text("[req]\ndistinguished_name=dn\nx509_extensions=ext\nprompt=no\n"
                      "[dn]\nCN=technical-loopback-fixture\n[ext]\n"
                      "subjectAltName=IP:127.0.0.1,DNS:localhost\n"
                      "basicConstraints=critical,CA:TRUE\nkeyUsage=critical,keyCertSign,digitalSignature,keyEncipherment\n", encoding="utf-8")
    certificate, key = root / "technical-cert.pem", root / "technical-key.pem"
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
                    "-config", str(config), "-keyout", str(key), "-out", str(certificate)],
                   check=True, capture_output=True, timeout=15)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certificate, key)
    monkeypatch.setenv("SSL_CERT_FILE", str(certificate))
    return context


def _invoke(case, origin, monkeypatch, tmp_path):
    from livemorebio.sdk import Platform

    monkeypatch.setenv("LIVEMORE_AEGLE_URL", origin)
    monkeypatch.setenv("LIVEMORE_LIFE_URL", origin)
    if case in {"virtual_patch", "telemetry"}:
        from livemorebio.aegle import server
        from livemorebio.life_system import service
        for app, role in ((server.app, "aegle"), (service.app, "life")):
            monkeypatch.setattr(app.state, "stack_proof", SimpleNamespace(
                snapshot=IdentitySnapshot(TECHNICAL_IDENTITY_KEY, role, origin)))
    if case == "sdk_get":
        return Platform(mode="attach")._get("/technical")
    if case == "sdk_post":
        return Platform(mode="attach")._post("/technical", RECORD)
    if case == "virtual_patch":
        from livemorebio.aegle.server import _forward_virtual_patch
        return _forward_virtual_patch(RECORD)
    if case == "telemetry":
        from livemorebio.life_system.service import _forward_to_aegle
        return _forward_to_aegle(RECORD)
    if case == "execution":
        return Platform(mode="attach")._continuous_request("GET", "/technical")
    if case == "atlas":
        from livemorebio.atlas_client import AtlasClientError
        try:
            return Platform(mode="attach").atlas_reference_status()
        except AtlasClientError:
            return None  # The fixture deliberately is not a scientific atlas response.
    if case == "source":
        from livemorebio.life_patch.execution_source import ExecutionSourceClient
        return ExecutionSourceClient(origin, TOKEN, "a" * 64, expected_role="aegle",
            identity=IdentitySnapshot(TECHNICAL_IDENTITY_KEY, "aegle", origin))._http("GET", "/technical", None)
    if case in {"console", "console_pair"}:
        from livemorebio.console_session import mint_console_code
        return mint_console_code(origin, manual=case == "console_pair")
    if case == "walkthrough":
        from livemorebio.security import authorization_headers
        from livemorebio import stack_client, stack_transport
        import io
        from livemorebio.tests._source_tree import require_source_tree
        require_source_tree("trials/capture_walkthrough.py")
        path = Path(__file__).resolve().parents[2] / "trials/capture_walkthrough.py"
        from .private_reference_helpers import require_private_reference_data
        require_private_reference_data(path)
        tree = ast.parse(path.read_text(encoding="utf-8"))
        post = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "post")
        # Exercise the shipped sender without requiring the optional browser/image tools.
        namespace = {"B": origin, "json": json, "urllib": urllib,
                     "authorization_headers": authorization_headers,
                     "stack_client": stack_client, "stack_transport": stack_transport, "io": io}
        exec(compile(ast.Module(body=[post], type_ignores=[]), str(path), "exec"), namespace)
        return namespace["post"]("/technical", RECORD)
    if case == "kegg":
        from livemorebio.life_system.reference.sources import kegg
        # Isolate transport from the vendor's HTTPS/443 entitlement admission.
        monkeypatch.setattr(kegg, "approved_kegg_base", lambda: origin + "/")
        monkeypatch.setattr(kegg, "kegg_entitlement", lambda: SimpleNamespace(configured=True, fingerprint="technical"))
        monkeypatch.setenv("LIVEMORE_KEGG_API_TOKEN", TOKEN)
        return kegg.KEGG(cache_dir=str(tmp_path / "kegg-cache")).fetch("technical")
    raise AssertionError(case)


@pytest.mark.parametrize("case", ["sdk_get", "sdk_post", "virtual_patch", "telemetry", "kegg",
                                  "execution", "atlas", "source"])
def test_SEC_2_bearer_requests_bypass_inherited_proxy(case, monkeypatch, isolated_transport):
    with _server(role="life" if case == "virtual_patch" else "aegle") as (origin, direct), _server() as (collector, proxied):
        monkeypatch.setenv("http_proxy", collector)
        monkeypatch.setenv("HTTP_PROXY", collector)
        result = _invoke(case, origin, monkeypatch, isolated_transport)
        assert proxied == [], "technical bearer request reached inherited proxy collector"
        assert len(direct) == 1
        assert direct[0][2] == "Bearer " + TOKEN
        if case in {"sdk_get", "sdk_post", "execution", "kegg"}:
            assert result == RECORD


def _genecards(origin, monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources.genecards import GeneCards
    for key, value in {
        "LIVEMORE_GENECARDS_COMMERCIAL_LICENSE": "acknowledged",
        "LIVEMORE_GENECARDS_LICENSE_ID": "technical-fixture-license",
        "LIVEMORE_GENECARDS_API_BASE": origin + "/api",
        "GENECARDS_API_TOKEN": TOKEN,
    }.items():
        monkeypatch.setenv(key, value)
    return GeneCards(cache_dir=str(tmp_path / "genecards-cache"))


def test_SEC_2_genecards_bypasses_inherited_https_proxy(monkeypatch, isolated_transport, technical_tls):
    with _server(tls=technical_tls) as (origin, direct), _server() as (collector, proxied):
        for key in ("http_proxy", "HTTP_PROXY", "https_proxy", "HTTPS_PROXY"):
            monkeypatch.setenv(key, collector)
        result = _genecards(origin, monkeypatch, isolated_transport).gene("TECHNICAL_FIXTURE")
        assert proxied == [], "technical licensed request reached inherited proxy collector"
        assert direct == [("GET", "/api/genes/TECHNICAL_FIXTURE", "Bearer " + TOKEN)]
        assert result == RECORD


def test_SEC_1_genecards_refuses_https_to_http_redirect(monkeypatch, isolated_transport, technical_tls):
    with _server() as (target, leaked):
        with _server(redirect=target + "/collect", tls=technical_tls) as (origin, direct):
            result = _genecards(origin, monkeypatch, isolated_transport).gene("TECHNICAL_FIXTURE")
        assert leaked == [], "GeneCards forwarded its technical bearer token on a redirect"
        assert result is None
        assert direct == [("GET", "/api/genes/TECHNICAL_FIXTURE", "Bearer " + TOKEN)]
        assert not list((isolated_transport / "genecards-cache").glob("*.cache"))


def _redirect_refusal(case, origin, monkeypatch, tmp_path):
    """Assert the refusal each public client exposes, as well as no bearer leak."""
    from livemorebio.execution_client import ContinuousClientError

    if case in {"console", "console_pair"}:
        from livemorebio.console_session import ConsoleSessionError
        with pytest.raises(ConsoleSessionError) as caught:
            _invoke(case, origin, monkeypatch, tmp_path)
        assert caught.value.code == "CONSOLE_CODE_UNAVAILABLE"
    elif case in {"sdk_get", "sdk_post", "walkthrough"}:
        with pytest.raises(urllib.error.HTTPError) as caught:
            _invoke(case, origin, monkeypatch, tmp_path)
        assert caught.value.code == 302
    elif case == "execution":
        with pytest.raises(ContinuousClientError):
            _invoke(case, origin, monkeypatch, tmp_path)
    elif case == "virtual_patch":
        try:
            result = _invoke(case, origin, monkeypatch, tmp_path)
        except json.JSONDecodeError:
            pass  # The technical 302 deliberately has no JSON body.
        else:
            assert 300 <= result[0] < 400
    elif case == "source":
        status, _, body = _invoke(case, origin, monkeypatch, tmp_path)
        assert status == 302 and body == b""
    elif case == "telemetry":
        result = _invoke(case, origin, monkeypatch, tmp_path)
        assert result["status"] == "rejected" and result["http_status"] == 302
    else:
        assert _invoke(case, origin, monkeypatch, tmp_path) is None


@pytest.mark.parametrize("case", ["sdk_get", "sdk_post", "virtual_patch", "telemetry",
                                  "execution", "atlas", "source", "kegg", "console", "console_pair", "walkthrough"])
def test_SEC_1_every_bearer_client_refuses_redirect(case, monkeypatch, isolated_transport):
    with _server() as (collector, leaked):
        with _server(redirect=collector + "/collect", role="life" if case == "virtual_patch" else "aegle") as (origin, received):
            _redirect_refusal(case, origin, monkeypatch, isolated_transport)
        assert leaked == [], f"{case} forwarded its technical bearer to a redirect collector"
        assert len(received) == 1 and received[0][2] == "Bearer " + TOKEN


@pytest.fixture
def intercepted_connections(monkeypatch):
    """Keep vendor urllib handlers and mock the migrated clients' proved-response seam.

    NEW-5c's wire tests separately exercise the actual first-party boundary;
    this fixture retains the older callers' status/header parser coverage.
    """
    import http.client
    import io

    received = []
    behavior = {"redirect": False}
    real_response = http.client.HTTPResponse
    real_connection = http.client.HTTPConnection

    class Wire:
        def __init__(self, raw):
            self.raw = raw

        def makefile(self, *args):
            return io.BytesIO(self.raw)

    class Connection:
        _get_content_length = staticmethod(real_connection._get_content_length)

        def __init__(self, host, port=None, **kwargs):
            self.host = host if port is None else f"{host}:{port}"
            self.sock = None
            self.tunnel = None

        def set_debuglevel(self, level):
            pass

        def set_tunnel(self, host, port=None, headers=None):
            self.tunnel = host if port is None else f"{host}:{port}"

        def request(self, method, path, body=None, headers=None, **kwargs):
            authorization = {k.lower(): v for k, v in (headers or {}).items()}.get("authorization")
            received.append((self.host, method, path, authorization, self.tunnel))

        def getresponse(self):
            if "raw_response" in behavior:
                raw = behavior["raw_response"]
            elif behavior["redirect"] and self.host == "127.0.0.1:19873":
                raw = b"HTTP/1.1 302 Found\r\nLocation: http://localhost:19874/collect\r\nContent-Length: 0\r\n\r\n"
            else:
                body = json.dumps(RECORD).encode()
                raw = (b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: "
                       + str(len(body)).encode() + b"\r\n\r\n" + body)
            response = real_response(Wire(raw))
            response.begin()
            return response

        def close(self):
            pass

    from livemorebio import stack_transport

    def proved_response(url, *, identity, method="GET", headers=None, body=None, **kwargs):
        parsed = urllib.parse.urlsplit(url)
        assert identity.key == TECHNICAL_IDENTITY_KEY
        connection = Connection(parsed.netloc)
        path = parsed.path + ("?" + parsed.query if parsed.query else "")
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        raw = response.read() if kwargs.get("read_response_body", True) else b""
        return stack_transport.StackResponse(response.status, response.reason,
                                              tuple(response.getheaders()), raw)

    monkeypatch.setattr(stack_transport, "request", proved_response)
    monkeypatch.setattr(http.client, "HTTPConnection", Connection)
    monkeypatch.setattr(http.client, "HTTPSConnection", Connection)
    return received, behavior


@pytest.mark.parametrize("case", ["sdk_get", "sdk_post", "virtual_patch", "telemetry", "kegg",
                                  "execution", "atlas", "source"])
def test_SEC_2_proxy_dispatch_is_disabled_without_sockets(case, monkeypatch, isolated_transport,
                                                         intercepted_connections):
    received, _ = intercepted_connections
    for key in ("http_proxy", "HTTP_PROXY"):
        monkeypatch.setenv(key, "http://127.0.0.1:19875")
    _invoke(case, "http://127.0.0.1:19873", monkeypatch, isolated_transport)
    assert [row[0] for row in received] == ["127.0.0.1:19873"], "bearer dispatch selected proxy collector"
    assert received[0][3] == "Bearer " + TOKEN


@pytest.mark.parametrize("manual", [False, True], ids=("ordinary", "manual"))
def test_SEC_2_console_mint_proxy_dispatch_is_disabled_without_sockets(
        manual, monkeypatch, isolated_transport, intercepted_connections):
    from livemorebio.console_session import mint_console_code

    received, behavior = intercepted_connections
    code = "0123-4567-89AB-CDEF" if manual else "T" * 43
    body = json.dumps({"code": code, "expires_in": 57}).encode("utf-8")
    behavior["raw_response"] = (
        b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: "
        + str(len(body)).encode("ascii") + b"\r\n\r\n" + body)
    for key in ("http_proxy", "HTTP_PROXY", "https_proxy", "HTTPS_PROXY", "all_proxy", "ALL_PROXY"):
        monkeypatch.setenv(key, "http://127.0.0.1:19875")

    result = mint_console_code("http://127.0.0.1:19873", manual=manual)

    path = "/api/session/pair-code" if manual else "/api/session/code"
    assert [row[:3] for row in received] == [("127.0.0.1:19873", "POST", path)]
    assert bool(received[0][3] == "Bearer " + TOKEN)
    assert received[0][4] is None
    assert result.origin == "http://127.0.0.1:19873"
    assert bool(result.code == code)
    assert result.expires_in == 57


@pytest.mark.parametrize("manual", [False, True], ids=("ordinary", "manual"))
def test_SEC_2_console_mint_bypasses_inherited_proxy(
        manual, monkeypatch, isolated_transport):
    from livemorebio.console_session import mint_console_code

    code = "0123-4567-89AB-CDEF" if manual else "T" * 43
    with _server(response={"code": code, "expires_in": 57}) as (origin, direct), _server() as (collector, proxied):
        for key in ("http_proxy", "HTTP_PROXY", "https_proxy", "HTTPS_PROXY", "all_proxy", "ALL_PROXY"):
            monkeypatch.setenv(key, collector)
        result = mint_console_code(origin, manual=manual)
        assert proxied == [], "console mint request reached inherited proxy collector"
        path = "/api/session/pair-code" if manual else "/api/session/code"
        assert [row[:2] for row in direct] == [("POST", path)]
        assert bool(direct[0][2] == "Bearer " + TOKEN)
        assert bool(result.code == code)
        assert result.expires_in == 57


def test_SEC_2_genecards_proxy_dispatch_is_disabled_without_sockets(monkeypatch, isolated_transport,
                                                                  intercepted_connections):
    received, _ = intercepted_connections
    for key in ("http_proxy", "HTTP_PROXY", "https_proxy", "HTTPS_PROXY"):
        monkeypatch.setenv(key, "http://127.0.0.1:19875")
    result = _genecards("https://127.0.0.1:19873", monkeypatch, isolated_transport).gene("TECHNICAL_FIXTURE")
    assert [row[0] for row in received] == ["127.0.0.1:19873"], "licensed dispatch selected proxy collector"
    assert received[0][3] == "Bearer " + TOKEN
    assert result == RECORD


def test_SEC_1_genecards_redirect_is_refused_without_sockets(monkeypatch, isolated_transport,
                                                           intercepted_connections):
    received, behavior = intercepted_connections
    behavior["redirect"] = True
    result = _genecards("https://127.0.0.1:19873", monkeypatch, isolated_transport).gene("TECHNICAL_FIXTURE")
    assert [row[0] for row in received] == ["127.0.0.1:19873"], "GeneCards bearer followed redirect"
    assert result is None
    assert not list((isolated_transport / "genecards-cache").glob("*.cache"))


@pytest.mark.parametrize("status, body", [(200, b""), (409, b'{"code":"EXECUTION_CONFLICT"}')])
def test_SEC_2_source_transport_preserves_status_and_empty_body(status, body, monkeypatch,
                                                               isolated_transport, intercepted_connections):
    from livemorebio.life_patch.execution_source import ExecutionSourceClient
    received, behavior = intercepted_connections
    behavior["raw_response"] = (f"HTTP/1.1 {status} Technical Fixture\r\nContent-Length: {len(body)}\r\n\r\n".encode()
                                + body)
    result = ExecutionSourceClient("http://127.0.0.1:19873", TOKEN, "a" * 64, expected_role="aegle",
        identity=IdentitySnapshot(TECHNICAL_IDENTITY_KEY, "aegle", "http://127.0.0.1:19873"))._http("POST", "/technical", b"")
    assert result[0] == status
    assert result[2] == body
    assert len(received) == 1


def test_SEC_2_source_transport_still_refuses_duplicate_headers(monkeypatch, isolated_transport,
                                                              intercepted_connections):
    from livemorebio.aegle.execution_contract import ExecutionError
    from livemorebio.life_patch.execution_source import ExecutionSourceClient
    _, behavior = intercepted_connections
    behavior["raw_response"] = (b"HTTP/1.1 200 Technical Fixture\r\nContent-Length: 0\r\n"
                                b"X-Technical-Fixture: first\r\nx-technical-fixture: second\r\n\r\n")
    with pytest.raises(ExecutionError) as caught:
        ExecutionSourceClient("http://127.0.0.1:19873", TOKEN, "a" * 64, expected_role="aegle",
            identity=IdentitySnapshot(TECHNICAL_IDENTITY_KEY, "aegle", "http://127.0.0.1:19873"))._http("GET", "/technical", None)
    assert caught.value.code == "EXECUTION_UNAVAILABLE"


def test_SEC_1_source_transport_preserves_refused_redirect_status(monkeypatch, isolated_transport,
                                                                intercepted_connections):
    from livemorebio.life_patch.execution_source import ExecutionSourceClient
    received, behavior = intercepted_connections
    behavior["redirect"] = True
    status, _, body = ExecutionSourceClient("http://127.0.0.1:19873", TOKEN, "a" * 64, expected_role="aegle",
        identity=IdentitySnapshot(TECHNICAL_IDENTITY_KEY, "aegle", "http://127.0.0.1:19873"))._http("GET", "/technical", None)
    assert status == 302
    assert body == b""
    assert [row[0] for row in received] == ["127.0.0.1:19873"]


@pytest.mark.parametrize("case", ["sdk_get", "sdk_post", "virtual_patch", "telemetry",
                                  "execution", "atlas", "source", "kegg", "console", "console_pair", "walkthrough"])
def test_SEC_1_every_bearer_client_refuses_redirect_without_sockets(
        case, monkeypatch, isolated_transport, intercepted_connections):
    received, behavior = intercepted_connections
    behavior["redirect"] = True
    _redirect_refusal(case, "http://127.0.0.1:19873", monkeypatch, isolated_transport)
    assert len(received) == 1 and received[0][0] == "127.0.0.1:19873"
    assert received[0][3] == "Bearer " + TOKEN


def _bearer_transport_violations(source):
    """A cheap source guard complements the actual urllib redirect tests."""
    tree = ast.parse(source)
    violations = []
    for scope in ast.walk(tree):
        if not isinstance(scope, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        def own_nodes(node):
            yield node
            for child in ast.iter_child_nodes(node):
                if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    yield from own_nodes(child)

        nodes = list(own_nodes(scope))
        name = getattr(scope, "name", "<module>")
        bearer = any(
            (isinstance(node, ast.Call) and
             ((isinstance(node.func, ast.Name) and node.func.id == "authorization_headers") or
              (isinstance(node.func, ast.Attribute) and node.func.attr == "authorization_headers"))) or
            (isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value.startswith("Bearer "))
            for node in nodes)
        if not bearer:
            continue

        def authenticated(node):
            return isinstance(node, ast.Call) and (
                isinstance(node.func, ast.Name) and node.func.id == "authenticated_opener" or
                isinstance(node.func, ast.Attribute) and node.func.attr == "authenticated_opener")

        openers = {target.id for node in nodes if isinstance(node, ast.Assign) and authenticated(node.value)
                   for target in node.targets if isinstance(target, ast.Name)}
        for node in nodes:
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
                continue
            if node.func.attr == "urlopen":
                # L0-R16: the egress check's send, handed the authenticated opener, is the one exception.
                through_egress = (isinstance(node.func.value, ast.Name) and node.func.value.id == "egress"
                                  and any(keyword.arg == "opener" and authenticated(keyword.value)
                                          for keyword in node.keywords))
                if not through_egress:
                    violations.append((name, node.lineno))
            if node.func.attr == "open":
                receiver = node.func.value
                if isinstance(receiver, ast.Name) and receiver.id in {"os", "webbrowser"}:
                    continue
                if not authenticated(receiver) and not (isinstance(receiver, ast.Name) and receiver.id in openers):
                    violations.append((name, node.lineno))
    return violations


def test_SEC_1_bearer_senders_use_only_authenticated_opener():
    package = Path(__file__).resolve().parents[1]
    checked = []
    for path in package.rglob("*.py"):
        if any(part in {"tests", "v1"} for part in path.relative_to(package).parts):
            continue
        source = path.read_text(encoding="utf-8")
        assert not _bearer_transport_violations(source), path.relative_to(package)
        if "authorization_headers(" in source or '"Bearer "' in source:
            checked.append(path)
    assert len(checked) >= 8, "the bearer-client source guard must inspect the shipping clients"


@source_tree_only("trials/capture_walkthrough.py")
def test_SEC_1_trial_bearer_senders_use_only_authenticated_opener():
    trials = Path(__file__).resolve().parents[2] / "trials"
    from .private_reference_helpers import require_private_reference_data
    require_private_reference_data(trials / "capture_walkthrough.py")
    checked = list(trials.glob("*.py"))
    assert checked, "source-tree trials must be inspected"
    for path in checked:
        assert not _bearer_transport_violations(path.read_text(encoding="utf-8")), path.name


@pytest.mark.parametrize("opening", ["urllib.request.urlopen(request)",
    "urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request)",
    "opener.open(request)"])
def test_SEC_1_source_guard_detects_redirect_following_mutants(opening):
    source = 'def send():\n    headers = {"Authorization": "Bearer " + token}\n    ' + opening + "\n"
    assert _bearer_transport_violations(source)
