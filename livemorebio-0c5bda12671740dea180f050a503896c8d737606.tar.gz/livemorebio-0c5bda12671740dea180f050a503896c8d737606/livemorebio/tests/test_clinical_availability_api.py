"""Observation-only surfaces: authored technical fixtures, no participant or solver."""
from copy import deepcopy
import os
import subprocess
import sys

import pytest


SUMMARY = {"twin_id": "twin-technical-unbound", "subject_id": "technical-not-a-person",
           "display_label": "Technical observation-only selection", "version": 2,
           "source_class": "REAL_HUMAN", "lifecycle": "ACTIVE"}
NULL_FIELDS = {"profile", "base", "profile_params", "pk_context", "parameter_provenance",
               "provenance", "intervention", "metabolic", "cardiac", "hepatic", "comparison"}


@pytest.fixture
def client(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.aegle.model_source import ModelSourceAuthority

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-availability-test-token")
    monkeypatch.setattr(server, "_model_source_authority", ModelSourceAuthority())
    monkeypatch.setattr(server, "_state", {"tw": None, "subject": deepcopy(SUMMARY),
        "initialized": True, "observation_state": ObservationState(),
        "model_availability": {"schema": "livemore.model-availability.v1", "state": "UNAVAILABLE",
            "reason_code": "MODEL_BINDING_REQUIRED", "selection_mode": "observations_only",
            "twin_id": SUMMARY["twin_id"], "twin_version": 2,
            "source_generation": server._model_source_authority.generation,
            "preparation_available": False}})
    monkeypatch.setattr(server, "AegleTwin", lambda *a, **k: pytest.fail("unavailable view constructed a model"))
    monkeypatch.setattr(server, "_workspace_actions", [])
    return TestClient(server.app, headers={"Authorization": "Bearer technical-availability-test-token"})


def test_server_import_does_not_construct_a_healthy_twin_before_registry_restore():
    script = """
from livemorebio.aegle import runtime
def forbidden(*args, **kwargs):
    raise AssertionError('eager healthy constructor before authoritative selection')
runtime.AegleTwin = forbidden
from livemorebio.aegle import server
assert server._state['tw'] is None
"""
    result = subprocess.run([sys.executable, "-B", "-c", script], capture_output=True,
                            text=True, timeout=15, env=dict(os.environ), encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_admitted_packet_does_not_grow_intervention_history_or_rewrite_model_parameters():
    from types import SimpleNamespace
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.life_patch.protocol_v3 import TelemetryEnvelopeV3
    from livemorebio.tests.test_patch_protocol_v3 import envelope_payload

    packet = TelemetryEnvelopeV3(envelope_payload())
    twin = SimpleNamespace(applied=["technical prior intervention"], profile=object(),
                           observations={}, patch={}, execution_observations={})
    twin.state = lambda: {"observations": deepcopy(twin.observations)}
    original = twin.profile
    result = AegleTwin.ingest_patch_envelope(twin, packet)
    assert result["observations"]
    assert twin.applied == ["technical prior intervention"]
    assert twin.profile is original


def test_unavailable_state_and_workspace_preserve_reference_without_any_previous_physiology(client):
    for path in ("/api/state", "/api/workspace"):
        response = client.get(path)
        assert response.status_code == 200
        body = response.json()
        assert body["model_availability"]["state"] == "UNAVAILABLE"
        assert body["model_availability"]["twin_id"] == SUMMARY["twin_id"]
        state = body["twin"] if path.endswith("workspace") else body
        assert all(state[field] is None for field in NULL_FIELDS)
        assert state["active_execution"] is None and state["applied"] == []
        if path.endswith("workspace"):
            assert body["subject"] == SUMMARY
            assert body["multiscale"]["comparison"] is None
            assert body["multiscale"]["active_execution"] is None
            assert body["multiscale"]["biological_time"]["axes"] == []
            assert body["multiscale"]["systems"]
            assert all(system["execution_status"] == "UNAVAILABLE" and system["state"] == {}
                       for system in body["multiscale"]["systems"])


def test_unavailable_biology_keeps_actual_reference_atlas_and_null_quantities(client):
    response = client.get("/api/biology")
    assert response.status_code == 200
    value = response.json()
    assert value["model_availability"]["state"] == "UNAVAILABLE"
    assert value["twin"]["profile"] is None
    assert len(value["organs"]) == 7
    assert all(row["evidence_state"] == "REFERENCE_ONLY" and row["value"] is None
               and row["cell"]["activity"] is None for row in value["organs"])


def test_unavailable_patch_has_no_fabricated_model_day_or_channels(client):
    response = client.get("/api/patch")
    assert response.status_code == 200
    value = response.json()
    assert value["model_availability"]["state"] == "UNAVAILABLE"
    assert value["day_minutes"] is None and value["t_min"] == []
    assert value["n_recorded"] == 0 and value["n_live"] == 0
    assert not any(row.get("data_class") == "modeled" for row in value["channels"])
    assert value["profile"] is None and value["intervention"] is None


@pytest.mark.parametrize("path,body", [
    ("/api/workspace/actions", {"kind": "reset", "params": {}}),
    ("/api/stimulate", {"kind": "meal", "params": {"grams": 20}}),
    ("/api/stimulate", {"kind": "factor", "params": {"name": "exercise"}}),
    ("/api/patch/virtual", {"mode": "virtual"}),
])
def test_unavailable_numerical_actions_fail_before_engine_or_registry_calls(client, path, body):
    from livemorebio.aegle import server

    previous_generation = server._model_source_authority.generation
    response = client.post(path, json=body)
    assert response.status_code == 409
    assert response.json()["code"] == "MODEL_BINDING_REQUIRED"
    assert server._model_source_authority.generation == previous_generation
    assert server._state["tw"] is None


@pytest.mark.parametrize("outcome", ["success", "cleanup_failure", "rollback", "uncertain"])
def test_observation_selection_commit_installs_coherent_source_or_explicit_uncertainty(client, monkeypatch, outcome):
    import threading
    from types import SimpleNamespace
    from uuid import UUID
    from livemorebio.aegle import execution_api, server
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.execution_contract import ExecutionError
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority, SourceSelectionUnconfirmed
    from livemorebio.aegle.subjects import SubjectRegistryError, prepare_observation_selection
    from livemorebio.tests.clinical_registry_fixtures import legacy_twin_record

    target = legacy_twin_record("selected")
    old_twin = SimpleNamespace(execution_observations={"old": "technical"})
    old_subject = {**server._state["subject"], "source_class": "SYNTHETIC", "selection_mode": "model"}
    old_state = {**server._state, "tw": old_twin, "subject": old_subject}
    old_actions = server._workspace_actions
    calls, preparations, snapshots = [], [], []

    class Manager:
        _lock = threading.RLock()
        permitted = None

        def set_source_generation(self, value):
            assert self._lock._is_owned()
            self.permitted = value

        def invalidate_source(self, old, reason):
            assert not self._lock._is_owned()
            assert not server._model_source_authority._lock._is_owned()
            assert not execution_api._creation_lock._is_owned()
            if outcome == "uncertain":
                assert server._state is old_state and server._state["tw"] is old_twin
                assert server._workspace_actions is old_actions
            else:
                assert server._state["tw"] is None
            calls.append((old, reason))
            if outcome == "cleanup_failure":
                raise ExecutionError("EXECUTION_STORAGE")

    manager = Manager()
    authority = ModelSourceAuthority(server._invalidate_model_source, fence=server._assign_model_fence,
                                     fence_guard=server._model_fence_guard)
    old_generation = authority.generation
    old_state["model_availability"] = model_availability(old_subject, source_generation=old_generation)
    old_availability = deepcopy(old_state["model_availability"])
    old_observed = old_state["observation_state"]
    manager.permitted = old_generation
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_state", old_state)
    monkeypatch.setattr(server, "_snapshot_twin", lambda st: snapshots.append(deepcopy(st)))

    class Registry:
        def prepare_observation_selection(self, identifier, *, expected_version, request_id):
            assert identifier == target["twin_id"]
            assert authority._lock._is_owned() and not manager._lock._is_owned()
            assert not execution_api._creation_lock._is_owned()
            assert expected_version == 1 and str(UUID(request_id)) == request_id
            value = SimpleNamespace(kind="select_observations", request_id=request_id,
                record=prepare_observation_selection(target, expected_version=expected_version).record,
                active_before=deepcopy(old_subject))
            preparations.append(value)
            return value

        def page_records(self, *args, **kwargs):
            return {"records": [deepcopy(target)], "pagination": {}}

        def commit_prepared_transition(self, prepared):
            assert manager._lock._is_owned() and authority._lock._is_owned()
            assert execution_api._creation_lock._is_owned()
            assert len(preparations) == 1 and prepared is preparations[0]
            assert server._state["tw"] is old_twin
            assert authority.generation == old_generation
            if outcome in {"rollback", "uncertain"}:
                raise SubjectRegistryError("SELECTION_COMMIT_UNCONFIRMED" if outcome == "uncertain"
                                           else "TWIN_VERSION_CONFLICT", "technical selection failure")
            return "COMMITTED"

    monkeypatch.setattr(server, "_subject_registry", Registry)
    response = client.post(f"/api/twins/{target['twin_id']}/select-observations", json={"expected_version": 1})
    assert len(preparations) == 1 and response.headers["X-Request-ID"] == preparations[0].request_id
    assert response.headers["Cache-Control"] == "no-store"
    if outcome == "rollback":
        assert response.status_code == 409
        assert server._state is old_state and server._state["tw"] is old_twin
        assert authority.generation == old_generation == manager.permitted and not calls and not snapshots
    elif outcome == "uncertain":
        assert response.status_code == 503 and response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        assert manager.permitted is DENY_ALL and server._state is old_state
        assert server._state["tw"] is old_twin and server._workspace_actions is old_actions
        assert server._state["observation_state"] is old_observed
        assert server._state["model_availability"] == old_availability and not snapshots
        assert len(calls) == 1, "uncertain selection must still attempt prior-owner cleanup outside commit locks"
        with pytest.raises(SourceSelectionUnconfirmed):
            authority.capture(lambda: pytest.fail("uncertain numerical source was read"))
        assert client.get("/api/workspace").status_code == 503
        listing = client.get("/api/twins")
        assert listing.status_code == 200 and listing.json()["twins"]
        assert listing.json()["active"] is None
        assert listing.json()["selection_status"] == "UNCONFIRMED"
    else:
        assert response.status_code == (200 if outcome == "success" else 503)
        if outcome == "cleanup_failure":
            assert response.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        assert server._state["tw"] is None
        assert server._state["subject"]["twin_id"] == target["twin_id"]
        assert server._state["subject"]["version"] == 2
        assert authority.generation != old_generation and manager.permitted == authority.generation
        assert len(calls) == 1
        assert len(snapshots) == 1 and snapshots[0]["profile_params"] is None
        assert snapshots[0]["model_availability"] == server._state["model_availability"]
        state = client.get("/api/state").json()
        assert state["model_availability"]["twin_version"] == 2
        assert state["observations"] == {} and state["applied"] == []


@pytest.mark.parametrize("body", [{}, {"expected_version": True}, {"expected_version": "2"},
                                {"expected_version": 2, "model_binding": {}}])
def test_observation_selection_rejects_coercion_and_extra_fields_before_read(client, monkeypatch, body):
    from livemorebio.aegle import server

    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("invalid selection reached registry"))
    response = client.post("/api/twins/technical/select-observations", json=body)
    assert response.status_code == 422


@pytest.mark.parametrize("raw", ['{"expected_version":1,"expected_version":2}',
    '{"expected_version":NaN}', '{"expected_version":1,"padding":"' + 'x' * 16384 + '"}'])
def test_selection_bounded_strict_json_before_registry(client, monkeypatch, raw):
    from livemorebio.aegle import server

    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("invalid wire body reached registry"))
    assert client.post("/api/twins/technical/select-observations", content=raw).status_code == 422


def test_selection_auth_precedes_registry_read(client, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server

    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("unauthenticated registry read"))
    result = TestClient(server.app).post("/api/twins/technical/select-observations", json={"expected_version": 1})
    assert result.status_code == 401


def test_real_cohort_http_returns_compact_summary_and_explicit_frozen_member_views(client, tmp_path, monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.tests.clinical_registry_fixtures import KEY, human_payload

    registry = SubjectRegistry(tmp_path / "technical-subjects.sqlite3", key=KEY)
    people = [registry.create_twin(human_payload(suffix)) for suffix in ("first", "second")]
    record = registry.create_cohort({"name": "Technical cohort", "source_class": "REAL_HUMAN",
        "size": 2, "seed": 0, "indication": "research", "member_twin_ids": [row["twin_id"] for row in people]})
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    prefix = f"/api/cohorts/{record['cohort_id']}"
    summary = client.get(prefix)
    assert summary.status_code == 200
    assert "members" not in summary.json() and "member_twin_ids" not in summary.json()
    assert summary.json()["execution_eligibility"]["reason_code"] == "MODEL_BINDING_REQUIRED"
    rows = client.get("/api/cohorts").json()["cohorts"]
    assert len(rows) == 1 and "members" not in rows[0]
    page = client.get(prefix + "/members?limit=1")
    assert page.status_code == 200 and page.headers["Cache-Control"] == "no-store"
    assert len(page.json()["members"]) == 1 and page.json()["pagination"]["has_more"]
    assert "snapshot" not in page.json()["members"][0]
    detail = client.get(prefix + "/members/" + people[0]["twin_id"])
    assert detail.status_code == 200 and detail.headers["Cache-Control"] == "no-store"
    assert detail.json() == record["members"][0]
    assert detail.json()["snapshot"]["observations"] == people[0]["observations"]


@pytest.mark.parametrize("tail", ["/members", "/members/twin-technical"])
def test_cohort_member_routes_require_auth_before_registry(client, monkeypatch, tail):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server

    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("unauthenticated member read"))
    assert TestClient(server.app).get("/api/cohorts/cohort-technical" + tail).status_code == 401


@pytest.mark.parametrize("path,body", [
    ("/api/workspace/actions", {"kind": "reset", "params": {}}),
    ("/api/stimulate", {"kind": "meal", "params": {"grams": 20}}),
])
def test_ready_check_before_body_cannot_authorize_new_unavailable_selection(client, monkeypatch, path, body):
    from types import SimpleNamespace
    from livemorebio.aegle import server

    selected = deepcopy(server._state)
    old = server._model_source_authority.generation
    monkeypatch.setattr(server, "_state", {**selected, "tw": SimpleNamespace()})
    check = server._require_numerical_model

    def switch_after_first_check():
        check()
        server._state = selected

    monkeypatch.setattr(server, "_require_numerical_model", switch_after_first_check)
    response = client.post(path, json=body)
    assert response.status_code == 409 and response.json()["code"] == "MODEL_BINDING_REQUIRED"
    assert server._model_source_authority.generation == old
    assert server._state["tw"] is None and server._workspace_actions == []


def test_uncertain_selection_rejects_telemetry_before_any_admission_or_registry(client, monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution import DENY_ALL

    with server._model_source_authority.commit_guard():
        server._model_source_authority.install_generation(DENY_ALL)
    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("uncertain selected-person read"))
    observed = deepcopy(server._state["observation_state"].state())
    result = client.post("/api/patch/telemetry", json={})
    assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    assert server._state["observation_state"].state() == observed


@pytest.mark.parametrize("outcome", ["record", "none", "first_read_failure", "final_conflict", "final_audit_failure"])
def test_selection_reconciliation_uses_audited_authority_and_never_reselects(client, monkeypatch, outcome):
    import json
    from types import SimpleNamespace
    from livemorebio.aegle import server
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.subjects import CheckedActiveSelection, SubjectRegistryError
    from livemorebio.tests.clinical_registry_fixtures import legacy_twin_record

    record = legacy_twin_record("actual-authority", version=3)
    record.update(lifecycle="ACTIVE", selection_mode="observations_only")
    selected = None if outcome == "none" else record
    calls, captures, snapshots = [], [], []
    reference = SimpleNamespace(state=lambda: {"profile": "AUTHORED_REFERENCE", "profile_params": {}})
    monkeypatch.setattr(server, "AegleTwin", lambda base: reference if base == "healthy" else pytest.fail("wrong preview"))
    monkeypatch.setattr(server, "_snapshot_twin", lambda st: snapshots.append(deepcopy(st)))
    authority = server._model_source_authority
    with authority.commit_guard():
        authority.install_generation(DENY_ALL)
    before = server._state

    class Registry:
        def audited_active_twin(self, *, action, request_id, _checked_snapshot):
            assert authority._lock._is_owned() and _checked_snapshot is True
            assert action == "reconcile_selection"
            calls.append(("read", request_id))
            if outcome == "first_read_failure":
                raise RuntimeError("PRIVATE_CORRUPTED_STORAGE")
            identifier = selected["twin_id"] if selected else None
            captured = CheckedActiveSelection("AUTHORED_STORE", "AUTHORED_AUTHORITY", request_id,
                (), ("active_twin_id", identifier, "AUTHORED_TIMESTAMP") if identifier else None,
                (identifier,) if identifier else (), json.dumps(selected, allow_nan=False).encode())
            captures.append(captured)
            return captured

        def confirm_active_selection(self, *, expected_record, request_id, _expected_snapshot):
            assert authority._lock._is_owned() and authority.permitted_generation is DENY_ALL
            assert expected_record == selected
            assert len(captures) == 1 and _expected_snapshot is captures[0]
            assert request_id == calls[0][1]
            calls.append(("confirm", request_id))
            if outcome == "final_conflict":
                raise SubjectRegistryError("SELECTION_RECONCILIATION_CONFLICT", "technical changed record")
            if outcome == "final_audit_failure":
                raise RuntimeError("PRIVATE_AUDIT_COMMIT")

        def select_observations(self, *args, **kwargs):
            pytest.fail("reconciliation repeated the selection mutation")

    monkeypatch.setattr(server, "_subject_registry", Registry)
    response = client.post("/api/twins/reconcile-selection", json={})
    assert "PRIVATE" not in response.text
    assert response.headers["Cache-Control"] == "no-store"
    assert response.headers["X-Request-ID"] == calls[0][1]
    if outcome in {"record", "none"}:
        assert response.status_code == 200 and authority.permitted_generation is not DENY_ALL
        assert server._state["subject"] == (server._subject_summary(record) if selected else None)
        assert server._state["tw"] is (None if selected else reference)
        assert response.json()["selection_status"] == "CONFIRMED"
        assert len(calls) == 2
        assert len(snapshots) == 1 and snapshots[0]["profile_params"] == (None if selected else {})
        assert snapshots[0]["model_availability"] == response.json()["model_availability"]
        prior_generation = authority.generation
        again = client.post("/api/twins/reconcile-selection", json={})
        assert again.status_code == 409 and len(calls) == 2
        assert authority.generation == prior_generation
    else:
        assert response.status_code == (409 if outcome == "final_conflict" else 503)
        assert authority.permitted_generation is DENY_ALL and server._state is before and not snapshots


@pytest.mark.parametrize("mismatched_field", [None, "twin_id", "subject_id", "source_class", "version"])
def test_signed_technical_packet_projects_without_a_model_and_keeps_original_clocks(client, monkeypatch, mismatched_field):
    """A wire fixture, not a physical device, calibration, or human-use validation."""
    from datetime import datetime, timezone
    from types import SimpleNamespace
    from livemorebio.aegle import server
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest, PatchAdmissionController
    from livemorebio.security import sign_patch_admission
    from livemorebio.tests.test_patch_protocol_v3 import envelope_payload, manifest_payload

    monkeypatch.setenv("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", "dGVjaG5pY2FsLWZpeHR1cmUta2V5LWZvci10ZXN0cyE=")
    monkeypatch.setattr(server, "_patch_admission", PatchAdmissionController())
    monkeypatch.setattr(server, "_snapshot_twin", lambda *a: None)
    manifest = decode_manifest(manifest_payload("physical"))
    raw = envelope_payload("physical")
    now = datetime.now(timezone.utc).isoformat()
    raw.update(subject_id="pseudonym-technical-mapping", captured_at=now, acquisition_start=now, acquisition_end=now)
    packet = decode_envelope(raw)
    server._state["subject"]["subject_id"] = raw["subject_id"]
    active = {**server._state["subject"], "patch_bindings": [{"device_id": packet.device_id,
        "mode": "physical", "protocol_version": "3.0"}]}
    if mismatched_field is not None:
        server._state["subject"][mismatched_field] = (3 if mismatched_field == "version" else "technical-stale-memory")
        monkeypatch.setattr(server._patch_admission, "admit", lambda *a: pytest.fail("stale subject reached replay admission"))
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(active_twin=lambda: deepcopy(active)))
    admission = {"admission": "accepted", "device_id": packet.device_id, "mode": "physical",
        "envelope_hash": packet.envelope_hash, "manifest_hash": manifest.capability_hash,
        "capability_hash": manifest.capability_hash, "received_at": now}
    body = {"envelope": packet.to_dict(), "manifest": manifest.to_dict(), "admission": admission,
            "admission_signature": sign_patch_admission(admission)}
    generation = server._model_source_authority.generation
    response = client.post("/api/patch/telemetry", json=body)
    if mismatched_field is not None:
        assert response.status_code == 409, response.json()
        assert response.json()["code"] == "MODEL_SOURCE_CHANGED"
        assert server._state["observation_state"].observations == {}
        assert server._model_source_authority.generation == generation
        return
    assert response.status_code == 202, response.json()
    result = response.json()
    assert result["model_availability"]["state"] == "UNAVAILABLE" and result["metabolic"] is None
    assert result["applied"] == [] and server._state["tw"] is None
    observation = result["observations"]["hr_bpm"]
    assert observation["clock"]["session_id"] == "boot-fixture"
    assert observation["measurement_id"] == "hr-1" and observation["envelope_hash"] == packet.envelope_hash
    assert observation["captured_at"] == packet.captured_at.isoformat().replace("+00:00", "Z")
    assert server._model_source_authority.generation == generation
    assert client.post("/api/patch/telemetry", json=body).status_code == 422
    assert client.get("/api/state").json()["observations"] == result["observations"]
