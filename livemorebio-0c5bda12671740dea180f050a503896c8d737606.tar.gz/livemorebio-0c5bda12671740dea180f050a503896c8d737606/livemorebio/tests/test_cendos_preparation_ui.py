"""Run the ordinary Cendos handlers with authored reads, never scientific execution."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess

import pytest
from ._node import NODE, run_node as _run_node


PAGE = Path(__file__).parents[1] / "aegle/console/cendos.html"


def run_ui(body: str) -> None:
    source = re.search(r"<script>\s*(.*?)</script>", PAGE.read_text(encoding="utf-8"), re.S)
    assert source
    program = r"""
const assert=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map(),calls=[];
function el(id){
 if(!nodes.has(id))nodes.set(id,{value:'',textContent:'',_html:'',hidden:false,disabled:false,checked:false,
  style:{display:''},attributes:{},handlers:{},dataset:{},options:[],
  get innerHTML(){return this._html;},set innerHTML(value){this._html=value;this.options=[...value.matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/g)].map(m=>({value:m[1].match(/value="([^"]*)"/)?.[1]||'',disabled:/\bdisabled\b/.test(m[1])}));if(this.options.length)this.value=this.options[0].value;},
  setAttribute(k,v){this.attributes[k]=v;},replaceChildren(){this.innerHTML='';},
  addEventListener(k,fn){this.handlers[k]=fn;},querySelector(){return this;},querySelectorAll(){return[];},
  classList:{toggle(){}},scrollIntoView(){},focus(){}});
 return nodes.get(id);
}
for(const [id,value] of Object.entries({'cohort-protocol-choice':'metformin','history-size':'10','protocol-member-size':'25','gem-glucose':'1','gem-oxygen':'0, 1, 10'}))el(id).value=value;
el('protocolResult').style.display='none';el('resultCard').style.display='none';
const reply=payload=>({ok:true,status:200,json:async()=>structuredClone(payload)});
let route=async path=>{
 if(path==='/api/state')return reply({context_id:'technical-context',profile:'healthy reference',metabolic:{mean_glucose:90},model_availability:{state:'READY'}});
 if(path.startsWith('/api/cohorts?'))return reply({cohorts:[],pagination:{has_more:false,next_cursor:null}});
 if(path==='/api/genome-models')return reply({models:[]});
 if(path==='/api/cendos/programs')return reply({insulin:{admitted:[{product_id:'rapid-acting-analogue-sc',display_name:'Rapid-acting analogue'}],declared_not_admitted:[{product_id:'glargine-sc',reason:'no admitted absorption model'}]},botanical:{programs:[{program_id:'LBHR-030',compound:'Arctigenin',question:'q',executability:'MARGIN_COMPUTABLE',reason_code:null,pharmacokinetic_species:'piglet'}],validation_status:'0 of 5 validated in vivo'}});
 throw Error('Unexpected authored request: '+path);
};
const context={URLSearchParams,console,window:{},document:{getElementById:el,querySelectorAll:()=>[]},
 setInterval:()=>1,fetch:async(path,options={})=>{calls.push({path,method:options.method||'GET',options});return route(path,options);}};
vm.createContext(context);vm.runInContext(SOURCE,context);
const tick=async()=>{for(let i=0;i<6;i++)await new Promise(setImmediate);};
const evaluate=code=>vm.runInContext(code,context);
const cohort=(id,stratum='dpp-high-risk-metabolic')=>({cohort_id:id,name:'Technical '+id,size:2,source_class:'REFERENCE_GROUNDED_SYNTHETIC',stratum});
const saved=(id)=>({run_id:id,protocol_id:'cendos.human-gem-oxygen-capacity.v1',evidence_state:'MODELED_STEADY_STATE',qualification_state:'NOT_QUALIFIED',unit:'mmol/gDW/h',model:{release:'technical'},conditions:[],controls:[]});
(async()=>{await tick();BODY})().catch(error=>{console.error(error);process.exitCode=1;});
""".replace("SOURCE", json.dumps(source[1])).replace("BODY", body)
    result = _run_node([NODE, "--eval", program],
                            capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_ordinary_entry_is_blank_and_read_only():
    run_ui("""
assert.equal(evaluate('CURRENT_RUN'),null);assert.equal(evaluate('RERUN'),null);
assert.equal(el('protocolResult').style.display,'none');assert.equal(el('preparation-empty').hidden,false);
assert.equal(calls.length,3);assert(calls.every(c=>c.method==='GET'));
assert(!calls.some(c=>c.path.includes('/protocols/')));
for(const id of ['metformin-cohort-a','metformin-cohort-b','garcinoic-cohort'])assert.equal(el(id).value,'');
assert.equal(el('run-metformin-cohorts').disabled,true);assert.equal(el('run-garcinoic-pxr').disabled,true);
""")


def test_new_experiment_clears_old_cohort_selections_without_deleting_cohorts():
    run_ui("""
context.records=[cohort('a'),cohort('b'),cohort('pxr','pxr-reference')];
evaluate('COHORTS=records;populateCohorts()');
el('metformin-cohort-a').value='a';el('metformin-cohort-b').value='b';el('garcinoic-cohort').value='pxr';
evaluate('newExperiment()');
for(const id of ['metformin-cohort-a','metformin-cohort-b','garcinoic-cohort'])assert.equal(el(id).value,'');
assert.equal(evaluate('COHORTS.length'),3);assert.equal(calls.length,3);
assert.match(el('protocolStatus').textContent,/Nothing executed; existing history is unchanged/);
""")


def test_new_experiment_clears_current_reconciliation_and_evidence_but_keeps_log():
    run_ui("""
evaluate("CURRENT_RUN={run_id:'old'};RERUN={parent_run_id:'old'};LASTRUN={subject:'old'};ASSAYS=[{id:'kept'}]");
el('rInsilico').textContent='91% exposure';el('resultCard').style.display='';
el('result-context').textContent='Old result';el('rerun-context').textContent='Old parent';
evaluate('newExperiment()');
assert.equal(evaluate('LASTRUN'),null);assert.equal(context.window.lmbLastRun(),null);
assert.equal(el('rInsilico').textContent,'—');assert.equal(el('result-context').textContent,'');
assert.equal(el('resultCard').style.display,'none');assert.equal(evaluate('CURRENT_RUN'),null);
assert.equal(evaluate('RERUN'),null);assert.equal(evaluate('ASSAYS[0].id'),'kept');assert.equal(calls.length,3);
""")


@pytest.mark.parametrize("operation", ["recallRun", "prepareRerun"])
@pytest.mark.parametrize("outcome", ["success", "failure"])
def test_old_history_read_cannot_repaint_new_preparation(operation, outcome):
    run_ui("""
let settle;route=()=>new Promise((resolve,reject)=>{settle=OUTCOME==='failure'?()=>reject(Error('Old read failed')):()=>resolve(reply({}));});
const pending=evaluate("OPERATION('old-run')");await tick();
evaluate('newExperiment()');const before=[el('protocolStatus').textContent,el('history-status').textContent];
settle();await pending;
assert.deepEqual([el('protocolStatus').textContent,el('history-status').textContent],before);
assert.equal(evaluate('CURRENT_RUN'),null);assert.equal(evaluate('RERUN'),null);
assert.equal(el('protocolResult').style.display,'none');assert.equal(calls.length,4);
assert(calls.every(c=>c.method==='GET'));
""".replace("OPERATION", operation).replace("OUTCOME", json.dumps(outcome)))


@pytest.mark.parametrize("operation", ["recallRun", "prepareRerun"])
def test_current_history_failure_remains_visible(operation):
    run_ui("""
route=async()=>{throw Error('Current technical read failed');};
await evaluate("OPERATION('current-run')");
assert.match(el('history-status').textContent,/unavailable: Current technical read failed/);
assert.equal(evaluate('CURRENT_RUN'),null);assert.equal(calls.length,4);
assert(calls.every(c=>c.method==='GET'));
""".replace("OPERATION", operation))


@pytest.mark.parametrize("operation", ["recallRun", "prepareRerun"])
def test_newer_recall_stays_visible_after_old_read_rejects(operation):
    run_ui(r"""
let rejectOld;route=path=>path.includes('old-run')?new Promise((_,reject)=>rejectOld=reject):Promise.resolve(reply(saved('new-run')));
const old=evaluate("OPERATION('old-run')");await tick();
await evaluate("recallRun('new-run')");const before=[el('protocolStatus').textContent,el('history-status').textContent];
assert.equal(evaluate('CURRENT_RUN.run_id'),'new-run');
rejectOld(Error('Old request failed'));await old;
assert.deepEqual([el('protocolStatus').textContent,el('history-status').textContent],before);
assert.equal(evaluate('CURRENT_RUN.run_id'),'new-run');
assert.match(el('protocolExports').innerHTML,/biology\?run_id=new-run/);
assert(calls.every(c=>c.method==='GET'));
""".replace("OPERATION", operation))


def test_prepare_rerun_restores_exact_cohorts_and_only_explicit_run_posts_once():
    run_ui("""
const prepared={parent_run_id:'parent-run',protocol_id:'cendos.metformin-cohort-comparison.v1',endpoint:'/api/cendos/protocols/metformin-cohorts',warnings:[],request:{cohort_a_id:'a',cohort_b_id:'b',dose_mg:500,grams:50}};
route=async(path,options)=>{
 if(path.endsWith('/prepare-rerun'))return reply(prepared);
 if(path==='/api/cohorts/a')return reply({cohort:cohort('a')});
 if(path==='/api/cohorts/b')return reply({cohort:cohort('b')});
 assert.equal(options.method,'POST');return {ok:false,json:async()=>({error:'Authored execution refusal'})};
};
await evaluate("prepareRerun('parent-run')");
assert.equal(el('metformin-cohort-a').value,'a');assert.equal(el('metformin-cohort-b').value,'b');
assert.equal(Number(el('metformin-dose-mg').value),500);assert.equal(Number(el('metformin-ogtt-g').value),50);
assert.equal(calls.filter(c=>c.method==='POST').length,0);assert.equal(el('rerun-ack-label').hidden,false);
await evaluate('runMetforminCohorts()');
const posts=calls.filter(c=>c.method==='POST');assert.equal(posts.length,1);
assert.deepEqual(JSON.parse(posts[0].options.body),{...prepared.request,parent_run_id:'parent-run'});
assert.equal(evaluate('RERUN.parent_run_id'),'parent-run');assert.equal(evaluate('CURRENT_RUN'),null);
assert.equal(el('protocolStatus').textContent,'Authored execution refusal');
""")


def test_cohort_page_is_bounded_and_preserves_only_explicit_selected_records():
    run_ui("""
context.records=[cohort('chosen'),...Array.from({length:49},(_,i)=>cohort('old-'+i))];
evaluate('COHORTS=records;populateCohorts()');el('metformin-cohort-a').value='chosen';
const page=Array.from({length:50},(_,i)=>cohort('new-'+i,i%2?'pxr-reference':'dpp-high-risk-metabolic'));
route=async()=>reply({cohorts:page,pagination:{has_more:true,next_cursor:'technical-next'}});
await evaluate('loadCohorts(false)');
assert.equal(evaluate('COHORTS.length'),51);assert.equal(el('metformin-cohort-a').value,'chosen');
assert.equal(el('metformin-cohort-b').value,'');assert.equal(el('garcinoic-cohort').value,'');
assert.equal(evaluate("COHORTS.some(c=>c.cohort_id==='old-0')"),false);
assert.equal(el('cohort-more').disabled,false);assert(calls.every(c=>c.method==='GET'));
""")


def test_pending_legacy_assay_owns_action_lock_and_prevents_duplicate_or_reset():
    run_ui("""
let rejectPost;const originalRoute=route;
route=(path,options)=>options.method==='POST'?new Promise((_,reject)=>rejectPost=reject):originalRoute(path,options);
el('grams').value='75';el('dose').value='100';
const pending=evaluate('runAssay()');await tick();
assert.equal(evaluate('PROTOCOL_BUSY'),true);assert.equal(el('run-current-assay').disabled,true);
assert.equal(el('new-experiment').disabled,true);assert.equal(el('history-tab').disabled,true);
await evaluate('runAssay()');evaluate('newExperiment()');
assert.equal(calls.filter(c=>c.method==='POST').length,1);assert.equal(el('resultCard').style.display,'');
await evaluate('loadTwin()');assert.equal(el('run-current-assay').disabled,true);
rejectPost(Error('Technical uncertain response'));await pending;
assert.equal(evaluate('PROTOCOL_BUSY'),false);assert.equal(el('run-current-assay').disabled,false);
assert.match(el('assayNote').textContent,/Technical uncertain response/);
assert(!el('protocolStatus').textContent.includes('in progress'));
assert.equal(calls.filter(c=>c.method==='POST').length,1);
""")


def test_governed_protocol_busy_also_disables_and_blocks_legacy_run():
    run_ui("""
evaluate('setProtocolBusy(true)');
assert.equal(el('run-current-assay').disabled,true);
await evaluate('runAssay()');assert(calls.every(c=>c.method==='GET'));
await evaluate('loadTwin()');assert.equal(el('run-current-assay').disabled,true);
evaluate('setProtocolBusy(false)');assert.equal(el('run-current-assay').disabled,false);
""")


def test_protocol_selector_starts_blank_and_preserves_exact_six_protocols():
    source = PAGE.read_text(encoding="utf-8")
    selector = re.search(r'<select id="cohort-protocol-choice".*?</select>', source, re.S)
    assert selector
    assert re.findall(r'<option value="([^"]*)"', selector[0]) == [
        '', 'metformin', 'pxr', 'human-gem', 'lobeline', 'insulin', 'botanical']
    assert '<option value="" selected>Choose a protocol</option>' in selector[0]
    run_ui("""
assert.equal(el('cohort-protocol-choice').value,'');
for(const id of ['metformin-preparation','pxr-preparation','human-gem-preparation','lobeline-preparation','insulin-preparation','botanical-preparation','cohort-preparation-details'])assert(el(id).hidden,id);
assert.equal(calls.length,3);assert(calls.every(c=>c.method==='GET'));
""")


@pytest.mark.parametrize('choice', ['metformin', 'pxr', 'human-gem', 'lobeline', 'insulin', 'botanical'])
def test_protocol_choice_shows_one_form_without_request_or_result_relabel(choice):
    run_ui("""
evaluate("CURRENT_RUN={run_id:'retained-result'}");el('result-context').textContent='Retained immutable result';
el('cohort-protocol-choice').value=CHOICE;evaluate('chooseCohortProtocol()');
for(const name of ['metformin','pxr','human-gem','lobeline','insulin','botanical'])assert.equal(el(name+'-preparation').hidden,name!==CHOICE,name);
assert.equal(el('cohort-preparation-details').hidden,!['metformin','pxr'].includes(CHOICE));
await tick();
// Selecting a six-program panel reads the program catalogue once; nothing else changes.
assert.equal(calls.length,['insulin','botanical'].includes(CHOICE)?4:3);
assert(!calls.some(c=>c.method==='POST'));
assert.equal(evaluate('CURRENT_RUN.run_id'),'retained-result');
assert.equal(el('result-context').textContent,'Retained immutable result');
evaluate('newExperiment()');assert.equal(el('cohort-protocol-choice').value,'');
for(const name of ['metformin','pxr','human-gem','lobeline','insulin','botanical'])assert(el(name+'-preparation').hidden);
""".replace('CHOICE', json.dumps(choice)))


@pytest.mark.parametrize('operation', ['recallRun', 'prepareRerun'])
def test_new_protocol_choice_invalidates_pending_history_read(operation):
    run_ui("""
let reject;route=()=>new Promise((_,r)=>reject=r);
const pending=evaluate("OPERATION('old-run')");await tick();
el('cohort-protocol-choice').value='lobeline';evaluate('chooseCohortProtocol()');
const before=[el('protocolStatus').textContent,el('history-status').textContent];
reject(Error('Late authored read'));await pending;
assert.equal(el('cohort-protocol-choice').value,'lobeline');assert(!el('lobeline-preparation').hidden);
assert.deepEqual([el('protocolStatus').textContent,el('history-status').textContent],before);
assert.equal(evaluate('RERUN'),null);assert.equal(evaluate('CURRENT_RUN'),null);
""".replace('OPERATION', operation))


def test_busy_protocol_choice_and_new_experiment_cannot_switch_forms():
    run_ui("""
el('cohort-protocol-choice').value='human-gem';evaluate('chooseCohortProtocol();setProtocolBusy(true)');
assert(el('cohort-protocol-choice').disabled);el('cohort-protocol-choice').value='lobeline';
evaluate('chooseCohortProtocol();newExperiment()');
assert.equal(el('cohort-protocol-choice').value,'human-gem');assert(!el('human-gem-preparation').hidden);assert(el('lobeline-preparation').hidden);
evaluate('setProtocolBusy(false)');assert(!el('cohort-protocol-choice').disabled);assert.equal(calls.length,3);
""")


@pytest.mark.parametrize('choice,protocol,spec', [
    ('metformin', 'metformin-cohort-comparison', {'cohort_a_id': 'a', 'cohort_b_id': 'b', 'dose_mg': 500, 'grams': 50}),
    ('pxr', 'garcinoic-acid-pxr', {'cohort_id': 'pxr', 'concentrations_um': [0.05, 1.3]}),
    ('human-gem', 'human-gem-oxygen-capacity', {'conditions': [{'condition_id': 'retained', 'glucose_uptake': 2, 'oxygen_uptake': 3}], 'knockout_gene_ids': []}),
    ('lobeline', 'lobeline-vmat2-initial-rate', {'concentration_unit': 'nM', 'substrate_concentrations': [1, 1000], 'inhibitor_concentrations': [0, 250]}),
])
def test_rerun_restores_exact_protocol_and_requires_new_to_switch(choice, protocol, spec):
    run_ui("""
const protocol='cendos.__PROTOCOL__.v1';const endpoint=evaluate('PROTOCOL_ENDPOINTS['+JSON.stringify(protocol)+']');
route=async path=>path.endsWith('/prepare-rerun')?reply({parent_run_id:'parent',protocol_id:protocol,endpoint,warnings:[],request:REQUEST}):reply({cohort:cohort(path.split('/').at(-1),path.endsWith('/pxr')?'pxr-reference':'dpp-high-risk-metabolic')});
await evaluate("prepareRerun('parent')");
assert.equal(evaluate('RERUN.parent_run_id'),'parent');assert.equal(el('cohort-protocol-choice').value,CHOICE);
for(const name of ['metformin','pxr','human-gem','lobeline'])assert.equal(el(name+'-preparation').hidden,name!==CHOICE);
assert(el('cohort-protocol-choice').disabled);el('cohort-protocol-choice').value=CHOICE==='lobeline'?'metformin':'lobeline';evaluate('chooseCohortProtocol()');
assert.equal(el('cohort-protocol-choice').value,CHOICE);assert.equal(evaluate('RERUN.protocol_id'),protocol);
evaluate('newExperiment()');assert.equal(el('cohort-protocol-choice').value,'');assert(!el('cohort-protocol-choice').disabled);assert.equal(evaluate('RERUN'),null);
assert(calls.every(c=>c.method==='GET'));
""".replace('__PROTOCOL__', protocol).replace('REQUEST', json.dumps(spec)).replace('CHOICE', json.dumps(choice)))


@pytest.mark.parametrize("protocol", ["insulin", "botanical"])
def test_unrendered_protocol_has_typed_biology_reason_and_keeps_analysis_exports(protocol):
    from livemorebio.cendos import botanical_programs, insulin_protocol

    if protocol == "insulin":
        record = insulin_protocol.run_exogenous_insulin_protocol(
            insulin_protocol.validate_spec({"cohort_size": 1, "hours": 1}))
    else:
        record = botanical_programs.run_botanical_exposure_program(
            botanical_programs.validate_spec({"program_id": "LBHR-129"}))
    run_ui(r"""
context.record=RECORD;const before=JSON.stringify(context.record);evaluate('renderProtocol(record)');
const links=el('protocolExports').innerHTML;
assert(!links.includes('/biology?run_id='),'An unavailable renderer must not be linked');
assert.match(links,/BIOLOGY_PROTOCOL_UNSUPPORTED/);
assert(links.includes(context.record.protocol_id));
assert(links.includes('/analysis.csv'));assert(links.includes('/analysis.ipynb'));
assert.equal(JSON.stringify(context.record),before);
assert(calls.every(c=>c.method==='GET'));
""".replace("RECORD", json.dumps(record)))


@pytest.mark.parametrize("program,dose,shape", [
    ("LBHR-030", 400, "members_with_range"),
    ("LBHR-172", 1000, "members_without_range"),
    ("LBHR-135", 500, "measured_margin"),
    ("LBHR-129", 100, "refusal"),
    ("LBHR-135", 100, "refusal"),
])
def test_botanical_result_renders_the_actual_stored_shape(program, dose, shape):
    from livemorebio.cendos import botanical_programs

    record = botanical_programs.run_botanical_exposure_program(
        botanical_programs.validate_spec({"program_id": program, "dose_mg": dose, "cohort_size": 2}))
    run_ui(r"""
context.record=RECORD;const before=JSON.stringify(context.record);evaluate('renderProtocol(record)');
const d=context.record,summary=el('protocolSummary').innerHTML,table=el('protocolMembers').innerHTML,
 mechanism=el('protocolMechanism').innerHTML,boundary=el('protocolBoundary').innerHTML;
const escaped=value=>evaluate('esc('+JSON.stringify(value)+')');
assert(summary.includes(d.outcome));assert(summary.includes(d.in_vivo_validation));
if(SHAPE.startsWith('members_')){
 assert(d.members.length);assert(!table.includes('No exposure was computed'));
 for(const member of d.members){assert(table.includes(member.member_id));assert(table.includes(String(member.cmax_unbound_um)));}
 if(SHAPE==='members_with_range'){
  assert(d.active_range_um);assert(table.includes('Margin to active floor'));
  assert(table.includes(String(d.members[0].margin_to_active_low)));
 }else{
  assert.equal(d.active_range_um,null);assert(summary.includes(escaped(d.active_range_missing)));
  assert(summary.includes(d.reason_code));assert(!mechanism.includes('Measured active range'));
  assert(!table.includes('Margin to active floor'));assert(!table.includes('Reaches range'));
 }
}else if(SHAPE==='measured_margin'){
 assert.equal(d.members.length,0);assert(d.margin);
 assert(!table.includes('No exposure was computed'));assert(!table.includes('Member</th>'));
 assert(summary.includes(d.exposure_basis));assert(!mechanism.includes('Oral exposure model'));
 for(const value of [d.margin.unbound_cmax_um,d.margin.margin_to_active_low,d.margin.margin_at_one_standard_error_below_cmax])assert(table.includes(String(value)));
 assert.match(table,/not robust to one standard error/i);
 assert(!table.includes('t-peak'));assert(!table.includes('Unbound AUC'));
}else{
 assert.equal(d.outcome,'EXPOSURE_NOT_COMPUTABLE');assert.equal(d.members.length,0);
 assert(summary.includes(d.reason_code));assert(summary.includes(escaped(d.missing_measurement)));
 assert.match(table,/No exposure was computed/);assert(!table.includes('Margin to active floor'));
 assert(!mechanism.includes('Oral exposure model'));assert(!mechanism.includes('Exposure margin'));
}
for(const limit of [...d.interpretation_limits,...d.transfer_limits])assert(boundary.includes(escaped(limit)),limit);
assert(![summary,table,boundary].some(html=>html.includes('undefined')));
assert.equal(JSON.stringify(context.record),before);assert(calls.every(c=>c.method==='GET'));
""".replace("RECORD", json.dumps(record)).replace("SHAPE", json.dumps(shape)))
