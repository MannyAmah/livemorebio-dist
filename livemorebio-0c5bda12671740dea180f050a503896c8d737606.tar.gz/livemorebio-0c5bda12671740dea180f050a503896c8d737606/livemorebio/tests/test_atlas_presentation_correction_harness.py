"""Authored transcripts/DOM doubles only: no listener, socket or browser probe."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import subprocess
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_atlas_presentation_harness import node

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def harness():
    spec = importlib.util.spec_from_file_location("atlas_correction_subject", ROOT / "tools/check_atlas_presentation.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def transcript(endpoint="127.0.0.1:8910", fields=""):
    return f"p123\nf7\nPTCP\nn{endpoint}\nTST=LISTEN\n{fields}".encode()


@pytest.mark.parametrize("endpoint,address,port", [
    ("127.0.0.1:8910", "127.0.0.1", 8910), ("0.0.0.0:8911", "0.0.0.0", 8911),
    ("[::1]:8912", "::1", 8912), ("[::]:8910", "::", 8910), ("*:8911", "*", 8911),
])
def test_listener_positive_machine_grammar(harness, endpoint, address, port):
    result = harness.parse_listener_output(transcript(endpoint, "TQR=0\nTQS=12\n"), b"", 0)
    assert result == {"owned_listeners_absent": False, "inspection_code": "LISTENERS_PRESENT",
                      "listeners": [{"pid": 123, "fd": "7", "address": address, "port": port, "state": "LISTEN"}]}


def test_no_match_is_only_exit_one_and_exact_empty_streams(harness):
    assert harness.parse_listener_output(b"", b"", 1)["owned_listeners_absent"] is True
    # TIME_WAIT is not LISTEN evidence. The actual LISTEN-filtered command must
    # produce no match, rather than interpreting this nonconforming transcript.
    assert harness.parse_listener_output(transcript().replace(b"LISTEN", b"TIME_WAIT"), b"", 0)["owned_listeners_absent"] is None


@pytest.mark.parametrize("stdout,stderr,exit_code", [
    (b"", b"", 0), (b"", b"", 2), (transcript(), b"", 1), (b"", b"PRIVATE warning", 1),
    (transcript(), b"PRIVATE permission error", 0), (b"\n", b"", 1),
    (transcript()[:-1], b"", 0), (transcript() + b"\n", b"", 0),
    (transcript().replace(b"p123", b"p0123"), b"", 0),
    (transcript().replace(b"f7", b"f07"), b"", 0),
    (transcript().replace(b"PTCP\n", b"PTCP\nPTCP\n"), b"", 0),
    (transcript().replace(b"PTCP", b"PUDP"), b"", 0),
    (transcript().replace(b"n127.0.0.1:8910\n", b""), b"", 0),
    (transcript() + b"TST=LISTEN\n", b"", 0),
    (transcript() + b"TQR=1\nTQR=1\n", b"", 0),
    (transcript() + b"TQS=01\n", b"", 0),
    (transcript() + b"TUNKNOWN=PRIVATE\n", b"", 0),
    (transcript() + b"cPRIVATE command\n", b"", 0),
    (transcript() + b"p124\n", b"", 0),
    (transcript() + b"f7\nPTCP\nn*:8911\nTST=LISTEN\n", b"", 0),
    (transcript() + transcript(), b"", 0),
    (transcript("[fe80::1%en0]:8910"), b"", 0),
    (transcript("127.0.0.1:8913"), b"", 0),
    (transcript("127.0.0.1:8910->127.0.0.1:22"), b"", 0),
    (transcript("localhost:8910"), b"", 0),
    (transcript().replace(b"p123", b"p-1"), b"", 0),
])
def test_listener_ambiguous_or_malformed_never_claims_absence(harness, stdout, stderr, exit_code):
    result = harness.parse_listener_output(stdout, stderr, exit_code)
    assert result["owned_listeners_absent"] is None and result["listeners"] == []
    assert "PRIVATE" not in repr(result) and "8913" not in repr(result)


def test_listener_multiple_descriptors_and_processes_have_unique_boundaries(harness):
    raw = transcript() + b"f8u\nPTCP\nn[::1]:8911\nTST=LISTEN\np124\nf0\nPTCP\nn*:8912\nTST=LISTEN\n"
    result = harness.parse_listener_output(raw, b"", 0)
    assert [row["fd"] for row in result["listeners"]] == ["7", "8u", "0"]


def install_fake_query(harness, monkeypatch, *, stdout=b"", stderr=b"", exit_code=1,
                       stall=False, term_fails=False, kill_fails=False, read_fails=False, close_fails=False):
    calls = []; now = [0.0]; chunks = {10: [stdout, b""] if stdout else [b""], 11: [stderr, b""] if stderr else [b""]}
    class Stream:
        def __init__(self, fd): self.fd = fd
        def fileno(self): return self.fd
        def close(self):
            calls.append(("close", self.fd))
            if close_fails: raise OSError("PRIVATE close")
    class Child:
        pid = 123
        def __init__(self): self.stdout = Stream(10); self.stderr = Stream(11); self.killed = False
        def wait(self, timeout):
            calls.append(("wait", timeout))
            if stall and (not self.killed or kill_fails): raise subprocess.TimeoutExpired("PRIVATE", timeout)
            return exit_code
        def poll(self): return None if stall else exit_code
        def terminate(self):
            calls.append(("terminate", 123))
            if term_fails: raise OSError("PRIVATE terminate")
        def kill(self): calls.append(("kill", 123)); self.killed = True
    child = Child()
    class Selector:
        def __init__(self): self.registered = {}
        def register(self, stream, events, data): self.registered[stream.fd] = (stream, data)
        def unregister(self, stream): self.registered.pop(stream.fd)
        def get_map(self): return self.registered
        def select(self, timeout):
            now[0] += timeout if stall else .01
            if stall: return []
            return [(SimpleNamespace(fileobj=stream, data=data), 1) for stream, data in list(self.registered.values())]
        def close(self): calls.append(("selector-close",))
    def popen(command, **kwargs): calls.append(("spawn", command, kwargs)); return child
    def read(fd, count):
        calls.append(("read", fd, count))
        if read_fails: raise OSError("PRIVATE read")
        chunk = chunks[fd].pop(0)
        if len(chunk) > count: chunks[fd].insert(0, chunk[count:]); chunk = chunk[:count]
        return chunk
    monkeypatch.setattr(harness.subprocess, "Popen", popen)
    monkeypatch.setattr(harness.time, "monotonic", lambda: now[0])
    monkeypatch.setattr(harness.selectors, "DefaultSelector", Selector)
    monkeypatch.setattr(harness.os, "set_blocking", lambda *args: None)
    monkeypatch.setattr(harness.os, "read", read)
    return calls


def test_listener_query_has_fixed_minimal_environment_and_bounded_streaming(harness, monkeypatch):
    calls = install_fake_query(harness, monkeypatch)
    result = harness.inspect_listeners()
    assert result["owned_listeners_absent"] is True and result["query_cleanup"] == "SETTLED"
    spawn = calls[0]
    assert spawn[1] == ["/usr/sbin/lsof", "-nP", "-a", "-iTCP:8910-8912", "-sTCP:LISTEN", "-F", "pfnPT"]
    assert spawn[2]["env"] == {"PATH": "/usr/bin:/bin:/usr/sbin", "LC_ALL": "C", "LANG": "C"}
    assert spawn[2]["stdin"] == subprocess.DEVNULL and spawn[2]["close_fds"] is True
    assert all(call[2] <= 4096 for call in calls if call[0] == "read")
    assert not any(call[0] in {"terminate", "kill"} for call in calls)


@pytest.mark.parametrize("mode", ["timeout", "term-error", "kill-error", "stdout-limit", "stderr-limit", "read-error", "close-error", "missing"])
def test_listener_query_failure_is_bounded_and_never_retains_raw_errors(harness, monkeypatch, mode):
    calls = install_fake_query(harness, monkeypatch,
        stdout=b"x" * 65537 if mode == "stdout-limit" else b"",
        stderr=b"x" * 8193 if mode == "stderr-limit" else b"",
        stall=mode in {"timeout", "term-error", "kill-error"}, term_fails=mode == "term-error",
        kill_fails=mode == "kill-error", read_fails=mode == "read-error", close_fails=mode == "close-error")
    if mode == "missing":
        monkeypatch.setattr(harness.subprocess, "Popen", lambda *_a, **_k: (_ for _ in ()).throw(FileNotFoundError("PRIVATE")))
    result = harness.inspect_listeners()
    assert result["owned_listeners_absent"] is None and not result["listeners"]
    assert "PRIVATE" not in repr(result)
    if mode in {"timeout", "term-error", "kill-error"}:
        assert ("terminate", 123) in calls and ("kill", 123) in calls
        assert all(call[1] <= 2 for call in calls if call[0] == "wait")
    if mode == "kill-error": assert result["query_cleanup"] == "UNCONFIRMED"


def test_teardown_inspection_is_independent_and_never_calls_startup_bind(harness, monkeypatch):
    calls = []
    monkeypatch.setattr(harness, "free_ports", lambda: pytest.fail("Finalization attempted bind"))
    monkeypatch.setattr(harness, "inspect_listeners", lambda: {"owned_listeners_absent": None, "listeners": [], "inspection_code": "LISTENER_QUERY_TIMEOUT", "query_cleanup": "SETTLED"})
    report = {"primary_failure": "ORIGINAL"}
    def cleanup(): calls.append("children"); raise OSError("PRIVATE")
    def verify(): calls.append("cache"); raise OSError("PRIVATE")
    def write(value): calls.append("write"); assert value["owned_listeners_absent"] is None
    harness.finalize(report, cleanup, verify, lambda value: (harness.record_listener_inspection(value), write(value)))
    assert calls == ["children", "cache", "write"] and report["primary_failure"] == "ORIGINAL"
    assert report["cleanup_failure"] == "CLEANUP_UNCONFIRMED"


STATE = """const rawState=()=>({bounds:{x:10,y:120,width:300,height:440},viewport:{width:390,height:844},scroll:{x:0,y:90},chrome:{header:{visible:true,position:'sticky',rect:{x:0,y:0,width:390,height:68}},scope:{visible:true,position:'sticky',rect:{x:0,y:68,width:390,height:40}}},reference_state:'ready',loaded:'9',view_status_hidden:false,scroll_width:390,labels:[],selected_label:null,search_result_value:'FJ2629',search_query:'FJ2629',search_options:['FJ2629'],source_article:'Pancreas · FJ2629 · FMA7198',cue_hidden:false,frame_enabled:true,isolate_enabled:true,inspector:{dom_text:'Pancreas · FJ2629 · FMA7198\\nLong source details',identity_dom_text:'Pancreas · FJ2629 · FMA7198',source_id:'FJ2629',rect:{x:10,y:120,width:300,height:900},identity_rect:{x:20,y:130,width:270,height:24}}});const keys=['skin','heart','liver','pancreas','right-kidney','left-kidney','right-lung','left-lung','brain'];const state=()=>({...rawState(),labels_requested:false,document_hidden:false,axis:'off',isolated:'false',callout_list_count:9,callout_list:keys.map(key=>key.replaceAll('-',' ')+' · labels off'),callout_status:'0 group callouts placed · 9 omitted. labels off Complete reference group list:',group_controls_count:9,group_controls:keys.map(key=>({key,checked:true,disabled:false}))});"""


def test_visible_clip_uses_viewport_css_coordinates_not_document_offsets():
    node(STATE + "a.deepEqual(h.visibleCanvasClip(state()),{x:10,y:120,width:300,height:440});")


@pytest.mark.parametrize("change", ["s.bounds.x=-1", "s.bounds.y=90", "s.bounds.width=NaN", "s.bounds.height=0", "s.bounds.x=150", "s.bounds.y=500", "s.viewport.height=Infinity", "s.scroll.y=NaN", "s.chrome.scope.rect.height=-1"])
def test_clip_rejects_invalid_offscreen_or_sticky_occlusion(change):
    node(STATE + f"a.deepEqual(h.visibleCanvasClip(state()),state().bounds);const s=state();{change};a.throws(()=>h.visibleCanvasClip(s),e=>['CAPTURE_GEOMETRY_INVALID','CANVAS_NOT_FULLY_VISIBLE','CANVAS_CHROME_OCCLUDED'].includes(e.code));")


def test_static_mobile_chrome_outside_canvas_is_not_claimed_sticky_occlusion():
    node(STATE + "const s=state();s.chrome.header.position='static';s.chrome.header.rect.y=-100;a.deepEqual(h.visibleCanvasClip(s),s.bounds);")


def test_each_image_retains_before_after_and_previous_image_on_second_failure():
    node(STATE + """
(async()=>{const e={screenshots:[]};let count=0;const calls=[];
const page={screenshot:async options=>{calls.push(options);if(++count===2)throw Error('PRIVATE');},locator:()=>{throw Error('ELEMENT_CAPTURE_FORBIDDEN');}};
const work=fn=>fn();await h.captureImage(page,e,'pose','viewport',async()=>state(),work,'/private/technical');
await a.rejects(h.captureImage(page,e,'pose','canvas',async()=>state(),work,'/private/technical'));
a.equal(e.screenshots.length,2);a.equal(e.screenshots[0].capture,'SAVED');a.deepEqual(e.screenshots[0].before,e.screenshots[0].after);
a.equal(e.screenshots[1].capture,'FAILED');a(e.screenshots[1].before);a(!JSON.stringify(e).includes('PRIVATE'));
a.equal(calls[0].path,'/private/technical/pose-viewport.png');a.deepEqual(calls[1].clip,state().bounds);
for(const call of calls){a(!('fullPage' in call));a(!('captureBeyondViewport' in call));a(!('style' in call));}
})().catch(()=>process.exitCode=1);
""")


def test_scroll_change_after_saved_image_is_retained_as_capture_failure():
    node(STATE + """
(async()=>{const e={screenshots:[]};let count=0;const snapshot=async()=>{const s=state();if(count++)s.scroll.y++;return s;};
await a.rejects(h.captureImage({screenshot:async()=>{}},e,'pose','canvas',snapshot,fn=>fn(),'/private/technical'));
a.equal(e.screenshots[0].image_written,true);a.equal(e.screenshots[0].capture,'FAILED');a(e.screenshots[0].after);
})().catch(()=>process.exitCode=1);
""")


def test_image_readiness_change_is_retained_without_claiming_a_saved_pass():
    node(STATE + """
(async()=>{let reads=0;const e={screenshots:[]};await a.rejects(h.captureImage({screenshot:async()=>{}},e,'pose','canvas',async()=>{const s=state();if(reads++)s.reference_state='error';return s;},fn=>fn(),'/private/technical'),error=>error.code==='PRESENTATION_NOT_READY');a.equal(e.screenshots[0].image_written,true);a.equal(e.screenshots[0].capture,'FAILED');a.equal(e.screenshots[0].after.reference_state,'error');})().catch(()=>process.exitCode=1);
""")


def test_inspector_dom_text_is_distinguished_from_visible_pixel_coverage():
    node(STATE + """
const s=state(),result=h.inspectorCoverage(s);a.equal(result.text_kind,'DOM_TEXT_NOT_PIXEL_TRANSCRIPTION');a.equal(result.source_id,'FJ2629');a.equal(result.full_article_visible,false);a.equal(result.identity_header_visible,true);a(result.viewport_intersection.height<900);
s.inspector.identity_rect.y=50;const hidden=h.inspectorCoverage(s);a.equal(hidden.identity_header_visible,false);a(hidden.limitations.includes('IDENTITY_HEADER_NOT_FULLY_VISIBLE'));
""")


def test_fixed_twenty_case_ledger_predeclares_three_inspector_poses():
    node("const evidence=h.newCaseEvidence(),ids=evidence.cases.map(row=>row.id);a.equal(ids.length,20);a.equal(evidence.planned_images.length,33);a.equal(new Set(evidence.planned_images).size,33);a.equal(ids.filter(id=>id.endsWith('-inspector')).length,3);for(const prefix of ['desktop-FJ1895','desktop-FJ2629','mobile-FJ2629'])a.equal(ids.indexOf(prefix+'-inspector'),ids.indexOf(prefix+'-assembled-restored')+1);")


def test_return_guard_rejects_any_selection_divergence_and_retains_search():
    node(STATE + """
const before=state(),after=state();Object.assign(after,{search_result_value:'',cue_hidden:true,frame_enabled:false,isolate_enabled:false,source_article:'Select a source element to inspect its identity.'});h.requireClearedSelection(before,after);
for(const field of ['search_result_value','cue_hidden','frame_enabled','isolate_enabled','source_article']){const bad=structuredClone(after);bad[field]=before[field];a.throws(()=>h.requireClearedSelection(before,bad));}
const bad=structuredClone(after);bad.search_query='';a.throws(()=>h.requireClearedSelection(before,bad));
""")


def test_callout_identity_leader_and_overlap_checks_are_not_only_containment():
    node(STATE + """
const s=state();const box={x:20,y:150,width:50,height:20};s.labels=[{key:'heart',text:'heart',rect:box,leader:{key:'heart',anchor:{x:100,y:170},end:{x:70,y:160}}}];h.requireLabelLayout(s);
const duplicate=structuredClone(s);duplicate.labels.push({...duplicate.labels[0],key:'liver',text:'liver',leader:{...duplicate.labels[0].leader,key:'liver'}});a.throws(()=>h.requireLabelLayout(duplicate));
const mismatch=structuredClone(s);mismatch.labels[0].leader.key='brain';a.throws(()=>h.requireLabelLayout(mismatch));
const cue=structuredClone(s);cue.selected_label={x:50,y:145,width:60,height:20};a.throws(()=>h.requireLabelLayout(cue));
""")


def test_actual_dom_snapshot_has_no_stale_implicit_bounds_and_reads_identity_range():
    node("""
const box={x:10,y:120,width:300,height:440};
const element=(text='',rect=box)=>({textContent:text,getBoundingClientRect:()=>rect,getClientRects:()=>[rect],style:{visibility:'visible',display:'block',opacity:'1',position:'static'},hidden:false,disabled:false,value:'',dataset:{},getAttribute:()=> 'false'});
const article=element('Pancreas · FJ2629 · FMA7198\\nSource reference'),text={nodeType:3};article.firstChild=text;
const entries={'canvas':element(),'[data-canvas]':element(),'[data-selection]':article,'[data-results]':Object.assign(element(),{value:'FJ2629',options:[{value:'FJ2629'}]}),'[data-search]':Object.assign(element(),{value:'FJ2629'}),'[data-frame]':element(),'[data-isolate]':element(),'[data-axis]':element(),'[data-view-status]':element('Reference layers loaded'),'.atlas-reference-selection':element(),'.atlas-reference-selection-label':null};
const groupKeys=['skin','heart','liver','pancreas','right-kidney','left-kidney','right-lung','left-lung','brain'];
const list=groupKeys.map(key=>element(key.replaceAll('-',' ')+' · anchor outside the camera view'));
const controls=groupKeys.map(key=>Object.assign(element(),{dataset:{group:key},checked:true,disabled:false}));
entries['[data-labels]']=Object.assign(element(),{checked:true});entries['[data-callout-status]']=element('0 group callouts placed · 9 omitted. Reference bounds-center anchors, not surface visibility. Complete reference group list:');
const host={dataset:{referenceState:'ready',loadedGroups:'9'},querySelector:key=>entries[key]??null,querySelectorAll:key=>key==='[data-callout-list] li'?list:key==='[data-group]'?controls:[]};
const header=element('',{x:0,y:0,width:390,height:68}),scope=element('',{x:0,y:68,width:390,height:40});header.style.position=scope.style.position='sticky';
let rangeCalls=0;global.document={hidden:false,querySelector:key=>({'#atlas-reference-host':host,'.workspace-header':header,'.scope-strip':scope}[key]),documentElement:{scrollWidth:390},createRange:()=>({setStart:(n,p)=>{a.equal(n,text);a.equal(p,0);rangeCalls++;},setEnd:(n,p)=>a.equal(p,article.textContent.split('\\n')[0].length),getBoundingClientRect:()=>({x:20,y:130,width:270,height:24})})};
global.Node={TEXT_NODE:3};global.getComputedStyle=n=>n.style;Object.assign(global,{innerWidth:390,innerHeight:844,scrollX:0,scrollY:90});
const s=h.readPresentationState();a.deepEqual(s.bounds,box);a.equal(s.search_result_value,'FJ2629');a.equal(s.inspector.source_id,'FJ2629');a.equal(rangeCalls,1);a.deepEqual(h.visibleCanvasClip(s),box);a.equal(s.chrome.scope.position,'sticky');
a.equal(s.labels_requested,true);a.equal(s.document_hidden,false);a.equal(s.callout_list_count,9);a.equal(s.group_controls_count,9);a.equal(s.group_controls.length,9);
list.push(list[0]);controls.push(controls[0]);const extra=h.readPresentationState();a.equal(extra.callout_list_count,10);a.equal(extra.group_controls_count,10);a.equal(extra.callout_list.length,9);a.equal(extra.group_controls.length,9);
""")


@pytest.mark.parametrize("raw", [b"p123\nf7u\nPTCP\nn*:8910\nTST=LISTEN\nf7r\nPTCP\nn*:8911\nTST=LISTEN\n",
                                 transcript().replace(b"\n", b"\r\n"), transcript("999.0.0.1:8910"),
                                 transcript("[:::1]:8910"), transcript() + b"TQR=-1\n",
                                 transcript().replace(b"\n", b"\v", 1)])
def test_additional_listener_ambiguity_rejects_after_valid_control(harness, raw):
    assert harness.parse_listener_output(transcript(), b"", 0)["owned_listeners_absent"] is False
    assert harness.parse_listener_output(raw, b"", 0)["owned_listeners_absent"] is None


def test_listener_inspection_exception_still_reaches_evidence(harness, monkeypatch):
    report = {"primary_failure": "ORIGINAL"}
    monkeypatch.setattr(harness, "inspect_listeners", lambda: (_ for _ in ()).throw(OSError("PRIVATE")))
    harness.record_listener_inspection(report)
    assert report["owned_listeners_absent"] is None and report["cleanup_failure"] == "CLEANUP_UNCONFIRMED"
    assert report["primary_failure"] == "ORIGINAL" and "PRIVATE" not in repr(report)


BOOKS = STATE + """
const books=(reason='anchor outside the camera view')=>{const s=state();s.labels_requested=true;s.callout_list=keys.map(k=>k.replaceAll('-',' ')+' · '+reason);s.callout_status='0 group callouts placed · 9 omitted. Reference bounds-center anchors, not surface visibility. Complete reference group list:';return s;};
const placed=s=>{s.labels=[{key:'heart',text:'heart',rect:{x:20,y:150,width:50,height:20},leader:{key:'heart',anchor:{x:100,y:170},end:{x:70,y:160}}}];s.callout_list[1]='heart · callout placed';s.callout_status=s.callout_status.replace('0 group callouts placed · 9 omitted','1 group callouts placed · 8 omitted');return s;};
"""


@pytest.mark.parametrize("reason", ["anchor outside the camera view", "insufficient label space", "anchor or measured text unavailable"])
def test_callout_bookkeeping_accepts_explicit_zero_visible_without_minimum(reason):
    node(BOOKS + f"const result=h.requireCalloutBookkeeping(books({reason!r}));a.deepEqual(result.placed_keys,[]);a.equal(result.omitted.length,9);")


def test_callout_bookkeeping_accepts_exact_partial_and_disabled_partition():
    node(BOOKS + "const s=placed(books());s.group_controls[0].checked=false;s.callout_list[0]='skin · layer disabled';const r=h.requireCalloutBookkeeping(s);a.deepEqual(r.placed_keys,['heart']);a.equal(r.omitted.length,8);h.requireLabelLayout(s);")


@pytest.mark.parametrize("alter", [
    "s.callout_status=s.callout_status.replace('0 group callouts placed · 9 omitted','9 group callouts placed · 0 omitted')",
    "s.callout_status=s.callout_status.replace('9 omitted','8 omitted')",
    "s.callout_status=s.callout_status.replace('0 group','00 group')",
    "s.callout_status+=' PRIVATE'", "s.callout_status=''",
    "s.callout_list_count=10", "s.callout_list_count=8", "s.callout_list.pop()",
    "s.callout_list[0]=s.callout_list[1]", "s.callout_list.reverse()",
    "s.callout_list[0]='skin · UNKNOWN'", "s.callout_list[0]='skin · layer not loaded'",
    "s.callout_list[0]='skin · callout unavailable'", "s.callout_list[0]='skin · callout placed'",
    "s.labels=placed(books()).labels", "s.labels=[{key:'unknown'}]",
    "s.labels_requested=false", "s.labels_requested='true'", "s.document_hidden=true",
    "s.axis='x'", "s.isolated='true'", "s.axis='invalid'",
    "s.group_controls_count=10", "s.group_controls_count=8", "s.group_controls.pop()",
    "s.group_controls[0]={...s.group_controls[1]}", "s.group_controls[0].disabled=true",
    "s.group_controls[0].checked=false", "s.group_controls[0].checked='true'",
    "s.callout_list[0]='skin · layer disabled'",
])
def test_callout_bookkeeping_rejects_each_contradiction_after_valid_control(alter):
    node(BOOKS + f"h.requireCalloutBookkeeping(books());const s=books();{alter};a.throws(()=>h.requireCalloutBookkeeping(s),e=>e.code==='CALLOUT_BOOKKEEPING_INVALID');")


@pytest.mark.parametrize("mode", ["off", "section", "isolation"])
def test_callout_suppression_precedence_matches_product(mode):
    node(BOOKS + f"""
const s=state();s.axis='x';s.isolated='true';
const mode={mode!r};let reason='labels off';
if(mode!=='off'){{s.labels_requested=true;reason='suppressed during section';}}
if(mode==='isolation'){{s.axis='off';reason='suppressed during isolation';}}
s.callout_list=keys.map(key=>key.replaceAll('-',' ')+' · '+reason);
s.callout_status='0 group callouts placed · 9 omitted. '+reason+' Complete reference group list:';
h.requireCalloutBookkeeping(s);s.labels_requested=!s.labels_requested;
a.throws(()=>h.requireCalloutBookkeeping(s),e=>e.code==='CALLOUT_BOOKKEEPING_INVALID');
""")


def test_bookkeeping_failure_after_saved_inspector_keeps_previous_image():
    node(BOOKS + """
(async()=>{const e={screenshots:[]};const page={screenshot:async()=>{}};await h.captureImage(page,e,'first','viewport',async()=>state(),fn=>fn(),'/private/technical');let n=0;await a.rejects(h.captureImage(page,e,'second','inspector',async()=>{const s=state();if(n++)s.callout_list_count=10;return s;},fn=>fn(),'/private/technical'),e=>e.code==='CALLOUT_BOOKKEEPING_INVALID');a.equal(e.screenshots[0].capture,'SAVED');a.equal(e.screenshots[1].image_written,true);a.equal(e.screenshots[1].capture,'FAILED');a.equal(e.screenshots[1].after.callout_list_count,10);})().catch(()=>process.exitCode=1);
""")
