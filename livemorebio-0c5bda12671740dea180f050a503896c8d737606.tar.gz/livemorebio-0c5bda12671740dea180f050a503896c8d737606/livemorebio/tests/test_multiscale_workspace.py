"""Executable multiscale workspace and cross-product contract tests."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta, timezone


def test_whole_body_contracts_cover_every_system_with_units_and_time_scales():
    from livemorebio.anatomy import load_ontology
    from livemorebio.multiscale import whole_body_contracts

    contracts = whole_body_contracts()
    ontology_ids = set(load_ontology().systems)

    assert {item["system_id"] for item in contracts} == ontology_ids
    assert len(contracts) == len(ontology_ids)
    for contract in contracts:
        assert contract["time_scales"]
        assert contract["inputs"]
        assert contract["outputs"]
        assert contract["applicability"]["claim_state"]
        for variable in contract["state_variables"]:
            assert variable["id"]
            assert variable["unit"]
            assert variable["value_type"] == "number"


def test_unimplemented_systems_have_formal_contracts_but_no_invented_state(pinned_cardiac_asset):
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.multiscale import multiscale_state

    state = multiscale_state(AegleTwin("healthy"))
    systems = {item["system_id"]: item for item in state["systems"]}

    assert systems["cardiovascular"]["execution_status"] == "EXECUTED"
    assert systems["endocrine"]["execution_status"] == "EXECUTED"
    assert systems["respiratory"]["execution_status"] == "UNAVAILABLE"
    assert systems["respiratory"]["state"] == {}
    assert systems["respiratory"]["unavailable_reason"]


def test_metformin_execution_is_person_specific_and_spans_implemented_scales(pinned_cardiac_asset):
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.life_system.synthetic_human import SyntheticHuman
    from livemorebio.multiscale import multiscale_state

    reference = AegleTwin(human=SyntheticHuman(
        "reference", age=58, sex="F", conditions=["type 2 diabetes"],
        genome={"SLC22A1_lof": 0}, lifestyle=0.4,
    ))
    reduced_transport = AegleTwin(human=SyntheticHuman(
        "reduced", age=58, sex="F", conditions=["type 2 diabetes"],
        genome={"SLC22A1_lof": 2}, lifestyle=0.4,
    ))

    reference.stimulate("metabolic_drug", name="metformin", dose=1.0)
    reduced_transport.stimulate("metabolic_drug", name="metformin", dose=1.0)
    first = multiscale_state(reference)
    second = multiscale_state(reduced_transport)

    nodes = {item["id"]: item for item in first["active_execution"]["nodes"]}
    assert {
        "gene.slc22a1", "protein.oct1", "molecule.metformin_exposure",
        "cell.hepatocyte", "cell.cardiomyocyte", "tissue.ventricular",
        "organ.liver", "organ.heart", "system.endocrine",
        "system.cardiovascular", "whole_body.homeostasis",
    }.issubset(nodes)
    assert nodes["gene.slc22a1"]["value"] == 0
    assert nodes["protein.oct1"]["unit"] == "1"
    assert first["active_execution"]["edges"]
    assert (
        first["active_execution"]["summary"]["hepatic_exposure_ratio"]
        > second["active_execution"]["summary"]["hepatic_exposure_ratio"]
    )
    assert (
        first["comparison"]["treated"]["mean_glucose_mg_dL"]
        != first["comparison"]["baseline"]["mean_glucose_mg_dL"]
    )


def test_legacy_patch_reconciliation_requires_mapping_without_mutating_model_parameters():
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for
    from livemorebio.multiscale import reconcile_patch

    twin = AegleTwin("healthy")
    before = deepcopy(twin.state()["profile_params"])
    device = VirtualLifePatch(manifest_for("virtual-reconcile-001", DeviceMode.VIRTUAL))
    envelope = device.emit(
        "pseudonym-001",
        {"glucose_mgdl": 105.0, "hr_bpm": 72.0},
        captured_at=datetime.now(timezone.utc),
    )
    twin.ingest_patch_envelope(envelope)
    result = reconcile_patch(twin)

    rows = {item["signal"]: item for item in result["signals"]}
    assert rows["glucose_mgdl"]["residual"] is None
    assert rows["hr_bpm"]["residual"] is None
    assert rows["glucose_mgdl"]["status"] == "MAPPING_UNAVAILABLE"
    assert result["model_parameters_updated"] is False
    assert twin.state()["profile_params"] == before


def test_patch_reconciliation_refuses_unit_mismatch():
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.multiscale import reconcile_observations

    twin = AegleTwin("healthy")
    result = reconcile_observations(twin, {
        "hr_bpm": {
            "value": 72.0,
            "unit": "mg/dL",
            "quality_status": "pass",
            "calibration_status": "pass",
            "envelope_id": "bad-unit",
        }
    })

    assert result["signals"][0]["status"] == "UNIT_MISMATCH"
    assert result["signals"][0]["residual"] is None


def test_cendos_qualification_is_context_bound_and_never_authorizes_calibration():
    from livemorebio.cendos.qualification import assess_counterpart

    generated_at = datetime.now(timezone.utc)
    measured_at = generated_at + timedelta(hours=2)
    result = assess_counterpart(
        prediction_id="prediction-001",
        measurement_id="measurement-001",
        protocol_id="protocol-001",
        subject_id="pseudonym-001",
        prediction_subject_id="pseudonym-001",
        endpoint="glucose_auc",
        prediction_endpoint="glucose_auc",
        predicted_value=100.0,
        measured_value=104.0,
        unit="mg.h/dL",
        prediction_unit="mg.h/dL",
        tolerance=5.0,
        generated_at=generated_at,
        measured_at=measured_at,
        expected_window_seconds=7200,
        quality_status="pass",
        calibration_status="pass",
        population="adults_with_t2d",
        intervention="metformin",
        dose="1000_mg",
    )

    assert result["status"] == "CRITERION_MET"
    assert result["absolute_error"] == 4.0
    assert result["context"]["population"] == "adults_with_t2d"
    assert result["calibration_authorized"] is False
    assert result["next_gate"] == "evidence_service_validation_review"


def test_cendos_qualification_marks_binding_mismatch_not_assessable():
    from livemorebio.cendos.qualification import assess_counterpart

    now = datetime.now(timezone.utc)
    result = assess_counterpart(
        prediction_id="prediction-001",
        measurement_id="measurement-001",
        protocol_id="protocol-001",
        subject_id="pseudonym-001",
        prediction_subject_id="pseudonym-002",
        endpoint="glucose_auc",
        prediction_endpoint="glucose_auc",
        predicted_value=100.0,
        measured_value=100.0,
        unit="mg.h/dL",
        prediction_unit="mg.h/dL",
        tolerance=5.0,
        generated_at=now,
        measured_at=now + timedelta(hours=2),
        expected_window_seconds=7200,
        quality_status="pass",
        calibration_status="pass",
        population="adults_with_t2d",
        intervention="metformin",
        dose="1000_mg",
    )

    assert result["status"] == "NOT_ASSESSABLE"
    assert "subject_binding_mismatch" in result["reasons"]
    assert result["calibration_authorized"] is False


def test_cendos_qualification_api_requires_auth_and_persists_only_candidate_state(
    monkeypatch,
):
    from fastapi.testclient import TestClient
    from livemorebio import bus
    from livemorebio.cendos import service

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "workspace-token")
    captured = {}
    monkeypatch.setattr(bus, "set_snapshot", lambda key, value: captured.update({key: value}))
    monkeypatch.setattr(bus, "publish", lambda *args, **kwargs: None)
    client = TestClient(service.app)
    body = {
        "prediction_id": "prediction-001",
        "measurement_id": "measurement-001",
        "protocol_id": "protocol-001",
        "subject_id": "pseudonym-001",
        "prediction_subject_id": "pseudonym-001",
        "endpoint": "glucose_auc",
        "prediction_endpoint": "glucose_auc",
        "predicted_value": 100.0,
        "measured_value": 103.0,
        "unit": "mg.h/dL",
        "prediction_unit": "mg.h/dL",
        "tolerance": 5.0,
        "generated_at": "2026-08-30T12:00:00Z",
        "measured_at": "2026-08-30T14:00:00Z",
        "expected_window_seconds": 7200,
        "quality_status": "pass",
        "calibration_status": "current",
        "population": "adults_with_t2d",
        "intervention": "metformin",
        "dose": "1000_mg",
    }

    assert client.post("/qualification/assess", json=body).status_code == 401
    response = client.post(
        "/qualification/assess",
        headers={"Authorization": "Bearer workspace-token"},
        json=body,
    )

    assert response.status_code == 200
    assert response.json()["status"] == "CRITERION_MET"
    assert response.json()["calibration_authorized"] is False
    assert captured["cendos.latest-qualification"]["evidence_effect"] == "candidate_validation_event"


def test_workspace_api_is_authenticated_and_preserves_existing_product_routes(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.runtime import AegleTwin

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "workspace-token")
    monkeypatch.setattr(server, "_snapshot_twin", lambda *args, **kwargs: None)
    server._state["tw"] = AegleTwin("type-2-diabetes")
    client = TestClient(server.app)

    assert client.get("/api/workspace").status_code == 401
    response = client.get(
        "/api/workspace", headers={"Authorization": "Bearer workspace-token"},
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["schema"] == "livemore.multiscale-workspace.v1"
    assert payload["multiscale"]["systems"]
    assert payload["products"]["aegle"]["connected"] is True
    for route in ("/", "/legacy", "/biology", "/patch", "/cendos", "/adapters"):
        assert client.get(route).status_code == 200


def test_workspace_action_has_visible_lifecycle_and_validates_inputs(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.runtime import AegleTwin

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "workspace-token")
    monkeypatch.setattr(server, "_snapshot_twin", lambda *args, **kwargs: None)
    server._state["tw"] = AegleTwin("type-2-diabetes")
    server._workspace_actions.clear()
    client = TestClient(server.app)

    bad = client.post(
        "/api/workspace/actions",
        headers={"Authorization": "Bearer workspace-token"},
        json={"kind": "metabolic_drug", "params": {"name": "metformin", "dose": -1}},
    )
    assert bad.status_code == 422

    response = client.post(
        "/api/workspace/actions",
        headers={"Authorization": "Bearer workspace-token"},
        json={"kind": "metabolic_drug", "params": {"name": "metformin", "dose": 1}},
    )
    assert response.status_code == 200
    action = response.json()["action"]
    assert action["status"] == "COMPLETED"
    assert action["transitions"] == ["QUEUED", "RUNNING", "COMPLETED"]
    assert response.json()["workspace"]["multiscale"]["comparison"]["intervention"] == "metformin"


def test_sdk_and_shell_expose_the_same_multiscale_workspace_and_actions():
    from livemorebio.sdk import Platform
    from livemorebio.shell import run_command

    platform = Platform(mode="inprocess")
    initial = platform.workspace()
    assert initial["schema"] == "livemore.multiscale-workspace.v1"
    assert initial["multiscale"]["systems"]

    result = platform.workspace_action("metabolic_drug", name="metformin", dose=1.0)
    assert result["action"]["transitions"] == ["QUEUED", "RUNNING", "COMPLETED"]
    assert result["workspace"]["multiscale"]["comparison"]["intervention"] == "metformin"

    output = []
    run_command(platform, "show workspace", output.append)
    assert any("contracts=" in line and "executed=" in line for line in output)

    run_command(platform, "action reset", output.append)
    assert any("action=reset" in line and "status=COMPLETED" in line for line in output)


def test_sdk_virtual_patch_uses_device_contract_and_does_not_calibrate():
    from livemorebio.sdk import Platform

    platform = Platform(mode="inprocess")
    result = platform.virtual_patch_sample(readings={"glucose_mgdl": 110.0, "hr_bpm": 71.0})

    assert result["patch"]["mode"] == "virtual"
    assert result["reconciliation"]["signals"]
    assert result["reconciliation"]["model_parameters_updated"] is False
    assert result["reconciliation"]["calibration_authorized"] is False
