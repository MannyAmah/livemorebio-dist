"""The actual service routes preserve descriptive versus executable boundaries."""
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_execution_api import product, HEADERS


def test_root_mounts_sources_and_projects_public_cohort_summary(product, monkeypatch):
    from livemorebio.aegle import server, reference_cohort_api
    record = {"cohort_id": "cohort-reference", "source_class": "PUBLIC_REFERENCE", "member_integrity_manifest": ["private"]}
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(
        get_cohort=lambda value: record,
        page_records=lambda *args, **kwargs: {"records": [record], "pagination": {"next_cursor": None}}))
    projected = []
    def safe(value):
        projected.append(value)
        return {"cohort_id": "cohort-reference", "source_class": "PUBLIC_REFERENCE", "executable": False}
    monkeypatch.setattr(reference_cohort_api, "project_cohort_summary_for_api", safe)
    assert product.client.get("/api/population-sources").status_code == 401
    single = product.client.get("/api/cohorts/cohort-reference", headers=HEADERS)
    page = product.client.get("/api/cohorts", headers=HEADERS)
    assert single.status_code == page.status_code == 200
    assert "private" not in single.text and "private" not in page.text
    assert len(projected) == 2


@pytest.mark.parametrize("protocol", ["metformin", "pxr"])
def test_shared_protocol_gate_rejects_unbound_reference_before_model_work(protocol):
    from livemorebio.reference_cohort_contract import ReferenceModelBindingRequired
    from livemorebio.cendos.protocols import run_metformin_cohort_comparison, run_garcinoic_acid_pxr
    reference = {"source_class": "PUBLIC_REFERENCE", "executable": True, "members": []}
    with pytest.raises(ReferenceModelBindingRequired):
        if protocol == "metformin":
            run_metformin_cohort_comparison(reference, reference)
        else:
            run_garcinoic_acid_pxr(reference, concentrations_um=[.1])


def test_public_reference_protocol_error_keeps_specific_actionable_code(product, monkeypatch):
    from livemorebio.aegle import server
    record = {"cohort_id": "cohort-reference", "source_class": "PUBLIC_REFERENCE", "executable": False}
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(get_cohort=lambda value: record))
    result = product.client.post("/api/cendos/protocols/metformin-cohorts", headers=HEADERS,
        json={"cohort_a_id": "cohort-reference", "cohort_b_id": "cohort-reference"})
    assert result.status_code == 422 and result.json()["code"] == "REFERENCE_MODEL_BINDING_REQUIRED"


@pytest.mark.parametrize("protocol", ["metformin", "pxr"])
def test_direct_cendos_exposes_same_reference_gate_without_persistence(product, monkeypatch, protocol):
    from fastapi.testclient import TestClient
    from livemorebio.cendos import service
    monkeypatch.setattr(service, "_protocol_store", lambda: pytest.fail("unbound reference persisted"))
    reference = {"source_class": "PUBLIC_REFERENCE", "executable": False}
    path = "/protocols/metformin-cohorts" if protocol == "metformin" else "/protocols/garcinoic-pxr"
    body = {"cohort_a": reference, "cohort_b": reference} if protocol == "metformin" else {"cohort": reference}
    result = TestClient(service.app).post(path, json=body, headers=HEADERS)
    assert result.status_code == 422 and result.json()["code"] == "REFERENCE_MODEL_BINDING_REQUIRED"
