"""Workflow contract lint; only hosted runs establish running-image behaviour."""
from pathlib import Path
import re
import shlex
import subprocess
import textwrap

import pytest

from ._node import REQUIRE_NODE_ENV
from ._source_tree import CONTAINER_IMAGE_PATHS, source_tree_only, summary_report_characters


@source_tree_only(".github/workflows/installer.yml")
def test_runner_model_directory_is_initialized_inside_a_running_step():
    source = (Path(__file__).parents[2] / ".github/workflows/installer.yml").read_text(encoding="utf-8")
    job_env = re.search(r"^    env:\n(.*?)^    steps:", source, re.M | re.S).group(1)
    assert "runner." not in job_env
    assert '"$RUNNER_TEMP"' in source
    assert '>> "$GITHUB_ENV"' in source


@source_tree_only(".github/workflows/platforms.yml", "docker-compose.yml")
def test_the_container_stack_can_be_torn_down_whichever_step_failed():
    """`docker compose down` resolves docker-compose.yml before it does anything,
    and the file refuses to resolve without the four local keys. The teardown
    runs `if: always()`, so the keys have to exist before the first step that
    can fail. They were generated after the image build, so a failed build was
    reported twice: once truthfully, and once as a missing
    LIVEMORE_PATCH_ADMISSION_HMAC_KEY that nothing was actually wrong with."""
    root = Path(__file__).parents[2]
    workflow = (root / ".github/workflows/platforms.yml").read_text(encoding="utf-8")
    container = workflow[workflow.index("  container:\n"):workflow.index("  windows-native:\n")]
    steps = re.findall(r"^      - name: (.+)$", container, re.M)
    teardown = container[container.index("      - name: Stop the stack\n"):]
    assert "if: always()" in teardown and "docker compose down" in teardown

    compose = (root / "docker-compose.yml").read_text(encoding="utf-8")
    for key in ("LIVEMORE_API_TOKEN", "LIVEMORE_PATCH_STORAGE_KEY",
                "LIVEMORE_PATCH_ADMISSION_HMAC_KEY", "LIVEMORE_SERVICE_IDENTITY_KEY"):
        assert f"${{{key}:?" in compose, key
        assert f"printf '{key}=" in container, key
    assert steps[0] == "Generate ephemeral local keys", steps


def _installer_job() -> tuple[str, str]:
    source = (Path(__file__).parents[2] / ".github/workflows/installer.yml").read_text(encoding="utf-8")
    return source, re.search(r"^    env:\n(.*?)^    steps:", source, re.M | re.S).group(1)


@source_tree_only(".github/workflows/installer.yml")
def test_the_release_gate_installs_one_node_and_fails_without_it():
    """This job is where the tests of the console's JavaScript are meant to run.

    It took whatever Node.js the runner image happened to ship, a different
    major on each system, and asked nothing. Had an image stopped shipping one,
    1184 tests would have skipped and the gate would have stayed green with no
    JavaScript test executed. So it installs one major itself, and declares
    that a run with no Node.js is a failure rather than a skip."""
    source, job_env = _installer_job()
    assert f'      {REQUIRE_NODE_ENV}: "1"\n' in job_env

    setup = re.search(r'^      - uses: actions/setup-node@v\d+\n        with:\n          node-version: "(\d+)"\n',
                      source, re.M)
    assert setup, "actions/setup-node pinned to one major version"
    # One system, one major: no range, no alias that moves, no per-system matrix.
    assert source.count("actions/setup-node@") == 1 and "node-version: ${{" not in source
    assert source.index(setup.group(0)) < source.index("-m pytest")


@source_tree_only(".github/workflows/installer.yml")
def test_the_native_linux_gate_names_its_ubuntu_release():
    """``ubuntu-latest`` names no release, as ``python:3.11-slim`` named none.

    This job installs whatever libsundials-dev its runner's release ships, and
    the image's Debian base is chosen to match it: Ubuntu 24.04 and Debian 12
    both ship 6.4.1. Ubuntu 26.04 ships 7.1.1+dfsg1-10build3, a rebuild of the
    Debian source the image could not compile the cardiac kernel against. When
    the label moves to it, this gate moves with it and nothing here will have
    changed, which is the defect the image's base had.

    The macOS leg still names none. Homebrew installs its current SUNDIALS
    whichever macOS it runs on, so naming that release would not hold the
    version still."""
    source, _ = _installer_job()
    said = "\n".join(line for line in source.splitlines() if not line.lstrip().startswith("#"))
    (systems,) = re.findall(r"^        os: \[(.+)\]$", said, re.M)

    assert [system.strip() for system in systems.split(",")] == ["ubuntu-24.04", "macos-latest"]
    assert "runs-on: ${{ matrix.os }}\n" in said and "ubuntu-latest" not in said


class _Expression:
    """Enough of GitHub's expression language to read the three expressions the
    Installer workflow decides its legs with.

    It is a model of the documented semantics and not GitHub's evaluator: `&&`
    and `||` give back an operand, a missing property is null, strings compare
    without regard to case, and operands of two types are compared as numbers,
    where null is 0 and an object is not a number. What GitHub itself does with
    the text is shown by a hosted run and by nothing here."""

    _TOKEN = re.compile(r"\s*(\|\||&&|==|!=|[!(),]|'(?:[^']|'')*'|[A-Za-z_][\w.*-]*)")

    def __init__(self, text: str, github: dict) -> None:
        self._tokens, position = [], 0
        while position < len(text):
            found = self._TOKEN.match(text, position)
            assert found, text[position:]
            self._tokens.append(found.group(1))
            position = found.end()
        self._github = github

    def value(self) -> object:
        result = self._either()
        assert not self._tokens, self._tokens
        return result

    @staticmethod
    def _true(value: object) -> bool:
        return value not in (None, False, 0, "")

    def _take(self, token: str) -> bool:
        if self._tokens and self._tokens[0] == token:
            del self._tokens[0]
            return True
        return False

    def _either(self) -> object:
        left = self._both()
        while self._take("||"):
            right = self._both()
            left = left if self._true(left) else right
        return left

    def _both(self) -> object:
        left = self._compared()
        while self._take("&&"):
            right = self._compared()
            left = right if self._true(left) else left
        return left

    def _compared(self) -> object:
        left = self._negated()
        for operator in ("==", "!="):
            if self._take(operator):
                return self._equal(left, self._negated()) is (operator == "==")
        return left

    def _negated(self) -> object:
        if self._take("!"):
            return not self._true(self._negated())
        if self._take("("):
            inner = self._either()
            assert self._take(")")
            return inner
        token = self._tokens.pop(0)
        if token.startswith("'"):
            return token[1:-1].replace("''", "'")
        if token in ("null", "true", "false"):
            return {"null": None, "true": True, "false": False}[token]
        if self._take("("):
            arguments = []
            while not self._take(")"):
                arguments.append(self._either())
                self._take(",")
            return self._call(token, arguments)
        return self._property(token)

    def _property(self, path: str) -> object:
        context, *names = path.split(".")
        assert context == "github", path
        found: object = self._github
        for name in names:
            if name == "*":
                continue
            if isinstance(found, list):
                found = [item.get(name) for item in found]
            else:
                found = found.get(name) if isinstance(found, dict) else None
        return found

    @staticmethod
    def _call(name: str, arguments: list) -> object:
        if name == "contains":
            held, wanted = arguments
            return any(str(item).lower() == str(wanted).lower() for item in held or [])
        assert name == "format", name
        return arguments[0].replace("{0}", str(arguments[1]))

    @classmethod
    def _equal(cls, left: object, right: object) -> bool:
        if isinstance(left, str) and isinstance(right, str):
            return left.lower() == right.lower()
        if type(left) is type(right) and not isinstance(left, (dict, list)):
            return left == right
        numbers = [cls._number(side) for side in (left, right)]
        return None not in numbers and numbers[0] == numbers[1]

    @staticmethod
    def _number(value: object) -> float | None:
        if value is None or value == "":
            return 0.0
        if isinstance(value, bool):
            return float(value)
        return None


_MACOS_LEG = ("(github.event_name != 'pull_request'"
              " || contains(github.event.pull_request.labels.*.name, 'gate:macos')"
              " || (!github.event.pull_request.draft"
              " && (github.base_ref == 'main' || github.base_ref == 'codex/public-distribution')))"
              " && 'none' || 'macos-latest'")
_STARTS_NOTHING = ("(github.event.action == 'labeled' && github.event.label.name != 'gate:macos')"
                   " || (github.event.action == 'edited' && github.event.changes.base == null)")


def _installer_decisions() -> tuple[str, str, str, str]:
    source, _ = _installer_job()
    said = "\n".join(line for line in source.splitlines() if not line.lstrip().startswith("#"))
    (excluded,) = re.findall(r"^        exclude:\n          - os: \$\{\{ (.+) \}\}$", said, re.M)
    (condition,) = re.findall(r"^  installer-and-release-gate:\n    if: \$\{\{ (.+) \}\}$", said, re.M)
    (group,) = re.findall(r"^concurrency:\n  group: (.+)$", said, re.M)
    return said, excluded, condition, group


def _pull_request(action: str, base: str, *, draft: bool, labels: tuple[str, ...] = (),
                  label: str | None = None, base_changed: bool = False) -> dict:
    event: dict = {"action": action,
                   "pull_request": {"number": 17, "draft": draft, "labels": [{"name": name} for name in labels]}}
    if label is not None:
        event["label"] = {"name": label}
    if action == "edited":
        event["changes"] = {"base": {"ref": {"from": "v1/integration"}}} if base_changed else {"title": {"from": "x"}}
    return {"event_name": "pull_request", "base_ref": base, "ref": "refs/pull/17/merge", "run_id": 901, "event": event}


_STABLE, _MAIN, _LANE = "codex/public-distribution", "main", "v1/integration"
_LEGS = {"both": {"ubuntu-24.04", "macos-latest"}, "linux": {"ubuntu-24.04"}, "none": set()}
_EVENTS = [
    # Drafts and lanes: the Linux leg, on every push.
    *[(f"{action} draft into {base}", _pull_request(action, base, draft=True), "linux")
      for action in ("opened", "synchronize", "reopened") for base in (_MAIN, _STABLE, _LANE)],
    *[(f"{action} into the lane", _pull_request(action, _LANE, draft=False), "linux")
      for action in ("opened", "synchronize", "reopened", "ready_for_review")],
    # Where a release is decided: both legs.
    *[(f"{action} ready into {base}", _pull_request(action, base, draft=False), "both")
      for action in ("opened", "synchronize", "reopened", "ready_for_review") for base in (_MAIN, _STABLE)],
    # A pull request moved onto the stable line is decided there from then on.
    ("retargeted onto the stable line", _pull_request("edited", _STABLE, draft=False, base_changed=True), "both"),
    ("retargeted onto a lane", _pull_request("edited", _LANE, draft=False, base_changed=True), "linux"),
    # Asked for by the label, on the event that adds it and on every later one.
    *[(f"gate:macos added, draft {draft}, into {base}",
       _pull_request("labeled", base, draft=draft, labels=("gate:macos",), label="gate:macos"), "both")
      for draft in (True, False) for base in (_MAIN, _STABLE, _LANE)],
    ("a push to a labelled draft on a lane", _pull_request("synchronize", _LANE, draft=True, labels=("gate:macos",)), "both"),
    # Events that ask for nothing start nothing, and cancel nothing.
    ("another label", _pull_request("labeled", _STABLE, draft=False, labels=("documentation",), label="documentation"), "none"),
    ("another label beside the gate label",
     _pull_request("labeled", _LANE, draft=True, labels=("gate:macos", "documentation"), label="documentation"), "none"),
    ("a title edited", _pull_request("edited", _STABLE, draft=False), "none"),
    # Not a pull request: both legs.
    ("a push to main", {"event_name": "push", "base_ref": "", "ref": "refs/heads/main", "run_id": 902, "event": {}}, "both"),
    ("started by hand", {"event_name": "workflow_dispatch", "base_ref": "", "ref": "refs/heads/v1/integration",
                         "run_id": 903, "event": {"inputs": None}}, "both"),
]


@source_tree_only(".github/workflows/installer.yml")
def test_the_installer_workflow_states_its_three_decisions_in_these_words():
    """The words are held whole. A test that looked for each clause somewhere in
    the expression passed with `true ||` written in front of it, which runs the
    macOS leg on every push, and with `false &&`, which never runs it."""
    said, excluded, condition, group = _installer_decisions()

    assert excluded == _MACOS_LEG
    assert condition == f"!({_STARTS_NOTHING})"
    assert group == ("installer-${{ github.event.pull_request.number || github.ref }}"
                     f"${{{{ ({_STARTS_NOTHING}) && format('-starts-nothing-{{0}}', github.run_id) || '' }}}}")
    assert "  cancel-in-progress: ${{ github.event_name == 'pull_request' }}\n" in said

    # The matrix is the two systems less that one entry. A second entry could
    # leave the Linux leg out, and an `include` is applied after the exclusion
    # and could put the macOS leg back on every push; the table below would
    # pass with either, because it reads the first entry only.
    matrix = said[said.index("      matrix:\n"):said.index("    runs-on: ${{ matrix.os }}\n")]
    assert re.findall(r"^        (\w+):", matrix, re.M) == ["os", "exclude"]
    assert len(re.findall(r"^          - ", matrix, re.M)) == 1

    triggers = said[said.index("\non:\n"):said.index("\njobs:\n")]
    assert re.search(r"^  workflow_dispatch:$", triggers, re.M), "the legs can be asked for by hand"
    (types,) = re.findall(r"^    types: \[(.+)\]$", triggers, re.M)
    assert {kind.strip() for kind in types.split(",")} == {
        "opened", "synchronize", "reopened", "ready_for_review", "labeled", "edited"}


@source_tree_only(".github/workflows/installer.yml")
@pytest.mark.parametrize("event, legs", [pytest.param(event, legs, id=name) for name, event, legs in _EVENTS])
def test_the_macos_leg_runs_where_a_release_is_decided_and_where_it_is_asked_for(event: dict, legs: str):
    """A hosted macOS minute is billed as ten Linux minutes. On 2026-10-04 this
    leg ran on every push to every pull request, seventeen times, and was 2,500
    of the 3,031 minutes billed that day; the account's limit was reached twice
    and GitHub then started no job at all, so no gate ran on anything.

    The leg is the proof that the product installs on a Mac that is not the
    author's, and that is asked where a release is decided: on a pull request
    into the stable line or into main that is not a draft, and on a push to
    main. Anywhere else it runs when someone asks, by the label or by hand. The
    Linux leg runs wherever anything runs.

    An event that asks for nothing (another label, an edited title) starts no
    job. It must also cancel nothing, or adding a label would end a release
    run and put nothing in its place: so it is given a group of its own."""
    _, excluded, condition, group = _installer_decisions()

    runs = _Expression(condition, event).value() is True
    left_out = _Expression(excluded, event).value()
    assert left_out in ("none", "macos-latest")
    assert ({"ubuntu-24.04", "macos-latest"} - {left_out} if runs else set()) == _LEGS[legs]

    def group_of(github: dict) -> str:
        return "".join(str(_Expression(part, github).value()) if index % 2 else part
                       for index, part in enumerate(re.split(r"\$\{\{ (.+?) \}\}", group)))

    in_progress = group_of(_pull_request("synchronize", event.get("base_ref") or _STABLE, draft=False))
    if event["event_name"] != "pull_request":
        assert group_of(event) == f"installer-{event['ref']}"
    elif runs:
        assert group_of(event) == in_progress == "installer-17", "it replaces the run on the earlier event"
    else:
        assert group_of(event) == "installer-17-starts-nothing-901" != in_progress


@source_tree_only(".github/workflows/installer.yml")
def test_the_release_gate_names_every_failure_and_error_and_says_why_each_test_was_skipped():
    """``-rs`` alone lists the skips and stops listing failures and errors by
    name, because ``-r`` replaces pytest's default. A failed gate then shows a
    count, and a reader has to search the log for what the count refers to."""
    source, _ = _installer_job()
    runs = [line.strip() for line in source.splitlines() if "-m pytest" in line]

    assert len(runs) >= 2
    for run in runs:
        assert summary_report_characters(run) >= {"f", "E", "s"}, run


@source_tree_only("install.sh", "Dockerfile", "docker-compose.yml", ".github/workflows/platforms.yml")
def test_nothing_that_installs_or_builds_the_product_sets_the_node_requirement():
    """Node.js is not a prerequisite of the product. With LIVEMORE_REQUIRE_NODE
    unset, a client without Node.js still installs, and the image, whose base
    has none, still builds: both run this suite and refuse on a failure, and
    neither sets the switch that turns the skip into one.

    That is as far as this goes, and it used to be put more strongly than it
    had been shown. The installer hands its verification run the environment
    it was started in, the switch included. A caller that exported 1 gets a
    strict verification, which fails an install on a host with no Node.js, and
    a value that is not 0 or 1 stops the suite before its first test. That is
    kept on purpose: a run that sets 1 to prove the console's JavaScript was
    exercised must not have it dropped when it verifies an install.
    ``test_installer`` holds the installer to handing the value on unchanged,
    and ``test_node_gate`` holds each inherited value to what it does.

    The image inherits nothing. A build takes no variable from the shell that
    started it unless the Dockerfile declares one, and it declares none."""
    root = Path(__file__).parents[2]
    for name in ("install.sh", "Dockerfile", "docker-compose.yml", ".github/workflows/platforms.yml"):
        assert REQUIRE_NODE_ENV not in (root / name).read_text(encoding="utf-8"), name
    dockerfile = [line.split() for line in (root / "Dockerfile").read_text(encoding="utf-8").splitlines()]
    assert not [words for words in dockerfile if words and words[0] == "ARG"]
    compose = (root / "docker-compose.yml").read_text(encoding="utf-8")
    assert "args:" not in compose


def _container_job() -> tuple[str, str]:
    workflow = (Path(__file__).parents[2] / ".github/workflows/platforms.yml").read_text(encoding="utf-8")
    return workflow, workflow[workflow.index("  container:\n"):workflow.index("  windows-native:\n")]


def _step(job: str, name: str) -> str:
    return re.search(rf"^      - name: {re.escape(name)}\n(.*?)(?=^      - name: |\Z)", job, re.M | re.S).group(1)


@source_tree_only(".github/workflows/platforms.yml", "docker-compose.yml")
def test_the_stack_that_starts_is_the_image_the_build_step_verified():
    """The workflow built ``livemorebio:ci`` and docker-compose.yml runs
    ``livemorebio:latest``. ``docker compose up -d`` found no such image and
    built it again through the ``life`` service's ``build: .``. So the stack ran
    a second build rather than the one the build step had verified, and the
    whole suite ran twice whenever the layer cache missed."""
    _, container = _container_job()
    compose = (Path(__file__).parents[2] / "docker-compose.yml").read_text(encoding="utf-8")
    # One image for all three services, and exactly one service that builds it.
    assert len(set(re.findall(r"^    image: (\S+)$", compose, re.M))) == 1
    assert len(re.findall(r"^    build: ", compose, re.M)) == 1

    commands = "\n".join(line for line in container.splitlines() if not line.lstrip().startswith("#"))
    # Built through compose, so the tag is the one compose runs, whatever it is.
    assert "run: docker compose build\n" in _step(container, "Build the image")
    assert "docker build" not in commands
    # Started from that image, or not at all: never built again here.
    assert "run: docker compose up -d --no-build\n" in _step(container, "Start the three services")
    assert commands.count("docker compose up") == 1


@source_tree_only(".github/workflows/platforms.yml", "Dockerfile")
def test_a_change_to_anything_the_image_is_built_from_builds_the_image():
    """The pull-request filter left out tools/ and models/, which the Dockerfile
    copies, so a change to either could break the image without this job running."""
    root = Path(__file__).parents[2]
    workflow, _ = _container_job()
    filtered = re.search(r"^  pull_request:\n    paths:\n(.*?)^  push:", workflow, re.M | re.S).group(1)
    paths = {line.split("- ", 1)[1].strip().strip('"') for line in filtered.splitlines()
             if line.strip().startswith("- ")}

    for carried in CONTAINER_IMAGE_PATHS:
        assert (f"{carried}/**" if (root / carried).is_dir() else carried) in paths, carried
    for described in ("Dockerfile", "docker-compose.yml", ".github/workflows/platforms.yml"):
        assert described in paths, described


def _public_container_job() -> str:
    workflow = (Path(__file__).parents[2] / ".github/workflows/platforms.yml").read_text(encoding="utf-8")
    match = re.search(r"^  public-container:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)",
                      workflow, re.M | re.S)
    assert match, "the client's public archive needs its own container gate"
    return match.group(1)


@source_tree_only(".github/workflows/platforms.yml")
def test_public_container_gate_builds_the_publisher_archive_of_the_checked_out_commit():
    job = _public_container_job()
    assert "- uses: actions/checkout@v4" in job
    archive = _step(job, "Build and unpack the public release")
    assert 'commit="$(git rev-parse HEAD)"' in archive
    assert ('python3 tools/build_release.py --audience public --ref "$commit" '
            '--output "$release_output"') in archive
    assert 'release_output="$RUNNER_TEMP/livemore-public-release"' in archive
    assert 'public_source="$RUNNER_TEMP/livemore-public-source"' in archive
    assert ('tar -xzf "$release_output/livemorebio-$commit.tar.gz" '
            '--strip-components=1 -C "$public_source"') in archive
    assert '.tar.gz*' not in archive and '*.tar.gz' not in archive
    assert 'test -f "$public_source/.livemore-distribution.json"' in archive
    assert 'test -f "$public_source/docker-compose.yml"' in archive
    exported = 'printf \'LIVEMORE_PUBLIC_CONTAINER_SOURCE=%s\\n\' "$public_source" >> "$GITHUB_ENV"'
    assert exported in archive
    assert archive.index("tar -xzf") < archive.index("test -f") < archive.index(exported)


@source_tree_only(".github/workflows/platforms.yml", "docker-compose.yml")
def test_public_container_gate_generates_keys_before_build_and_uses_one_projection():
    job = _public_container_job()
    steps = re.findall(r"^      - name: (.+)$", job, re.M)
    assert steps[0] == "Generate ephemeral local keys", steps
    assert steps.index("Generate ephemeral local keys") < steps.index("Build and unpack the public release")
    assert steps.index("Build and unpack the public release") < steps.index("Build the public image")
    keys = _step(job, "Generate ephemeral local keys")
    for key in ("LIVEMORE_API_TOKEN", "LIVEMORE_PATCH_STORAGE_KEY",
                "LIVEMORE_PATCH_ADMISSION_HMAC_KEY", "LIVEMORE_SERVICE_IDENTITY_KEY"):
        assert f"printf '{key}=" in keys, key
    for name, command in (("Build the public image", "docker compose build"),
                          ("Start the three public services", "docker compose up -d --no-build")):
        step = _step(job, name)
        assert "working-directory: ${{ env.LIVEMORE_PUBLIC_CONTAINER_SOURCE }}" in step
        assert f"run: {command}\n" in step
    assert job.count("docker compose up") == 1
    assert "docker build" not in job


@source_tree_only(".github/workflows/platforms.yml")
def test_public_container_gate_bounds_health_wait_and_tears_down_only_its_projection():
    job = _public_container_job()
    health = _step(job, "Wait for public services health")
    assert "working-directory: ${{ env.LIVEMORE_PUBLIC_CONTAINER_SOURCE }}" in health
    for guard in ("for service in aegle:8850 life:8851 cendos:8852", 'role="${service%:*}"',
                  'port="${service#*:}"', 'python3 tools/stack_request.py --role "$role"',
                  '--url "http://127.0.0.1:$port" --wait-seconds 120',
                  "docker compose logs --tail 80", "exit 1"):
        assert guard in health, guard
    teardown = _step(job, "Stop the public stack")
    assert "if: always()" in teardown
    assert '[ -n "${LIVEMORE_PUBLIC_CONTAINER_SOURCE:-}" ]' in teardown
    assert '[ -f "$LIVEMORE_PUBLIC_CONTAINER_SOURCE/docker-compose.yml" ]' in teardown
    assert 'cd "$LIVEMORE_PUBLIC_CONTAINER_SOURCE"' in teardown
    assert "docker compose down -v" in teardown
    assert teardown.index('if [') < teardown.index('cd "') < teardown.index("docker compose down -v")
    assert "working-directory:" not in teardown


@source_tree_only(".github/workflows/platforms.yml")
def test_container_docs_keep_private_images_out_of_client_distribution():
    readme = (Path(__file__).parents[2] / "README.md").read_text(encoding="utf-8")
    assert "Clients build the image from the public release" in readme
    assert "Images built from a private checkout are for private use only" in readme
    assert "must not be distributed" in readme


@source_tree_only('.github/workflows/installer.yml')
def test_installer_workflow_triggers_for_every_release_contract_input():
    source, _ = _installer_job()
    root = Path(__file__).parents[2]
    manifest = (root / 'tools/public_release_manifest.txt').read_text(encoding="utf-8").splitlines()
    # The marker is generated, not a checkout input; its publisher is the input
    # whose changes can change its shipped bytes.
    generated_by = {'.livemore-distribution.json': 'tools/build_release.py'}
    required = {generated_by.get(path, path) for path in manifest if not path.endswith('/')}
    assert set(generated_by) <= set(manifest)
    for event in ('pull_request', 'push'):
        block = re.search(rf'^  {event}:\n(.*?)(?=^  \w+:|^permissions:)', source, re.M | re.S).group(1)
        paths = {line.strip().removeprefix('- ').strip('"') for line in block.splitlines()
                 if line.strip().startswith('- ')}
        missing = sorted(path for path in required
                         if not any(_workflow_path_matches(path, pattern) for pattern in paths))
        assert missing == [], f'{event}: shipped files without Installer coverage: {missing}'
        assert {'Dockerfile', 'docker-compose.yml', '.github/workflows/platforms.yml',
                'LICENSE', 'THIRD_PARTY_NOTICES.md', 'models/**', 'notebooks/**',
                '.gitattributes', 'dist-public/**'} <= paths


def _workflow_path_matches(path: str, pattern: str) -> bool:
    # These filters use only literals, * (one path component) and ** (any path).
    # Refuse new syntax rather than silently accepting a different glob language.
    assert not any(character in pattern for character in '![]?+\\'), pattern
    expression = re.escape(pattern).replace(r'\*\*', '\x00').replace(r'\*', '[^/]*').replace('\x00', '.*')
    return re.fullmatch(expression, path) is not None


@source_tree_only('.github/workflows/installer.yml')
def test_workflow_path_matching_respects_directory_boundaries():
    assert _workflow_path_matches('Livemore Console.command', '*.command')
    assert not _workflow_path_matches('nested/Livemore Console.command', '*.command')
    assert _workflow_path_matches('livemorebio/tests/fixture.json', 'livemorebio/**')
    assert not _workflow_path_matches('.gitignore-extra', '.gitignore')


@source_tree_only('.github/workflows/installer.yml')
def test_installer_fetches_and_requires_published_history_before_the_complete_suite():
    source, job_env = _installer_job()
    fetch = _step(source, 'Fetch published compatibility history')
    assert 'git fetch --depth 1 origin refs/tags/stable-6588707:refs/tags/stable-6588707' in fetch
    assert re.search(r'(?m)^    timeout-minutes: 75$', source)
    required = _step(source, 'Verify all published condition labels')
    assert 'LIVEMORE_REQUIRE_STABLE_HISTORY: "1"' in required
    assert 'test_seed_consumer_rework.py' in required
    assert '-k all_twenty_published_labels' in required
    assert source.index('name: Fetch published compatibility history') < source.index('name: Verify all published condition labels')
    assert source.index('name: Verify all published condition labels') < source.index('name: Run complete release gate')
    # Nested image gates have no history; strictness belongs to the hosted
    # compatibility step and must not leak into those child environments.
    assert 'LIVEMORE_REQUIRE_STABLE_HISTORY' not in job_env


@source_tree_only('.github/workflows/installer.yml')
@pytest.mark.parametrize('failure, expected_commands, succeeds', [
    ('none', ('update', 'install'), True),
    ('update-once', ('update', 'update', 'install'), True),
    ('install-once', ('update', 'install', 'update', 'install'), True),
    ('update-always', ('update', 'update'), False),
    ('install-always', ('update', 'install', 'update', 'install'), False),
])
def test_ubuntu_dependency_install_is_bounded_and_retries_the_whole_sequence(
    failure, expected_commands, succeeds,
):
    source, _ = _installer_job()
    step = _step(source, 'Install Ubuntu system dependencies')
    assert re.search(r'(?m)^        timeout-minutes: 20$', step)
    script = textwrap.dedent(step.split('        run: |\n', 1)[1])
    # Run the actual workflow shell with a function double: no apt or sudo
    # process is launched, including the permanent-failure cases.
    stub = '''
invocations=0
sudo() {
    invocations=$((invocations + 1))
    printf '%s\\n' "$*"
    case "FAILURE:$invocations" in
        update-once:1|install-once:2|update-always:*|install-always:2|install-always:4)
            return 42 ;;
    esac
}
'''.replace('FAILURE', failure)
    result = subprocess.run(['/bin/bash', '-c', stub + script],
                            capture_output=True, text=True, encoding='utf-8', timeout=10)
    commands = {
        'update': 'apt-get -o Acquire::Retries=5 update',
        'install': 'apt-get -o Acquire::Retries=5 install -y --no-install-recommends libsundials-dev shellcheck',
    }
    assert result.stdout.splitlines() == [commands[command] for command in expected_commands]
    assert (result.returncode == 0) is succeeds


@source_tree_only('.github/workflows/installer.yml', '.github/workflows/platforms.yml')
def test_every_hosted_job_has_an_explicit_bounded_timeout_and_stable_push_trigger():
    for relative in ('.github/workflows/installer.yml', '.github/workflows/platforms.yml'):
        source = (Path(__file__).parents[2] / relative).read_text(encoding="utf-8")
        assert re.search(r'branches: \[[^\]]*codex/public-distribution[^\]]*\]', source)
        jobs = re.findall(r'^  [a-z][a-z-]*:\n(.*?)(?=^  [a-z][a-z-]*:|\Z)',
                          source.split('jobs:\n', 1)[1], re.M | re.S)
        assert jobs
        for job in jobs:
            timeout = re.search(r'^    timeout-minutes: (\d+)$', job, re.M)
            # L0-R21: the suite outgrew 45 minutes on hosted x86_64; 75 is the ceiling.
            assert timeout and 0 < int(timeout.group(1)) <= 75


@source_tree_only('.github/workflows/platforms.yml')
def test_container_api_requests_have_explicit_deadlines():
    workflow, _ = _container_job()
    shell = re.sub(r"\\\r?\n", " ", workflow)
    commands = []
    for line in shell.splitlines():
        if "python3 tools/stack_request.py" in line:
            lexer = shlex.shlex(line, posix=True, punctuation_chars=";")
            lexer.whitespace_split = True
            words = list(lexer)
            end = words.index(";") if ";" in words else len(words)
            commands.append(words[words.index("tools/stack_request.py") + 1:end])
    # Each independent container job probes health plus all three named calls.
    assert len(commands) == 8
    for command in commands:
        assert command.count("--url") == 1, command
        if "--wait-seconds" in command:
            assert command[command.index("--wait-seconds") + 1] == "120", command
        else:
            assert command.count("--timeout") == 1, command
            assert command[command.index("--timeout") + 1] == "60", command


@source_tree_only('.github/workflows/platforms.yml')
def test_public_container_runs_insulin_controls_after_health_before_teardown():
    job = _public_container_job()
    steps = re.findall(r"^      - name: (.+)$", job, re.M)
    name = "Run a six-program workflow through the container API"
    assert name in steps
    assert (steps.index("Wait for public services health")
            < steps.index("Authenticate through the published port")
            < steps.index(name) < steps.index("Stop the public stack"))
    protocol = _step(job, name)
    assert "working-directory: ${{ env.LIVEMORE_PUBLIC_CONTAINER_SOURCE }}" in protocol
    assert "set -euo pipefail" in protocol
    assert "docker compose exec -T aegle python - <<'PY'" in protocol
    assert 'platform = Platform(mode="attach")' in protocol
    assert 'platform.run_insulin_protocol({"cohort_size": 4, "seed": 1})' in protocol
    assert 'assert insulin["controls"] and all(control["passed"] for control in insulin["controls"])' in protocol


@source_tree_only(".github/workflows/installer.yml")
def test_l0_hosted_browser_gate_installs_and_exports_the_pinned_playwright_module():
    """A Node-only host otherwise skips all package-dependent browser cases."""
    source, _ = _installer_job()
    setup = _step(source, "Install pinned Playwright test runtime")
    assert 'playwright_root="$RUNNER_TEMP/livemore-playwright"' in setup
    assert 'npm install --prefix "$playwright_root" --no-audit --no-fund --ignore-scripts --save-exact playwright@1.58.2' in setup
    assert 'node "$playwright_root/node_modules/playwright/cli.js" install --with-deps chromium' in setup
    assert 'LIVEMORE_PLAYWRIGHT_MODULE=%s' in setup
    assert '"$playwright_root/node_modules/playwright/index.js" >> "$GITHUB_ENV"' in setup
    preflight = _step(source, "Check pinned Playwright runtime before the gate")
    assert 'h.readVisibilityRuntime(process.env.LIVEMORE_PLAYWRIGHT_MODULE)' in preflight
    assert 'h.validateVisibilityRuntime' in preflight
    assert 'chromium.executablePath()' in preflight and 'accessSync' in preflight
    assert source.index('name: Install pinned Playwright test runtime') < source.index('name: Check pinned Playwright runtime before the gate') < source.index('name: Run complete release gate')


@source_tree_only(".github/workflows/installer.yml")
def test_l0_hosted_gate_runs_the_explicit_official_model_download():
    _, job_env = _installer_job()
    assert '      LIVEMORE_TEST_MODEL_DOWNLOAD: "1"' in job_env
