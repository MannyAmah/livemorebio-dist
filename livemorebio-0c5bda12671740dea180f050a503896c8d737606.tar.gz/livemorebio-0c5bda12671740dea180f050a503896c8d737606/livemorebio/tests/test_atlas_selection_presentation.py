"""Authored overlapping triangles, pinned THREE math; no GPU or human anatomy QA."""
from __future__ import annotations

import base64
import json

import pytest

from .test_atlas_reference_ui import CONSOLE, node
from .test_atlas_reference_geometry import technical_obj, replace_source


def scene_program(checks: str) -> str:
    from livemorebio.anatomy import _atlas_geometry as geometry

    raw, member = technical_obj()
    other_raw, other = replace_source(raw, member, b"FJ2810", b"FJ2811")
    other["element_id"] = "FJ2811"
    parts = [geometry.parse_obj(raw, member), geometry.parse_obj(other_raw, other)]
    content = geometry.convert_partition("pancreas", parts)
    audit = geometry.verify_partition(content, "pancreas", parts)
    return f"""
import assert from 'node:assert/strict';
import * as vendor from {json.dumps((CONSOLE/'lib/anatomy_vendor.js').as_uri())};
import {{createAtlasReferenceScene}} from {json.dumps((CONSOLE/'lib/atlas_reference_scene.js').as_uri())};
globalThis.fetch=()=>{{throw Error('No network in authored scene test')}};
const elements=[],observers=[],queued=new Map(),selected=[];
let sequence=0,rendered=null,camera=null,renderer=null,disposed=0,rayTargets=[];
class E {{
 constructor(){{this.clientWidth=600;this.clientHeight=600;this.style={{}};this.handlers={{}};this.children=[];this.hidden=false;this.attributes={{}};elements.push(this)}}
 setAttribute(k,v){{this.attributes[k]=v}} addEventListener(k,v){{this.handlers[k]=v}} removeEventListener(k){{delete this.handlers[k]}}
 replaceChildren(...items){{this.children=items}} append(...items){{this.children.push(...items)}}
 getBoundingClientRect(){{return this.className==='atlas-reference-selection-label'
   ? {{width:Math.min(190,parseFloat(this.style.maxWidth)||190),height:20}}
   : {{left:0,top:0,width:this.clientWidth,height:this.clientHeight}}}}
}}
globalThis.document={{hidden:false,createElement:()=>new E()}};
globalThis.window={{devicePixelRatio:1}};
globalThis.ResizeObserver=class{{constructor(callback){{observers.push(callback)}}observe(){{}}disconnect(){{}}}};
globalThis.requestAnimationFrame=fn=>{{queued.set(++sequence,fn);return sequence}};
globalThis.cancelAnimationFrame=id=>queued.delete(id);
class Renderer {{
 constructor(){{renderer=this;this.domElement=new E();this.info={{render:{{calls:2,triangles:2}},memory:{{geometries:2}}}}}}
 setPixelRatio(v){{this.dpr=v}}getPixelRatio(){{return this.dpr}}setSize(){{}}
 render(scene,cam){{scene.updateMatrixWorld(true);cam.updateMatrixWorld(true);rendered=scene;camera=cam}}
 dispose(){{disposed++}}forceContextLoss(){{}}
}}
class Controls {{constructor(){{this.target=new vendor.THREE.Vector3()}}addEventListener(){{}}removeEventListener(){{}}update(){{}}dispose(){{}}}}
class Raycaster extends vendor.THREE.Raycaster {{intersectObjects(objects){{rayTargets=objects;return objects.filter(o=>o.userData.element_id==='FJ2811').map(object=>({{object,point:new vendor.THREE.Vector3()}}))}}}}
const host=new E(),manifest={{members:{json.dumps([member,other])},assets:[{{asset_key:'pancreas',audit:{json.dumps(audit)}}}]}};
const bytes=Uint8Array.from(Buffer.from({json.dumps(base64.b64encode(content).decode())},'base64')).buffer;
const config={{host,vendor:{{...vendor,THREE:{{...vendor.THREE,WebGLRenderer:Renderer,Raycaster}},OrbitControls:Controls}},manifest,onSelect:id=>selected.push(id)}};
const view=createAtlasReferenceScene(config);
const flush=()=>{{for(const [id,fn] of [...queued]){{queued.delete(id);fn()}}assert.equal(queued.size,0,'idle loop scheduled')}};
const find=name=>elements.find(e=>e.className===name);
const mesh=id=>{{let result;rendered.traverse(o=>{{if(o.isMesh&&o.userData.element_id===id)result=o}});return result}};
const capture=o=>JSON.stringify({{position:[...o.geometry.attributes.position.array],normal:[...o.geometry.attributes.normal.array],index:[...o.geometry.index.array],matrix:o.matrix.elements,world:o.matrixWorld.elements,source:o.userData.source_sha256}});
await view.addPartition(manifest.assets[0],bytes);flush();
try{{{checks}}}finally{{view.dispose()}}
console.log('ok');
"""


def test_selection_preserves_coincident_source_meshes_and_assembled_materials():
    assert node(scene_program("""
const first=mesh('FJ2810'),second=mesh('FJ2811'),before=[capture(first),capture(second)];
const settings=o=>[o.material.color.getHex(),o.material.opacity,o.material.transparent,o.material.depthWrite,o.material.depthTest,o.material.side,o.renderOrder,o.visible];
const materials=[settings(first),settings(second)];
view.select('FJ2810');flush();
assert.deepEqual([settings(first),settings(second)],materials,'assembled selection changed source fills/depth/visibility');
assert.deepEqual([capture(first),capture(second)],before);
assert.equal(view.metrics().loaded_elements,2);assert.equal(view.metrics().geometries,2);
view.update({isolated:true});flush();assert.equal(first.material.color.getHex(),0x168f85);assert.equal(second.visible,false);
view.update({isolated:false});flush();assert.deepEqual([settings(first),settings(second)],materials);
view.select('FJ2811');flush();assert.equal(selected.at(-1),'FJ2811');
assert.deepEqual([capture(first),capture(second)],before);assert.deepEqual([settings(first),settings(second)],materials);
view.home();flush();assert.deepEqual([capture(first),capture(second)],before);
""")).strip() == "ok"


def test_exact_id_extent_cue_has_no_geometry_and_tracks_camera_and_resize():
    assert node(scene_program("""
view.select('FJ2810');flush();
const cue=find('atlas-reference-selection'),box=find('atlas-reference-selection-box'),label=find('atlas-reference-selection-label');
assert.ok(cue,'missing owned source-extent cue');assert.equal(cue.hidden,false);assert.equal(cue.attributes['aria-hidden'],'true');
assert.match(label.textContent,/source extent.*FJ2810/i);assert.equal(label.hidden,false);
assert.equal(elements.filter(e=>e.className==='atlas-reference-selection').length,1);
assert.ok(parseFloat(box.style.left)>=8&&parseFloat(box.style.top)>=8);
assert.ok(parseFloat(label.style.left)>=8&&parseFloat(label.style.top)>=8);
const before=box.style.left;renderer.domElement.handlers.keydown({key:'ArrowLeft',preventDefault(){}});flush();assert.notEqual(box.style.left,before);
host.clientWidth=390;host.clientHeight=440;observers[0]();flush();
assert.ok(parseFloat(box.style.left)+parseFloat(box.style.width)<=382.000001);
assert.ok(parseFloat(label.style.left)+label.getBoundingClientRect().width<=382.000001);
assert.equal(view.metrics().loaded_elements,2);assert.equal(view.metrics().geometries,2);
""")).strip() == "ok"


@pytest.mark.parametrize("transition", ["section", "layer", "selection", "hidden", "context", "near", "far"])
def test_cue_suppresses_unrepresentable_or_inactive_view_without_source_changes(transition):
    assert node(scene_program(f"""
view.select('FJ2810');flush();const cue=find('atlas-reference-selection');assert.ok(cue);assert.equal(cue.hidden,false);
const before=capture(mesh('FJ2810'));
const transition={json.dumps(transition)};
if(transition==='section')view.update({{axis:'z',depth:1}});
if(transition==='layer')view.update({{groups:[]}});
if(transition==='selection')view.select(null);
if(transition==='hidden'){{view.update({{labels:true}});assert.equal(queued.size,1);document.hidden=true;view.visible();assert.equal(queued.size,0);assert.equal(cue.hidden,true)}}
if(transition==='context'){{view.update({{labels:true}});renderer.domElement.handlers.webglcontextlost({{preventDefault(){{}}}});assert.equal(queued.size,0);assert.equal(cue.hidden,true)}}
if(transition==='near'){{camera.position.set(0,.7,0);camera.updateMatrixWorld(true);view.visible()}}
if(transition==='far'){{camera.position.set(0,.7,100);camera.updateMatrixWorld(true);view.visible()}}
flush();assert.equal(cue.hidden,true);assert.equal(capture(mesh('FJ2810')),before);
if(['section','layer','selection','hidden'].includes(transition)){{document.hidden=false;view.home();view.select('FJ2810');flush();assert.equal(cue.hidden,false)}}
""")).strip() == "ok"


def test_overlay_never_enters_raycast_and_dispose_removes_all_owned_resources():
    assert node(scene_program("""
view.select('FJ2810');flush();
renderer.domElement.handlers.pointerdown({clientX:300,clientY:300});renderer.domElement.handlers.pointerup({clientX:300,clientY:300});flush();
assert.equal(selected.at(-1),'FJ2811');assert.equal(rayTargets.length,2);assert.ok(rayTargets.every(o=>o.isMesh));
assert.match(find('atlas-reference-selection-label').textContent,/FJ2811/);
const geometries=new Set(['FJ2810','FJ2811'].map(id=>mesh(id).geometry)),released=new Set();
for(const geometry of geometries)geometry.addEventListener('dispose',()=>released.add(geometry));
view.dispose();assert.equal(disposed,1);assert.deepEqual(released,geometries);assert.equal(host.children.length,0);assert.equal(queued.size,0);
assert.equal(view.metrics().loaded_elements,0);view.dispose();assert.equal(disposed,1);
""")).strip() == "ok"


def test_tiny_viewport_hides_extent_and_late_parse_never_publishes_it():
    assert node(scene_program("""
view.select('FJ2810');flush();const cue=find('atlas-reference-selection');assert.ok(cue);
host.clientWidth=16;observers[0]();flush();assert.equal(cue.hidden,true);
const lateHost=new E(),late=createAtlasReferenceScene({...config,host:lateHost});
await assert.rejects(late.addPartition(manifest.assets[0],bytes,()=>false));
assert.equal(late.metrics().loaded_elements,0);late.dispose();assert.equal(lateHost.children.length,0);
""")).strip() == "ok"


def test_label_measurement_is_not_restricted_by_its_previous_inline_position():
    assert node(scene_program("""
view.select('FJ2810');flush();const cue=find('atlas-reference-selection'),label=find('atlas-reference-selection-label');
// Authored CSS shrink-to-fit stand-in: not a claim of actual browser layout.
label.getBoundingClientRect=()=>({width:Math.min(190,parseFloat(label.style.maxWidth)||190,Math.max(60,host.clientWidth-(parseFloat(label.style.left)||0))),height:20});
label.style.left='580px';host.clientWidth=390;host.clientHeight=440;camera.position.x=-.9;
observers[0]();flush();assert.equal(cue.hidden,false);assert.equal(label.hidden,false);
assert.ok(parseFloat(label.style.left)+label.getBoundingClientRect().width<=382,'label grew after anchoring past the eight-pixel inset');
""")).strip() == "ok"


def test_selection_and_acknowledgment_css_cannot_capture_input_or_overflow():
    css = (CONSOLE / "lib/atlas_reference.css").read_text(encoding="utf-8")
    assert ".atlas-reference-selection" in css
    assert "[data-install-ack]" in css
    assert "pointer-events: none" in css
    assert "overflow-wrap: anywhere" in css
