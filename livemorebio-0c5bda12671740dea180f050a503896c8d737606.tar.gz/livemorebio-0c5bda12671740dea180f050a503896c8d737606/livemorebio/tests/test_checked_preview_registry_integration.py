"""Real audited preview clears; authored private data and inert factories only."""
from contextlib import closing
from copy import deepcopy
import base64
import sqlite3
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio.tests.clinical_registry_fixtures import KEY, replace_fixture_record
from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_committed_registry_transitions import rows, seed
from livemorebio.tests.test_checked_startup_registry_integration import audit_rows, reservations
from livemorebio.tests.test_checked_binding_registry_integration import decode_audit, decode_record


NOTE = "AUTHORED TECHNICAL PREVIEW; NOT A CLINICAL NOTE"


def forbidden(*args, **kwargs):
    pytest.fail("Preview integration attempted old model or execution-store work")


@pytest.fixture
def integration(client, tmp_path, monkeypatch):
    from livemorebio import bus
    from livemorebio.aegle import execution_api, server
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.aegle.registry_audit import RegistryAudit
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.life_system import extract, population, synthetic_human

    path = tmp_path / "authored-preview-integration.sqlite3"
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(path))
    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", base64.urlsafe_b64encode(KEY).decode("ascii"))
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_subject_registry_path", None)
    registry = server._subject_registry()
    assert type(registry) is SubjectRegistry and registry.path == path and registry.key == KEY
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=server._model_fence_guard)
    generation = authority.generation
    store = SimpleNamespace(**{name: forbidden for name in
        ("get", "create", "update", "acquire_owner", "release_owner")})
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    observed = ObservationState()
    observed.observations = {"technical": {"value": "authored-prior", "measured_at": None}}
    observed.patch["envelope_id"] = "authored-prior-envelope"
    old_twin = SimpleNamespace(state=forbidden, patch=deepcopy(observed.patch),
                               observations=deepcopy(observed.observations))
    actions = [{"kind": "AUTHORED_PRIOR_ACTION"}]
    initial = {"tw": old_twin, "subject": None, "initialized": True,
               "observation_state": observed}
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", actions)
    t = SimpleNamespace(server=server, client=client, registry=registry, authority=authority,
        manager=manager, generation=generation, initial=initial, observed=observed,
        actions=actions, calls=[], snapshots=[], bus_events=[], current=None,
        baseline_rows=None, baseline_audit=[], original={}, interfere=None,
        changed_rows=None, fault=None, kind=None,
        extracted={"data_class": "AUTHORED_TEST_ONLY"})

    def unlocked():
        assert not authority._lock._is_owned()
        assert not execution_api._creation_lock._is_owned() and not manager._lock._is_owned()
        assert not server._initialization_lock._is_owned()

    def assert_audit(outcomes, request_id=None, *, pending=False, damaged=False):
        actual = audit_rows(registry)
        assert actual[:len(t.baseline_audit)] == t.baseline_audit
        actual = actual[len(t.baseline_audit):]
        assert len(actual) == len(outcomes)
        if actual and request_id is None:
            request_id = decode_audit(actual[0])["request_id"]
        if request_id:
            UUID(request_id)
        for raw, outcome in zip(actual, outcomes):
            if outcome == "DAMAGED":
                assert damaged and raw == t.fault["damaged_after"]
                continue
            event = decode_audit(raw)
            assert event["outcome_code"] == outcome and event["request_id"] == request_id
            assert event["action"] == "inspect" and event["opaque_record_id"] is None
            assert event["schema"] == "livemore.subject-access-audit.v1"
            assert event["local_store_id"] == registry.audit.store_id
            assert set(event) == {"schema", "request_id", "action", "opaque_record_id",
                "started_at", "completed_at", "outcome_code", "local_store_id",
                "local_process_instance", "source_sha256"}
        assert len({row[0] for row in actual}) == len(actual)
        expected_pending = [(actual[-1][0], request_id)] if pending else []
        assert reservations(registry) == expected_pending

    def freeze_memory():
        t.original = {"tw": initial["tw"], "subject": deepcopy(initial["subject"]),
            "availability": deepcopy(initial["model_availability"]),
            "observations": deepcopy(observed.observations), "patch": deepcopy(observed.patch)}

    def configure(kind="base", *, modeless=False, active=True):
        t.kind = kind
        unrelated = seed(registry, "preview-unrelated", version=7)
        t.current = seed(registry, "preview-selected", active=True, human=modeless, version=2) if active else None
        t.unrelated = unrelated
        initial.update(tw=None if modeless else old_twin,
            subject=server._subject_summary(t.current) if t.current else None,
            model_availability=model_availability(t.current, source_generation=generation))
        t.baseline_rows, t.baseline_audit = rows(registry), audit_rows(registry)
        assert reservations(registry) == []
        freeze_memory()

    def factory_phase(name):
        unlocked()
        assert_audit([None, "SUCCESS"])
        # A second actual writer proves lock release, not observation of close().
        with closing(sqlite3.connect(path, timeout=0.2)) as check:
            check.execute("BEGIN IMMEDIATE")
            check.rollback()
        t.calls.append(name)

    def candidate_state():
        factory_phase("state")
        return {"profile": "AUTHORED_INERT_PREVIEW", "profile_params": {"technical": "candidate-owned"},
                "observations": {}, "applied": []}

    candidate = SimpleNamespace(state=candidate_state)
    t.candidate = candidate
    human = object()

    def build(*args, **kwargs):
        factory_phase("candidate")
        if t.kind == "base":
            assert args == ("healthy",) and kwargs == {}
        else:
            assert args == () and kwargs == {"human": human}
        if t.interfere is not None:
            t.interfere()
            t.changed_rows = rows(registry)
        return candidate

    def synthetic(*args, **kwargs):
        factory_phase("human")
        assert t.kind == "life_system" and args == ("LMB-CAR",)
        return human

    class Extractor:
        def __init__(self):
            factory_phase("extractor")

        def to_synthetic_human(self, note, *, hid):
            factory_phase("extract")
            assert t.kind == "note" and note == NOTE and hid == "LMB-NOTE"
            return human, t.extracted

    def set_snapshot(key, value):
        unlocked()
        assert key == "twin"
        assert_audit([None, "SUCCESS", None, "SUCCESS"])
        assert server._state is not initial and server._state["tw"] is candidate
        assert server._state["subject"] is None and server._workspace_actions == []
        assert authority.generation == manager._permitted_generation != generation
        assert value["model_availability"] == server._state["model_availability"]
        t.snapshots.append(deepcopy(value))

    def publish(source, event, payload):
        unlocked()
        assert source == "Aegle" and event == server.events.TWIN_UPDATED
        t.bus_events.append(deepcopy(payload))

    monkeypatch.setattr(server, "AegleTwin", build)
    monkeypatch.setattr(synthetic_human, "SyntheticHuman", synthetic)
    monkeypatch.setattr(population, "LifeSystem", forbidden)
    monkeypatch.setattr(extract, "ClinicalExtractor", Extractor)
    monkeypatch.setattr(bus, "set_snapshot", set_snapshot)
    monkeypatch.setattr(bus, "publish", publish)
    protected = {name: getattr(SubjectRegistry, name) for name in (
        "prepare_preview_clear", "_prepare_transition", "commit_prepared_transition",
        "_selection_read_access", "_selection_audit_begin", "_selection_audit_reenter",
        "_selection_audit_finish", "_transition_snapshot", "_raw_transition_evidence",
        "_confirm_transition_witness", "_open", "_seal")}
    audited = {name: getattr(RegistryAudit, name) for name in ("begin", "finish", "check_authority")}
    sourced = {name: getattr(ModelSourceAuthority, name) for name in
               ("observation", "commit_guard", "install_generation")}
    server_names = ("_subject_registry", "_publish_research_preview", "_snapshot_twin",
                    "_assign_model_fence", "_model_fence_guard")
    server_functions = tuple(getattr(server, name) for name in server_names)

    def identities():
        for name, function in protected.items():
            bound = getattr(registry, name)
            assert getattr(bound, "__func__", bound) is function
        for name, function in audited.items():
            assert getattr(registry.audit, name).__func__ is function
        for name, function in sourced.items():
            assert getattr(authority, name).__func__ is function
        assert server_functions == tuple(getattr(server, name) for name in server_names)
        if t.fault is None:
            assert registry._connect.__func__ is SubjectRegistry._connect

    t.unlocked, t.configure = unlocked, configure
    t.assert_audit, t.freeze_memory = assert_audit, freeze_memory
    identities()
    yield t
    identities()
    assert manager._owners == manager._adapters == {} and not manager._closed
    manager.close()
    client.close()


def request(t, *, authorized=True):
    endpoint, body = ("/api/ingest_note", {"text": NOTE}) if t.kind == "note" else (
        "/api/stimulate", {"kind": t.kind, "params": {"base": "healthy"} if t.kind == "base" else {"mode": "carrier"}})
    response = t.client.post(endpoint, json=body,
        **({} if authorized else {"headers": {"Authorization": "Bearer invalid-authored-token"}}))
    assert "no-store" in response.headers["Cache-Control"]
    if authorized:
        UUID(response.headers["X-Request-ID"])
    return response


def assert_original(t, *, denied=False):
    from livemorebio.aegle.execution import DENY_ALL
    assert t.server._state is t.initial and t.server._workspace_actions is t.actions
    assert t.initial["tw"] is t.original["tw"] and t.initial["subject"] == t.original["subject"]
    assert t.initial["model_availability"] == t.original["availability"]
    assert t.initial["observation_state"] is t.observed
    assert t.observed.observations == t.original["observations"] and t.observed.patch == t.original["patch"]
    assert t.actions == [{"kind": "AUTHORED_PRIOR_ACTION"}]
    if denied:
        assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
        assert t.manager._wake.is_set()
    else:
        assert t.authority.generation == t.manager._permitted_generation == t.generation
        assert not t.manager._wake.is_set()
    assert not t.snapshots and not t.bus_events


def assert_clear_saved(t):
    after = rows(t.registry)
    old_records = {row[0]: row for row in t.baseline_rows["records"]}
    new_records = {row[0]: row for row in after["records"]}
    assert old_records.keys() == new_records.keys()
    identifier = t.current["twin_id"] if t.current else None
    for ident, old in old_records.items():
        new = new_records[ident]
        if ident != identifier:
            assert new == old
            continue
        assert new[:3] == old[:3] and new[5:8] == old[5:8]
        assert new[3] == "DATA_ADMITTED" and new[4] == old[4] + 1
        assert new[9:] != old[9:]
        record = decode_record(new)
        assert record == {**t.current, "lifecycle": "DATA_ADMITTED", "version": 3,
                          "updated_at": record["updated_at"]}
    assert after["registry_state"] == [row for row in t.baseline_rows["registry_state"] if row[0] != "active_twin_id"]
    for name in ("subject_identifiers", "physical_device_bindings"):
        assert after[name] == t.baseline_rows[name]
    with closing(sqlite3.connect(t.registry.path)) as connection:
        assert connection.execute("SELECT record_id FROM records WHERE record_type='TWIN' AND lifecycle='ACTIVE'").fetchall() == []


def assert_confirmed(t, result, *, cleanup=False):
    from livemorebio.aegle.model_contexts import model_availability
    assert result.status_code == (503 if cleanup else 200)
    if cleanup:
        assert result.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
    assert_clear_saved(t)
    t.assert_audit([None, "SUCCESS", None, "SUCCESS"], result.headers["X-Request-ID"])
    state = t.server._state
    assert state is not t.initial and state["tw"] is t.candidate
    assert state["initialized"] is True and state["subject"] is None
    assert state["model_availability"] == model_availability(None, source_generation=t.authority.generation)
    assert state["model_availability"]["selection_mode"] == "reference_preview"
    assert state["model_availability"]["state"] == "READY"
    assert t.authority.generation == t.manager._permitted_generation != t.generation
    assert state["observation_state"] is not t.observed and state["observation_state"].observations == {}
    assert t.server._workspace_actions == [] and t.server._workspace_actions is not t.actions
    assert t.observed.observations == t.original["observations"] and t.actions == [{"kind": "AUTHORED_PRIOR_ACTION"}]
    assert len(t.snapshots) == len(t.bus_events) == 1 and t.manager._wake.is_set()
    assert t.calls == {"base": ["candidate", "state"], "life_system": ["human", "candidate", "state"],
                       "note": ["extractor", "extract", "candidate", "state"]}[t.kind]
    assert t.snapshots[0]["profile_params"] == {"technical": "candidate-owned"}
    if not cleanup:
        assert result.json() == t.snapshots[0]
    if t.kind == "note":
        assert t.snapshots[0]["extracted"] == t.extracted
        t.extracted["later"] = "authored"
        assert "later" not in t.snapshots[0]["extracted"]


def install_fault(t, monkeypatch, mode):
    original_connect = t.registry._connect
    state = {"mode": mode, "attempts": 0, "updates": 0, "deletes": 0,
             "closed": 0, "rollback_faults": 0, "witness_reads": 0,
             "faulted": False, "damaged_before": None, "damaged_after": None}
    t.fault = state

    class Connection:
        def __init__(self, real):
            self.real, self.mutated, self.witness = real, False, False

        def __getattr__(self, name):
            return getattr(self.real, name)

        def execute(self, sql, parameters=()):
            if self.witness:
                assert sql.startswith("SELECT ")
            result = self.real.execute(sql, parameters)
            if sql == "BEGIN":
                assert state["faulted"] and not self.mutated
                self.witness = True
                state["witness_reads"] += 1
            if sql == "UPDATE records SET lifecycle=?,version=?,updated_at=?,nonce=?,ciphertext=? WHERE record_id=? AND version=?":
                assert parameters[:2] == ("DATA_ADMITTED", 3)
                assert parameters[-2:] == (t.current["twin_id"], 2) and result.rowcount == 1
                self.mutated = True
                state["updates"] += 1
            if sql == "DELETE FROM registry_state WHERE state_key='active_twin_id'":
                assert self.mutated and result.rowcount == 1
                state["deletes"] += 1
            return result

        def commit(self):
            if not self.mutated or state["faulted"]:
                return self.real.commit()
            assert state["updates"] == state["deletes"] == 1
            terminal = self.real.execute("SELECT * FROM registry_audit ORDER BY sequence DESC LIMIT 1").fetchone()
            assert decode_audit(terminal)["outcome_code"] == "SUCCESS"
            state["attempts"] += 1
            state["faulted"] = True
            if mode in {"rollback", "unknown_rollback"}:
                raise sqlite3.OperationalError("Authored final commit acknowledgment failure")
            self.real.commit()
            if mode == "damaged_ack":
                with closing(sqlite3.connect(t.registry.path)) as other, other:
                    raw = other.execute("SELECT * FROM registry_audit ORDER BY sequence DESC LIMIT 1").fetchone()
                    assert tuple(terminal) == raw
                    state["damaged_before"] = raw
                    other.execute("UPDATE registry_audit SET ciphertext=? WHERE event_id=?", (b"authored-damaged-audit", raw[0]))
                    state["damaged_after"] = other.execute("SELECT * FROM registry_audit WHERE event_id=?", (raw[0],)).fetchone()
            if mode in {"lost_ack", "damaged_ack"}:
                raise sqlite3.OperationalError("Authored durable commit acknowledgment lost")

        def rollback(self):
            if self.mutated and mode == "unknown_rollback":
                state["rollback_faults"] += 1
                raise OSError("Authored rollback acknowledgment unknown")
            return self.real.rollback()

        def close(self):
            self.real.close()
            state["closed"] += 1
            if self.mutated and mode == "close_ack":
                raise OSError("Authored close acknowledgment lost after actual close")

    monkeypatch.setattr(t.registry, "_connect", lambda: Connection(original_connect()))


@pytest.mark.parametrize("kind", ["base", "life_system", "note"])
def test_actual_selected_clear_precedes_preview_publication(integration, kind):
    t = integration
    t.configure(kind, modeless=kind == "life_system")
    if kind == "note":
        # L0-R15: a note is refused before the registry, audit or source are touched.
        result = request(t)
        assert result.status_code == 422 and result.json()["code"] == "CLINICAL_NOTE_NOT_ACCEPTED"
        assert rows(t.registry) == t.baseline_rows and audit_rows(t.registry) == t.baseline_audit
        assert reservations(t.registry) == [] and t.calls == []
        assert_original(t)
        return
    assert_confirmed(t, request(t))


def test_actual_absent_selection_preserves_unrelated_rows(integration):
    t = integration
    t.configure(active=False)
    assert_confirmed(t, request(t))
    assert rows(t.registry) == t.baseline_rows


@pytest.mark.parametrize("mismatch", ["memory_absent", "registry_absent", "subject_id"])
def test_actual_checked_capture_rejects_one_sided_or_four_field_mismatch(integration, mismatch):
    t = integration
    # L0-R15: the technical base route replaces the refused note route as the vehicle.
    t.configure({"memory_absent": "life_system", "registry_absent": "base", "subject_id": "base"}[mismatch],
                active=mismatch != "registry_absent")
    if mismatch == "memory_absent":
        t.initial["subject"] = None
    elif mismatch == "registry_absent":
        t.initial["subject"] = t.server._subject_summary({**t.unrelated, "lifecycle": "ACTIVE"})
    else:
        t.initial["subject"]["subject_id"] = "authored-different-subject"
    t.freeze_memory()
    result = request(t)
    assert result.status_code == 409 and result.json()["code"] == "MODEL_SOURCE_CHANGED"
    t.assert_audit([None, "SUCCESS"], result.headers["X-Request-ID"])
    assert rows(t.registry) == t.baseline_rows and t.calls == []
    assert_original(t)


@pytest.mark.parametrize("damage", ["same_version_payload", "pointer_timestamp"])
def test_actual_final_clear_confirmation_preserves_external_interference(integration, damage):
    t = integration
    t.configure("life_system" if damage == "same_version_payload" else "base")  # L0-R15: not the refused note route
    def interfere():
        if damage == "same_version_payload":
            changed = deepcopy(t.current)
            changed["display_label"] = "Authored external same-version edit"
            replace_fixture_record(t.registry, changed)
        else:
            with closing(sqlite3.connect(t.registry.path)) as other, other:
                other.execute("UPDATE registry_state SET updated_at='authored-external-clock' WHERE state_key='active_twin_id'")
    t.interfere = interfere
    result = request(t)
    assert result.status_code == 409 and result.json()["code"] == "TWIN_VERSION_CONFLICT"
    assert rows(t.registry) == t.changed_rows != t.baseline_rows
    t.assert_audit([None, "SUCCESS", None, "ACCESS_FAILED"], result.headers["X-Request-ID"])
    assert_original(t)


def test_actual_clear_commit_rollback_preserves_old_source(integration, monkeypatch):
    t = integration
    t.configure()
    install_fault(t, monkeypatch, "rollback")
    result = request(t)
    assert result.status_code == 503 and result.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert rows(t.registry) == t.baseline_rows
    t.assert_audit([None, "SUCCESS", None, "ACCESS_FAILED"], result.headers["X-Request-ID"])
    assert t.fault["attempts"] == t.fault["updates"] == t.fault["deletes"] == 1
    assert t.fault["witness_reads"] == 0 and t.fault["closed"] == 2
    assert_original(t)


def test_actual_lost_ack_confirms_demoted_row_and_absent_pointer_once(integration, monkeypatch):
    t = integration
    t.configure("life_system")
    install_fault(t, monkeypatch, "lost_ack")
    assert_confirmed(t, request(t))
    assert t.fault["attempts"] == t.fault["updates"] == t.fault["deletes"] == t.fault["witness_reads"] == 1
    assert t.fault["closed"] == 3


def test_actual_damaged_terminal_keeps_committed_clear_unconfirmed(integration, monkeypatch):
    t = integration
    t.configure("base")  # L0-R15: the technical route, not the refused note route
    install_fault(t, monkeypatch, "damaged_ack")
    result = request(t)
    assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    assert_clear_saved(t)
    assert t.fault["damaged_before"] != t.fault["damaged_after"]
    assert t.fault["attempts"] == t.fault["updates"] == t.fault["deletes"] == t.fault["witness_reads"] == 1
    t.assert_audit([None, "SUCCESS", None, "DAMAGED"], result.headers["X-Request-ID"], damaged=True)
    assert_original(t, denied=True)


def test_actual_unknown_rollback_stays_denied_after_close(integration, monkeypatch):
    t = integration
    t.configure()
    install_fault(t, monkeypatch, "unknown_rollback")
    result = request(t)
    assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    assert rows(t.registry) == t.baseline_rows
    assert t.fault["attempts"] == t.fault["updates"] == t.fault["deletes"] == t.fault["rollback_faults"] == 1
    assert t.fault["witness_reads"] == 0 and t.fault["closed"] == 2
    t.assert_audit([None, "SUCCESS", None], result.headers["X-Request-ID"], pending=True)
    assert_original(t, denied=True)


def test_actual_clear_close_ack_failure_preserves_published_preview(integration, monkeypatch):
    t = integration
    t.configure("life_system")
    install_fault(t, monkeypatch, "close_ack")
    assert_confirmed(t, request(t), cleanup=True)
    assert t.fault["attempts"] == t.fault["updates"] == t.fault["deletes"] == 1
    assert t.fault["witness_reads"] == 0 and t.fault["closed"] == 2


def test_unauthorized_note_does_not_reach_real_registry_access(integration):
    t = integration
    t.configure("note")
    assert request(t, authorized=False).status_code == 401
    assert rows(t.registry) == t.baseline_rows and audit_rows(t.registry) == t.baseline_audit
    assert reservations(t.registry) == [] and t.calls == []
    assert_original(t)
