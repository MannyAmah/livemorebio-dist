"""Technical launch regressions; no sockets, services, or operator state are used."""
from __future__ import annotations

import importlib
import os
from pathlib import Path
import subprocess
import sys

import pytest


def test_suite_removes_inherited_compose_opt_in_before_service_import(tmp_path):
    root = Path(__file__).resolve().parents[2]
    env = {name: value for name, value in os.environ.items()
           if not name.startswith(("LIVEMORE_", "CENDOS_", "PYTEST_"))}
    for name, relative in (("HOME", "home"), ("TMPDIR", "tmp"),
                           ("LIVEMORE_DATA_DIR", "data")):
        directory = tmp_path / relative
        directory.mkdir(mode=0o700)
        env[name] = str(directory)
    env.update(LIVEMORE_CONSOLE_PEER="docker-gateway", PYTHONDONTWRITEBYTECODE="1",
               PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONPATH=str(root))
    # A missing technical marker makes the guard independent of the host's
    # actual container status and prevents any read of its real route table.
    code = """
import sys
import pytest
from livemorebio import security
security._CONTAINER_MARKER = sys.argv[1]
raise SystemExit(pytest.main([
    '-p', 'no:cacheprovider', '-q',
    'livemorebio/tests/test_stable_security_session.py::test_SEC_3_forged_navigation_headers_cannot_issue_cookie',
    'livemorebio/tests/test_qa_regressions.py::test_issue_002_patch_counts_only_live_channels_as_live',
]))
"""
    result = subprocess.run(
        [sys.executable, "-B", "-c", code, str(tmp_path / "absent-docker-marker")],
        cwd=root, env=env, capture_output=True, text=True, timeout=60, encoding="utf-8",
    )

    assert result.returncode == 0, result.stdout + result.stderr
    assert "2 passed" in result.stdout


@pytest.mark.parametrize("module_name,port", [
    ("livemorebio.aegle.server", 19871),
    ("livemorebio.cendos.service", 19872),
    ("livemorebio.life_system.service", 19873),
])
def test_compose_service_entrypoints_disable_proxy_headers(monkeypatch, module_name, port,
                                                         technical_environment_identity):
    import uvicorn

    module = importlib.import_module(module_name)
    monkeypatch.setattr(module.app.state, "stack_proof", module.app.state.stack_proof)
    calls = []
    monkeypatch.setenv("FORWARDED_ALLOW_IPS", "*")
    monkeypatch.setattr(uvicorn, "run", lambda *args, **kwargs: calls.append((args, kwargs)))

    # Calling the real entry point pins its runtime arguments; a source grep
    # would also match an unused call and would miss the compose launch path.
    module.main(host="127.0.0.1", port=port)

    assert len(calls) == 1
    args, kwargs = calls[0]
    assert args == (module.app,)
    assert kwargs["host"] == "127.0.0.1" and kwargs["port"] == port
    assert kwargs.get("proxy_headers") is False
