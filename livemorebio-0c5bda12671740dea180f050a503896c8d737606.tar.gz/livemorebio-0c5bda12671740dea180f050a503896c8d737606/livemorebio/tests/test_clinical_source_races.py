"""Technical request/source races; no numerical solver or external forwarding."""
from copy import deepcopy
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401


@pytest.mark.parametrize("path", ["/api/trajectory", "/api/patch/virtual"])
@pytest.mark.parametrize("uncertain", [False, True])
def test_inflight_result_cannot_publish_for_changed_source(client, monkeypatch, path, uncertain):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.engines import trajectory

    unavailable = deepcopy(server._state)
    monkeypatch.setattr(server, "_state", {**unavailable, "tw": SimpleNamespace(human=SimpleNamespace(id="technical"))})
    active = {**unavailable["subject"], "patch_bindings": [
        {"mode": "virtual", "device_id": "technical-virtual", "protocol_version": "3.0"}]}
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(active_twin=lambda: deepcopy(active)))
    calls = []

    def work(*args, **kwargs):
        assert not server._model_source_authority._lock._is_owned()
        calls.append(True)
        with server._model_source_authority.commit_guard():
            server._model_source_authority.install_generation(DENY_ALL if uncertain else "technical-new-generation")
            server._state = unavailable
        return {"technical_stale_result": True}

    monkeypatch.setattr(trajectory, "simulate_disease_trajectory", work)
    monkeypatch.setattr(server, "_forward_virtual_patch", lambda body: (202, work(body)))
    response = client.post(path, json={})
    assert calls == [True]
    assert response.status_code == (503 if uncertain else 409)
    assert response.json()["code"] == ("SELECTION_COMMIT_UNCONFIRMED" if uncertain else "MODEL_SOURCE_CHANGED")
    assert "technical_stale_result" not in response.text
    assert server._state is unavailable


@pytest.mark.parametrize("path", ["/api/trajectory", "/api/patch/virtual"])
@pytest.mark.parametrize("uncertain", [False, True])
def test_source_switch_before_worker_dispatch_does_not_run(client, monkeypatch, path, uncertain):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.engines import trajectory

    unavailable = deepcopy(server._state)
    monkeypatch.setattr(server, "_state", {**unavailable, "tw": SimpleNamespace(human=SimpleNamespace(id="technical"))})
    active = {**unavailable["subject"], "patch_bindings": [
        {"mode": "virtual", "device_id": "technical-virtual", "protocol_version": "3.0"}]}
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(active_twin=lambda: deepcopy(active)))
    dispatched = []

    async def dispatch(function, *args, **kwargs):
        dispatched.append(True)
        with server._model_source_authority.commit_guard():
            server._model_source_authority.install_generation(DENY_ALL if uncertain else "technical-new-generation")
            server._state = unavailable
        return function(*args, **kwargs)

    monkeypatch.setattr(server.asyncio, "to_thread", dispatch)
    monkeypatch.setattr(trajectory, "simulate_disease_trajectory", lambda *a, **k: pytest.fail("stale calculation"))
    monkeypatch.setattr(server, "_forward_virtual_patch", lambda *a: pytest.fail("stale forwarding"))
    response = client.post(path, json={})
    assert dispatched == [True]
    assert response.status_code == (503 if uncertain else 409)
    assert response.json()["code"] == ("SELECTION_COMMIT_UNCONFIRMED" if uncertain else "MODEL_SOURCE_CHANGED")
    assert server._state is unavailable


@pytest.mark.parametrize("field", ["twin_id", "subject_id", "source_class", "version"])
def test_virtual_capture_compares_full_selected_identity(client, monkeypatch, field):
    from livemorebio.aegle import server

    active = {**server._state["subject"], "patch_bindings": [
        {"mode": "virtual", "device_id": "technical-virtual", "protocol_version": "3.0"}]}
    server._state["tw"] = SimpleNamespace(human=None)
    server._state["subject"][field] = 3 if field == "version" else "technical-stale-memory"
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(active_twin=lambda: deepcopy(active)))
    monkeypatch.setattr(server, "_forward_virtual_patch", lambda *a: pytest.fail("different selected identity forwarded"))
    generation = server._model_source_authority.generation
    response = client.post("/api/patch/virtual", json={})
    assert response.status_code == 409
    assert response.json()["code"] == "MODEL_SOURCE_CHANGED"
    assert server._model_source_authority.generation == generation


@pytest.mark.parametrize("code", ["MODEL_BINDING_REQUIRED", "MODEL_CONTEXT_INVALID",
                                 "MODEL_CONTEXT_UNSUPPORTED", "MODEL_CONTEXT_SOURCE_MISMATCH"])
def test_activation_preserves_typed_model_context_failure(client, monkeypatch, code):
    from livemorebio.aegle import server
    from livemorebio.aegle.model_contexts import ModelContextError

    def unavailable(record):
        raise ModelContextError(code)

    before_record = deepcopy(server._state["subject"])
    after_record = {**before_record, "version": before_record["version"] + 1,
                    "twin_id": "twin-technical-target", "subject_id": "technical-target-not-a-person",
                    "source_class": "SYNTHETIC"}
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(
        prepare_activation=lambda *a, **k: SimpleNamespace(
            record=deepcopy(after_record), active_before=deepcopy(before_record)),
        build_twin=unavailable,
        commit_prepared_transition=lambda *a, **k: pytest.fail("unavailable model reached activation")))
    before = server._state
    generation = server._model_source_authority.generation
    response = client.post(f"/api/twins/{after_record['twin_id']}/activate", json={"expected_version": 2})
    assert response.status_code == 409
    assert response.json()["code"] == code
    assert server._state is before and server._model_source_authority.generation == generation
