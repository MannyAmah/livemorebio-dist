"""Pure projected-box arithmetic, not pixels, anatomy or observed physiology."""
from __future__ import annotations

import json

import pytest

from .test_atlas_reference_ui import CONSOLE, node


def program(checks: str) -> str:
    module = (CONSOLE / "lib/atlas_reference_presentation.js").as_uri()
    return f"""import assert from 'node:assert/strict';
import {{projectedSourceExtent,boundedExtentLabel}} from {json.dumps(module)};
const box=(left=-.5,right=.5,bottom=-.5,top=.5)=>
  [2,3].flatMap(depth=>[bottom,top].flatMap(y=>[left,right].map(x=>({{x,y,z:0,depth}}))));
const extent={{x:20,y:30,width:40,height:50}};
const same=(actual,expected)=>assert.deepEqual(actual,expected);
{checks}
console.log('ok');"""


def check(source: str) -> None:
    assert node(program(source)).strip() == "ok"


@pytest.mark.parametrize("width,height", [(390, 600), (768, 768), (1440, 900), (17, 17), (17.5, 18.5)])
def test_projection_is_deterministic_inset_bounded_and_never_mutates(width, height):
    check(f"""
const width={width},height={height},corners=box();
const saved=JSON.stringify(corners);corners.forEach(Object.freeze);Object.freeze(corners);
const left=Math.max(8,width*.25),top=Math.max(8,height*.25);
const right=Math.min(width-8,width*.75),bottom=Math.min(height-8,height*.75);
const expected={{x:left,y:top,width:right-left,height:bottom-top}};
same(projectedSourceExtent(corners,width,height,.1,10),expected);
same(projectedSourceExtent(corners,width,height,.1,10),expected);
same(JSON.stringify(corners),saved);
""")


def test_all_eight_corners_control_extent_not_just_two_diagonal_points():
    check("""
const corners=box(-.1,.1,-.1,.1);
corners[2].x=-.8;corners[3].y=.8;corners[4].x=.8;corners[5].y=-.8;
const rectangle=projectedSourceExtent(corners,100,200,.1,10);
assert.ok(Math.abs(rectangle.x-10)<1e-12 && Math.abs(rectangle.y-20)<1e-12);
assert.ok(Math.abs(rectangle.width-80)<1e-12 && Math.abs(rectangle.height-160)<1e-12);
for(let i=0;i<8;i++){
 const changed=structuredClone(corners);changed[i].depth=.1;
 same(projectedSourceExtent(changed,100,200,.1,10),null);
}
""")


@pytest.mark.parametrize("bounds,expected", [
    ((-2, .5, -.5, .5), {"x": 8, "y": 25, "width": 67, "height": 50}),
    ((-.5, 2, -.5, .5), {"x": 25, "y": 25, "width": 67, "height": 50}),
    ((-.5, .5, -2, .5), {"x": 25, "y": 25, "width": 50, "height": 67}),
    ((-.5, .5, -.5, 2), {"x": 25, "y": 8, "width": 50, "height": 67}),
    ((-2, 2, -2, 2), {"x": 8, "y": 8, "width": 84, "height": 84}),
    ((.95, .99, -.5, .5), None),
    ((-.99, -.95, -.5, .5), None),
    ((-.5, .5, .95, .99), None),
    ((-.5, .5, -.99, -.95), None),
])
def test_partial_extents_intersect_the_inset_without_oversized_fallback(bounds, expected):
    check(f"same(projectedSourceExtent(box(...{json.dumps(bounds)}),100,100,.1,10),{json.dumps(expected)});")


@pytest.mark.parametrize("bounds", [
    (1, 2, -.5, .5), (-2, -1, -.5, .5), (-.5, .5, 1, 2), (-.5, .5, -2, -1),
    (2, 3, 2, 3), (0, 0, -.5, .5), (-.5, .5, 0, 0), (0, 0, 0, 0),
])
def test_offscreen_touching_boundary_and_degenerate_extents_are_absent(bounds):
    check(f"same(projectedSourceExtent(box(...{json.dumps(bounds)}),390,768,.1,10),null);")


@pytest.mark.parametrize("change", [
    "corners[0].depth=0", "corners[7].depth=-2", "corners[4].depth=.1",
    "corners[2].depth=.099999999", "corners.forEach(c=>c.depth=.01)",
    "corners.forEach(c=>c.depth=10)", "corners.forEach(c=>c.depth=20)",
])
def test_camera_depth_rejects_near_crossings_behind_camera_and_wholly_far(change):
    check(f"const corners=box();{change};same(projectedSourceExtent(corners,390,600,.1,10),null);")


def test_partial_far_extent_retains_bounded_source_box_without_occlusion_claim():
    check("""
const corners=box();corners[7].depth=11;corners[7].z=1.1;
same(projectedSourceExtent(corners,100,100,.1,10),{x:25,y:25,width:50,height:50});
corners[0].depth=.100000001;
same(projectedSourceExtent(corners,100,100,.1,10),{x:25,y:25,width:50,height:50});
""")


@pytest.mark.parametrize("expression", [
    "null", "undefined", "{}", "new Float64Array(8)", "box().slice(0,7)", "[...box(),box()[0]]",
    "new Array(8)", "[null,...box().slice(1)]", "[{},...box().slice(1)]",
    "[[0,0,0,2],...box().slice(1)]",
])
def test_invalid_corner_container_or_missing_fields_fails_closed(expression):
    check(f"same(projectedSourceExtent({expression},390,600,.1,10),null);")


@pytest.mark.parametrize("field", ["x", "y", "z", "depth"])
def test_each_corner_field_requires_number_without_coercion(field):
    check(f"""
for(const invalid of [NaN,Infinity,-Infinity,'0',true,false,null,undefined,0n,{{valueOf:()=>0}}]){{
 const corners=box();corners[7][{json.dumps(field)}]=invalid;
 same(projectedSourceExtent(corners,390,600,.1,10),null);
}}
""")


@pytest.mark.parametrize("argument", [0, 1, 2, 3])
def test_viewport_and_camera_arguments_are_finite_numbers_with_valid_order(argument):
    check(f"""
for(const invalid of [NaN,Infinity,-Infinity,'390',true,false,null,undefined,-1,0]){{
 const args=[390,600,.1,10];args[{argument}]=invalid;
 same(projectedSourceExtent(box(),...args),null);
}}
""")


def test_tiny_viewports_and_reversed_or_equal_camera_planes_are_rejected():
    check("""
for(const size of [1,15.99,16]){
 same(projectedSourceExtent(box(),size,600,.1,10),null);
 same(projectedSourceExtent(box(),390,size,.1,10),null);
}
same(projectedSourceExtent(box(),390,600,10,10),null);
same(projectedSourceExtent(box(),390,600,11,10),null);
""")


def test_large_finite_projections_cannot_overflow_to_unbounded_css_values():
    check("""
const largest=Number.MAX_VALUE,corners=box(-largest,largest,-largest,largest);
same(projectedSourceExtent(corners,390,600,.1,10),{x:8,y:8,width:374,height:584});
const result=projectedSourceExtent(corners,largest,largest,.1,10);
assert.ok(result!==null && Object.values(result).every(Number.isFinite));
assert.ok(result.x>=8 && result.y>=8 && result.width<=largest-result.x && result.height<=largest-result.y);
""")


@pytest.mark.parametrize("anchor,expected", [
    ({"x": 20, "y": 30}, {"x": 20, "y": 30}),
    ({"x": 1, "y": -100}, {"x": 8, "y": 8}),
    ({"x": 389, "y": 599}, {"x": 282, "y": 572}),
    ({"x": 250, "y": 590}, {"x": 250, "y": 572}),
])
def test_label_prefers_extent_anchor_and_clamps_to_same_inset(anchor, expected):
    check(f"""
const input=Object.freeze({{...extent,...{json.dumps(anchor)}}});
same(boundedExtentLabel(input,100,20,390,600),{json.dumps(expected)});
same(input,{{...extent,...{json.dumps(anchor)}}});
""")


def test_label_exact_fit_and_tiny_extent_never_expand_or_reframe_source():
    check("""
const tiny=Object.freeze({x:18,y:18,width:.01,height:.01});
same(boundedExtentLabel(tiny,374,584,390,600),{x:8,y:8});
same(boundedExtentLabel(tiny,374.000001,20,390,600),null);
same(boundedExtentLabel(tiny,100,584.000001,390,600),null);
same(boundedExtentLabel(tiny,1,1,17,17),{x:8,y:8});
same(boundedExtentLabel(tiny,1.01,1,17,17),null);
same(tiny,{x:18,y:18,width:.01,height:.01});
""")


@pytest.mark.parametrize("bad", ["null", "undefined", "{}", "[]", "{x:0,y:0,width:0,height:2}", "{x:0,y:0,width:2,height:-1}"])
def test_label_requires_nonempty_finite_extent(bad):
    check(f"same(boundedExtentLabel({bad},100,20,390,600),null);")


@pytest.mark.parametrize("field", ["x", "y", "width", "height"])
def test_label_extent_field_validation_does_not_coerce_or_emit_nonfinite_values(field):
    check(f"""
for(const invalid of [NaN,Infinity,-Infinity,null,undefined,true,'0']){{
 same(boundedExtentLabel({{...extent,[{json.dumps(field)}]:invalid}},100,20,390,600),null);
}}
""")


@pytest.mark.parametrize("argument", [0, 1, 2, 3])
def test_label_measurements_and_viewport_are_strict_finite_positive_numbers(argument):
    check(f"""
for(const invalid of [NaN,Infinity,-Infinity,null,undefined,true,'20',0,-1]){{
 const args=[100,20,390,600];args[{argument}]=invalid;
 same(boundedExtentLabel(extent,...args),null);
}}
same(boundedExtentLabel(extent,1,1,16,600),null);
same(boundedExtentLabel(extent,1,1,390,16),null);
""")


def test_fixed_grid_projection_and_label_outputs_stay_finite_within_viewport():
    check("""
for(const width of [17,390,768,1440])for(const height of [17,390,900]){
 for(const left of [-3,-1,-.8,0,.8,1])for(const right of [left,left+.01,left+1,left+4]){
  const corners=box(left,right,-.8,.8),result=projectedSourceExtent(corners,width,height,.1,10);
  if(!result)continue;
  assert.ok(Object.values(result).every(Number.isFinite));
  assert.ok(result.width>0 && result.height>0 && result.x>=8 && result.y>=8);
  assert.ok(result.width<=width-8-result.x && result.height<=height-8-result.y);
  for(const labelWidth of [1,20,100,width])for(const labelHeight of [1,20,height]){
   const label=boundedExtentLabel(result,labelWidth,labelHeight,width,height);
   if(!label)continue;
   assert.ok(Object.values(label).every(Number.isFinite));
   assert.ok(label.x>=8 && label.y>=8 && labelWidth<=width-8-label.x && labelHeight<=height-8-label.y);
  }
 }
}
""")
