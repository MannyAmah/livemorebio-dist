"""Offline cardiac acquisition checks; all downloaded bytes are technical fixtures."""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import stat
import urllib.error

import pytest

from livemorebio import model_assets as assets
from ._source_tree import source_tree_only


TECHNICAL_BYTES = b"TECHNICAL FIXTURE ONLY; NOT A BIOLOGICAL MODEL\n"


class TechnicalResponse(io.BytesIO):
    status = 200

    def __init__(self, data: bytes, url: str, length: str | None = None):
        super().__init__(data)
        self.url = url
        self.headers = {"Content-Length": str(len(data)) if length is None else length}

    def geturl(self):
        return self.url


@pytest.fixture
def technical_source(tmp_path, monkeypatch):
    destination = tmp_path / "technical-install" / "models" / "cardiac" / "ohara_rudy_cipa_2017.cellml"
    monkeypatch.setattr(assets, "_cardiac_path", lambda: destination)
    original = assets._CARDIAC_ASSET
    monkeypatch.setattr(assets, "_CARDIAC_ASSET", assets.AssetFile(
        original.asset_id, original.filename, original.source_url,
        hashlib.sha256(TECHNICAL_BYTES).hexdigest(), len(TECHNICAL_BYTES),
    ))
    calls = []

    def open_technical(request, timeout):
        assert 0 < timeout <= 10
        calls.append(request.full_url)
        return TechnicalResponse(TECHNICAL_BYTES, request.full_url)

    monkeypatch.setattr(assets, "_open_url", open_technical)
    return destination, calls


def test_cardiac_manifest_keeps_execution_identity_and_original_source():
    manifest = assets.asset_manifest("cardiac")
    assert manifest["assets"]["cellml"]["sha256"] == "ed127e6737611eb1469ea32db0b9d102f0780fc286a29ca88d11d8a868a94175"
    assert manifest["assets"]["cellml"]["size_bytes"] == 400980
    assert "/workspace/4e4/rawfile/2c2629a8e2b60c2cde677903e03c9c9be3f39a00/" in manifest["source_url"]
    assert assets._cardiac_path().relative_to(Path(assets.__file__).resolve().parents[1]).as_posix() == "models/cardiac/ohara_rudy_cipa_2017.cellml"
    assert manifest["attribution"]["per_work_license"] == "unspecified"
    assert "Gary Mirams" in json.dumps(manifest)
    manifest["attribution"]["per_work_license"] = "technical mutation"
    assert assets.asset_manifest("cardiac")["attribution"]["per_work_license"] == "unspecified"


def test_missing_cardiac_status_never_downloads_or_creates_paths(technical_source):
    path, calls = technical_source
    result = assets.cardiac_status()
    assert result["available"] is False
    assert result["reason_code"] == "CARDIAC_MODEL_NOT_INSTALLED"
    assert assets.status("cardiac") == result
    with pytest.raises(assets.ModelAssetError) as error:
        assets.verified_cardiac_path()
    assert error.value.code == "CARDIAC_MODEL_NOT_INSTALLED"
    assert calls == [] and not path.parent.exists()
    assert str(path) not in json.dumps(result)


def test_cardiac_install_is_verified_attributed_and_idempotent(technical_source):
    path, calls = technical_source
    result = assets.install("cardiac")
    assert result["available"] is True
    assert path.read_bytes() == TECHNICAL_BYTES
    assert assets.verified_cardiac_path() == path
    assert assets.verified_model_path("cardiac") == path
    receipt = json.loads(path.with_suffix(".cellml.attribution.json").read_text(encoding="utf-8"))
    assert receipt["model_sha256"] == hashlib.sha256(TECHNICAL_BYTES).hexdigest()
    assert receipt["source_url"] == assets._CARDIAC_ASSET.source_url
    assert receipt["attribution"]["per_work_license"] == "unspecified"
    assert receipt["acquired_at"]
    assert str(path) not in json.dumps(receipt)
    assert assets.install("cardiac")["available"] is True
    assert len(calls) == 1
    assert not list(path.parent.glob(".install-cardiac-*"))


def test_existing_exact_file_is_accepted_without_redownload(technical_source):
    path, calls = technical_source
    path.parent.mkdir(parents=True)
    path.write_bytes(TECHNICAL_BYTES)
    assert assets.install("cardiac")["available"] is True
    assert assets.cardiac_status()["available"] is True
    assert calls == []


def test_corrupt_installed_file_is_refused_and_never_repaired(technical_source):
    path, calls = technical_source
    path.parent.mkdir(parents=True)
    content = b"TECHNICAL CORRUPT FIXTURE"
    path.write_bytes(content)
    assert assets.cardiac_status()["reason_code"] == "CARDIAC_MODEL_HASH_MISMATCH"
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install("cardiac")
    assert error.value.code == "CARDIAC_MODEL_HASH_MISMATCH"
    assert path.read_bytes() == content
    assert calls == []


@pytest.mark.parametrize("failure", ["timeout", "error", "hash", "short", "long", "redirect"])
def test_bad_download_never_publishes(technical_source, monkeypatch, failure):
    path, _ = technical_source

    def failed(request, timeout):
        if failure == "timeout":
            raise TimeoutError("technical untrusted detail")
        if failure == "error":
            raise urllib.error.URLError("technical untrusted detail")
        payload = TECHNICAL_BYTES
        if failure == "hash":
            payload = b"x" * len(payload)
        elif failure == "short":
            payload = payload[:-1]
        elif failure == "long":
            payload += b"x"
        url = "https://technical.invalid/redirect" if failure == "redirect" else request.full_url
        return TechnicalResponse(payload, url, str(len(TECHNICAL_BYTES)))

    monkeypatch.setattr(assets, "_open_url", failed)
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install("cardiac")
    assert error.value.code == "CARDIAC_MODEL_DOWNLOAD_FAILED"
    assert "untrusted detail" not in str(error.value)
    assert not path.exists()
    assert not path.with_suffix(".cellml.attribution.json").exists()
    assert not list(path.parent.glob(".install-cardiac-*"))


@pytest.mark.parametrize("component", ["models", "cardiac", "file"])
def test_symlink_is_refused_without_following_it(technical_source, tmp_path, component):
    path, calls = technical_source
    target = tmp_path / "technical-outside"
    if component == "file":
        target.write_bytes(TECHNICAL_BYTES)
        path.parent.mkdir(parents=True)
        path.symlink_to(target)
    else:
        target.mkdir()
        link = path.parent if component == "cardiac" else path.parent.parent
        link.parent.mkdir(parents=True)
        link.symlink_to(target, target_is_directory=True)
    assert assets.cardiac_status()["reason_code"] == "CARDIAC_MODEL_UNSAFE_PATH"
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    assert calls == []


def test_interrupted_publication_does_not_expose_unverified_model(technical_source, monkeypatch):
    path, _ = technical_source
    original = assets.os.link

    def interrupted(source, destination, *args, **kwargs):
        if Path(destination).name == path.name:
            raise OSError("technical interrupted publication")
        return original(source, destination, *args, **kwargs)

    monkeypatch.setattr(assets.os, "link", interrupted)
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install("cardiac")
    assert error.value.code == "CARDIAC_MODEL_INSTALL_FAILED"
    assert not path.exists()
    monkeypatch.setattr(assets.os, "link", original)
    assert assets.install("cardiac")["available"] is True


def test_cli_check_reports_typed_missing_and_install_is_available(technical_source, capsys):
    assert assets.main(["check", "cardiac"]) == 2
    assert json.loads(capsys.readouterr().out)["error"]["code"] == "CARDIAC_MODEL_NOT_INSTALLED"
    assert assets.main(["install", "cardiac"]) == 0
    assert json.loads(capsys.readouterr().out)["available"] is True
    assert assets.main(["check", "cardiac"]) == 0
    assert json.loads(capsys.readouterr().out)["available"] is True


@source_tree_only("Dockerfile")
def test_container_acquires_the_same_cardiac_asset_before_its_mandatory_gate():
    """Offline Docker text contract; technical downloads are exercised above."""
    source = (Path(__file__).parents[2] / "Dockerfile").read_text(encoding="utf-8")
    acquisition = "RUN python -X utf8 -m livemorebio.model_assets install cardiac"
    assert acquisition in source
    assert source.index(acquisition) < source.index('RUN python -X utf8 -c "from livemorebio._toolchain import _probe_cardiac')
    assert source.index(acquisition) < source.index("python -X utf8 -m pytest -q -rfEs")
    assert source.split(acquisition, 1)[1].splitlines()[0] == ""


def test_l0_r11_cardiac_install_under_umask_0400_succeeds_or_leaves_no_lock(technical_source):
    path, _ = technical_source
    lock = path.parent / ".install.lock"
    previous = os.umask(0o400)
    try:
        try:
            result = assets.install("cardiac")
        except assets.ModelAssetError as error:
            result = error
    finally:
        os.umask(previous)
    if isinstance(result, assets.ModelAssetError):
        assert not (lock.exists() or lock.is_symlink()), (
            f"{result.code}: the failed install left the lock it created")
    else:
        assert result["available"] is True
        assert stat.S_IMODE(lock.stat().st_mode) == 0o600
    assert not list(path.parent.glob(".install-cardiac-*"))
    assert assets.install("cardiac")["available"] is True


@pytest.mark.parametrize("run", ["success", "failure"])
def test_l0_r11_cardiac_interrupt_at_every_step_leaves_no_staging_or_partial_model(
    technical_source, tmp_path, monkeypatch, run
):
    from .test_model_assets import StepInterrupts, _report, sweep_every_step

    failing = {"on": True}
    if run == "failure":
        def failed(request, timeout):
            if failing["on"]:
                raise TimeoutError("technical failure")
            return TechnicalResponse(TECHNICAL_BYTES, request.full_url)

        monkeypatch.setattr(assets, "_open_url", failed)
    steps = StepInterrupts(monkeypatch)
    installs = iter(range(10**6))
    state = {}
    # The fixture's own destination, relative to its install root; no new
    # literal reference to the acquired path (its inventory is reviewed).
    relative = technical_source[0].relative_to(technical_source[0].parents[2])

    def prepare():
        destination = tmp_path / f"technical-install-{next(installs)}" / relative
        monkeypatch.setattr(assets, "_cardiac_path", lambda: destination)
        state["path"] = destination

    def verify(outcome):
        path = state["path"]
        top = path.parents[2]
        left = sorted(entry.relative_to(top).as_posix() for entry in top.rglob("*")
                      if entry.name.startswith((".install-cardiac-", ".livemore-aside-")))
        if left:
            return f"left behind {left}"
        lock = path.parent / ".install.lock"
        if lock.exists() and stat.S_IMODE(lock.stat().st_mode) != 0o600:
            return "the persistent lock is not a private 0600 file"
        if path.exists() and path.read_bytes() != TECHNICAL_BYTES:
            return "a partial or different model was published"
        if run == "failure" and path.exists():
            return "a model was published by a failed install"
        # L0-R13: the failure run retries too, once the download succeeds.
        failing["on"] = False
        try:
            if not assets.install("cardiac")["available"]:
                return "a retry could not install"
        except assets.ModelAssetError as error:
            return f"a retry was refused: {error.code}"
        finally:
            failing["on"] = True
        return None

    labels, failures = sweep_every_step(steps, prepare, lambda: assets.install("cardiac"), verify)
    assert labels, "the operation made no filesystem calls"
    assert not failures, _report(labels, failures)


# L0-R11 round 1. Each case below is a defect the adversarial verifiers
# reproduced in build part 10, turned into a test that fails on that build.
def _snapshot(root: Path) -> dict[str, str]:
    entries = {}
    for entry in sorted(root.rglob("*")):
        info = entry.lstat()
        relative = entry.relative_to(root).as_posix()
        if stat.S_ISLNK(info.st_mode):
            entries[relative] = "L" + os.readlink(entry)
        elif stat.S_ISDIR(info.st_mode):
            entries[relative] = f"D{stat.S_IMODE(info.st_mode):o}:{info.st_ino}"
        else:
            entries[relative] = f"F{info.st_ino}:" + hashlib.sha256(entry.read_bytes()).hexdigest()
    return entries


@pytest.mark.parametrize("name", [".livemore-aside-technical", ".livemore-aside-own-1-2-0-1-0a1b2c3d"])
def test_l0_r11_round1_check_and_restore_never_follow_a_symlink_named_like_an_aside(technical_source, tmp_path, name):
    # Verifier test_restore_follows_a_symlinked_aside_entry: restore emptied the
    # directory a symlink pointed to, then check and restore disagreed forever.
    path, calls = technical_source
    path.parent.mkdir(parents=True)
    elsewhere = tmp_path / "technical-other-program"
    (elsewhere / "technical-subdirectory").mkdir(parents=True)
    (elsewhere / "notes.txt").write_bytes(b"technical notes of another program\n")
    (elsewhere / path.name).write_bytes(b"technical file named like the model\n")
    (elsewhere / "technical-subdirectory" / "data.txt").write_bytes(b"technical data\n")
    before = _snapshot(elsewhere)
    (path.parent / name).symlink_to(elsewhere, target_is_directory=True)

    assert assets.check("cardiac")["reason_code"] == "CARDIAC_MODEL_NOT_INSTALLED"
    assert assets.restore("cardiac")["state"] == "nothing_pending"
    assert _snapshot(elsewhere) == before
    assert sorted(os.listdir(path.parent)) == [name]
    assert calls == []


@pytest.mark.parametrize("kind", ["directory_0755", "regular_file"])
def test_l0_r11_round1_check_and_restore_ignore_an_entry_no_rollback_made(technical_source, kind):
    # Verifier test_restore: restore put a file from someone's 0755 directory at
    # the model's name; a regular file named like an aside made check and
    # install refuse forever while restore could never clear it.
    path, calls = technical_source
    path.parent.mkdir(parents=True)
    if kind == "regular_file":
        (path.parent / ".livemore-aside-file").write_bytes(b"technical file of another program\n")
    else:
        foreign = path.parent / ".livemore-aside-notmine"
        foreign.mkdir()
        os.chmod(foreign, 0o755)
        (foreign / path.name).write_bytes(b"technical file named like the model\n")
    before = _snapshot(path.parent)

    assert assets.check("cardiac")["reason_code"] == "CARDIAC_MODEL_NOT_INSTALLED"
    assert assets.restore("cardiac")["state"] == "nothing_pending"
    assert _snapshot(path.parent) == before
    assert not path.exists()
    assert assets.install("cardiac")["available"] is True
    assert {name for name in os.listdir(path.parent) if name.startswith(".livemore-")} == {
        name for name in before if name.startswith(".livemore-") and "/" not in name}


def test_l0_r11_round1_restore_never_acts_in_a_rollback_directory_whose_mode_changed(technical_source):
    # A directory with a rollback's exact name but not its 0700 mode may hold
    # what another program put there. It stays reported, and restore refuses to
    # act in it rather than put its file at the model's name.
    path, calls = technical_source
    path.parent.mkdir(parents=True)
    foreign = path.parent / ".livemore-aside-own-1-2-0-1-0a1b2c3d"
    foreign.mkdir()
    os.chmod(foreign, 0o755)
    (foreign / path.name).write_bytes(b"technical file named like the model\n")
    before = _snapshot(path.parent)

    with pytest.raises(assets.ModelAssetError) as pending:
        assets.check("cardiac")
    assert pending.value.code == "CARDIAC_MODEL_ASIDE_PENDING" and str(foreign) in str(pending.value)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.restore("cardiac")
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING" and "0755" in str(refused.value)
    assert _snapshot(path.parent) == before
    assert not path.exists()


# L0-R11 round 3.
def test_l0_r11_round3_an_unmanaged_install_in_a_set_group_id_directory_finishes_and_leaves_nothing(
        technical_source, monkeypatch):
    # Verifier K-linux-setgid (U1-U3): in a source checkout under `chmod g+s`,
    # Linux makes every new directory 02700, so the install refused
    # ASIDE_PENDING over its own empty staging directory and restore refused
    # the record as "mode 2700". Set-group-ID grants no access.
    import sys

    path, calls = technical_source
    checkout = path.parents[2]
    checkout.mkdir(mode=0o755)
    os.chmod(checkout, 0o2755)
    if not os.lstat(checkout).st_mode & stat.S_ISGID:
        pytest.skip("this account cannot set the set-group-ID bit here")
    if not sys.platform.startswith("linux"):
        mkdir = os.mkdir

        def inherited(target, mode=0o777, *, dir_fd=None):
            mkdir(target, mode, dir_fd=dir_fd)
            parent = os.path.dirname(os.fsdecode(target)) or "."
            if os.stat(parent, dir_fd=dir_fd).st_mode & stat.S_ISGID:
                current = stat.S_IMODE(os.stat(target, dir_fd=dir_fd, follow_symlinks=False).st_mode)
                os.chmod(target, current | stat.S_ISGID, dir_fd=dir_fd)

        monkeypatch.setattr(os, "mkdir", inherited)
    result = assets.install("cardiac")
    assert result["available"] is True
    assert os.lstat(path.parent).st_mode & stat.S_ISGID
    left = sorted(entry.relative_to(checkout).as_posix() for entry in checkout.rglob("*")
                  if entry.name.startswith((".install-cardiac-", ".livemore-")))
    assert left == []
    assert assets.check("cardiac")["available"] is True
    assert assets.restore("cardiac")["state"] == "nothing_pending"
