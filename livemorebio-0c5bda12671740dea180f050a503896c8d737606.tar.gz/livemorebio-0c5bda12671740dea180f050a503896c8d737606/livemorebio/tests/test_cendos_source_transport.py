"""Actual safe-client parsing on intercepted authored bytes; no peer HTTP."""
from copy import deepcopy
from dataclasses import asdict
import io
import json
from types import SimpleNamespace

import pytest

from livemorebio.tests.stack_client_fixtures import install_stack_client_opener

from livemorebio.tests.cendos_source_fixtures import no_cendos_peer_network, technical_source  # noqa: F401

REQUEST_ID = "01234567-89ab-4cde-8fab-0123456789ab"


@pytest.fixture
def envelope():
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY
    return technical_source({"profile": HEALTHY.name, "profile_params": asdict(HEALTHY),
        "pk_context": {"age": 50, "genome": {}, "evidence_class": "REFERENCE_INITIALIZED"}})


def wire(monkeypatch, raw, *, status=200, request_id=REQUEST_ID, encoding="identity", failure=None):
    from livemorebio import execution_client
    calls, reads, closed = [], [], []
    stream = io.BytesIO(raw)
    monkeypatch.setenv("LIVEMORE_AEGLE_URL", "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer technical"})

    def opener(*handlers):

        def read(count):
            reads.append(count)
            return stream.read(count)

        def request(req, *, timeout):
            calls.append((req, timeout))
            if failure:
                raise failure
            return SimpleNamespace(status=status, headers={"X-Request-ID": request_id,
                "Content-Encoding": encoding}, read=read, close=lambda: closed.append(True))

        return SimpleNamespace(open=request)

    install_stack_client_opener(monkeypatch, opener)
    return calls, reads, closed


def test_source_safe_get_exact_path_current_uuid_one_bounded_read(envelope, monkeypatch):
    from livemorebio.cendos.current_source import CurrentSourceClient
    from livemorebio.execution_client import MAX_RESPONSE_BYTES

    calls, reads, closed = wire(monkeypatch, json.dumps(envelope).encode())
    client = CurrentSourceClient()
    assert client.read_source() == envelope
    assert len(calls) == 1 and calls[0][1] == 10
    request = calls[0][0]
    assert request.full_url == "http://127.0.0.1:9999/api/cendos/current-source"
    assert request.method == "GET" and request.data is None
    assert request.headers["Authorization"] == "Bearer technical"
    assert request.headers["Accept-encoding"] == "identity"
    assert reads == [MAX_RESPONSE_BYTES + 1] and closed == [True]
    assert client.last_continuous_response["request_id"] == REQUEST_ID


def test_source_get_does_not_accept_created_status(envelope, monkeypatch):
    from livemorebio.cendos.current_source import CurrentSourceClient
    from livemorebio.execution_client import ContinuousClientError

    calls, _, closed = wire(monkeypatch, json.dumps(envelope).encode(), status=201)
    with pytest.raises(ContinuousClientError) as caught:
        CurrentSourceClient().read_source()
    assert caught.value.code == "CLIENT_RESPONSE" and caught.value.request_id == REQUEST_ID
    assert len(calls) == 1 and closed == [True]


@pytest.mark.parametrize("case", ["hash", "schema", "snapshot_extra", "profile_partial", "profile_identity",
    "invalid_parameter", "missing_pk", "string_age", "boolean_gene", "unsupported_evidence", "not_ready",
    "wrong_preview_id", "boolean_version", "not_prepared", "oversized_schema", "null", "duplicate", "nan", "deep"])
def test_source_rejects_untrusted_payload_with_current_uuid(envelope, monkeypatch, case):
    from livemorebio.cendos.current_source import CurrentSourceClient
    from livemorebio.execution_client import ContinuousClientError

    value = deepcopy(envelope)
    snapshot = value["snapshot"]
    if case == "hash":
        value["snapshot_sha256"] = "f" * 64
    elif case == "schema":
        value["schema"] = "unsupported"
    elif case == "snapshot_extra":
        snapshot["private_notes"] = "technical-private-sentinel"
    elif case == "profile_partial":
        snapshot["profile_params"].pop("p2")
    elif case == "profile_identity":
        snapshot["profile"] = "different-name"
    elif case == "invalid_parameter":
        snapshot["profile_params"]["Si"] = -1
    elif case == "missing_pk":
        snapshot.pop("pk_context")
    elif case == "string_age":
        snapshot["pk_context"]["age"] = "50"
    elif case == "boolean_gene":
        snapshot["pk_context"]["genome"] = {"SLC22A1": True}
    elif case == "unsupported_evidence":
        snapshot["pk_context"]["evidence_class"] = "HUMAN_EQUIVALENT"
    elif case == "not_ready":
        snapshot["model_availability"]["state"] = "UNAVAILABLE"
    elif case == "wrong_preview_id":
        snapshot["model_availability"]["twin_id"] = "technical"
    elif case == "boolean_version":
        snapshot["model_availability"]["twin_version"] = False
    elif case == "not_prepared":
        snapshot["model_availability"]["preparation_available"] = False
    elif case == "oversized_schema":
        snapshot["parameter_provenance"] = {"value": "x" * 2_000_000}
    if case not in {"hash", "schema"}:
        value = technical_source(snapshot)
    raw = json.dumps(value).encode()
    if case == "null":
        raw = b"null"
    elif case == "duplicate":
        raw = b'{"schema":1,"schema":2}'
    elif case == "nan":
        raw = b'{"bad":NaN}'
    elif case == "deep":
        raw = b'{"value":' + b'[' * 70 + b'0' + b']' * 70 + b'}'
    calls, _, closed = wire(monkeypatch, raw)
    client = CurrentSourceClient()
    with pytest.raises(ContinuousClientError) as caught:
        client.read_source()
    assert caught.value.code == "CLIENT_RESPONSE" and caught.value.request_id == REQUEST_ID
    assert "technical-private-sentinel" not in str(caught.value)
    assert len(calls) == 1 and closed == [True]


@pytest.mark.parametrize("request_id", [None, "a" * 32, REQUEST_ID.upper(), "not-a-uuid"])
def test_source_requires_this_reads_canonical_uuid(envelope, monkeypatch, request_id):
    from livemorebio.cendos.current_source import CurrentSourceClient
    from livemorebio.execution_client import ContinuousClientError

    wire(monkeypatch, json.dumps(envelope).encode(), request_id=request_id)
    client = CurrentSourceClient()
    client.last_continuous_response = {"request_id": REQUEST_ID}
    with pytest.raises(ContinuousClientError) as caught:
        client.read_source()
    assert caught.value.code == "CLIENT_RESPONSE" and caught.value.request_id is None


@pytest.mark.parametrize("case,code", [("timeout", "CLIENT_TRANSPORT"), ("redirect", "CLIENT_RESPONSE"),
    ("encoding", "CLIENT_RESPONSE"), ("wire_oversize", "CLIENT_RESPONSE"), ("unavailable", "MODEL_BINDING_REQUIRED"),
    ("storage", "REGISTRY_STORAGE_UNAVAILABLE"), ("uncertain", "SELECTION_COMMIT_UNCONFIRMED")])
def test_source_failed_transport_never_retries_or_uses_cache(envelope, monkeypatch, case, code):
    from livemorebio.cendos.current_source import CurrentSourceClient
    from livemorebio.execution_client import ContinuousClientError, MAX_RESPONSE_BYTES

    raw, status = json.dumps(envelope).encode(), 200
    if case == "wire_oversize":
        raw = b" " * (MAX_RESPONSE_BYTES + 1)
    elif case == "redirect":
        status, raw = 302, b"{}"
    elif case in {"unavailable", "storage", "uncertain"}:
        status, raw = (409 if case == "unavailable" else 503), json.dumps({"code": code}).encode()
    calls, _, closed = wire(monkeypatch, raw, status=status, encoding="gzip" if case == "encoding" else "identity",
        failure=TimeoutError("PRIVATE TIMEOUT") if case == "timeout" else None)
    with pytest.raises(ContinuousClientError) as caught:
        CurrentSourceClient().read_source()
    assert caught.value.code == code and len(calls) == 1
    assert "PRIVATE" not in str(caught.value)
    assert closed == ([] if case == "timeout" else [True])


@pytest.mark.parametrize("source_class", ["SYNTHETIC", "REFERENCE_GROUNDED_SYNTHETIC", "REAL_HUMAN"])
@pytest.mark.parametrize("mismatch", [False, True])
def test_registered_source_identity_has_exact_coherent_eligibility(envelope, source_class, mismatch):
    from livemorebio.cendos.current_source import validate_source_envelope
    from livemorebio.execution_client import ContinuousClientError

    snapshot = envelope["snapshot"]
    snapshot["subject"] = {"twin_id": "twin-technical", "subject_id": "pseudonym-technical",
        "display_label": "Technical reference", "source_class": source_class, "lifecycle": "ACTIVE", "version": 4}
    snapshot["model_availability"].update(selection_mode="model", twin_id="twin-technical", twin_version=5 if mismatch else 4)
    value = technical_source(snapshot)
    if mismatch or source_class == "REAL_HUMAN":
        with pytest.raises(ContinuousClientError):
            validate_source_envelope(value)
    else:
        assert validate_source_envelope(value) == value
