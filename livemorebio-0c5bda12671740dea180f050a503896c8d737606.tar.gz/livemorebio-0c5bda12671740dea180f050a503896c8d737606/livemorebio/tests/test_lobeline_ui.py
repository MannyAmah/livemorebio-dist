"""Lobeline inspection is bound to a nonhuman frozen concentration assay."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess

import pytest
from ._node import require_node, run_node as _run_node

CONSOLE = Path(__file__).parents[1] / "aegle/console"


def js(source: str) -> str:
    node = require_node()
    result = _run_node([node, "--eval", source], text=True, capture_output=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    return result.stdout


@pytest.fixture
def assay():
    from livemorebio.cendos.lobeline_vmat2 import run_lobeline_vmat2

    return run_lobeline_vmat2({
        "material_id": "lobeline-hemisulfate",
        "context_id": "rat-striatal-synaptic-vesicles",
        "concentration_unit": "uM",
        "substrate_concentrations": [0, .001, .11, 1, 5],
        "inhibitor_concentrations": [0, .25],
    })


def inspect(assay, selection=None):
    source = (CONSOLE / "lib/lobeline_biology.js").read_text(encoding="utf-8").replace("export function", "function")
    return json.loads(js(source + "\ntry { console.log(JSON.stringify(lobelineInspection(" + json.dumps(assay) + "," + json.dumps(selection or {}) + "))); } catch(e) {console.log(JSON.stringify({error:e.message}));}"))


def test_lobeline_selected_point_retains_native_axis_and_nonhuman_evidence(assay):
    view = inspect(assay, {"conditionIndex": 1, "pointIndex": 2})
    point = assay["conditions"][1]["points"][2]
    assert view["binding"] == {"run_id": assay["run_id"], "condition_id": "lobeline-condition-2", "context_id": "rat-striatal-synaptic-vesicles"}
    assert view["axis"] == {"kind": "recorded_condition", "quantity": "substrate_concentration", "unit": "uM", "value": .11, "index": 2}
    assert view["quantity"]["value"] == point["initial_rate"]
    assert view["quantity"]["control"] == point["control_rate"]
    assert view["evidence_state"] == "MODELED_INITIAL_RATE"
    assert view["freshness"] == "FROZEN_RECORD"
    assert view["provenance"]["source_sha256"] == assay["source_sha256"]
    assert view["benchmark_discrepancy"]["parameters_refitted"] is False


def test_zero_substrate_is_zero_not_missing_and_fraction_is_unavailable(assay):
    view = inspect(assay)
    assert view["quantity"]["value"] == 0
    assert view["quantity"]["control"] == 0
    assert view["quantity"]["fraction"] is None


@pytest.mark.parametrize("mutation", ["scope", "evidence", "time", "context", "unit", "duplicate", "nan", "boolean"])
def test_lobeline_mismatched_or_malformed_result_is_not_projected(assay, mutation):
    if mutation == "scope": assay["scope"] = "human"
    elif mutation == "evidence": assay["evidence_state"] = "OBSERVED"
    elif mutation == "time": assay["native_axis"]["time_evolution"] = True
    elif mutation == "context": assay["input"]["context_id"] = "human"
    elif mutation == "unit": assay["unit"] = "mg/dL"
    elif mutation == "duplicate": assay["conditions"][1]["condition_id"] = assay["conditions"][0]["condition_id"]
    elif mutation == "nan": assay["conditions"][0]["points"][0]["initial_rate"] = None
    elif mutation == "boolean": assay["conditions"][0]["points"][0]["initial_rate"] = True
    assert "error" in inspect(assay)


@pytest.mark.parametrize("mutation", ["refitted", "missing_benchmark", "wrong_status", "benchmark_nan", "wrong_comparator", "negative_rate", "off_domain", "different_substrates", "different_inhibitors", "zero_fraction", "missing_control"])
def test_lobeline_contradictory_benchmark_or_frozen_grid_is_rejected(assay, mutation):
    if mutation == "refitted": assay["benchmark_discrepancy"]["parameters_refitted"] = True
    elif mutation == "missing_benchmark": assay.pop("benchmark_discrepancy")
    elif mutation == "wrong_status": assay["benchmark_discrepancy"]["status"] = "QUALIFIED"
    elif mutation == "benchmark_nan": assay["benchmark_discrepancy"]["predicted_apparent_km_um"] = None
    elif mutation == "wrong_comparator": assay["benchmark_discrepancy"]["reported_apparent_km_um"] = .3
    elif mutation == "negative_rate": assay["conditions"][0]["points"][1]["initial_rate"] = -.1
    elif mutation == "off_domain": assay["input"]["substrate_concentrations"][-1] = 10; assay["conditions"][0]["points"][-1]["substrate_um"] = 10
    elif mutation == "different_substrates": assay["conditions"][1]["points"].pop()
    elif mutation == "different_inhibitors": assay["conditions"][1]["inhibitor_um"] = .1
    elif mutation == "zero_fraction": assay["conditions"][0]["points"][0]["rate_fraction"] = 0
    elif mutation == "missing_control": assay["controls"].pop()
    assert "error" in inspect(assay)


def test_lobeline_visible_selection_changes_only_the_frozen_inspection(assay):
    source = (CONSOLE / "lib/lobeline_biology.js").read_text(encoding="utf-8").replace("export function", "function")
    program = r'''
const nodes=new Map();function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',value:'',hidden:false,handlers:{},attrs:{},setAttribute(k,v){this.attrs[k]=v},addEventListener(k,v){this.handlers[k]=v}});return nodes.get(id)}
const host={innerHTML:'',querySelector:el};let requests=0;global.fetch=()=>{requests++;throw Error('inspection must not fetch')};
renderLobelineRun(host,RUN);
el('#lobeline-condition').handlers.change({target:{value:'1'}});
el('#lobeline-substrate').handlers.change({target:{value:'2'}});
const source=JSON.parse(el('#lobeline-source').textContent);
if(source.binding.condition_id!=='lobeline-condition-2'||source.axis.value!==.11)throw Error('selection context mismatch');
if(!el('#lobeline-readout').innerHTML.includes('Initial dopamine uptake')||!el('#lobeline-plot').innerHTML.includes('<circle'))throw Error('selected result not visible');
if(!host.innerHTML.includes('No time kinetics')||!host.innerHTML.includes('UNQUALIFIED_DISCREPANCY')||host.innerHTML.includes('protocol-time-slider'))throw Error('assay boundary missing');
if(!host.innerHTML.includes('8 minutes')||!host.innerHTML.includes('endpoint normalized per minute'))throw Error('source interval and endpoint basis are not visible');
if(requests)throw Error('inspection made requests');
console.log('ok');
'''.replace("RUN", json.dumps(assay))
    assert js(source + program).strip() == "ok"


def test_cendos_lobeline_preparation_submits_explicit_inputs_without_cohorts():
    html = (CONSOLE / "cendos.html").read_text(encoding="utf-8")
    assert 'id="run-lobeline-vmat2"' in html
    script = re.search(r"async function runLobeline\(\)\{.*?\n\}", html, re.S)
    assert script, "explicit assay action missing"
    program = r'''
const nodes={'lobeline-unit':{value:'uM'},'lobeline-substrates':{value:'0, .001, .11, 1, 5'},'lobeline-inhibitors':{value:'0, .25'},protocolStatus:{textContent:''}};
const $=id=>nodes[id];let calls=[];async function postProtocol(path,body){calls.push({path,body})}
FUNCTION
(async()=>{await runLobeline();if(calls.length!==1||calls[0].path!=='/api/cendos/protocols/lobeline-vmat2'||calls[0].body.context_id!=='rat-striatal-synaptic-vesicles'||'cohort_id' in calls[0].body)throw Error('wrong assay request');nodes['lobeline-substrates'].value='0,,1';await runLobeline();if(calls.length!==1||!nodes.protocolStatus.textContent)throw Error('blank field became zero');console.log('ok')})().catch(e=>{console.error(e);process.exit(1)});
'''.replace("FUNCTION", script.group())
    assert js(program).strip() == "ok"
