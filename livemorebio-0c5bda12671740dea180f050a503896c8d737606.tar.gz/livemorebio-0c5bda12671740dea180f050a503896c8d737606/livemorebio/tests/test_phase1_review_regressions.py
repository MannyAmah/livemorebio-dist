from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import subprocess
import sys
import textwrap
import os

import pytest
from fastapi.testclient import TestClient


TOKEN = "review-regression-token"


def _auth() -> dict[str, str]:
    return {"Authorization": f"Bearer {TOKEN}"}


def test_screen_regenerates_a_cohort_when_seed_changes():
    from livemorebio.sdk import Platform

    reused = Platform()
    reused.screen("metformin", n=4, seed=11)
    second = reused.screen("metformin", seed=12)
    fresh = Platform().screen("metformin", n=4, seed=12)

    assert [row["id"] for row in second["ranked"]] == [
        row["id"] for row in fresh["ranked"]
    ]
    assert second["audit"]["result_sha256"] == fresh["audit"]["result_sha256"]


def test_sdk_screen_rejects_invalid_terminal_inputs():
    from livemorebio.sdk import Platform

    with pytest.raises(ValueError, match="dose"):
        Platform().screen("metformin", n=1, dose=-1)
    with pytest.raises(ValueError, match="compound"):
        Platform().screen([], n=1)


def test_chembl_effect_cache_cannot_bypass_qualification(monkeypatch):
    from livemorebio.engines import metabolism
    from livemorebio.engines.coupling import gem_metabolic
    from livemorebio.sdk import Platform

    pins = {
        "compound-a": {"compound": "compound-a", "chembl_id": "A", "source": "test",
                       "targets": [{"gene": "GENE", "action": "inhibitor", "scale": 0.8}],
                       "pinned_from_cache": True},
        "compound-b": {"compound": "compound-b", "chembl_id": "B", "source": "test",
                       "targets": [{"gene": "GENE", "action": "inhibitor", "scale": 0.2}],
                       "pinned_from_cache": True},
    }
    calls: list[float] = []

    monkeypatch.setattr(Platform, "_pin_resolution", staticmethod(lambda compound, refresh=False: pins[compound]))
    monkeypatch.setattr(metabolism, "load_recon3d", lambda: object())
    monkeypatch.setattr(metabolism, "_find_gene", lambda model, gene: object())
    monkeypatch.setattr(metabolism, "operating_point", lambda human: "same-point")

    def fake_effect(base, genome, scales, dose, human=None):
        scale = scales["GENE"]
        calls.append(scale)
        return base, {"d_Gb_pct": -10.0 * scale, "d_Si_pct": 10.0 * scale}

    monkeypatch.setattr(gem_metabolic, "gem_drug_effect", fake_effect)

    platform = Platform()
    with pytest.raises(ValueError, match="qualified"):
        platform.screen("compound-a", n=1, seed=5, mode="chembl")
    with pytest.raises(ValueError, match="qualified"):
        platform.screen("compound-b", n=1, seed=5, mode="chembl")

    assert calls == []


@pytest.mark.parametrize("dose", [0.0, -1.0, float("nan"), float("inf")])
def test_pk_rejects_non_positive_or_non_finite_dose(dose: float):
    from livemorebio.engines.hepatic_pk import pk_profile

    with pytest.raises(ValueError, match="dose_mg"):
        pk_profile("metformin", dose_mg=dose)


def test_pk_uses_apparent_oral_clearance_without_double_applying_bioavailability():
    from livemorebio.engines.hepatic_pk import pk_profile

    result = pk_profile("metformin", dose_mg=1000.0)

    assert result["auc_mg_h_L"] == pytest.approx(1000.0 / 68.0, abs=0.01)
    assert result["params"]["CL_over_F_L_per_h"] == 68.0
    assert "CL_L_per_h" not in result["params"]


def test_screen_api_rejects_malformed_and_invalid_bodies(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    monkeypatch.setenv("LIVEMORE_SCREEN_RUN_DIR", str(tmp_path))
    from livemorebio.aegle.server import app

    client = TestClient(app)
    malformed = client.post(
        "/api/screen",
        headers={**_auth(), "Content-Type": "application/json"},
        content="{",
    )
    wrong_shape = client.post("/api/screen", headers=_auth(), json=[])
    invalid_dose = client.post(
        "/api/screen", headers=_auth(), json={"compound": "metformin", "dose": -1}
    )

    assert malformed.status_code == 400
    assert wrong_shape.status_code == 400
    assert invalid_dose.status_code == 400


def test_cendos_rejects_invalid_pharmacology_inputs(monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    from livemorebio.cendos.service import app

    client = TestClient(app)
    assert client.post(
        "/assay/ogtt", headers=_auth(), json={"drug": "metformin", "dose": -1}
    ).status_code == 400
    assert client.post(
        "/assay/ogtt", headers=_auth(), json=[]
    ).status_code == 400


def test_adapter_probe_requires_mutation_auth(monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    from livemorebio.aegle.server import app

    client = TestClient(app)
    assert client.get("/api/adapters?probe=true").status_code == 401
    assert client.get("/api/adapters?probe=true", headers=_auth()).status_code == 200
    assert client.post("/api/adapters/probe", json={}).status_code == 401


def test_attach_authorization_reuses_persisted_launcher_token(monkeypatch, tmp_path):
    from livemorebio import registry, security

    token = "persisted-attach-token"
    (tmp_path / "api-token").write_text(token + "\n", encoding="utf-8")
    monkeypatch.delenv("LIVEMORE_API_TOKEN", raising=False)
    monkeypatch.setattr(registry, "REG_DIR", str(tmp_path))

    assert security.authorization_headers() == {"Authorization": f"Bearer {token}"}


def test_attach_token_helper_does_not_require_optional_fastapi(tmp_path):
    token = "base-install-token"
    (tmp_path / "api-token").write_text(token + "\n", encoding="utf-8")
    script = textwrap.dedent(
        f"""
        import builtins
        real_import = builtins.__import__
        def blocked(name, *args, **kwargs):
            if name.startswith('fastapi'):
                raise ModuleNotFoundError('fastapi intentionally unavailable')
            return real_import(name, *args, **kwargs)
        builtins.__import__ = blocked
        from livemorebio import registry, security
        registry.REG_DIR = {str(tmp_path)!r}
        assert security.authorization_headers() == {{'Authorization': 'Bearer {token}'}}
        """
    )

    completed = subprocess.run(
        [sys.executable, "-c", script], text=True, capture_output=True, check=False,
        env={key: value for key, value in os.environ.items()
             if key != "LIVEMORE_API_TOKEN"}, encoding="utf-8",
    )

    assert completed.returncode == 0, completed.stderr


def test_terminal_screen_forwards_parametric_inputs():
    from livemorebio.shell import run_command

    captured: dict = {}

    class FakePlatform:
        mode = "inprocess"

        def screen(self, compound, **kwargs):
            captured.update({"compound": compound, **kwargs})
            return {
                "summary": {"compound": compound, "cohort_n": 0, "seed": 1,
                            "n_effect": 0, "responder_rate": 0.0, "mean_delta_mean": 0.0},
                "ranked": [], "audit": {"result_sha256": "0" * 64},
            }

    run_command(
        FakePlatform(),
        "screen botanical mode=auto n=1 seed=1 si_boost=.2 gb_drop=.05 gamma_boost=.1",
        out=lambda _line: None,
    )

    assert captured["si_boost"] == 0.2
    assert captured["gb_drop"] == 0.05
    assert captured["gamma_boost"] == 0.1


def test_screen_api_rejects_parametric_inputs_in_auto_mode(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    monkeypatch.setenv("LIVEMORE_SCREEN_RUN_DIR", str(tmp_path))
    from livemorebio.aegle.server import app

    response = TestClient(app).post(
        "/api/screen",
        headers=_auth(),
        json={"compound": "research compound", "mode": "auto", "n": 1,
              "si_boost": 0.2, "gb_drop": 0.05, "gamma_boost": 0.1},
    )

    assert response.status_code == 422
    assert "run_id" not in response.json()


def test_parametric_effect_inputs_cannot_create_a_successful_screen():
    from livemorebio.sdk import Platform

    with pytest.raises(ValueError, match="qualified"):
        Platform().screen(
            "research compound", mode="parametric", n=1, seed=3,
            si_boost=0.2, gb_drop=0.05, gamma_boost=0.1,
        )


def test_inprocess_metformin_assay_uses_pk_linked_pharmacology(monkeypatch):
    from livemorebio.engines import pharmacology
    from livemorebio.sdk import Platform

    platform = Platform()
    called: dict = {}

    def fake_metformin(base, human, dose):
        called.update({"human": human, "dose": dose})
        return base, {"path": "metformin", "pk": {"auc_mg_h_L": 12.3}}

    monkeypatch.setattr(pharmacology, "metformin", fake_metformin)
    result = platform.assay_ogtt("metformin", dose=1.25)

    assert called == {"human": platform._twin.human, "dose": 1.25}
    assert result["pk"]["auc_mg_h_L"] == 12.3


def test_screen_api_preserves_actionable_unresolved_compound_error(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    monkeypatch.setenv("LIVEMORE_SCREEN_RUN_DIR", str(tmp_path))
    from livemorebio.aegle.server import app
    from livemorebio.sdk import Platform

    monkeypatch.setattr(
        Platform,
        "screen",
        lambda *args, **kwargs: (_ for _ in ()).throw(
            RuntimeError("compound 'unknown' did not resolve to any ChEMBL targets")
        ),
    )
    response = TestClient(app).post(
        "/api/screen", headers=_auth(),
        json={"compound": "unknown", "mode": "chembl", "n": 1},
    )

    assert response.status_code == 422
    assert "did not resolve" in response.json()["error"]


def test_cohort_audit_binds_the_indication(monkeypatch):
    from livemorebio import audit
    from livemorebio.sdk import Platform

    records: list[tuple[str, dict, dict]] = []
    monkeypatch.setattr(audit, "record", lambda action, inputs, outputs: records.append(
        (action, inputs, outputs)
    ) or {"id": "test"})

    Platform().cohort(n=1, seed=9, indication="type-2-diabetes")

    action, inputs, _outputs = records[-1]
    assert action == "cohort.generate"
    assert inputs["indication"] == "type-2-diabetes"


def test_unlicensed_kegg_and_unconfigured_usda_make_no_network_calls(monkeypatch, tmp_path):
    from livemorebio.engines import foods
    from livemorebio.life_system.reference.sources.kegg import KEGG

    calls: list[object] = []
    monkeypatch.delenv("LIVEMORE_KEGG_COMMERCIAL_LICENSE", raising=False)
    monkeypatch.delenv("USDA_API_KEY", raising=False)
    monkeypatch.setattr("urllib.request.urlopen", lambda *args, **kwargs: calls.append(args) or None)
    foods.resolve_food.cache_clear()

    assert KEGG(cache_dir=str(tmp_path)).human_pathways() == []
    assert foods.resolve_food("turmeric")["resolved"] is True
    assert calls == []


def test_concurrent_token_initialization_converges_on_one_token(monkeypatch, tmp_path):
    from livemorebio import cli

    monkeypatch.delenv("LIVEMORE_API_TOKEN", raising=False)
    monkeypatch.setattr(cli.R, "REG_DIR", str(tmp_path))
    monkeypatch.setattr(cli, "TOKEN_FILE", str(tmp_path / "api-token"))

    with ThreadPoolExecutor(max_workers=8) as pool:
        tokens = list(pool.map(lambda _: cli.ensure_api_token(), range(24)))

    assert len(set(tokens)) == 1
    assert (tmp_path / "api-token").read_text(encoding="utf-8").strip() == tokens[0]
