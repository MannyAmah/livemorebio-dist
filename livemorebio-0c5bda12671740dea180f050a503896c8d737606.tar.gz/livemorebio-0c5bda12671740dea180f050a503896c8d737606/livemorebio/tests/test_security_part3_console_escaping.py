"""Offline AST audit of console HTML composition (technical source fixtures only).

Node bundles Acorn for its REPL; use that parser without adding/downloading a
dependency. The existing Node gate applies; parser errors fail, never skip.
HTML fragments are recursively checked, not blanket-allowlisted. In particular,
escaping a composed variable does not exempt its interpolated leaves from this
explicit-escaping policy. This catches the historical rx.drug spelling too.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from ._node import run_node

CONSOLE = Path(__file__).parents[1] / "aegle" / "console"

# Only locally constructed constants may be exempted; never server numbers,
# formatters, URLs, whole markup helpers, or arbitrary identifier patterns.
ALLOWLIST: dict[tuple[str, str], str] = {
    ("patch.html", "provDot(ch.data_class,ch.provenance)"):
        "provDot returns only the fixed CSS classes meas, nom, pend, or eng.",
}

PARSER = r"""
const fs = require('node:fs');
const path = require('node:path').posix;
const acorn = require('internal/deps/acorn/acorn/dist/acorn');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const units = [], failures = [], sinks = [], usedAllowlist = new Set();
// Actual local helper declarations, not globally trusted spellings. Imported
// aliases are resolved to these declarations below. Native escape() is not HTML escaping.
const escapeHelpers = {
  'adapters.html':['esc'], 'biology.html':['esc'], 'cendos.html':['esc'],
  'index.html':['esc'], 'patch.html':['esc'], 'lib/core.js':['escapeHTML'],
  'lib/continuous_execution.js':['esc'], 'lib/execution_anatomy.js':['esc'],
  'lib/member_picker.js':['esc'], 'lib/reference_cohorts.js':['esc'],
  'lib/run_anatomy.js':['escape'], 'lib/workspace.js':['safe'],
  'lib/lobeline_biology.js':['lobelineEscape'], 'technical.js':['esc'],
};
const allowed = new Set(input.allowlist.map(([file, expr])=>file+'\n'+expr));
function children(node) {
  return Object.values(node).flatMap(value => Array.isArray(value) ? value : [value])
    .filter(value => value && typeof value === 'object' && typeof value.type === 'string');
}
function visit(node, fn) { fn(node); for(const child of children(node)) visit(child, fn); }
function member(node, name) {
  return node?.type==='MemberExpression' &&
    (node.computed ? node.property.type==='Literal' && node.property.value===name : node.property.name===name);
}
for(const file of input.files) {
  const parts = file.name.endsWith('.html')
    ? [...file.source.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)].map(m=>({source:m[1],offset:file.source.slice(0,m.index+m[0].indexOf('>')+1).split('\n').length-1}))
    : [{source:file.source,offset:0}];
  for(const part of parts) {
    if(!part.source.trim())continue;
    const ast=acorn.parse(part.source,{ecmaVersion:'latest',sourceType:'module',locations:true});
    const parents=new Map(),bindings=new Map(),imports=new Map();
    visit(ast,node=>{for(const child of children(node))parents.set(child,node);});
    function scope(node) {
      while(node && !['Program','FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type))node=parents.get(node);
      return node;
    }
    function bind(name, value, node, owner=scope(node)) {
      if(!bindings.has(owner))bindings.set(owner,new Map());
      const names=bindings.get(owner);if(!names.has(name))names.set(name,[]);
      if(value)names.get(name).push(value);
    }
    visit(ast,node=>{
      if(node.type==='VariableDeclarator' && node.id.type==='Identifier')bind(node.id.name,node.init,node);
      if(node.type==='FunctionDeclaration')bind(node.id.name,node,parents.get(node));
      if(node.type==='ImportDeclaration')for(const spec of node.specifiers) {
        bind(spec.local.name,spec,node);
        if(spec.type==='ImportSpecifier')imports.set(spec,{
          file:node.source.value.startsWith('/')?node.source.value.slice(1):path.normalize(path.join(path.dirname(file.name),node.source.value)),
          name:spec.imported.name,
        });
      }
    });
    // Assignments in closures update their enclosing declaration. Collect
    // declarations first, including uninitialized ones, before locating writes.
    visit(ast,node=>{
      if(node.type!=='AssignmentExpression'||node.left.type!=='Identifier')return;
      let owner=scope(node);
      while(owner&&!bindings.get(owner)?.has(node.left.name)&&!hasParameter(owner,node.left.name))
        owner=scope(parents.get(owner));
      bind(node.left.name,node.right,node,owner||scope(node));
    });
    units.push({file:file.name,...part,ast,parents,bindings,imports,scope});
  }
}
function hasParameter(scope,name) {
  return scope.params?.some(param=>{let found=false;visit(param,n=>{
    if(n.type==='Identifier'&&n.name===name)found=true;
  });return found;});
}
function definitions(unit,node) {
  let scope=unit.scope(node);
  while(scope) {
    // A callback parameter must not resolve to an unrelated outer variable.
    if(hasParameter(scope,node.name))return [];
    const defs=unit.bindings.get(scope)?.get(node.name);
    if(defs)return defs;
    scope=unit.scope(unit.parents.get(scope));
  }
  return [];
}
function resolvedFunction(unit,node,seen=new Set()) {
  if(node?.type!=='Identifier'||seen.has(node))return null;
  seen=new Set(seen);seen.add(node);
  const defs=definitions(unit,node);
  if(defs.length!==1)return null;
  const def=defs[0];
  if(/Function/.test(def.type))return {unit,fn:def,name:node.name};
  if(def.type==='Identifier')return resolvedFunction(unit,def,seen);
  const imported=unit.imports.get(def);
  if(imported) {
    const target=units.find(u=>u.file===imported.file);
    const fn=target?.bindings.get(target.ast)?.get(imported.name);
    if(fn?.length===1&&/Function/.test(fn[0].type))return {unit:target,fn:fn[0],name:imported.name};
  }
  return null;
}
function isEscape(unit,node) {
  const target=resolvedFunction(unit,node);
  if(!target||!escapeHelpers[target.unit.file]?.includes(target.name))return false;
  // Only the actual top-level helper qualifies, never a same-name callback/local.
  return target.unit.bindings.get(target.unit.ast)?.get(target.name)?.[0]===target.fn;
}
function returns(fn) {
  if(fn.type==='ArrowFunctionExpression' && fn.body.type!=='BlockStatement')return [fn.body];
  const values=[];
  function walk(node) {
    if(node!==fn && /Function/.test(node.type))return;
    if(node.type==='ReturnStatement' && node.argument)values.push(node.argument);
    else for(const child of children(node))walk(child);
  }
  walk(fn);return values;
}
function markup(node) {
  let found=false;visit(node,n=>{
    if(n.type==='TemplateLiteral'&&n.quasis.some(q=>/<[a-z!/]/i.test(q.value.raw)))found=true;
    if(n.type==='Literal'&&typeof n.value==='string'&&/<[a-z!/]/i.test(n.value))found=true;
  });return found;
}
function fault(unit,node) {
  const expression=unit.source.slice(node.start,node.end);
  if(!allowed.has(unit.file+'\n'+expression))failures.push({file:unit.file,line:node.loc.start.line+unit.offset,expression});
}
function check(unit,node,seen=new Set()) {
  if(!node)return;
  if(seen.has(node)){fault(unit,node);return;}
  seen=new Set(seen);seen.add(node);
  const recur=n=>check(unit,n,seen);
  const expression=unit.source.slice(node.start,node.end);
  if(allowed.has(unit.file+'\n'+expression)){usedAllowlist.add(unit.file+'\n'+expression);return;}
  if(node.type==='Literal')return;
  if(node.type==='TemplateLiteral'){node.expressions.forEach(recur);return;}
  if(node.type==='BinaryExpression' && node.operator==='+'){recur(node.left);recur(node.right);return;}
  if(node.type==='ConditionalExpression'){recur(node.consequent);recur(node.alternate);return;}
  if(node.type==='LogicalExpression'){recur(node.left);recur(node.right);return;}
  if(node.type==='Identifier') {
    const defs=definitions(unit,node);
    if(defs.length){defs.forEach(recur);return;}
  }
  if(node.type==='CallExpression') {
    if(isEscape(unit,node.callee)) {
      // workspace.safe permits a caller-provided fallback; it must be safe too.
      if(resolvedFunction(unit,node.callee).name==='safe')node.arguments.slice(1).forEach(recur);
      // Inspect composed text bindings too: leaves must be explicit, once only.
      const arg=node.arguments[0];
      if(arg?.type==='Identifier')for(const def of definitions(unit,arg))
        if(def.type==='TemplateLiteral')recur(def);
      return;
    }
    if(member(node.callee,'map')||member(node.callee,'flatMap')||
        (member(node.callee,'from')&&node.callee.object.name==='Array')) {
      const callback=node.arguments[member(node.callee,'from')?1:0];
      if(isEscape(unit,callback))return;
      if(callback&&/Function/.test(callback.type)){returns(callback).forEach(recur);return;}
    }
    if(member(node.callee,'join')) {
      const receiver=node.callee.object;
      if(receiver.type==='ArrayExpression'){receiver.elements.forEach(recur);node.arguments.forEach(recur);return;}
      if(receiver.type==='CallExpression'&&member(receiver.callee,'from')&&receiver.callee.object.name==='Array') {
        recur(receiver);node.arguments.forEach(recur);return;
      }
      if(receiver.type==='CallExpression' && (member(receiver.callee,'map')||member(receiver.callee,'flatMap'))) {
        const callback=receiver.arguments[0];
        if(isEscape(unit,callback)){node.arguments.forEach(recur);return;}
        if(/Function/.test(callback.type)) {
          returns(callback).forEach(recur);node.arguments.forEach(recur);return;
        }
      }
      if(receiver.type==='Identifier') {
        const defs=definitions(unit,receiver);
        if(defs.length&&defs.every(d=>d.type==='ArrayExpression'||d.type==='CallExpression')) {
          defs.forEach(d=>d.type==='ArrayExpression'?d.elements.forEach(recur):recur(d));
          visit(unit.ast,n=>{
            // Follow only the same lexical array binding. Reject unmodelled writes.
            const same=(obj,seenAliases=new Set())=>{
              if(obj?.type!=='Identifier'||seenAliases.has(obj))return false;
              seenAliases=new Set(seenAliases);seenAliases.add(obj);
              return definitions(unit,obj).some(def=>defs.includes(def)||same(def,seenAliases));
            };
            if(n.type==='AssignmentExpression'&&n.left.type==='MemberExpression'&&same(n.left.object))fault(unit,n);
            if(n.type==='CallExpression'&&n.arguments.some(arg=>same(arg)))fault(unit,n);
            if(n.type==='CallExpression'&&n.callee.type==='MemberExpression'&&same(n.callee.object)) {
              if(member(n.callee,'push'))n.arguments.forEach(recur);
              else if(!member(n.callee,'join')&&!member(n.callee,'map')&&!member(n.callee,'flatMap'))fault(unit,n);
            }
          });
          node.arguments.forEach(recur);return;
        }
      }
    }
    if(node.callee.type==='Identifier') {
      const target=resolvedFunction(unit,node.callee);
      if(target && returns(target.fn).some(markup)) {returns(target.fn).forEach(n=>check(target.unit,n,seen));return;}
    }
  }
  fault(unit,node);
}
for(const unit of units)visit(unit.ast,node=>{
  if(node.type==='AssignmentExpression'&&(member(node.left,'innerHTML')||member(node.left,'outerHTML'))) {
    sinks.push({file:unit.file,line:node.loc.start.line+unit.offset});check(unit,node.right);
  }
  if(node.type==='CallExpression'&&member(node.callee,'insertAdjacentHTML')) {
    sinks.push({file:unit.file,line:node.loc.start.line+unit.offset});check(unit,node.arguments[1]);
  }
  // Helpers exported to other files or indirectly composed later are audited too.
  if(node.type==='TemplateLiteral'&&node.quasis.some(q=>/<[a-z!/]/i.test(q.value.raw)))check(unit,node);
});
// The sole constant-output exemption also has an implementation contract, so
// changing its body cannot silently expand what the allowlisted call emits.
const provDot = units.filter(u=>u.file==='patch.html').flatMap(u=>u.bindings.get(u.ast)?.get('provDot')||[]);
const provDotReturns = provDot.length===1 ? returns(provDot[0]).map(n=>n.type==='Literal'?n.value:null) : [];
console.log(JSON.stringify({sinks,usedAllowlist:[...usedAllowlist],provDotReturns,
  failures:[...new Map(failures.map(f=>[JSON.stringify(f),f])).values()]}));
"""


def audit(files: list[dict[str, str]]) -> dict:
    result = run_node(
        ["node", "--expose-internals", "-e", PARSER],
        input=json.dumps({"files": files, "allowlist": list(ALLOWLIST)}),
        capture_output=True, text=True, encoding="utf-8", timeout=45,
    )
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)


@pytest.fixture(scope="module")
def console_audit() -> dict:
    paths = sorted({*CONSOLE.rglob("*.html"), *(CONSOLE / "lib").rglob("*.js")})
    return audit([{"name": str(p.relative_to(CONSOLE)), "source": p.read_text(encoding="utf-8")} for p in paths])


def test_every_console_html_sink_escapes_dynamic_values(console_audit):
    assert len(console_audit["sinks"]) >= 100, "Console sink inventory unexpectedly empty"
    assert set(console_audit["usedAllowlist"]) == {"\n".join(key) for key in ALLOWLIST}
    assert console_audit["provDotReturns"] == ["meas", "nom", "pend", "eng"]
    assert not console_audit["failures"], "\n".join(
        f'{f["file"]}:{f["line"]}: {f["expression"]}' for f in console_audit["failures"]
    )


TECHNICAL_ESC = """
const esc = value => String(value ?? '').replace(/[&<>"']/g,
    ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[ch]));
"""


@pytest.mark.parametrize("source", [
    "node.innerHTML = `<b>${rx.drug}</b>`;",
    "node.outerHTML = '<b>' + server.count + '</b>';",
    "node.insertAdjacentHTML('beforeend', `<b>${url.hash}</b>`);",
    "node['innerHTML'] += `<b>${storage.value}</b>`;",
    "const html = rows.map(r=>`<b>${r.count}</b>`).join(''); node.innerHTML=html;",
    "function render(){return `<b>${server.value}</b>`;} node.innerHTML=render();",
    "const label=`Drug ${rx.drug}`; node.innerHTML=`<b>${esc(label)}</b>`;",
    "node.innerHTML = `<b>${esc(server.name) + server.count}</b>`;",
    "node.innerHTML = '<b>' + escape(server.value) + '</b>';",
    "const safe=value=>value; node.innerHTML = `<b>${safe(server.value)}</b>`;",
    "function render(esc){node.innerHTML=`<b>${esc(server.value)}</b>`;}",
    "node.innerHTML = values.map(escape).join('');",
    "const safe=value=>value; node.innerHTML=values.map(safe).join('');",
    "function render(esc){node.innerHTML=values.map(esc).join('');}",
    "const html=['fixed']; html[0]=server.value; node.innerHTML=html.join('');",
    "const html=['fixed']; const alias=html; alias.push(server.value); node.innerHTML=html.join('');",
    "const html=['fixed']; html.splice(0,1,server.value); node.innerHTML=html.join('');",
    "function render(v){if(flag)v='fixed';return '<b>'+v+'</b>';} node.innerHTML=render(server.value);",
    "let html=html; node.innerHTML=html;",
    "const html=['fixed']; mutate(html); node.innerHTML=html.join('');",
    "function render(){return '<b>fixed</b>';} function x(render){node.innerHTML=render(server.value);}",
    "let html='fixed'; function update(){html=server.value;} node.innerHTML=html;",
    "let html; function update(){html=server.value;} node.innerHTML=html;",
    "function update(){esc=server.fn;} node.innerHTML=esc(server.value);",
])
def test_audit_rejects_technical_unescaped_mutants(source):
    assert audit([{"name": "technical.js", "source": TECHNICAL_ESC + source}])["failures"]


def test_audit_accepts_escaped_nested_fragments_and_text_content():
    source = """
    const label=`Drug ${esc(rx.drug)}`;
    node.innerHTML=`<b>${label}</b>` + rows.map(r=>`<i>${esc(r.count)}</i>`).join('');
    node.outerHTML='<p>'+names.map(esc).join(', ')+'</p>';
    node.insertAdjacentHTML('beforeend', `<b>${ready?'Ready':'Pending'}</b>`);
    node.textContent=`${server.text}`;
    """
    assert not audit([{"name": "technical.js", "source": TECHNICAL_ESC + source}])["failures"]


def test_audit_rejects_unescaped_safe_fallback_even_through_an_alias():
    source = """
    function safe(value, fallback='—'){return value==null?fallback:esc(value);}
    const alias=safe;
    node.innerHTML='<p>'+alias(null, server.value)+'</p>';
    """
    assert audit([{"name": "lib/workspace.js", "source": source}])["failures"]


def test_audit_does_not_borrow_an_unimported_function_from_another_file():
    assert audit([
        {"name": "technical.js", "source": "node.innerHTML=render(server.value);"},
        {"name": "unrelated.js", "source": "function render(){return '<b>fixed</b>';}"},
    ])["failures"]


def test_audit_resolves_named_imports_and_their_escape_alias():
    assert not audit([
        {"name": "technical.js", "source": TECHNICAL_ESC.replace("const esc", "export const esc")},
        {"name": "view.js", "source": "import {esc as encode} from './technical.js'; export function render(v){return '<b>'+encode(v)+'</b>'; }"},
        {"name": "page.js", "source": "import {render} from './view.js'; node.innerHTML=render(server.value);"},
    ])["failures"]
