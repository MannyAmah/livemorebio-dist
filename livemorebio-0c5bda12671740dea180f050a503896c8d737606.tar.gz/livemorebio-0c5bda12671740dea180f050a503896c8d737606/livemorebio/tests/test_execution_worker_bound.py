"""Technical byte-protocol fixtures; no solver or person data is involved."""
from __future__ import annotations

from io import BytesIO
import json
from types import SimpleNamespace

import pytest

from livemorebio.aegle import execution_adapters, execution_worker
from livemorebio.aegle.execution_contract import ExecutionError, MAX_JSON_BYTES, METABOLIC, encoded


def test_worker_accepts_the_full_encoder_bound_and_rejects_overflow_or_missing_newline(monkeypatch):
    configured = []

    class TechnicalAdapter:
        runtime_identity = {"fixture": "technical-byte-bound"}

        def __init__(self, source):
            configured.append(source)

        def close(self):
            pass

    monkeypatch.setattr(execution_adapters, "MetabolicExecutionAdapter", TechnicalAdapter)
    request = {"operation": "configure", "source": {"engine_contract_id": METABOLIC,
                                                      "fixture": "technical-byte-bound", "padding": ""}}
    overhead = len(encoded(request))

    def payload(size):
        request["source"]["padding"] = "T" * (size - overhead)
        return json.dumps(request, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")

    def exchange(raw):
        output = BytesIO()
        with monkeypatch.context() as patch:
            patch.setattr(execution_worker.sys, "stdin", SimpleNamespace(buffer=BytesIO(raw)))
            patch.setattr(execution_worker.sys, "stdout", SimpleNamespace(buffer=output))
            execution_worker.main()
        return output.getvalue()

    exact = payload(MAX_JSON_BYTES)
    assert encoded(request) == exact
    assert len(exact) == MAX_JSON_BYTES
    response = exchange(exact + b"\n")
    assert response, "The encoder-admitted maximum request must reach the worker."
    assert json.loads(response)["ok"] is True
    assert len(configured) == 1

    smaller = payload(MAX_JSON_BYTES - 1)
    assert json.loads(exchange(smaller + b"\n"))["ok"] is True
    assert len(configured) == 2

    too_large = payload(MAX_JSON_BYTES + 1)
    with pytest.raises(ExecutionError):
        encoded(request)
    assert exchange(too_large + b"\n" + smaller + b"\n") == b""
    assert exchange(exact) == b""
    assert exchange(smaller) == b""
    assert len(configured) == 2
