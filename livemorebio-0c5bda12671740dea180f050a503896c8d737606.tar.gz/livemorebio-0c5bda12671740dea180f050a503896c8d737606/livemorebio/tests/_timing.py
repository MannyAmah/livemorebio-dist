"""Wall-clock waits for tests, sized for the slowest machine that must pass.

The installer runs this suite and refuses to activate a release when it fails,
so a test that waits too briefly does not merely flake — it stops a client
installing on modest hardware. A two-CPU host reported 32 such failures, all of
them Node-driven harness tests waiting on a child process.

These helpers cover *waiting for something to finish*. They are deliberately
not used for a deadline that a test is itself asserting: widening the thing
under test would hide the behaviour instead of measuring it.
"""
from __future__ import annotations

import os

SCALE_ENV = "LIVEMORE_TEST_TIMEOUT_SCALE"
# Generous by default: when the work completes promptly these waits cost
# nothing, and when it does not the difference is a passing install.
_DEFAULT_SCALE = 5.0


def scale() -> float:
    """Multiplier applied to every wait, raised on a slow or loaded host."""
    raw = os.environ.get(SCALE_ENV, "").strip()
    if not raw:
        return _DEFAULT_SCALE
    try:
        value = float(raw)
    except ValueError:
        return _DEFAULT_SCALE
    return value if 0.1 <= value <= 100 else _DEFAULT_SCALE


def wait_seconds(base: float) -> float:
    """Seconds to wait for work that should finish quickly on a fast machine."""
    return float(base) * scale()
