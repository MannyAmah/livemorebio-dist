"""Frozen descriptive cohorts of authored software records, never real enrollment."""
from __future__ import annotations

from copy import deepcopy
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from threading import Event

import pytest

from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError
from livemorebio.tests.clinical_registry_fixtures import (
    COHORT_FIELDS, EVIDENCE_FIELDS, KEY, canonical, forbid_compilation, historical_intent,
    legacy_cohort_record, legacy_twin_record, record_count, replace_fixture_record, saved_bytes,
    seed_legacy, sha,
)
from ._timing import wait_seconds


@pytest.fixture
def registry(tmp_path):
    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=KEY)
    for suffix in ("one", "two", "three"):
        seed_legacy(registry, legacy_twin_record(suffix))
    return registry


def body(ids=None):
    return {"source_class": "REAL_HUMAN", "name": "Authored cohort software check", "seed": 0,
            "indication": "not-an-inferred-model", "member_twin_ids": ids or ["twin-fixture-one", "twin-fixture-two"]}


def test_unselected_partial_profiles_can_form_a_frozen_descriptive_cohort(registry, monkeypatch):
    forbid_compilation(monkeypatch)
    snapshots = {twin_id: registry.get_twin(twin_id) for twin_id in body()["member_twin_ids"]}
    assert registry.active_twin() is None
    cohort = registry.create_cohort(body(), idempotency_key="cohort-one")
    assert cohort["size"] == 2 and cohort["lifecycle"] == "FROZEN"
    assert [member["twin_id"] for member in cohort["members"]] == body()["member_twin_ids"]
    for member in cohort["members"]:
        snapshot = snapshots[member["twin_id"]]
        assert member == {
            "schema": "livemore.frozen-real-human-member.v1", "source_class": "REAL_HUMAN",
            "twin_id": snapshot["twin_id"], "record_version": snapshot["version"],
            "snapshot_sha256": sha(snapshot, b"livemore.real-human-member-snapshot.v1\0"),
            "evidence_sha256": sha({field: snapshot[field] for field in EVIDENCE_FIELDS},
                                   b"livemore.real-human-member-evidence.v1\0"),
            "snapshot": snapshot,
        }
        assert "model_binding" not in member["snapshot"]  # Preserve absence in old ciphertext.
    assert cohort["creation_identity"]["record_type"] == "COHORT"
    assert registry.active_twin() is None


@pytest.mark.parametrize("mutation", ["consent", "custody", "evidence", "nonhuman"])
def test_cohort_members_need_admission_and_research_consent_not_a_nonempty_list(registry, mutation):
    record = registry.get_twin("twin-fixture-two")
    record["lifecycle"] = "ACTIVE"  # ACTIVE cannot rescue failed admission.
    if mutation == "consent":
        record["consent_scope"] = ["digital_twin", "life_patch"]
    elif mutation == "custody":
        record["chain_of_custody"] = ""
    elif mutation == "evidence":
        record["observations"] = {}
    else:
        record["source_class"] = "SYNTHETIC"
    replace_fixture_record(registry, record)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_cohort(body())
    assert caught.value.code == "COHORT_MEMBER_INELIGIBLE"
    assert record_count(registry, "COHORT") == 0


@pytest.mark.parametrize("ids", [["twin-fixture-one", "twin-fixture-one"], [" twin-fixture-one", "twin-fixture-two"],
                                ["twin-fixture-one", "twin-fixture-two "]])
def test_cohort_roster_requires_unique_canonical_ids(registry, ids):
    with pytest.raises(SubjectRegistryError):
        registry.create_cohort(body(ids))
    assert record_count(registry, "COHORT") == 0


def test_two_record_ids_for_one_subject_cannot_inflate_cohort(registry):
    duplicate = registry.get_twin("twin-fixture-two")
    duplicate["subject_id"] = "pseudonym-technical-one"
    replace_fixture_record(registry, duplicate)  # Deliberate authenticated malformed historical fixture.
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_cohort(body())
    assert caught.value.code == "COHORT_MEMBER_INELIGIBLE"
    assert record_count(registry, "COHORT") == 0


def test_current_member_edits_never_change_frozen_cohort_or_exact_retry(registry, monkeypatch):
    forbid_compilation(monkeypatch)
    cohort = registry.create_cohort(body(), idempotency_key="frozen-key")
    frozen = deepcopy(cohort)
    before = saved_bytes(registry, cohort["cohort_id"])
    current = registry.get_twin("twin-fixture-two")
    current.update(version=6, consent_scope=["digital_twin"], conditions=["Changed technical record"])
    replace_fixture_record(registry, current)
    assert registry.get_cohort(cohort["cohort_id"]) == frozen
    assert registry.create_cohort(body(), idempotency_key="frozen-key") == frozen
    assert saved_bytes(registry, cohort["cohort_id"]) == before
    with pytest.raises(SubjectRegistryError):
        registry.create_cohort(body(), idempotency_key="new-consent-check")


def test_new_key_freezes_new_eligible_version_without_rewriting_old_cohort(registry):
    first = registry.create_cohort(body(), idempotency_key="first")
    updated = registry.get_twin("twin-fixture-two")
    updated.update(version=4, conditions=["Different technical description"])
    replace_fixture_record(registry, updated)
    second = registry.create_cohort(body(), idempotency_key="second")
    assert first["members"][1]["record_version"] == 1
    assert second["members"][1]["record_version"] == 4
    assert first["members"][1]["evidence_sha256"] != second["members"][1]["evidence_sha256"]
    assert registry.get_cohort(first["cohort_id"]) == first


def test_legacy_cohort_retry_precedes_current_eligibility_and_does_not_backfill(registry, monkeypatch):
    old = legacy_cohort_record(["twin-fixture-one", "twin-fixture-two"])
    seed_legacy(registry, old, "legacy-cohort")
    before = saved_bytes(registry, old["cohort_id"])
    forbid_compilation(monkeypatch)
    monkeypatch.setattr(registry, "get_twin", lambda *_: (_ for _ in ()).throw(AssertionError("retry must not reload members")))
    assert registry.create_cohort(historical_intent(old), idempotency_key="legacy-cohort") == old
    assert saved_bytes(registry, old["cohort_id"]) == before
    assert old["members"] == []


def test_reordered_roster_is_changed_intent_even_for_same_members(registry):
    old = legacy_cohort_record(["twin-fixture-one", "twin-fixture-two"])
    seed_legacy(registry, old, "legacy-cohort")
    changed = {**historical_intent(old), "member_twin_ids": list(reversed(old["member_twin_ids"]))}
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_cohort(changed, idempotency_key="legacy-cohort")
    assert caught.value.code == "IDEMPOTENCY_CONFLICT"


def test_global_key_namespace_conflicts_between_twin_and_cohort(registry):
    seed_legacy(registry, legacy_twin_record("four"), "cross-type")
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_cohort(body(), idempotency_key="cross-type")
    assert caught.value.code == "IDEMPOTENCY_CONFLICT"


def test_composition_reads_members_only_inside_its_write_transaction(registry, monkeypatch):
    original_open = registry._open
    row_connections = {}
    member_connections = []
    writes = []
    class Cursor(sqlite3.Cursor):
        def fetchone(self):
            row = super().fetchone()
            if row is not None:
                row_connections[id(row)] = self.connection
            return row
        def fetchall(self):
            result = super().fetchall()
            for row in result:
                row_connections[id(row)] = self.connection
            return result
    class Connection(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if "INSERT INTO records(" in sql and parameters[1] == "COHORT":
                writes.append(self)
            cursor = self.cursor(factory=Cursor)
            return cursor.execute(sql, parameters)
    def connect():
        connection = sqlite3.connect(registry.path, factory=Connection)
        connection.row_factory = sqlite3.Row
        return connection

    def opened(row):
        if row["record_type"] == "TWIN":
            connection = row_connections[id(row)]
            assert connection.in_transaction
            member_connections.append(connection)
        return original_open(row)

    monkeypatch.setattr(registry, "_connect", connect)
    monkeypatch.setattr(registry, "_open", opened)
    registry.create_cohort(body())
    assert len(writes) == 1 and len(member_connections) == 2
    assert all(connection is writes[0] for connection in member_connections)


def test_external_member_edit_cannot_change_inputs_mid_composition(registry, monkeypatch):
    original_open = registry._open
    entered, attempted = Event(), Event()
    changed = {**registry.get_twin("twin-fixture-two"), "version": 2, "conditions": ["Later technical change"]}
    nonce, ciphertext = registry._seal(changed["twin_id"], changed)
    def edit():
        assert entered.wait(3)
        with sqlite3.connect(registry.path, timeout=5) as connection:
            attempted.set()
            connection.execute("BEGIN IMMEDIATE")
            connection.execute("UPDATE records SET version=?,nonce=?,ciphertext=? WHERE record_id=?", (2, nonce, ciphertext, changed["twin_id"]))
    def opened(row):
        if row["record_id"] == "twin-fixture-one":
            entered.set()
            assert attempted.wait(3)
        return original_open(row)
    monkeypatch.setattr(registry, "_open", opened)
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(edit)
        cohort = registry.create_cohort(body())
        future.result(timeout=wait_seconds(6))
    assert cohort["members"][1]["record_version"] == 1
    assert registry.get_twin("twin-fixture-two")["version"] == 2


def test_no_partial_cohort_on_encryption_failure(registry, monkeypatch):
    original_seal = registry._seal

    def fail_cohort(record_id, payload):
        if record_id.startswith("cohort-"):
            raise RuntimeError("authored encryption failure")
        return original_seal(record_id, payload)

    monkeypatch.setattr(registry, "_seal", fail_cohort)
    with pytest.raises(RuntimeError):
        registry.create_cohort(body())
    assert record_count(registry, "COHORT") == 0


def test_actual_oversize_member_snapshots_fail_before_cohort_write(registry):
    for twin_id in body()["member_twin_ids"]:
        record = registry.get_twin(twin_id)
        record["authored_padding_not_clinical"] = "x" * (8 * 1024 * 1024)
        replace_fixture_record(registry, record)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_cohort(body())
    assert caught.value.code == "COHORT_PAYLOAD_TOO_LARGE"
    assert record_count(registry, "COHORT") == 0


def test_oversize_attempt_is_audited_without_success_or_dangling_reservation(registry):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    import json
    for twin_id in body()["member_twin_ids"]:
        record = registry.get_twin(twin_id)
        record["authored_padding_not_clinical"] = "x" * (8 * 1024 * 1024)
        replace_fixture_record(registry, record)
    with sqlite3.connect(registry.path) as connection:
        before = connection.execute("SELECT MAX(sequence) FROM registry_audit").fetchone()[0]
    with pytest.raises(SubjectRegistryError):
        registry.create_cohort(body())
    with sqlite3.connect(registry.path) as connection:
        events = connection.execute("SELECT event_id,nonce,ciphertext FROM registry_audit WHERE sequence>?", (before,)).fetchall()
        assert connection.execute("SELECT COUNT(*) FROM registry_audit_reservations").fetchone()[0] == 0
    payloads = [json.loads(AESGCM(KEY).decrypt(nonce, ciphertext, b"livemore.subject-registry.audit.v1\0" + event_id.encode())) for event_id, nonce, ciphertext in events]
    assert [payload["outcome_code"] for payload in payloads] == [None, "ACCESS_FAILED"]
    assert all(payload["action"] == "create_cohort" for payload in payloads)
    assert record_count(registry, "COHORT") == 0


def test_exact_serialized_payload_bound_is_utf8_canonical_not_character_count():
    from livemorebio.aegle import subjects
    limit = 16_777_216
    record = {"technical": ""}
    overhead = len(canonical(record))
    record["technical"] = "x" * (limit - overhead)
    subjects.enforce_real_cohort_size(record)
    record["technical"] += "x"
    with pytest.raises(SubjectRegistryError) as caught:
        subjects.enforce_real_cohort_size(record)
    assert caught.value.code == "COHORT_PAYLOAD_TOO_LARGE"


def test_member_1001_rejects_before_any_member_read(registry, monkeypatch):
    monkeypatch.setattr(registry, "get_twin", lambda *_: (_ for _ in ()).throw(AssertionError("count before I/O")))
    with pytest.raises(SubjectRegistryError):
        registry.create_cohort(body([f"twin-technical-{index}" for index in range(1001)]))
    assert record_count(registry, "COHORT") == 0


def test_summary_never_returns_full_roster_or_member_snapshots(registry):
    from livemorebio.aegle import subjects
    cohort = registry.create_cohort(body())
    summary = subjects.project_cohort_summary(cohort)
    assert summary["cohort_id"] == cohort["cohort_id"] and summary["size"] == 2
    assert not ({"members", "member_twin_ids", "member_fingerprints", "creation_identity"} & summary.keys())
    assert "observations" not in canonical(summary).decode()
    assert summary["execution_eligibility"]["reason_code"] == "MODEL_BINDING_REQUIRED"


def test_legacy_cohort_summary_requires_snapshot_not_live_member_lookup():
    from livemorebio.aegle import subjects
    old = legacy_cohort_record(["twin-fixture-one"])
    summary = subjects.project_cohort_summary(old)
    assert summary["execution_eligibility"]["reason_code"] == "COHORT_MEMBER_SNAPSHOT_REQUIRED"


def test_paged_member_summaries_and_exact_frozen_member_are_distinct(registry):
    cohort = registry.create_cohort(body())
    first = registry.page_cohort_members(cohort["cohort_id"], limit=1)
    assert len(first["members"]) == 1 and first["pagination"]["has_more"] is True
    assert set(first["members"][0]) == {"twin_id", "record_version", "display_label", "source_class", "execution_eligibility"}
    second = registry.page_cohort_members(cohort["cohort_id"], limit=1, cursor=first["pagination"]["next_cursor"])
    assert [first["members"][0]["twin_id"], second["members"][0]["twin_id"]] == body()["member_twin_ids"]
    assert second["pagination"]["next_cursor"] is None
    assert registry.get_cohort_member(cohort["cohort_id"], "twin-fixture-two") == cohort["members"][1]


@pytest.mark.parametrize("limit", [True, "10", 1.5, 0, 51, None])
def test_frozen_member_page_size_does_not_coerce(registry, limit):
    cohort = registry.create_cohort(body())
    with pytest.raises(SubjectRegistryError) as caught:
        registry.page_cohort_members(cohort["cohort_id"], limit=limit)
    assert caught.value.code == "INVALID_PAGE"


def test_member_cursor_binds_cohort_version_and_page_semantics(registry):
    first = registry.create_cohort(body(), idempotency_key="page-one")
    second = registry.create_cohort(body(), idempotency_key="page-two")
    page = registry.page_cohort_members(first["cohort_id"], limit=1)
    cursor = page["pagination"]["next_cursor"]
    for cohort_id, page_size, supplied in [(second["cohort_id"], 1, cursor), (first["cohort_id"], 2, cursor),
                                          (first["cohort_id"], 1, "invalid-cursor")]:
        with pytest.raises(SubjectRegistryError) as caught:
            registry.page_cohort_members(cohort_id, limit=page_size, cursor=supplied)
        assert caught.value.code == "INVALID_PAGE"
    first["version"] += 1
    replace_fixture_record(registry, first)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.page_cohort_members(first["cohort_id"], limit=1, cursor=cursor)
    assert caught.value.code == "INVALID_PAGE"


def test_cohort_and_success_audit_are_one_transaction(registry, monkeypatch):
    from livemorebio.aegle import registry_audit
    original_finish = registry_audit.RegistryAudit.finish

    def fail(self, connection, reservation, *, outcome_code):
        if outcome_code == "SUCCESS" and connection.execute("SELECT COUNT(*) FROM records WHERE record_type='COHORT'").fetchone()[0]:
            raise RuntimeError("authored cohort audit failure")
        return original_finish(self, connection, reservation, outcome_code=outcome_code)

    monkeypatch.setattr(registry_audit.RegistryAudit, "finish", fail)
    with pytest.raises(RuntimeError, match="authored cohort audit"):
        registry.create_cohort(body())
    assert record_count(registry, "COHORT") == 0


def test_member_inspection_detects_corrupt_snapshot_digest_without_live_fallback(registry, monkeypatch):
    cohort = registry.create_cohort(body())
    cohort["members"][0]["snapshot"]["conditions"] = ["Tampered authored ciphertext fixture"]
    replace_fixture_record(registry, cohort)
    monkeypatch.setattr(registry, "get_twin", lambda *_: (_ for _ in ()).throw(AssertionError("no live fallback")))
    with pytest.raises(ValueError):
        registry.get_cohort_member(cohort["cohort_id"], "twin-fixture-one")
