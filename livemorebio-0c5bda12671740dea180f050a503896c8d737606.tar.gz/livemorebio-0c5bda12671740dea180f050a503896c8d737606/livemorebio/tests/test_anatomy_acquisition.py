"""Concurrent anatomy pages cannot race on acquisition or trust corrupt caches."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import io
import json
import multiprocessing
import os
import threading
import time

import pytest

from livemorebio.anatomy import meshes
from livemorebio.tests.anatomy_fixtures import technical_glb
from ._timing import wait_seconds


def _probe_process_lock(result):
    try:
        with meshes._asset_lock("heart", timeout=0.1):
            result.put("acquired")
    except TimeoutError:
        result.put("acquiring")


def test_asset_lock_serializes_separate_processes(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    context = multiprocessing.get_context("spawn")
    result = context.Queue()
    with meshes._asset_lock("heart"):
        child = context.Process(target=_probe_process_lock, args=(result,))
        child.start()
        assert result.get(timeout=10) == "acquiring"
        child.join(timeout=wait_seconds(5))
        assert child.exitcode == 0
        row = next(row for row in meshes.manifest() if row["key"] == "heart")
        assert row["acquisition_state"] == "acquiring"
        assert not row["cached"]


def test_cache_directory_symlink_is_rejected(tmp_path, monkeypatch):
    target = tmp_path / "target"
    target.mkdir()
    linked = tmp_path / "linked"
    linked.symlink_to(target, target_is_directory=True)
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(linked))
    with pytest.raises(ValueError, match="directory"):
        meshes.anatomy_dir()


@pytest.mark.parametrize("kind", ["symlink", "hardlink", "foreign_owner"])
def test_unsafe_cache_entries_are_rejected(tmp_path, monkeypatch, kind):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    target = tmp_path / "technical-target"
    target.write_bytes(b"original")
    destination = tmp_path / "heart.glb"
    if kind == "symlink":
        destination.symlink_to(target)
    elif kind == "hardlink":
        os.link(target, destination)
    else:
        destination.write_bytes(b"original")
        original = Path.lstat
        def foreign_lstat(path, *args, **kwargs):
            value = original(path, *args, **kwargs)
            if path == destination:
                values = list(value)
                values[4] = value.st_uid + 1
                return os.stat_result(values)
            return value
        monkeypatch.setattr(Path, "lstat", foreign_lstat)
    with pytest.raises(ValueError, match="safe"):
        meshes.ensure_mesh("heart")
    assert target.read_bytes() == b"original"


def test_lock_names_cannot_escape_cache(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    with pytest.raises(ValueError, match="key"):
        with meshes._asset_lock("../outside"):
            pytest.fail("unsafe lock name admitted")


def test_provenance_publication_does_not_follow_fixed_temporary_symlink(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    target = tmp_path / "technical-target"
    target.write_text("preserve me", encoding="utf-8")
    glb = tmp_path / "heart.glb"
    glb.write_bytes(technical_glb())
    glb.with_suffix(".provenance.tmp").symlink_to(target)
    meshes._write_provenance("heart", glb, meshes.CATALOG["heart"])
    assert target.read_text(encoding="utf-8") == "preserve me"
    assert meshes.provenance("heart")["key"] == "heart"


def test_oversized_provenance_is_not_admitted(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    (tmp_path / "heart.glb").write_bytes(technical_glb())
    (tmp_path / "heart.provenance.json").write_text(json.dumps({"padding": "x" * 65536}), encoding="utf-8")
    assert meshes.provenance("heart") is None


def test_failed_download_preserves_existing_final_and_cleans_own_temporary(tmp_path, monkeypatch):
    destination = tmp_path / "heart.glb"
    destination.write_bytes(b"previous complete bytes")
    class BrokenResponse(io.BytesIO):
        def read(self, *args):
            if self.tell():
                raise OSError("interrupted technical transfer")
            return super().read(*args)
    monkeypatch.setattr(meshes.urllib.request, "urlopen", lambda *args, **kwargs: BrokenResponse(b"partial"))
    with pytest.raises(OSError, match="interrupted"):
        # L0-R16: a pinned catalog URL, the only kind the egress check admits for meshes.
        meshes._download(meshes.CATALOG["heart"]["url"], destination)
    assert destination.read_bytes() == b"previous complete bytes"
    assert list(tmp_path.iterdir()) == [destination]


@pytest.mark.parametrize("field,value", [("source_url", "https://example.invalid/wrong"), ("license", "unknown"), ("uberon", "UBERON:wrong")])
def test_cache_ready_requires_matching_catalog_binding(tmp_path, monkeypatch, field, value):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    glb = tmp_path / "heart.glb"
    glb.write_bytes(technical_glb())
    meshes._write_provenance("heart", glb, meshes.CATALOG["heart"])
    sidecar = glb.with_suffix(".provenance.json")
    metadata = json.loads(sidecar.read_text(encoding="utf-8"))
    metadata[field] = value
    sidecar.write_text(json.dumps(metadata), encoding="utf-8")
    row = next(row for row in meshes.manifest() if row["key"] == "heart")
    assert not row["cached"]
    assert "provenance" not in row
    assert meshes.provenance("heart") is None


def test_concurrent_mesh_requests_acquire_once(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    calls = []
    began = threading.Event()
    def download(url, destination, timeout=120):
        calls.append(url)
        began.set()
        time.sleep(0.1)
        Path(destination).write_bytes(technical_glb())
    monkeypatch.setattr(meshes, "_download", download)
    with ThreadPoolExecutor(2) as workers:
        first = workers.submit(meshes.ensure_mesh, "heart")
        assert began.wait(2)
        second = workers.submit(meshes.ensure_mesh, "heart")
        assert first.result(timeout=wait_seconds(3)) == second.result(timeout=wait_seconds(3))
    assert len(calls) == 1


def test_changed_cached_bytes_are_not_reported_ready(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    def download(url, destination, timeout=120):
        Path(destination).write_bytes(technical_glb("source-bound technical bytes"))
    monkeypatch.setattr(meshes, "_download", download)
    path = meshes.ensure_mesh("heart")
    path.write_bytes(b"corrupted bytes")
    row = next(row for row in meshes.manifest() if row["key"] == "heart")
    assert row["cached"] is False
    assert "provenance" not in row
    assert meshes.ensure_mesh("heart").read_bytes() == technical_glb("source-bound technical bytes")


def test_acquisition_error_response_does_not_expose_local_paths(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app
    def fail(key):
        raise OSError("PRIVATE LOCAL PATH")
    monkeypatch.setattr(meshes, "read_asset", fail)
    response = TestClient(app).get("/assets/anatomy/heart.glb")
    assert response.status_code == 503
    assert "PRIVATE" not in response.text
    assert response.headers["retry-after"]


def test_writable_cache_directory_is_not_admitted(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    tmp_path.chmod(0o777)
    with pytest.raises(ValueError, match="directory"):
        meshes.anatomy_dir()


def test_bp3d_changed_requested_parts_invalidate_old_geometry(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    glb = tmp_path / "muscle.glb"
    glb.write_bytes(technical_glb())
    entry = dict(meshes.CATALOG["muscle"])
    meshes._write_provenance("muscle", glb, entry, extra={
        "fma_parts": entry["fma_parts"], "part_names": entry["part_names"],
        "conversion": "OBJ->GLB via trimesh, geometry unmodified"})
    assert meshes.provenance("muscle") is not None
    monkeypatch.setitem(meshes.CATALOG, "muscle", {**entry, "fma_parts": ["FMA:wrong"]})
    assert meshes.provenance("muscle") is None


@pytest.mark.parametrize("payload", [b"", b"<html>error</html>", b"glTF" + b"\0" * 16,
                                     technical_glb()[:-4]])
def test_bad_glb_download_is_rejected_before_replacing_existing_asset(tmp_path, monkeypatch, payload):
    destination = tmp_path / "heart.glb"
    destination.write_bytes(technical_glb("previous"))
    monkeypatch.setattr(meshes.urllib.request, "urlopen", lambda *args, **kwargs: io.BytesIO(payload))
    with pytest.raises(ValueError, match="GLB"):
        # L0-R16: a pinned catalog URL, the only kind the egress check admits for meshes.
        meshes._download(meshes.CATALOG["heart"]["url"], destination)
    assert destination.read_bytes() == technical_glb("previous")


def test_asset_response_returns_only_bytes_matching_its_verified_digest(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    glb = tmp_path / "heart.glb"
    glb.write_bytes(technical_glb("before"))
    meshes._write_provenance("heart", glb, meshes.CATALOG["heart"])
    original = meshes._verified_provenance
    def race(*args):
        metadata = original(*args)
        glb.write_bytes(technical_glb("changed after verification"))
        return metadata
    monkeypatch.setattr(meshes, "_verified_provenance", race)
    response = TestClient(app).get("/assets/anatomy/heart.glb")
    assert response.status_code == 503
    assert response.json()["code"] == "ANATOMY_UNAVAILABLE"


def test_asset_provenance_timeout_is_sanitized(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    def fail(*args):
        raise TimeoutError("PRIVATE timeout path")
    monkeypatch.setattr(meshes, "_verified_provenance", fail)
    response = TestClient(app, raise_server_exceptions=False).get("/assets/anatomy/heart.glb")
    assert response.status_code == 503
    assert response.json()["code"] == "ANATOMY_ACQUIRING"
    assert "PRIVATE" not in response.text
