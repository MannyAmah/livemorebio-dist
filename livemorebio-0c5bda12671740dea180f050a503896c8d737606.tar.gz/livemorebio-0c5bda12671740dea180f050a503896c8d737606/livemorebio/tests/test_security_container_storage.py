"""Technical container-storage fixtures; no observed biological data."""
from __future__ import annotations

from pathlib import Path
import asyncio
import importlib
import os
import re
import stat

import pytest

from ._source_tree import source_tree_only


@source_tree_only("Dockerfile")
def test_image_creates_owner_only_data_directory_before_declaring_volume():
    source = (Path(__file__).resolve().parents[2] / "Dockerfile").read_text(encoding="utf-8")
    volume = source.index('VOLUME ["/root/.livemore"]')
    creation = re.search(r"(?m)^RUN mkdir -m 0700 -p /root/\.livemore$", source)
    assert creation is not None, "new named volumes must inherit an owner-only root"
    assert creation.start() < volume
    assert not re.search(r"(?m)^USER (?!root\s*$|0\s*$)", source[:creation.start()])


@pytest.mark.parametrize("service", ("aegle.server", "life_system.service", "cendos.service"))
def test_each_service_tightens_storage_before_restoration_or_serving(
    tmp_path, monkeypatch, service, technical_stack_identities,
):
    from livemorebio import registry
    from livemorebio.stack_proof import configure_test_identity

    module = importlib.import_module("livemorebio." + service)
    monkeypatch.setattr(module.app.state, "stack_proof", module.app.state.stack_proof)
    configure_test_identity(module.app, technical_stack_identities[module.app.state.stack_proof_role])
    directory = tmp_path / "old-image-volume"
    directory.mkdir(mode=0o755)
    directory.chmod(0o755)
    monkeypatch.setattr(registry, "REG_DIR", str(directory))
    calls = []
    ensure = registry.ensure_data_dir

    def tighten():
        calls.append("tighten")
        return ensure()

    monkeypatch.setattr(registry, "ensure_data_dir", tighten)

    def restore():
        assert calls == ["tighten"]
        assert stat.S_IMODE(directory.stat().st_mode) == 0o700
        calls.append("restore")

    if service == "aegle.server":
        monkeypatch.setattr(module, "_startup_publish", restore)
        monkeypatch.setattr(module, "shutdown_execution_manager", lambda: None)
    elif service == "life_system.service":
        monkeypatch.setattr(module, "shutdown_virtual_manager", lambda: None)

    async def serve():
        async with module.app.router.lifespan_context(module.app):
            expected = ["tighten", "restore"] if service == "aegle.server" else ["tighten"]
            assert calls == expected
            assert stat.S_IMODE(directory.stat().st_mode) == 0o700

    asyncio.run(serve())


@pytest.mark.parametrize("initial", (0o755, 0o750, 0o700, 0o500, 0o300))
def test_tightening_owned_directory_never_adds_permissions(tmp_path, initial):
    from livemorebio import registry

    directory = tmp_path / "technical-storage"
    directory.mkdir()
    directory.chmod(initial)
    try:
        assert registry.ensure_data_dir(str(directory)) == str(directory)
        assert stat.S_IMODE(directory.stat().st_mode) == (initial & 0o700)
    finally:
        directory.chmod(0o700)


def test_foreign_directory_is_unchanged_and_registry_still_refuses_it(tmp_path, monkeypatch):
    from livemorebio import registry
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError, prepare_storage

    directory = tmp_path / "foreign-owned-volume"
    directory.mkdir()
    directory.chmod(0o755)
    actual_uid = directory.stat().st_uid
    # Emulate another process uid; ownership itself is never changed by this test.
    monkeypatch.setattr(os, "getuid", lambda: actual_uid + 1)
    monkeypatch.setattr(os, "geteuid", lambda: actual_uid + 1)
    registry.ensure_data_dir(str(directory))
    assert stat.S_IMODE(directory.stat().st_mode) == 0o755
    with pytest.raises(RegistryBootstrapError) as refused:
        prepare_storage(directory / "subjects.sqlite3")
    assert refused.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert not (directory / "subjects.sqlite3").exists()
    assert list(directory.iterdir()) == []


@pytest.mark.parametrize("owned", [True, False])
def test_directory_symlink_tightens_only_owned_target_and_registry_still_refuses_it(
    tmp_path, monkeypatch, owned,
):
    from livemorebio import registry
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError, prepare_storage

    target = tmp_path / "symlink-target"
    target.mkdir()
    target.chmod(0o755)
    directory = tmp_path / "linked-volume"
    directory.symlink_to(target, target_is_directory=True)
    if not owned:
        actual_uid = target.stat().st_uid
        # Model a foreign owner without changing any filesystem ownership.
        monkeypatch.setattr(os, "getuid", lambda: actual_uid + 1)
        monkeypatch.setattr(os, "geteuid", lambda: actual_uid + 1)
    registry.ensure_data_dir(str(directory))
    assert stat.S_IMODE(target.stat().st_mode) == (0o700 if owned else 0o755)
    with pytest.raises(RegistryBootstrapError) as refused:
        prepare_storage(directory / "subjects.sqlite3")
    assert refused.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert list(target.iterdir()) == []
