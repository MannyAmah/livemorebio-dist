"""Storage/worker failure tests use only private technical data."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3

import pytest

from livemorebio.aegle.execution_store import ExecutionStore
from livemorebio.aegle.execution_contract import ExecutionError


@pytest.mark.parametrize("alias", ["symlink", "hardlink", "public"])
def test_store_rejects_unsafe_final_files(tmp_path, alias):
    target = tmp_path / "target"
    target.touch(mode=0o600)
    path = tmp_path / "database"
    if alias == "symlink":
        path.symlink_to(target)
    elif alias == "hardlink":
        os.link(target, path)
    else:
        path.touch(mode=0o644)
        path.chmod(0o644)
    with pytest.raises(ValueError):
        ExecutionStore(path, key=b"x" * 32)


def test_store_rejects_nonprivate_directory(tmp_path):
    directory = tmp_path / "public"
    directory.mkdir(mode=0o755)
    directory.chmod(0o755)
    with pytest.raises(ValueError):
        ExecutionStore(directory / "state.sqlite3", key=b"x" * 32)


def test_native_worker_launch_isolates_environment_and_mutable_paths(tmp_path, monkeypatch):
    import livemorebio.aegle.execution_worker as module
    from livemorebio.tests.test_continuous_execution import captured_source

    observed = {}
    monkeypatch.setenv("HOME", str(tmp_path / "operational-home"))
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "TECHNICAL SECRET MARKER")
    monkeypatch.setenv("DYLD_LIBRARY_PATH", "/untrusted/native")
    monkeypatch.setenv("PATH", "/untrusted/bin")

    def stopped_launch(args, **kwargs):
        observed.update(kwargs)
        assert args[1:3] == ["-I", "-B"]
        assert Path(kwargs["env"]["HOME"]).is_dir()
        raise OSError("technical launch denied")

    monkeypatch.setattr(module.subprocess, "Popen", stopped_launch)
    with pytest.raises(ExecutionError):
        module.IsolatedAdapter(captured_source())
    environment = observed["env"]
    assert "LIVEMORE_API_TOKEN" not in environment
    assert environment["HOME"] != str(tmp_path / "operational-home")
    assert environment["TMPDIR"] != environment.get("HOME")
    assert "/untrusted" not in json.dumps(environment)
    assert observed["close_fds"] is True


def test_native_worker_actual_metabolic_roundtrip(tmp_path):
    from livemorebio.aegle.execution_worker import IsolatedAdapter
    from livemorebio.tests.test_continuous_execution import captured_source

    adapter = IsolatedAdapter(captured_source())
    try:
        initial = adapter.initialize()
        advanced = adapter.advance(initial, 1.)
        assert advanced["checkpoint"]["native_time"] == 1.
        assert advanced["series"][0]["values"][-1] > 90.
    finally:
        adapter.close()
    assert adapter.process.poll() is not None


def test_quota_is_shared_across_executions_with_reserved_transition_capacity(tmp_path):
    from livemorebio.tests.test_continuous_execution import captured_source
    store = ExecutionStore(tmp_path / "total.sqlite3", key=b"k" * 32, quota_bytes=16384)
    source = captured_source()
    policy = {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}
    with pytest.raises(ExecutionError) as error:
        for index in range(20):
            store.create(source, policy, idempotency_key=f"total-{index}")
    assert error.value.code == "EXECUTION_QUOTA"
    with sqlite3.connect(store.path) as database:
        used, count = database.execute("SELECT SUM(used_bytes), COUNT(*) FROM executions").fetchone()
    assert used + count * 4096 <= store.quota_bytes


def test_encrypted_access_audit_reserves_outcome_space_and_rejects_free_text(tmp_path):
    store = ExecutionStore(tmp_path / "audit.sqlite3", key=b"a" * 32, quota_bytes=8192)
    request_id = store.begin_access("frames", execution_id="f" * 32)
    assert len(request_id) == 32
    pending = []
    with pytest.raises(ExecutionError) as error:
        for _ in range(100):
            pending.append(store.begin_access("status"))
    assert error.value.code == "EXECUTION_QUOTA"
    # Every admitted request retains reserved capacity even if later requests
    # fill all unreserved bytes, including its error result after a mutation.
    store.finish_access(request_id, "OK")
    for request in pending:
        store.finish_access(request, "EXECUTION_UNAVAILABLE")
    with pytest.raises(ValueError):
        store.begin_access("PRIVATE TECHNICAL PHI MARKER")
    with pytest.raises(ValueError):
        store.finish_access(request_id, "PRIVATE TECHNICAL PHI MARKER")
    assert b"local-operator" not in store.path.read_bytes()
    assert b"PRIVATE TECHNICAL PHI MARKER" not in store.path.read_bytes()
    with sqlite3.connect(store.path) as database:
        assert database.execute("SELECT COUNT(*) FROM access_audit WHERE outcome IS NULL").fetchone()[0] == 0


def test_incomplete_audit_is_preserved_on_restart(tmp_path):
    path = tmp_path / "pending.sqlite3"
    store = ExecutionStore(path, key=b"p" * 32)
    request_id = store.begin_access("prepare")
    restarted = ExecutionStore(path, key=b"p" * 32)
    with sqlite3.connect(path) as database:
        assert database.execute("SELECT outcome FROM access_audit WHERE request_id=?", (request_id,)).fetchone() == (None,)
    restarted.finish_access(request_id, "EXECUTION_UNAVAILABLE")
def test_storage_kind_is_encrypted_and_cannot_be_reinterpreted(tmp_path):
    from livemorebio.aegle.execution_store import ExecutionStore
    path = tmp_path / "kind.sqlite3"
    original = ExecutionStore(path, key=b"t" * 32, store_kind="virtual-session")
    assert ExecutionStore(path, key=b"t" * 32, store_kind="virtual-session").path == original.path
    assert b"virtual-session" not in path.read_bytes()
    with pytest.raises(ValueError):
        ExecutionStore(path, key=b"t" * 32)
    with pytest.raises(ValueError):
        ExecutionStore(tmp_path / "arbitrary.sqlite3", key=b"t" * 32, store_kind="arbitrary")


def test_unmarked_existing_file_cannot_be_adopted_as_virtual_session_store(tmp_path):
    from livemorebio.aegle.execution_store import ExecutionStore
    path = tmp_path / "unmarked.sqlite3"
    original = ExecutionStore(path, key=b"t" * 32)
    with original._connection() as connection:
        connection.execute("DROP TABLE storage_kind")
    with pytest.raises(ValueError):
        ExecutionStore(path, key=b"t" * 32, store_kind="virtual-session")
    # The additive marker preserves pre-marker execution databases.
    assert ExecutionStore(path, key=b"t" * 32).path == original.path
