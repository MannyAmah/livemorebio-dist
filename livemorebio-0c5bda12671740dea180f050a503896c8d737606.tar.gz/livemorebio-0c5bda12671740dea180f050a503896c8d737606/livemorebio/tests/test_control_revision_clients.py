"""Lifecycle intent guards stay explicit across SDK, terminal and one-shot HTTP."""
import json

import pytest

from livemorebio.execution_client import ContinuousClientError
from livemorebio.execution_commands import run_continuous_command
from livemorebio.sdk import Platform
from livemorebio.tests.test_execution_clients import IDENTITY
from livemorebio.tests.test_execution_commands import RecordingPlatform


CONTROLS = [(False, action) for action in ("start", "pause", "resume", "stop")] + [
    (True, action) for action in ("pause", "resume", "stop")]


@pytest.mark.parametrize("virtual,action", CONTROLS)
@pytest.mark.parametrize("guard", ["expected_revision", "expected_control_revision"])
def test_sdk_sends_one_explicit_guard_without_hidden_read_or_retry(monkeypatch, virtual, action, guard):
    platform, calls = Platform(mode="attach"), []
    monkeypatch.setattr(platform, "_continuous_request", lambda *args, **kwargs: calls.append((args, kwargs)) or {})
    kwargs = {guard: 7}
    if not virtual:
        kwargs["expected_source_generation"] = "generation-a"
    method = action + ("_virtual_session" if virtual else "_execution")
    getattr(platform, method)(IDENTITY, **kwargs)
    path = ("/api/patch/virtual/sessions/" if virtual else "/api/executions/") + IDENTITY + "/" + action
    assert len(calls) == 1
    assert calls[0][0] == ("POST", path, kwargs)
    if not virtual:
        assert calls[0][1]["timeout"] == (60 if action in {"start", "resume"} else 20)


@pytest.mark.parametrize("virtual,action", CONTROLS)
@pytest.mark.parametrize("guards", [{}, {"expected_revision": 1, "expected_control_revision": 1},
    *[{"expected_control_revision": value} for value in (True, False, 0, -1, 1.0, "1")]])
def test_sdk_rejects_missing_conflicting_or_coerced_guard_before_transport(monkeypatch, virtual, action, guards):
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_continuous_request", lambda *args, **kwargs: pytest.fail("invalid guard reached transport"))
    kwargs = dict(guards)
    if not virtual:
        kwargs["expected_source_generation"] = "generation-a"
    with pytest.raises(ContinuousClientError):
        getattr(platform, action + ("_virtual_session" if virtual else "_execution"))(IDENTITY, **kwargs)


@pytest.mark.parametrize("virtual,action", CONTROLS)
def test_new_cli_guard_has_exact_sdk_mapping_and_metadata_visibility(virtual, action):
    platform, output = RecordingPlatform(), []
    method = action + ("_virtual_session" if virtual else "_execution")
    def call(*args, **kwargs):
        platform.calls.append((method, args, kwargs))
        return {"revision": 91, "control_revision": 7, "state": "paused", "private_values": [123]}
    setattr(platform, method, call)
    tokens = (["patch", "virtual"] if virtual else ["execution"]) + [action, IDENTITY, "control_revision=7"]
    kwargs = {"expected_control_revision": 7}
    if not virtual:
        tokens.append("generation=generation-a")
        kwargs["expected_source_generation"] = "generation-a"
    run_continuous_command(platform, tokens, out=output.append)
    assert platform.calls == [(method, (IDENTITY,), kwargs)]
    assert json.loads(output[0]) == {"revision": 91, "control_revision": 7, "state": "paused"}


@pytest.mark.parametrize("virtual", [False, True])
@pytest.mark.parametrize("guard_tokens", [[], ["control_revision=1", "revision=2"],
    ["control_revision=1", "control_revision=2"], *[["control_revision=" + value] for value in ("true", "false", "0", "-1", "1.0", "NaN")]])
def test_cli_invalid_guard_never_calls_sdk(virtual, guard_tokens):
    platform = RecordingPlatform()
    tokens = (["patch", "virtual"] if virtual else ["execution"]) + ["pause", IDENTITY] + guard_tokens
    if not virtual:
        tokens.append("generation=generation-a")
    with pytest.raises(ContinuousClientError):
        run_continuous_command(platform, tokens, out=lambda value: None)
    assert platform.calls == []


def test_control_conflict_is_returned_once_without_fetching_a_new_guard(monkeypatch):
    platform, calls = Platform(mode="attach"), []
    def reject(*args, **kwargs):
        calls.append(args)
        raise ContinuousClientError("EXECUTION_CONFLICT", status=409)
    monkeypatch.setattr(platform, "_continuous_request", reject)
    with pytest.raises(ContinuousClientError, match="rejected"):
        platform.pause_virtual_session(IDENTITY, expected_control_revision=7)
    assert len(calls) == 1 and calls[0][0] == "POST"
