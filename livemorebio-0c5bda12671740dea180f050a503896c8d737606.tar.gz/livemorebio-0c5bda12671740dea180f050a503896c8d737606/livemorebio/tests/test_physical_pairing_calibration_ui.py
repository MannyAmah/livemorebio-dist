"""Authored legacy pairing UI only: no participant, device, browser or service."""

import json
import re
from html.parser import HTMLParser
from pathlib import Path
import subprocess

import pytest
from ._node import NODE, run_node as _run_node


CONSOLE = Path(__file__).parents[1] / "aegle/console"


class Markup(HTMLParser):
    def __init__(self):
        super().__init__()
        self.fields = {}
        self.options = []
        self.calibration = False
        self.in_form = False
        self.form_fields = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.fields[attrs["id"]] = (tag, attrs)
            if self.in_form:
                self.form_fields.add(attrs["id"])
        if tag == "form":
            self.in_form = attrs.get("id") == "physical-patch-form"
        if tag == "select":
            self.calibration = attrs.get("id") == "physical-calibration"
        elif tag == "option" and self.calibration:
            self.options.append(attrs)

    def handle_endtag(self, tag):
        if tag == "select":
            self.calibration = False
        elif tag == "form":
            self.in_form = False


def test_markup_requires_explicit_declaration_and_preserves_legacy_scope():
    source = (CONSOLE / "twins.html").read_text(encoding="utf-8")
    markup = Markup()
    markup.feed(source)
    assert "required" in markup.fields["physical-calibration"][1]
    assert markup.fields["physical-calibration"][1]["aria-describedby"] == "physical-calibration-feedback"
    assert markup.fields["physical-calibration-feedback"][1]["role"] == "status"
    assert "physical-calibration-feedback" in markup.form_fields
    assert "hidden" not in markup.fields["physical-calibration-feedback"][1]
    assert markup.options[0] == {"value": "", "selected": None, "disabled": None}
    assert [row["value"] for row in markup.options] == ["", "current", "due", "failed"]
    assert all("selected" not in row for row in markup.options[1:])
    for field, expected in (("physical-protocol-version", "2.0"),
                            ("physical-hardware-revision", "B0-EVT-target")):
        assert markup.fields[field][1]["value"] == expected
        assert "readonly" in markup.fields[field][1]
    assert "Declared calibration" in source
    assert "operator declaration, not a verified calibration certificate" in source
    assert "Complete registered-lineage physical-v3 onboarding is not available in this form" in source
    assert "v3 provisioning uses the API/SDK" not in source
    assert "signed admission envelope" in source
    assert "does not prove a live sensor connection" in source
    assert "not a human-use release" in source


PREAMBLE = r"""
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
let completed=false;process.on('beforeExit',()=>{if(!completed){console.error('TEST_DID_NOT_SETTLE');process.exitCode=1}});
(async()=>{
const {mountSelectionReconciliation,selectionRequest}=await import(RECOVERY);
const source=fs.readFileSync(SUBJECTS,'utf8').replace(/^import .*;\n/gm,'').split('document.querySelector("#refresh-records")')[0];
let focused=null,validityCalls=0,posts=[],reads=0,hold=false;
let active={twin_id:'twin-technical',version:3,source_class:'REAL_HUMAN',subject_id:'technical-only',display_label:'Authored pairing fixture — not a participant',lifecycle:'ACTIVE'};
const listing=()=>({selection_status:'CONFIRMED',active:{...active},twins:[],pagination:{}});
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return{promise,resolve}};
const pending=deferred();
class E {
 constructor(id){this.id=id;this.value='';this.dataset={};this.disabled=false;this.hidden=false;this.textContent='';this.innerHTML='';this.handlers={};this.classList={toggle(){}};this.open=false;this.opens=0;this.closes=0}
 addEventListener(k,f){this.handlers[k]=f} removeEventListener(k,f){if(this.handlers[k]===f)delete this.handlers[k]}
 setAttribute(){} querySelectorAll(){return[]} focus(){focused=this.id}
 showModal(){this.open=true;this.opens++} close(){this.open=false;this.closes++}
}
const nodes=new Map();const get=id=>{if(!nodes.has(id))nodes.set(id,new E(id));return nodes.get(id)};
const button=get('#technical-pair-button'),submit=get('#technical-submit');
button.dataset={physical:active.twin_id,version:String(active.version)};
const document={body:{dataset:{subjectView:'twins'},setAttribute(){}},querySelector:get,querySelectorAll:s=>s.startsWith('[data-activate]')?[button,submit]:s.startsWith('#record-list button')?[button,submit]:[]};
const form=get('#physical-patch-form'),dialog=get('#physical-patch-dialog'),calibration=get('#physical-calibration');
form.reportValidity=()=>{validityCalls++;const invalid=['#physical-device-id','#physical-firmware-version','#physical-attestation','#physical-calibration'].find(id=>!get(id).value);if(invalid)get(invalid).focus();return !invalid};
get('#physical-hardware-revision').value='B0-EVT-target';get('#physical-protocol-version').value='2.0';
// The authored DOM deliberately starts with the old default so opening itself
// must clear any value, independently of the separate parsed-markup assertion.
calibration.value='current';
const context={document,escapeHTML:String,URLSearchParams,AbortController,mountSelectionReconciliation,setTimeout(){},clearTimeout(){},
 fetch:async(path,options)=>{assert.equal(options.method,'POST');posts.push({path,body:JSON.parse(options.body)});if(hold)await pending.promise;return{status:200,ok:true,json:async()=>({twin_id:active.twin_id,version:4})}},
 selectionRequest:(path,options={})=>selectionRequest(path,{...options,fetcher:async(url,init)=>{assert.equal(init.method,'GET');reads++;return new Response(JSON.stringify(listing()),{status:200})}})};
vm.createContext(context);vm.runInContext(source,context);
const admit=(payload=listing())=>{context.payload=payload;assert(vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context))};
admit();vm.runInContext('bindPhysicalPatchForm()',context);
const open=()=>{context.button=button;vm.runInContext('openPhysicalPatch(button)',context)};
const fill=()=>{get('#physical-device-id').value='technical-device';get('#physical-firmware-version').value='technical-firmware';get('#physical-attestation').value='technical-declaration'};
const submitForm=()=>form.handlers.submit({preventDefault(){},currentTarget:form});
const finish=()=>vm.runInContext('disposeSubjectView()',context);
"""


def run_node(script):
    source = PREAMBLE.replace("RECOVERY", json.dumps((CONSOLE / "lib/selection_reconciliation.js").as_uri()))
    source = source.replace("SUBJECTS", json.dumps(str(CONSOLE / "lib/subjects.js")))
    source += script + "\nfinish();})().then(()=>{completed=true},error=>{completed=true;console.error(error);process.exitCode=1});"
    result = _run_node([NODE, "--eval", source],
                            capture_output=True, text=True, timeout=12, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("prior", ["", "current", "due", "failed"])
def test_every_reopening_requires_new_choice(prior):
    run_node(f"""open();fill();calibration.value={json.dumps(prior)};dialog.close();open();
assert.equal(calibration.value,'');assert.equal(dialog.opens,2);assert(dialog.open);
for(const id of ['#physical-device-id','#physical-firmware-version','#physical-attestation'])assert.equal(get(id).value,'');
assert.equal(focused,'#physical-device-id');assert.equal(posts.length,0);assert.equal(reads,0);""")


def test_new_person_open_captures_new_authority_without_prior_calibration():
    run_node("""open();fill();calibration.value='current';dialog.close();
active={...active,twin_id:'twin-other-technical',version:7};admit();button.dataset={physical:active.twin_id,version:'7'};open();
assert.equal(calibration.value,'');assert.equal(form.dataset.twin,active.twin_id);assert.equal(form.dataset.version,'7');
assert.equal(form.dataset.selectionEpoch,String(vm.runInContext('selectionRecovery.snapshot().epoch',context)));
assert.equal(focused,'#physical-device-id');assert.equal(posts.length,0);""")


def test_blank_calibration_uses_native_validity_before_post():
    run_node("""open();fill();calibration.value='';await submitForm();assert.equal(validityCalls,1);
assert.equal(posts.length,0);assert.equal(reads,0);assert(dialog.open);assert.equal(focused,'#physical-calibration');
assert(!get('#subject-banner').textContent.includes('Recording'));assert.equal(vm.runInContext('operationBusy',context),false);""")


@pytest.mark.parametrize("value", ["due", "failed", "unknown"])
def test_noncurrent_declaration_blocks_post_and_retains_inputs(value):
    run_node(f"""open();fill();calibration.value={json.dumps(value)};await submitForm();assert.equal(validityCalls,1);
assert.equal(posts.length,0);assert.equal(reads,0);assert(dialog.open);assert.equal(focused,'#physical-calibration');
assert.equal(calibration.value,{json.dumps(value)});assert.equal(get('#physical-device-id').value,'technical-device');
assert.equal(get('#subject-banner').textContent,'Physical pairing requires an explicit declaration of current calibration. Due or failed calibration cannot be paired.');
assert.equal(get('#physical-calibration-feedback').textContent,get('#subject-banner').textContent);assert(!get('#physical-calibration-feedback').hidden);""")


def test_explicit_current_keeps_exact_existing_v2_wire_payload():
    run_node("""open();fill();calibration.value='current';await submitForm();assert.equal(validityCalls,1);
assert.deepEqual(posts,[{path:'/api/twins/twin-technical/patches',body:{expected_version:3,device_id:'technical-device',mode:'physical',hardware_revision:'B0-EVT-target',protocol_version:'2.0',firmware_version:'technical-firmware',calibration_status:'current',attestation_reference:'technical-declaration'}}]);
assert.equal(reads,1);assert.equal(dialog.closes,1);assert.equal(vm.runInContext('operationBusy',context),false);
assert.match(get('#subject-banner').textContent,/Telemetry is still pending a signed LIFE admission envelope/);""")


@pytest.mark.parametrize("change", ["epoch", "version", "twin", "unconfirmed"])
def test_selection_fence_precedes_validation_and_post(change):
    mutations = {"epoch": "form.dataset.selectionEpoch='999';",
                 "version": "form.dataset.version='4';",
                 "twin": "form.dataset.twin='twin-stale';",
                 "unconfirmed": "admit({selection_status:'UNCONFIRMED',active:null,twins:[],pagination:{}});"}
    run_node("open();fill();calibration.value='current';" + mutations[change] + """
await submitForm();assert.equal(posts.length,0);assert.equal(reads,0);assert.equal(validityCalls,0);
assert(dialog.open);assert.equal(calibration.value,'current');assert.match(get('#subject-banner').textContent,/Selection changed or is unconfirmed/);""")


def test_overlapping_submission_cannot_send_a_second_post():
    run_node("""open();fill();calibration.value='current';hold=true;const first=submitForm();
assert.equal(posts.length,1);assert(button.disabled&&submit.disabled);await submitForm();assert.equal(posts.length,1);
pending.resolve();await first;assert.equal(posts.length,1);assert.equal(reads,1);assert.equal(dialog.closes,1);
assert.equal(vm.runInContext('operationBusy',context),false);""")


def test_local_feedback_is_cleared_on_each_opening():
    run_node("""open();get('#physical-calibration-feedback').textContent='Prior declaration rejected';dialog.close();open();
assert.equal(get('#physical-calibration-feedback').textContent,'');assert.equal(calibration.value,'');
assert.equal(focused,'#physical-device-id');assert(dialog.open);assert.equal(posts.length,0);""")


def test_current_resubmission_clears_prior_local_feedback_before_post():
    run_node("""open();fill();calibration.value='due';await submitForm();assert.equal(posts.length,0);
assert(get('#physical-calibration-feedback').textContent.length>0);calibration.value='current';hold=true;
const current=submitForm();assert.equal(posts.length,1);assert.equal(get('#physical-calibration-feedback').textContent,'');
assert(dialog.open);pending.resolve();await current;assert.equal(posts.length,1);assert.equal(reads,1);""")


def test_empty_calibration_placeholder_is_short_without_assigning_a_declaration():
    source = (CONSOLE / 'twins.html').read_text(encoding="utf-8")
    select = re.search(r'<label>Declared calibration<select id="physical-calibration"[^>]*>(.*?)</select>', source).group(1)
    assert select.startswith('<option value="" selected disabled>Choose status…</option>')
    assert '<option value="current">Current</option>' in select
    markup = Markup(); markup.feed(source)
    assert 'required' in markup.fields['physical-calibration'][1]
    assert [row['value'] for row in markup.options] == ['', 'current', 'due', 'failed']


def test_only_empty_local_feedback_is_hidden_without_removing_live_association():
    css = (CONSOLE / 'lib/subjects.css').read_text(encoding="utf-8")
    rules = re.findall(r'([^{}]+)\{([^{}]*)\}', css)
    local = [(selector.strip(), body.strip()) for selector, body in rules if 'physical-calibration-feedback' in selector]
    assert local == [('#physical-calibration-feedback:empty', 'display:none;')]
    markup = Markup(); markup.feed((CONSOLE / 'twins.html').read_text(encoding="utf-8"))
    assert markup.fields['physical-calibration-feedback'][1]['role'] == 'status'
    assert markup.fields['physical-calibration'][1]['aria-describedby'] == 'physical-calibration-feedback'
