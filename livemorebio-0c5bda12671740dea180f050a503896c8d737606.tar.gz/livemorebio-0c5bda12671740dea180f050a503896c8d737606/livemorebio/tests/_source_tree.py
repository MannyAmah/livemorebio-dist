"""Which tree the suite is running in, and what that tree may legitimately lack.

The same suite is run from three trees, and only the first is a repository:

* a source checkout -- developers and hosted CI;
* an unpacked release archive -- ``install.sh`` verifying a client's install.
  The publisher may omit policy-private research inputs, but its public marker
  must identify that projection. There is no repository, and ``git`` is not an
  install prerequisite, so the executable may not exist at all;
* the container image -- the Dockerfile's verification step, on a base image
  that has no ``git``.

Tests that build a release need a repository. Everywhere else they skip, and
they must skip through this module: asking ``git`` directly raises when there
is no ``git`` to ask, and a module that raises while it is being imported is a
collection error, which stops the whole run instead of skipping one test.

The image is also not a source tree. It is the product a client receives, so it
carries only ``CONTAINER_IMAGE_PATHS``. Tests of the source tree's own release
tooling -- the installer, the Dockerfile, the hosted workflows, the records
pinned under ``docs/solutions`` -- read files it does not have, and have nothing
to verify there. They skip in the image through ``source_tree_only`` and
``require_source_tree``, with a reason naming what is absent. The tests of the
frozen research tools cannot be edited to say so, and are named in
``FROZEN_TESTS_READING_THE_SOURCE_TREE`` instead. Four rules keep that from
becoming a silent pass:

* only a tree the Dockerfile has *declared* to be the image may skip. In any
  other tree an absent file fails the test, as it always did;
* the declaration is believed only where it is true. It is an environment
  variable, so it can be exported anywhere. A tree that has any of
  ``NEVER_IN_AN_IMAGE`` is a checkout, an unpacked release or an install, and
  declaring it an image stops the run instead of excusing what it has lost;
* a path the image is built from can never be excused, so a test that runs in
  the image and reads a product file fails the build when the file is missing.
  That is not every file the image carries. When every file the image's gate
  opened was logged, 29 carried files had been opened by no test, because
  their tests need Node.js, .NET, R, git or a record under ``docs/``, or
  because they have no test. The twelve that belong to the frozen research
  tools are checked on their own, by ``test_frozen_tool_hashes``. The other
  seventeen are carried unchecked: the console's browser harnesses and
  recorders, the build script of its Three.js vendor bundle
  (``tools/build_anatomy_vendor.mjs``), one JavaScript fixture of a test
  that needs Node.js, and the release, review and catalogue tools;
* ``test_container_image`` holds ``CONTAINER_IMAGE_PATHS`` to the Dockerfile's
  COPY lines, so this list cannot drift from the real image.
"""
from __future__ import annotations

import errno
import os
from pathlib import Path, PureWindowsPath
import re
import shutil
import subprocess
import sys

import pytest

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]

# Set by the Dockerfile's verification step, and by nothing else.
TREE_ENV = "LIVEMORE_TEST_TREE"
CONTAINER_IMAGE = "container-image"
# Exactly what the Dockerfile copies into the image.
CONTAINER_IMAGE_PATHS = ("pyproject.toml", "README.md", "requirements-python311.lock",
                         "LICENSE", "THIRD_PARTY_NOTICES.md", ".livemore-distribution.json",
                         "livemorebio", "models", "tools")
# The publisher creates this file only for its public projection. Its absence
# does not excuse any missing private input; the reference helper decides that.
OPTIONAL_CONTAINER_IMAGE_PATHS = frozenset({".livemore-distribution.json"})
# What no image has at its root, and every other tree this suite runs in has at
# least one of: the repository; the environment ``install.sh`` creates beside
# the source it unpacked; and the three files that build or install the product
# rather than being it, which every release archive is required to keep. The
# Dockerfile copies none of them and creates no environment, and
# ``test_container_image`` holds it to that.
NEVER_IN_AN_IMAGE = (".git", ".venv", "install.sh", "Dockerfile", "docker-compose.yml")
# Exactly what the Dockerfile's verification step hands to ``python``.
CONTAINER_IMAGE_VERIFICATION = ("-X", "utf8", "-m", "pytest", "-q", "-rfEs", "-p", "no:cacheprovider",
                                "livemorebio/tests")
# What pytest lists by name in its short summary when no ``-r`` is given, and
# what its two shorthands stand for.
_SUMMARY_DEFAULT = "fE"
_SUMMARY_SHORTHAND = {"a": "sxXEf", "A": "PpsxXEf"}


def summary_report_characters(command: str) -> frozenset[str]:
    """The outcomes a pytest command line lists by name in its short summary.

    ``-r`` does not add to pytest's default, it replaces it. ``-rs`` therefore
    lists the skips and stops listing failures and errors, which is how the
    first hosted build of the image reported 64 failed and 15 errors and named
    none of them. This reads the option the way pytest does: the last ``-r``
    given, ``a`` and ``A`` as shorthands, ``N`` as a reset. Only pytest's own
    arguments are read, so the ``-rf`` of an ``rm`` later in the same shell
    line is not mistaken for one.
    """
    words = command.split()
    try:
        start = next(index for index, word in enumerate(words) if word == "pytest" or word.endswith("/pytest"))
    except StopIteration:
        raise ValueError(f"{command!r} does not run pytest, so it has no summary to read") from None
    given = _SUMMARY_DEFAULT
    arguments = words[start + 1:]
    for index, word in enumerate(arguments):
        if word in ("&&", "||", ";", "|", "&"):
            break
        if word == "-r" and index + 1 < len(arguments):
            given = arguments[index + 1]
        elif re.fullmatch(r"-r[A-Za-z]+", word):
            given = word[2:]
    listed: set[str] = set()
    for character in given:
        if character == "N":
            listed.clear()
        else:
            listed.update(_SUMMARY_SHORTHAND.get(character, character))
    return frozenset(listed)


# The image's base, python:3.11-slim-bookworm, has no process tools either. A research
# tool the image carries, and which is frozen, samples its child's memory with
# ``/bin/ps``, so the Dockerfile has to install the Debian package that provides
# it. Executable, and that package.
BASE_IMAGE_LACKS = {"ps": "procps"}
# Set only by this suite's own reconstruction of the image, and only to tools
# named above that the Dockerfile leaves the image without. A developer's
# machine has ``/bin/ps`` whatever PATH says, so a reconstruction is told which
# tools the real image would lack and is held to it, as it is for Node.js. The
# switch can only take a tool away: it cannot excuse or skip anything.
ABSENT_TOOLS_ENV = "LIVEMORE_TEST_ABSENT_TOOLS"


def dockerfile_system_packages(dockerfile: str) -> frozenset[str]:
    """The Debian packages a Dockerfile's ``apt-get install`` commands add to the base."""
    commands = "\n".join(line for line in dockerfile.splitlines() if not line.lstrip().startswith("#"))
    packages: set[str] = set()
    for arguments in re.findall(r"apt-get\s+install\b([^&|;\n]*)", commands.replace("\\\n", " ")):
        packages.update(word for word in arguments.split() if not word.startswith("-"))
    return frozenset(packages)


def tools_the_image_lacks(dockerfile: str) -> tuple[str, ...]:
    """What the base does not ship and this Dockerfile does not install."""
    installed = dockerfile_system_packages(dockerfile)
    return tuple(sorted(tool for tool, package in BASE_IMAGE_LACKS.items() if package not in installed))


def tools_declared_absent() -> frozenset[str]:
    """The tools this session has been told the image would not have."""
    declared = frozenset(filter(None, os.environ.get(ABSENT_TOOLS_ENV, "").split(",")))
    unknown = sorted(declared - set(BASE_IMAGE_LACKS))
    if unknown:
        # A misspelt tool must not quietly mean "nothing is absent".
        raise ValueError(f"{ABSENT_TOOLS_ENV} may name only {', '.join(sorted(BASE_IMAGE_LACKS))}, "
                         f"not {', '.join(unknown)}")
    return declared


def refuse_a_tool_declared_absent(event: str, arguments: tuple) -> None:
    """Audit hook: starting a tool the image would not have fails as it fails there."""
    if event != "subprocess.Popen":
        return
    executable = arguments[0]
    if not isinstance(executable, (str, bytes, os.PathLike)):
        return
    tool = os.path.basename(os.fsdecode(executable))
    if tool in tools_declared_absent():
        raise FileNotFoundError(
            errno.ENOENT,
            f"The image's base has no {tool}, and its Dockerfile does not install "
            f"{BASE_IMAGE_LACKS[tool]}, which provides it",
            executable)


def hold_a_reconstructed_image_to_what_its_base_lacks() -> bool:
    """Install the refusal, but only in a session told that a tool is absent.

    Every other session gets no hook, and starts whatever its host has.
    """
    if not tools_declared_absent():
        return False
    sys.addaudithook(refuse_a_tool_declared_absent)
    return True


def git_executable() -> str | None:
    """Absolute path of ``git``, or None on a host that does not have it."""
    return shutil.which("git")


def in_git_checkout() -> bool:
    """Whether this tree is the root of a repository ``git`` can read. Never raises.

    Being somewhere beneath a repository is not enough. An install directory
    inside a home directory that is kept under version control is enclosed by a
    repository that has nothing to do with this product, and the release tests
    would build from, and fail against, that one. ``build_info`` refuses an
    enclosing repository's identity for the same reason.
    """
    git = git_executable()
    if git is None:
        return False
    try:
        probe = subprocess.run([git, "rev-parse", "--show-toplevel"], cwd=REPOSITORY_ROOT,
                               capture_output=True)
        # git prints the resolved work tree, so compare files, not spellings.
        return probe.returncode == 0 and os.path.samefile(
            os.fsdecode(probe.stdout).rstrip("\r\n"), REPOSITORY_ROOT)
    except (OSError, ValueError):
        return False


def no_git_checkout_reason(purpose: str) -> str:
    """The skip reason, naming which of the two causes applies on this host."""
    cause = ("git is not installed" if git_executable() is None
             else "this tree is not a git repository")
    return f"NOT_A_GIT_CHECKOUT: {purpose} requires a git checkout, and {cause}"


def requires_git_checkout(purpose: str) -> pytest.MarkDecorator:
    """Mark a test that can only run where there is a repository to read."""
    return pytest.mark.skipif(not in_git_checkout(), reason=no_git_checkout_reason(purpose))


def require_git_checkout(purpose: str) -> None:
    """The same rule for a fixture, which cannot carry a mark."""
    if not in_git_checkout():
        pytest.skip(no_git_checkout_reason(purpose))


def verifying_container_image() -> bool:
    """Whether this tree has been declared the image. A declaration that is not true raises.

    Nothing but the Dockerfile sets the variable, but nothing stops a shell
    from exporting it either, and it used to be believed wherever it was set:
    in a source checkout it excused a missing ``install.sh``. Skipping there
    hides a lost file. Carrying on as though it were unset hides that something
    set it. So a tree that cannot be an image, declared one, is an error, and
    ``conftest`` asks before the first test so that it stops the session.
    """
    declared = os.environ.get(TREE_ENV, "")
    if declared not in ("", CONTAINER_IMAGE):
        # A misspelt declaration must not quietly mean "not an image".
        raise ValueError(f"{TREE_ENV} must be unset or {CONTAINER_IMAGE!r}, not {declared!r}")
    if declared != CONTAINER_IMAGE:
        return False
    # lexists: a link that leads nowhere is still not something an image has.
    contradicting = [name for name in NEVER_IN_AN_IMAGE if os.path.lexists(os.path.join(REPOSITORY_ROOT, name))]
    if contradicting:
        raise ValueError(
            f"NOT_A_CONTAINER_IMAGE: {TREE_ENV}={CONTAINER_IMAGE} declares {REPOSITORY_ROOT} to be the "
            f"container image, but it has {', '.join(contradicting)}, which no image has (an image is built "
            f"from {', '.join(CONTAINER_IMAGE_PATHS)}). This is a source tree or an install, where a file "
            f"that has gone missing must fail its test and not skip it. Unset {TREE_ENV}.")
    return True


def _components_outside_the_image(path: str) -> tuple[str, ...]:
    """The components of a path named from the tree's root, which the image does not carry.

    The rule that a product path is never excused has to judge the file a path
    reaches, not the way it is written. Comparing the first component as spelt
    excused a missing ``livemorebio/x`` when it was written ``docs/../livemorebio/x``,
    as an absolute path, with a backslash, or in another case. So a path that
    cannot be placed in the tree by reading it is refused outright, both
    separators divide it, and its first component is compared without case.
    A symbolic link is the one spelling that reading cannot see through, so
    what the path reaches is then judged as well.
    """
    parts = tuple(part for part in re.split(r"[\\/]+", path) if part not in ("", "."))
    if not parts or path[0] in "\\/" or PureWindowsPath(path).drive or ".." in parts:
        raise ValueError(f"{path!r} is not a relative path free of '..' components; a path that cannot be "
                         "placed in the tree by reading it is never excused")
    if parts[0].lower() in {carried.lower() for carried in CONTAINER_IMAGE_PATHS}:
        raise ValueError(f"{path} is part of the container image, so its absence is never excused")
    _refuse_what_a_link_reaches(path, parts)
    return parts


def _refuse_what_a_link_reaches(path: str, parts: tuple[str, ...]) -> None:
    """The same rule, for the file a path reaches once its links have been followed.

    Reading a path places it in the tree only if none of its components is a
    symbolic link. ``docs/product-link/missing.py`` reads as a record under
    ``docs/``; where ``product-link`` points at ``../livemorebio`` it is a
    product file, and its absence was excused. So the path is resolved and
    judged a second time: what it reaches must still be inside this tree, and
    outside everything the image carries. The tree's own root is resolved too,
    because a tree is routinely reached through a link.
    """
    root = REPOSITORY_ROOT.resolve()
    try:
        reached = root.joinpath(*parts).resolve()
    except (OSError, RuntimeError) as error:
        # A link that leads back to itself reaches no file that could be judged.
        raise ValueError(f"{path} cannot be followed to a file ({error}); a path that cannot be placed in "
                         "the tree is never excused") from None
    if root not in reached.parents:
        raise ValueError(f"{path} leads to {reached}, which is not inside this tree, so its absence is "
                         "never excused")
    inside = reached.relative_to(root)
    if inside.parts[0].lower() in {carried.lower() for carried in CONTAINER_IMAGE_PATHS}:
        raise ValueError(f"{path} leads to {inside.as_posix()}, which is part of the container image, so "
                         "its absence is never excused")


def source_tree_skip_reason(*relative: str) -> str | None:
    """Why a test that reads these source-tree paths does not apply in this tree.

    None means the test must run -- including when a path is absent from a tree
    that is not a declared image, where running it is what reports the loss.
    """
    if not relative:
        raise ValueError("name the source-tree paths the test reads")
    # Every path is judged before any is excused, declared image or not.
    named = [_components_outside_the_image(path) for path in relative]
    if not verifying_container_image():
        return None
    absent = ["/".join(parts) for parts in named if not REPOSITORY_ROOT.joinpath(*parts).exists()]
    if not absent:
        return None
    return (f"SOURCE_TREE_ONLY: the container image does not carry {', '.join(absent)} "
            f"(it is built from {', '.join(CONTAINER_IMAGE_PATHS)}); "
            "this check verifies the source tree and runs there")


def source_tree_only(*relative: str) -> pytest.MarkDecorator:
    """Mark a test, or a module through ``pytestmark``, that reads these source-tree paths."""
    reason = source_tree_skip_reason(*relative)
    return pytest.mark.skipif(reason is not None,
                              reason=reason or f"reads {', '.join(relative)}, which this tree carries")


def require_source_tree(*relative: str) -> None:
    """The same rule for a fixture or a shared helper, which cannot carry a mark."""
    reason = source_tree_skip_reason(*relative)
    if reason is not None:
        pytest.skip(reason)


# The research tools under ``tools/`` (OSP, Beard, the build tracker) and their
# test modules are frozen. Records under ``docs/`` pin their hashes, and those
# pins are what vouch for the evidence retained from them, so a frozen test
# that reads a source-tree record cannot be edited to carry ``source_tree_only``.
# ``conftest`` gives it the same mark by name instead, from this table: module,
# test, and the records the test reads. ``test_source_tree_gate`` holds every
# name here to a test that exists, and the modules to carrying no mark of ours.
_PRECISION_PREREGISTRATION = "docs/solutions/2026-09-08-beard-native-precision-v2-preregistration.md"
_SOURCE_PREREGISTRATION = "docs/solutions/2026-09-08-beard-native-source-preregistration.md"
_RECOVERY_PLAN = "docs/solutions/2026-09-08-full-scope-recovery-plan.md"
_STARTUP_CONTRACT = "docs/solutions/2026-09-09-osp-r-startup-contract-v1.json"
_RUNTIME_INVENTORY = "docs/solutions/2026-09-08-osp-retained-runtime-static-inventory-v2.json"
_STAGE_B_BENCHMARK = "docs/solutions/2026-09-08-osp-stage-b-numerical-benchmark.md"
FROZEN_TESTS_READING_THE_SOURCE_TREE: dict[str, dict[str, tuple[str, ...]]] = {
    "test_beard_precision_analysis.py": {
        "test_frozen_matrix_candidate_and_protocol": (_PRECISION_PREREGISTRATION,),
    },
    # Every test that starts the matrix through ``mock_matrix``. ``run_matrix``
    # checks both preregistered protocols before the first branch. Without them
    # every branch is blocked, so a test asserting that a branch did not run
    # would pass without the matrix having started.
    "test_beard_precision_execution.py": {
        "test_numerical_discrepancy_does_not_change_fixed_candidate_or_schedule":
            (_PRECISION_PREREGISTRATION, _SOURCE_PREREGISTRATION),
        "test_local_failure_stops_all_later_native_branches":
            (_PRECISION_PREREGISTRATION, _SOURCE_PREREGISTRATION),
        "test_uncertain_h3_never_supplies_checkpoint":
            (_PRECISION_PREREGISTRATION, _SOURCE_PREREGISTRATION),
    },
    "test_beard_source_analysis.py": {
        "test_plan_hash_is_frozen": (_SOURCE_PREREGISTRATION,),
    },
    # The requirement register the tracker reads is a source-tree record.
    "test_build_tracker.py": {
        "test_actual_scope_and_experiment_identities": (_RECOVERY_PLAN,),
        "test_scope_cannot_be_dropped": (_RECOVERY_PLAN,),
        "test_http_surface_is_fixed_read_only_and_no_store": (_RECOVERY_PLAN,),
    },
    "test_osp_r_initialization.py": {
        "test_separate_startup_manifest_does_not_change_semantic_identity_or_protocol":
            (_STARTUP_CONTRACT, _RUNTIME_INVENTORY),
        "test_manifest_verifies_all_four_images_selector_and_shadow_without_real_runtime_access":
            (_STARTUP_CONTRACT,),
    },
    # The admitted runtime inventory is a source-tree record.
    "test_osp_semantic_supervisor.py": {
        "test_actual_v2_schema_partial_header_is_not_full_hash": (_RUNTIME_INVENTORY,),
        "test_actual_image_admission_reconciles_all_channels": (_RUNTIME_INVENTORY,),
        # The case re-reads the inventory before it may report success. Without
        # the file it has already failed, and the disk overrun this test injects
        # no longer has a success to overturn.
        "test_disk_overrun_does_not_leave_parent_case_success": (_RUNTIME_INVENTORY,),
    },
    "test_osp_source_admission.py": {
        "test_old_numerical_source_files_stay_exact_without_import": (_STAGE_B_BENCHMARK,),
    },
}


def mark_frozen_tests_reading_the_source_tree(items) -> None:
    """Give each named frozen test the mark it would carry if it could be edited.

    Called by ``conftest`` with every collected test. Only a module-level test
    of this directory, in a named module and with a named function, is touched.
    """
    here = Path(__file__).resolve().parent
    for item in items:
        path = Path(item.path).resolve()
        if path.parent != here:
            continue
        paths = FROZEN_TESTS_READING_THE_SOURCE_TREE.get(path.name, {}).get(
            getattr(item, "originalname", None) or item.name)
        if paths and getattr(item, "cls", None) is None:
            item.add_marker(source_tree_only(*paths))
