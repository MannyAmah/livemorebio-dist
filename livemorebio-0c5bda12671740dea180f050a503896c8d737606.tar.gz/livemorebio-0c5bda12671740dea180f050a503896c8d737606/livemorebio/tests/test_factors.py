"""Non-food factors: physiological modifiers + chemical/environmental disease signatures."""
from dataclasses import dataclass
import os
import pytest
from livemorebio.engines import factors as FA
from livemorebio.engines.trajectory import ExposurePattern, simulate_disease_trajectory


@dataclass
class _H:
    id: str; age: int; sex: str; genome: dict


def test_physiological_factor_resolves_with_mechanism():
    f = FA.resolve_factor("chronic stress")
    assert f["kind"] == "physiological" and "cortisol" in f["mechanism"].lower()


def test_exercise_improves_insulin_sensitivity():
    assert FA.aggregate_physiological_modifiers(factors=("regular exercise",))["si_mult"] > 1.0


def test_stress_and_sleep_loss_push_toward_disease():
    h = _H("X", 35, "M", {})
    base = simulate_disease_trajectory(h, ExposurePattern(2700, 0.4), years=20)
    stressed = simulate_disease_trajectory(
        h, ExposurePattern(2700, 0.4, stress=0.8, factors=("sleep deprivation",)), years=20)
    assert base["final_stage"] == "normal"
    assert stressed["diabetes_onset_year"] is not None       # non-food factors alone drive emergence


@pytest.mark.network
@pytest.mark.skipif(os.environ.get("LIVEMORE_TEST_NETWORK") != "1",
                    reason="explicit public network lookup opt-in")
def test_environmental_chemical_disease_signature():
    from livemorebio.egress import EgressRefused

    # L0-R16: a chemical factor outside the compound vocabulary is looked up by its ChEMBL id only;
    # CHEMBL418971 is bisphenol A. An egress refusal is a failure here, never a skip.
    try:
        sig = FA.factor_disease_signature("CHEMBL418971")
    except EgressRefused:
        raise
    except Exception:
        pytest.skip("network unavailable")
    if not sig:
        pytest.skip("unavailable")
    assert any("cancer" in s["disease"].lower() or "carcinoma" in s["disease"].lower() for s in sig)
