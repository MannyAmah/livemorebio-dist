"""Technical reference factories preserve bootstrap refusals through their wrapper."""
from fastapi.testclient import TestClient
import pytest

from livemorebio.aegle import reference_cohort_api, reference_cohorts, server
from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError


@pytest.mark.parametrize("code", ["REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_BOOTSTRAP_INVALID"])
@pytest.mark.parametrize("method,path", [
    ("POST", "/api/reference-cohorts/preview"),
    ("POST", "/api/reference-cohorts"),
    ("GET", "/api/reference-cohorts/technical-cohort/members"),
    ("GET", "/api/reference-cohorts/technical-cohort/members/technical-member"),
])
def test_real_reference_factory_preserves_subject_registry_bootstrap_refusal(
        tmp_path, monkeypatch, method, path, code):
    directory = tmp_path / "technical-reference-storage"
    directory.mkdir(mode=0o700)
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-reference-bootstrap-token")
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(directory / "subjects.sqlite3"))
    monkeypatch.setattr(reference_cohort_api, "patch_storage_key", lambda **kwargs: b"t" * 32)
    attempts = []

    def refuse_registry(*args, **kwargs):
        attempts.append((args, kwargs))
        raise RegistryBootstrapError(code)

    # Keep the real factory and decorated ReferenceCohortService constructor:
    # replacing service() itself would miss its generic exception translation.
    monkeypatch.setattr(reference_cohorts, "_GuardedRegistry", refuse_registry)
    client = TestClient(server.app, raise_server_exceptions=False)
    response = client.request(method, path, json={} if method == "POST" else None, headers={
        "Authorization": "Bearer technical-reference-bootstrap-token",
        "Idempotency-Key": "technical-reference-bootstrap-attempt",
    })
    assert attempts, "request must reach the actual guarded SubjectRegistry construction"
    assert response.status_code == 503, response.text
    assert response.json() == {"code": code, "error": str(RegistryBootstrapError(code))}
    assert response.headers["Cache-Control"] == "no-store"
