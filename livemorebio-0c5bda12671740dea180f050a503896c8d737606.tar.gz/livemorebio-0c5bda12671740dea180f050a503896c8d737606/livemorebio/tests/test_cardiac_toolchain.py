"""The cardiac engine needs a C compiler and SUNDIALS, and must say so."""
from __future__ import annotations

import pytest


def test_the_toolchain_reports_whether_cardiac_simulation_is_available():
    from livemorebio import _toolchain

    state = _toolchain.cardiac_simulation()
    assert set(state) >= {"available", "reason", "requires"}
    assert isinstance(state["available"], bool)
    if not state["available"]:
        # A refusal names what to install, never just "unavailable".
        assert state["reason"] and "sundials" in state["reason"].lower()
    assert "libsundials-dev" in state["requires"] or "sundials" in state["requires"]


def test_an_unavailable_toolchain_is_reported_not_raised(monkeypatch):
    """A client on clean Linux without SUNDIALS must get a named reason, and the
    installer must not fail the whole verification over it."""
    from livemorebio import _toolchain

    def refuse(*_args, **_kwargs):
        raise RuntimeError("Unable to compile: sundials headers not found")

    monkeypatch.setattr(_toolchain, "_probe_cardiac", refuse)
    state = _toolchain.cardiac_simulation.__wrapped__() if hasattr(
        _toolchain.cardiac_simulation, "__wrapped__") else _toolchain.cardiac_simulation()
    assert state["available"] is False
    assert "sundials" in state["reason"].lower()


def test_the_probe_itself_lets_the_compilers_own_words_through(monkeypatch):
    """``cardiac_simulation()`` keeps the first line of Myokit's error, which is
    always "Unable to compile.", and drops the compiler output under it. That
    is the answer for a client. A build has to see the rest, so the container's
    fail-fast step calls the probe directly, and the probe must not swallow or
    shorten what Myokit raises."""
    import myokit

    from livemorebio import _toolchain

    words = ("Unable to compile.\nError message:\ncommand 'gcc' failed\nCompiler output:\n"
             "    sundials/sundials_types.h: fatal error: mpi.h: No such file or directory")

    def refuse(*_args, **_kwargs):
        raise myokit.CompilationError(words)

    monkeypatch.setattr(myokit, "Simulation", refuse)

    with pytest.raises(myokit.CompilationError) as failure:
        _toolchain._probe_cardiac()
    assert str(failure.value) == words


def test_doctor_reports_the_cardiac_toolchain():
    from livemorebio import doctor

    rendered = doctor.render(doctor.report())
    assert "cardiac" in rendered.lower()
