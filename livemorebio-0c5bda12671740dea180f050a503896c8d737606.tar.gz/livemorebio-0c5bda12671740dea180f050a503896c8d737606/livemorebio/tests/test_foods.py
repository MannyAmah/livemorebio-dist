"""Foods as multi-factor exposures: macronutrients + phytochemical targets on the model."""
import pytest
from livemorebio.engines import metabolism as MB
from livemorebio.engines.coupling import gem_metabolic as GC
from livemorebio.engines.metabolic.glucose_insulin import T2D

def test_multi_substrate_energetics_validate():
    with pytest.raises(ValueError, match="retired"):
        MB.substrate_atp_yield("EX_glc__D_e")


def test_food_effect_remains_unqualified_without_network_or_model():
    with pytest.raises(ValueError, match="qualified"):
        GC.food_effect(T2D, genome={}, food={"name": "reference only", "macros": {}})


@pytest.mark.network
def test_food_resolves_macros_and_phytochemical_targets():
    from livemorebio.engines import foods as F
    food = F.resolve_food("turmeric")
    if not food.get("resolved"):
        pytest.skip("USDA FDC unavailable")
    assert food["macros"] and food["phytochemicals"]
    with pytest.raises(ValueError, match="qualified"):
        GC.food_effect(T2D, genome={}, food=food)
