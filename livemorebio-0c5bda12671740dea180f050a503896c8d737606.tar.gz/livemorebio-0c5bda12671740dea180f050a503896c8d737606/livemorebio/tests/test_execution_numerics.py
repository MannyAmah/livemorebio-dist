"""Preregistered convergence limits; not independent biological validation."""
from __future__ import annotations

from dataclasses import asdict
from types import SimpleNamespace

import numpy as np
import pytest

from livemorebio.aegle.execution_contract import capture_source_payload, METABOLIC, CARDIAC
from livemorebio.aegle.execution_adapters import MetabolicExecutionAdapter, CardiacExecutionAdapter
from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, T2D, MetabolicProfile


def source(template=HEALTHY, meals=None, *, cellular=False, block=0.):
    return capture_source_payload(SimpleNamespace(profile=MetabolicProfile(**asdict(template)),
        meals=meals if meals is not None else [], cardiac_drug_block=block),
        {"subject_id": "technical-reference", "twin_id": "technical-twin", "twin_version": 1,
         "cohort_id": None, "member_id": None, "run_id": None, "condition_id": "baseline",
         "stage": "cardiac" if cellular else "metabolic", "source_data_class": "SYNTHETIC"},
        "technical-generation", CARDIAC if cellular else METABOLIC)


def metabolic_trace(adapter, end, chunk):
    state = adapter.initialize()
    points = {}
    for instant in np.arange(chunk, end + chunk, chunk):
        result = adapter.advance(state, min(float(instant), end))
        for index, time in enumerate(result["series"][0]["native_times"]):
            assert round(time, 9) not in points, "duplicate boundary sample"
            points[round(time, 9)] = [series["values"][index] for series in result["series"]]
        state = result["checkpoint"]
    return state, points


@pytest.mark.parametrize("template", [HEALTHY, T2D], ids=["healthy", "t2d"])
@pytest.mark.parametrize("meals", [[], [(0., 75.)], [(120.125, 75.)], [(0., 60.), (300., 75.), (660., 90.)]])
@pytest.mark.parametrize("end,chunks", [(240., (.25, 1., 5.)), (840., (1., 7.))])
def test_metabolic_preregistered_chunk_and_tolerance_convergence(template, meals, end, chunks):
    captured = source(template, meals)
    reference_adapter = MetabolicExecutionAdapter(captured, rtol=1e-8, atol=1e-10)
    _, reference = metabolic_trace(reference_adapter, end, end)
    expected_keys = {float(time) for time in np.arange(.25, end + .25, .25)} | {
        time for time, _ in meals if 0 < time <= end}
    assert set(reference) == expected_keys
    absolute = np.array([.02, .000002, .005])
    for chunk in (*chunks, end):
        _, points = metabolic_trace(MetabolicExecutionAdapter(captured), end, chunk)
        assert set(points) == expected_keys
        for instant in expected_keys:
            expected = np.array(reference[instant])
            actual = np.array(points[instant])
            assert np.all(np.abs(actual - expected) <= absolute + .0002 * np.abs(expected)), (template.name, chunk, instant)
        assert end in points


def test_only_healthy_no_meal_is_stationary_and_x_is_not_clamped():
    healthy = MetabolicExecutionAdapter(source())
    assert healthy.advance(healthy.initialize(), 240.)["checkpoint"]["state_values"] == pytest.approx([90., 0., 9.], abs=1e-8)
    diabetic = MetabolicExecutionAdapter(source(T2D))
    assert diabetic.advance(diabetic.initialize(), 1.)["checkpoint"]["state_values"][2] > 15.
    checkpoint = healthy.initialize()
    checkpoint["state_values"][2] = 8.
    assert healthy.advance(checkpoint, 1.)["checkpoint"]["state_values"][1] < 0.


# L0-R2: the installed-asset opt-in also runs the unchanged convergence gate.
@pytest.mark.parametrize("block", [0., .5])
def test_cellular_preregistered_chunk_and_tolerance_convergence(block, pinned_cardiac_asset):
    captured = source(cellular=True, block=block)
    reference = CardiacExecutionAdapter(captured, abs_tol=1e-12, rel_tol=1e-10)
    try:
        initial = reference.initialize()
        expected = reference.advance(initial, 2000.)
        atol = np.full(49, .000001)
        atol[0], atol[2:6], atol[[6, 9]], atol[[7, 8]] = .05, .0001, .0000002, .000002
        for chunk in (10., 100., 250., 2000.):
            adapter = CardiacExecutionAdapter(captured)
            try:
                # Identical pre-paced state isolates numerical continuation from
                # initialization tolerance; pre-pacing is checked separately.
                initialized = adapter.initialize()
                assert np.all(np.abs(np.array(initialized["state_values"]) - initial["state_values"]) <= atol + .0001 * np.abs(initial["state_values"]))
                current = initial
                traces = [[], []]
                times = []
                for instant in np.arange(chunk, 2000. + chunk, chunk):
                    result = adapter.advance(current, float(instant))
                    current = result["checkpoint"]
                    times.extend(result["series"][0]["native_times"])
                    for i in range(2):
                        traces[i].extend(result["series"][i]["values"])
                assert times == expected["series"][0]["native_times"]
                for i, tolerance in enumerate((.05, .0000002)):
                    expected_values = np.array(expected["series"][i]["values"])
                    assert np.all(np.abs(np.array(traces[i]) - expected_values) <= tolerance + .0001 * np.abs(expected_values))
                expected_states = np.array(expected["checkpoint"]["state_values"])
                assert np.all(np.abs(np.array(current["state_values"]) - expected_states) <= atol + .0001 * np.abs(expected_states))
            finally:
                adapter.close()
    finally:
        reference.close()
