"""API-6/API-8 regressions; every request and generated person is technical."""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

from fastapi import FastAPI
from fastapi.testclient import TestClient
import pytest

from livemorebio.strict_json import MAX_JSON_BYTES


@pytest.mark.parametrize("n", [0, 1001])
def test_API_6_population_rejects_outside_cohort_limit(monkeypatch, n):
    from livemorebio.life_system import service

    token = "technical-population-bounds-token"
    monkeypatch.setenv("LIVEMORE_API_TOKEN", token)
    generated = []
    monkeypatch.setattr(service, "LifeSystem", lambda: SimpleNamespace(
        generate=lambda count, seed: generated.append(count) or [],
    ))
    response = TestClient(service.app, base_url="http://127.0.0.1").get(
        f"/population?n={n}", headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 422
    assert generated == []


@pytest.mark.parametrize("n", [1, 1000])
def test_API_6_population_accepts_exact_boundaries(monkeypatch, n):
    from livemorebio.life_system import service

    token = "technical-population-bounds-token"
    monkeypatch.setenv("LIVEMORE_API_TOKEN", token)
    generated = []
    monkeypatch.setattr(service, "LifeSystem", lambda: SimpleNamespace(
        generate=lambda count, seed: generated.append((count, seed)) or [],
    ))
    response = TestClient(service.app, base_url="http://127.0.0.1").get(
        f"/population?n={n}&seed=7", headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    assert generated == [(n, 7)]


LEGACY_ROUTES = [
    "create_twin", "create_cohort", "run_workspace_action", "trajectory",
    "validate", "api_screen", "human",
]


def technical_route_app(monkeypatch, endpoint):
    from livemorebio.aegle import server
    from livemorebio.life_system import service

    monkeypatch.setattr(server, "_require_numerical_model", lambda: None)
    app = FastAPI()
    app.post("/technical")(getattr(service if endpoint == "human" else server, endpoint))
    return app


async def request_chunks(app, chunks, *, content_length=None):
    """Exercise the ASGI boundary without opening sockets or buffering the tail."""
    received = []
    sent = []
    headers = [(b"host", b"127.0.0.1"), (b"content-type", b"application/json")]
    if content_length is not None:
        headers.append((b"content-length", str(content_length).encode("ascii")))
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1",
             "method": "POST", "scheme": "http", "path": "/technical", "raw_path": b"/technical",
             "query_string": b"", "headers": headers, "client": ("127.0.0.1", 9000),
             "server": ("127.0.0.1", 9001)}

    async def receive():
        index = len(received)
        assert index < len(chunks), "request read after body end"
        received.append(index)
        return {"type": "http.request", "body": chunks[index], "more_body": index + 1 < len(chunks)}

    async def send(message):
        sent.append(message)

    try:
        await app(scope, receive, send)
    except Exception:
        # FastAPI re-raises after sending a 500 for an uncaught route error.
        # The response remains the evidence, rather than the private exception.
        if not any(message["type"] == "http.response.start" for message in sent):
            raise
    response = next(message for message in sent if message["type"] == "http.response.start")
    return response["status"], received


@pytest.mark.parametrize("endpoint", LEGACY_ROUTES)
def test_API_8_legacy_routes_refuse_advertised_oversize_without_reading(monkeypatch, endpoint):
    app = technical_route_app(monkeypatch, endpoint)
    status, received = asyncio.run(request_chunks(app, [b"{"], content_length=MAX_JSON_BYTES + 1))
    assert status == 413
    assert received == []


@pytest.mark.parametrize("endpoint", LEGACY_ROUTES)
def test_API_8_legacy_routes_stop_stream_at_limit_before_tail(monkeypatch, endpoint):
    app = technical_route_app(monkeypatch, endpoint)
    status, received = asyncio.run(request_chunks(app, [b" " * MAX_JSON_BYTES, b" ", b"{"]))
    assert status == 413
    assert received == [0, 1]


@pytest.mark.parametrize("advertised", [False, True])
def test_API_8_legacy_body_accepts_exact_limit(monkeypatch, advertised):
    app = technical_route_app(monkeypatch, "human")
    raw = json.dumps({"id": "LMB-1", "age": 30, "sex": "F"}).encode()  # L0-R15 round 1: a technical id
    raw += b" " * (MAX_JSON_BYTES - len(raw))
    status, received = asyncio.run(request_chunks(
        app, [raw[:MAX_JSON_BYTES // 2], raw[MAX_JSON_BYTES // 2:]],
        content_length=MAX_JSON_BYTES if advertised else None,
    ))
    assert status == 200
    assert received == [0, 1]
