"""Technical intake timestamps; no actual participant or device admission."""
from datetime import datetime, timedelta, timezone

import pytest


@pytest.mark.parametrize('value', ['', None, 123, True, 'unknown', 'not_provided', '2026-02-31T12:00:00Z',
                                  '2026-01-01T12:00:00', '0001-01-01T00:00:00+23:59', 'x' * 100])
def test_capture_time_rejects_missing_invalid_or_unrepresentable(value):
    from livemorebio.aegle.capture_time import normalize_capture_time

    with pytest.raises(ValueError) as caught:
        normalize_capture_time(value)
    assert 'captured_at' in str(caught.value)
    if isinstance(value, str) and value:
        assert value not in str(caught.value)


def test_capture_time_preserves_instant_and_declared_clock_allowance():
    from livemorebio.aegle.capture_time import normalize_capture_time

    now = datetime(2026, 9, 8, 12, tzinfo=timezone.utc)
    assert normalize_capture_time('2026-09-08T07:59:00-04:00', now=now) == '2026-09-08T11:59:00Z'
    assert normalize_capture_time((now + timedelta(minutes=5)).isoformat(), now=now) == '2026-09-08T12:05:00Z'
    with pytest.raises(ValueError, match='future'):
        normalize_capture_time((now + timedelta(minutes=5, microseconds=1)).isoformat(), now=now)


def source_record(captured_at):
    return {'source_id':'TECHNICAL-TIMESTAMP-SOURCE', 'kind':'FHIR_R4', 'system':'technical fixture',
            'release':'fixture-v1', 'captured_at':captured_at, 'provenance_uri':'urn:test:source-time',
            'quality_status':'not_assessed', 'domains':['demographics','labs']}


def normalize_sources(records):
    from livemorebio.aegle.profile_sources import normalize_profile_sources

    return normalize_profile_sources(records, source_class='REAL_HUMAN', chain_of_custody='urn:test:custody',
                                     observations_present=True, error=lambda code, message: ValueError(code + ': ' + message))


@pytest.mark.parametrize('kind', ['FHIR_R4', 'LEGACY_ADMISSION'])
def test_explicit_source_times_cannot_use_legacy_missing_marker(kind):
    record = source_record('not_provided'); record['kind'] = kind
    with pytest.raises(ValueError, match='PROFILE_SOURCE_INVALID'):
        normalize_sources([record])


def test_profile_times_normalize_but_internal_legacy_fallback_stays_explicit():
    result = normalize_sources([source_record('2026-01-01T12:00:00+02:00')])
    assert result[0]['captured_at'] == '2026-01-01T10:00:00Z'
    legacy = normalize_sources(None)
    assert legacy[0]['captured_at'] == 'not_provided'
    assert legacy[0]['kind'] == 'LEGACY_ADMISSION'


def test_bad_source_time_cannot_create_registry_record(tmp_path):
    from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError

    registry = SubjectRegistry(tmp_path / 'technical-source-time.sqlite3', key=b't' * 32)
    body = {'source_class':'REAL_HUMAN', 'subject_id':'pseudonym-technical-source-time',
            'display_label':'TECHNICAL timestamp rejection — not a participant',
            'demographics':{'age':40, 'sex':'F'}, 'consent_scope':['digital_twin'],
            'chain_of_custody':'urn:test:source-time', 'lifestyle':0.5,
            'observations':{'glucose_mgdl':{'value':95, 'unit':'mg/dL', 'captured_at':'2026-01-01T10:00:00Z',
                                         'source':'TECHNICAL-TIMESTAMP-SOURCE'}},
            'profile_sources':[source_record('not_provided')]}
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_twin(body)
    assert caught.value.code == 'PROFILE_SOURCE_INVALID'
    assert registry.list_twins() == []


def technical_profile():
    times = ['2026-01-02T02:02:00+01:00', '2026-01-03T03:03:00Z',
             '2026-01-04T04:04:00Z', '2026-01-05T05:05:00-02:00']
    sources = []
    for index, (kind, captured_at) in enumerate(zip(['FHIR_R4', 'WEARABLE', 'GENOMIC', 'ENVIRONMENT'], times)):
        sources.append({**source_record(captured_at), 'source_id':f'TECHNICAL-TIMESTAMP-{index}', 'kind':kind})
    return {'source_class':'REAL_HUMAN', 'subject_id':'pseudonym-technical-source-api',
            'display_label':'TECHNICAL intake validation — not a participant',
            'demographics':{'age':40, 'sex':'F'}, 'consent_scope':['digital_twin'],
            'chain_of_custody':'urn:test:source-time', 'lifestyle':{'activity_index':0.5, 'smoking_status':'unknown'},
            'observations':{'glucose_mgdl':{'value':95, 'unit':'mg/dL', 'captured_at':'2026-01-01T01:01:00Z',
                                         'source':'TECHNICAL-TIMESTAMP-0'}}, 'profile_sources':sources}


def test_protected_intake_api_rejects_bad_time_and_preserves_five_original_instants(tmp_path, monkeypatch):
    from copy import deepcopy
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.subjects import SubjectRegistry

    registry = SubjectRegistry(tmp_path / 'technical-api.sqlite3', key=b't' * 32)
    monkeypatch.setattr(server, '_subject_registry', lambda: registry)
    monkeypatch.setenv('LIVEMORE_API_TOKEN', 'technical-time-test-token')
    client = TestClient(server.app)
    auth = {'Authorization':'Bearer technical-time-test-token'}
    body = technical_profile()
    assert client.post('/api/twins', json=body).status_code == 401
    for time in ['not_provided', '2026-01-01T01:01:00', '9999-01-01T00:00:00Z']:
        bad = deepcopy(body); bad['profile_sources'][2]['captured_at'] = time
        response = client.post('/api/twins', headers=auth, json=bad)
        assert response.status_code == 422
        assert response.json()['code'] == 'PROFILE_SOURCE_INVALID'
        assert time not in response.text
        assert registry.list_twins() == []
    response = client.post('/api/twins', headers=auth, json=body)
    assert response.status_code == 201, response.text
    record = response.json()
    expected = ['2026-01-01T01:01:00Z', '2026-01-02T01:02:00Z', '2026-01-03T03:03:00Z',
                '2026-01-04T04:04:00Z', '2026-01-05T07:05:00Z']
    assert [record['observations']['glucose_mgdl']['captured_at'],
            *[source['captured_at'] for source in record['profile_sources']]] == expected
    assert record['observations']['glucose_mgdl']['value'] == 95
    assert record['observations']['glucose_mgdl']['unit'] == 'mg/dL'
    assert all(source['quality_status'] == 'not_assessed' for source in record['profile_sources'])
    assert record['lifestyle_profile']['smoking_status'] == 'unknown'
    assert record['lifestyle'] == 0.5
    assert record['lifecycle'] == 'DATA_ADMITTED' and registry.active_twin() is None
    assert client.get('/api/twins/' + record['twin_id']).status_code == 401
    assert client.get('/api/twins/' + record['twin_id'], headers=auth).json() == record


def test_historical_legacy_payload_reads_without_renormalizing_or_rewriting(tmp_path, monkeypatch):
    from livemorebio.aegle import profile_sources
    from livemorebio.aegle.subjects import SubjectRegistry

    registry = SubjectRegistry(tmp_path / 'technical-legacy.sqlite3', key=b't' * 32)
    body = technical_profile(); body.pop('profile_sources')
    created = registry.create_twin(body)
    assert created['profile_sources'][0]['captured_at'] == 'not_provided'
    assert created['profile_coverage']['status'] == 'ADMITTED_PARTIAL'
    with registry._connect() as connection:
        before = tuple(connection.execute('SELECT nonce,ciphertext FROM records').fetchone())
    def unexpected_normalization(*args, **kwargs):
        raise AssertionError('historical reads must not normalize missing source times')
    monkeypatch.setattr(profile_sources, 'normalize_capture_time', unexpected_normalization)
    assert registry.get_twin(created['twin_id']) == created
    assert registry.list_twins() == [created]
    with registry._connect() as connection:
        after = tuple(connection.execute('SELECT nonce,ciphertext FROM records').fetchone())
    assert after == before
