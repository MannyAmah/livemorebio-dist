"""The artefacts a client installs from must describe exactly what they contain."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

import pytest

from ._source_tree import (REPOSITORY_ROOT, require_git_checkout, requires_git_checkout,
                           source_tree_only)

INSTALLER = REPOSITORY_ROOT / "install.sh"

# Building a release needs the repository it is built from. The installer runs
# this same suite from an unpacked archive, where there is no checkout and
# nothing to package; the installer-contract tests still run there. The question
# goes through the shared helper because an installed release may be on a host
# with no ``git`` at all, and asking ``git`` directly raises during import.
requires_checkout = requires_git_checkout("release packaging")


@pytest.fixture(scope="module")
def release(tmp_path_factory):
    """Build a real release from the current commit, once."""
    require_git_checkout("release packaging")
    from tools.build_release import build

    output = tmp_path_factory.mktemp("release")
    ref = os.environ.get("LIVEMORE_REVIEW_ARCHIVE_REF", "HEAD")
    return build(output, ref=ref, channel="stable", audience="public"), output


def test_manifest_checksum_matches_the_archive_it_describes(release):
    result, output = release
    manifest = json.loads((output / "stable.json").read_text(encoding="utf-8"))
    archive = output / manifest["archive"]

    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert digest == manifest["sha256"] == result["sha256"]
    assert re.fullmatch(r"[0-9a-f]{40}", manifest["commit"])


def test_manifest_fields_survive_the_installer_s_strict_parser(release):
    """The installer parses the manifest with sed, not a JSON tool. A field it
    cannot express would resolve to an empty string and fail closed."""
    _, output = release
    manifest = json.loads((output / "stable.json").read_text(encoding="utf-8"))
    for field in ("commit", "sha256", "archive", "channel"):
        assert re.fullmatch(r"[A-Za-z0-9._-]{1,200}", manifest[field]), field


def test_archive_carries_everything_the_installer_requires(release):
    import tarfile

    result, output = release
    with tarfile.open(result["archive"]) as handle:
        names = handle.getnames()
    prefix = f"livemorebio-{result['commit']}/"
    for required in ("pyproject.toml", "requirements-python311.lock", "install.sh",
                     "docker-compose.yml", "Dockerfile", "livemorebio/cli.py"):
        assert prefix + required in names, required


def test_recorded_media_is_excluded_so_the_download_stays_reasonable(release):
    import tarfile

    result, _ = release
    with tarfile.open(result["archive"]) as handle:
        names = handle.getnames()
    assert not [name for name in names if name.endswith((".mp4", ".webm"))]


def test_channel_alias_is_the_same_bytes_as_the_pinned_archive(release):
    result, output = release
    alias = output / "livemorebio-stable.tar.gz"
    assert alias.read_bytes() == Path(result["archive"]).read_bytes()


def test_published_installer_is_the_committed_installer(release):
    result, output = release
    committed = subprocess.run(["git", "show", f"{result['commit']}:install.sh"],
                               cwd=REPOSITORY_ROOT, capture_output=True, check=True).stdout
    assert (output / "install.sh").read_bytes() == committed


@requires_checkout
def test_the_build_refuses_a_channel_name_the_installer_cannot_parse(tmp_path):
    from tools.build_release import build

    with pytest.raises(SystemExit):
        build(tmp_path, ref="HEAD", channel="../escape", audience="public")


# --- installer contract -------------------------------------------------

# These read or run install.sh, which an unpacked release carries and the
# container image does not.
installer_contract = source_tree_only("install.sh")


def _installer_text() -> str:
    return INSTALLER.read_text(encoding="utf-8")


@installer_contract
def test_installer_needs_no_github_cli_for_the_published_path():
    """A client without a GitHub account must reach a working install."""
    text = _installer_text()
    assert 'require_command curl' in text
    # Published installs and pinned local archives need no GitHub account.
    assert text.count('require_command gh') == 1
    index = text.index("require_command gh")
    guard = text[:index].rsplit('\nif ', 1)[-1].strip()
    assert guard == '[[ -n "$REQUESTED_REF" && -z "$LOCAL_ARCHIVE" ]]; then'


@installer_contract
def test_installer_verifies_the_archive_before_unpacking_it():
    text = _installer_text()
    verify = text.index("Release archive checksum mismatch")
    unpack = text.index('tar -xzf "$ARCHIVE_PATH"')
    assert verify < unpack, "checksum must be checked before extraction"


@installer_contract
def test_installer_refuses_a_non_https_distribution_base():
    result = subprocess.run(["bash", str(INSTALLER)], capture_output=True, text=True,
                            env={"PATH": "/usr/bin:/bin", "HOME": "/nonexistent-livemore-home",
                                 "LIVEMORE_DIST_BASE": "http://example.invalid/x"}, encoding="utf-8")
    assert result.returncode != 0
    assert "must be an https URL" in result.stderr + result.stdout


@installer_contract
def test_installer_refuses_a_malformed_pinned_checksum():
    result = subprocess.run(["bash", str(INSTALLER)], capture_output=True, text=True,
                            env={"PATH": "/usr/bin:/bin", "HOME": "/nonexistent-livemore-home",
                                 "LIVEMORE_SHA256": "not-a-checksum"}, encoding="utf-8")
    assert result.returncode != 0
    assert "64 hexadecimal" in result.stderr + result.stdout or "LIVEMORE_SHA256" in result.stderr + result.stdout
