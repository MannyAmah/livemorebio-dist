"""Timing/evidence regression tests use technical fixtures, not patient data."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone

import pytest


def test_freshness_never_promotes_modeled_or_legacy_samples_to_live_measurements():
    from livemorebio.life_patch.observation_view import observation_channel

    now = datetime(2026, 9, 8, 12, tzinfo=timezone.utc)
    sample = {"value": 100, "unit": "mg/dL", "captured_at": now.isoformat(),
              "received_at": now.isoformat(), "quality_status": "pass", "calibration_status": "current"}
    virtual = observation_channel("glucose_mgdl", {**sample, "mode": "virtual"}, now=now)
    assert virtual["data_class"] == "virtual"
    assert virtual["status"] == "recorded"
    assert "Observed" not in virtual["label"]
    legacy = observation_channel("glucose_mgdl", sample, now=now)
    assert legacy["data_class"] == "unknown"
    assert legacy["status"] != "live"


@pytest.mark.parametrize("age,status", [(0, "recent"), (61, "stale"), (-1, "clock_uncertain")])
def test_physical_freshness_has_explicit_clock_and_never_claims_connection(age, status):
    from livemorebio.life_patch.observation_view import observation_channel

    now = datetime(2026, 9, 8, 12, tzinfo=timezone.utc)
    sample = {"value": 100, "unit": "mg/dL", "mode": "physical",
              "captured_at": (now - timedelta(seconds=age)).isoformat(),
              "received_at": now.isoformat(), "quality_status": "pass", "calibration_status": "current"}
    channel = observation_channel("glucose_mgdl", sample, now=now)
    assert channel["status"] == status
    assert channel["freshness_policy"]["recent_within_seconds"] == 60
    assert channel["connection_verified"] is False
    assert channel["captured_at"] == sample["captured_at"]


def test_qc_and_missing_timestamps_are_visible_not_clamped():
    from livemorebio.life_patch.observation_view import observation_channel

    channel = observation_channel("hr_bpm", {"value": 70, "unit": "bpm", "mode": "physical", "quality_status": "reject"})
    assert channel["status"] == "quality_failed"
    assert channel["current"] == 70
    channel = observation_channel("hr_bpm", {"value": 70, "unit": "bpm", "mode": "physical"})
    assert channel["status"] == "timing_unknown"


def aligned_fixture():
    from livemorebio.life_patch.alignment import FrozenPrediction, ObservationMapping
    prediction = FrozenPrediction(
        prediction_id="technical-prediction", subject_id="technical-subject", condition_id="control",
        endpoint="glucose_mgdl", unit="mg/dL", compartment="plasma", site="technical-site",
        model_id="technical-linear-v1", t_min=(0., 10.), values=(100., 200.),
    )
    mapping = ObservationMapping(mapping_id="technical-identity-v1", prediction_id=prediction.prediction_id,
        subject_id=prediction.subject_id, condition_id="control", endpoint="glucose_mgdl", unit="mg/dL",
        compartment="plasma", biofluid="plasma", site="technical-site", time_basis="model_minute",
        source_class="technical_fixture")
    observation = {"value": 125., "unit": "mg/dL", "subject_id": "technical-subject", "mode": "virtual",
        "provenance": "technical_fixture", "quality_status": "pass", "calibration_status": "not_applicable",
        "context": {"endpoint": "glucose_mgdl", "compartment": "plasma", "biofluid": "plasma", "site": "technical-site"},
        "model_context": {"prediction_id": prediction.prediction_id, "condition_id": "control",
                          "mapping_id": mapping.mapping_id, "model_id": prediction.model_id, "model_time_min": 2.}}
    return prediction, mapping, observation


def test_alignment_interpolates_frozen_prediction_not_live_curve_average():
    from livemorebio.life_patch.alignment import align_observation
    prediction, mapping, observation = aligned_fixture()
    before = deepcopy(observation)
    result = align_observation(prediction, observation, mapping)
    assert result["predicted"] == 120
    assert result["residual"] == 5
    assert result["status"] == "UNQUALIFIED_RESIDUAL"
    assert result["calibration_authorized"] is False
    assert observation == before


@pytest.mark.parametrize("value,residual", [(120, 0), (115, -5)])
def test_alignment_retains_zero_and_negative_residuals(value, residual):
    from livemorebio.life_patch.alignment import align_observation
    prediction, mapping, observation = aligned_fixture()
    observation["value"] = value
    assert align_observation(prediction, observation, mapping)["residual"] == residual


@pytest.mark.parametrize("field,value", [("subject_id", "another"), ("unit", "mmol/L"), ("quality_status", "not_assessed"), ("mode", "physical")])
def test_alignment_fails_closed_for_bad_binding_or_quality(field, value):
    from livemorebio.life_patch.alignment import align_observation
    prediction, mapping, observation = aligned_fixture()
    observation[field] = value
    result = align_observation(prediction, observation, mapping)
    assert result["residual"] is None
    assert result["status"] != "UNQUALIFIED_RESIDUAL"


@pytest.mark.parametrize("field,value", [("model_time_min", -1), ("model_time_min", 11), ("model_time_min", True), ("prediction_id", "another"), ("condition_id", "treated"), ("mapping_id", "unknown")])
def test_alignment_requires_exact_prediction_and_in_domain_time(field, value):
    from livemorebio.life_patch.alignment import align_observation
    prediction, mapping, observation = aligned_fixture()
    observation["model_context"][field] = value
    assert align_observation(prediction, observation, mapping)["residual"] is None


def test_no_mapping_or_malformed_prediction_never_generates_residual():
    from dataclasses import replace
    from livemorebio.life_patch.alignment import align_observation
    prediction, mapping, observation = aligned_fixture()
    assert align_observation(prediction, observation, None)["status"] == "MAPPING_UNAVAILABLE"
    with pytest.raises(ValueError):
        replace(prediction, t_min=(0., 0.))
    with pytest.raises(ValueError):
        replace(prediction, values=(100., float("nan")))


def test_alignment_extreme_finite_values_cannot_emit_infinity():
    from dataclasses import replace
    from livemorebio.life_patch.alignment import align_observation
    prediction, mapping, observation = aligned_fixture()
    result = align_observation(replace(prediction, values=(-1e308, 1e308)), observation, mapping)
    assert result["predicted"] == pytest.approx(-6e307)
    observation["value"] = 1e308
    observation["model_context"]["model_time_min"] = 0
    result = align_observation(replace(prediction, values=(-1e308, 1e308)), observation, mapping)
    assert result["status"] == "INVALID_NUMERICAL_OUTPUT"
    assert result["predicted"] is None and result["residual"] is None
    with pytest.raises(ValueError):
        replace(prediction, values=(10 ** 1000, 1.))


def test_patch_ui_requires_prepared_virtual_input_not_implicit_sampling():
    from pathlib import Path
    source = (Path(__file__).parents[1] / "aegle/console/patch.html").read_text(encoding="utf-8")
    assert 'id="virtual-envelope"' in source
    assert "envelope.mode!=='virtual'" in source
    assert 'body:JSON.stringify({subject_id:subject})' not in source
    assert 'Admission not confirmed; inspect the LIFE journal before retrying.' in source
    assert "status.textContent='Not admitted:" not in source
