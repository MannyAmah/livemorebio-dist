"""Design-B red-first tests: technical fixtures only, no sockets, no patient data."""
import ipaddress
import inspect
from pathlib import Path
from unittest.mock import Mock

from http.cookies import SimpleCookie

import pytest
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient

from livemorebio import security

TOKEN = "technical-console-peer-token-not-real"
ORIGIN = "http://127.0.0.1:8850"
BEARER = {"Authorization": f"Bearer {TOKEN}"}
GATEWAY = ("172.18.0.1", 61488)
# Iface Destination Gateway Flags RefCnt Use Metric Mask MTU Window IRTT
HEADER = "Iface\tDestination\tGateway \tFlags\tRefCnt\tUse\tMetric\tMask\t\tMTU\tWindow\tIRTT\n"
BRIDGE_ROUTES = (HEADER
                 + "eth0\t00000000\t010012AC\t0003\t0\t0\t0\t00000000\t0\t0\t0\n"
                 + "eth0\t000012AC\t00000000\t0001\t0\t0\t0\t0000FFFF\t0\t0\t0\n")


@pytest.fixture(autouse=True)
def native_environment(monkeypatch):
    monkeypatch.delenv("LIVEMORE_CONSOLE_PEER", raising=False)


def technical_app():
    app = FastAPI()
    security.install_mutation_auth(app, session_document_paths=frozenset({"/"}))

    @app.get("/")
    def document():
        return HTMLResponse("Technical console fixture, not patient data.")

    return app


@pytest.fixture
def container(monkeypatch, tmp_path):
    """A technical stand-in for Aegle's container: marker, route table, opt-in."""
    marker = tmp_path / "dockerenv"
    marker.write_text("", encoding="utf-8")
    routes = tmp_path / "route"
    routes.write_text(BRIDGE_ROUTES, encoding="utf-8")
    monkeypatch.setattr(security, "_CONTAINER_MARKER", str(marker), raising=False)
    monkeypatch.setattr(security, "_ROUTE_TABLE", str(routes), raising=False)
    monkeypatch.setenv(security.TOKEN_ENV, TOKEN)
    monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", "docker-gateway")
    return routes


def client(app, peer):
    return TestClient(app, base_url=ORIGIN, client=peer)


def mint(c, headers=BEARER):
    return c.post("/api/session/code", headers=headers)


def exchange(c, code, headers=None):
    return c.post("/api/session/exchange", data={"code": code}, headers=headers or {},
                 follow_redirects=False)


def test_gateway_peer_gets_a_console_session(container):
    app = technical_app()
    with client(app, GATEWAY) as host:
        response = mint(host)
        assert response.status_code == 200 and TOKEN not in response.text
        done = exchange(host, response.json()["code"])
    assert done.status_code == 200 and '<meta http-equiv="refresh" content="0;url=/">' in done.text
    morsel = SimpleCookie(done.headers["set-cookie"])["livemore_local_session_8850"]
    assert morsel.value != TOKEN and morsel["httponly"] and morsel["samesite"] == "strict"


@pytest.mark.parametrize("member", ["172.18.0.2", "172.18.0.4", "172.18.0.254", "10.0.0.1"])
def test_other_bridge_members_cannot_mint_or_exchange(container, member):
    app = technical_app()
    with client(app, GATEWAY) as host, client(app, (member, 40000)) as other:
        refused = mint(other)
        assert refused.status_code == 403 and refused.json()["code"] == "CONSOLE_PEER_REFUSED"
        code = mint(host).json()["code"]
        stolen = exchange(other, code)
        assert stolen.status_code == 401 and "set-cookie" not in stolen.headers
        assert exchange(host, code).status_code == 200  # refusal did not consume the code


@pytest.mark.parametrize("peer", [
    "::ffff:172.18.0.1", "::ffff:ac12:1", "::172.18.0.1", "64:ff9b::ac12:1",
    "2002:ac12:1::", "172.18.0.1%eth0", "172.018.0.1", "2886860801", " 172.18.0.1",
])
def test_gateway_other_encodings_cannot_mint_or_consume_codes(container, peer):
    app = technical_app()
    with client(app, GATEWAY) as host, client(app, (peer, 40000)) as other:
        refused = mint(other)
        assert refused.status_code == 403
        assert refused.json()["code"] == "CONSOLE_PEER_REFUSED"
        code = mint(host).json()["code"]
        refused = exchange(other, code)
        assert refused.status_code == 401 and "set-cookie" not in refused.headers
        assert exchange(host, code).status_code == 200


def test_ipv6_loopback_can_still_mint_and_exchange_in_compose(container):
    app = technical_app()
    with client(app, ("::1", 40000)) as local:
        code = mint(local).json()["code"]
        assert exchange(local, code).status_code == 200


@pytest.mark.parametrize("forged", [
    {"X-Forwarded-For": "172.18.0.1"}, {"X-Real-IP": "172.18.0.1"},
    {"Forwarded": "for=172.18.0.1"}, {"X-Forwarded-For": "127.0.0.1"}])
def test_headers_cannot_make_a_member_the_gateway(container, forged):
    app = technical_app()
    with client(app, GATEWAY) as host, client(app, ("172.18.0.2", 40000)) as other:
        assert mint(other, {**BEARER, **forged}).status_code == 403
        code = mint(host).json()["code"]
        assert exchange(other, code, forged).status_code == 401


def test_native_path_admits_loopback_only(container, monkeypatch):
    monkeypatch.delenv("LIVEMORE_CONSOLE_PEER", raising=False)
    app = technical_app()
    with client(app, GATEWAY) as gateway, client(app, ("127.0.0.1", 40000)) as local:
        assert mint(gateway).status_code == 403
        code = mint(local).json()["code"]
        assert exchange(gateway, code).status_code == 401
        assert exchange(local, code).status_code == 200


@pytest.mark.parametrize("value", ["172.18.0.1", "any", "1", "true", "docker-gateway,10.0.0.1",
                                  "DOCKER-GATEWAY", "docker-gateway ", " docker-gateway"])
def test_only_the_one_mode_is_accepted(container, monkeypatch, value):
    monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", value)
    with pytest.raises(ValueError, match="CONSOLE_PEER_UNRESOLVED") as refused:
        technical_app()
    assert isinstance(refused.value, security.ConsolePeerError)
    assert refused.value.code == "CONSOLE_PEER_UNRESOLVED"


def test_opt_in_outside_a_container_refuses_to_start(container, monkeypatch, tmp_path):
    monkeypatch.setattr(security, "_CONTAINER_MARKER", str(tmp_path / "absent"), raising=False)
    with pytest.raises(ValueError, match="CONSOLE_PEER_UNRESOLVED") as refused:
        technical_app()
    assert isinstance(refused.value, security.ConsolePeerError)
    assert refused.value.code == "CONSOLE_PEER_UNRESOLVED"


def test_only_docker_marker_source_is_supported():
    assert security._CONTAINER_MARKER == "/.dockerenv"
    assert "containerenv" not in inspect.getsource(security)


def test_podman_marker_alone_cannot_enable_compose_peers(monkeypatch, tmp_path):
    routes = tmp_path / "technical-route"
    routes.write_text(BRIDGE_ROUTES, encoding="utf-8")
    monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", "docker-gateway")
    monkeypatch.setattr(security, "_ROUTE_TABLE", str(routes))
    monkeypatch.setattr(security, "_CONTAINER_MARKER", "/.dockerenv")

    # Both filesystem entry points see only the unsupported marker, independent
    # of whether this test itself runs inside an image or on a native host.
    marker_present = lambda path: str(path) == "/run/.containerenv"
    monkeypatch.setattr(security.os.path, "isfile", marker_present)
    monkeypatch.setattr(security.os.path, "exists", marker_present)
    for construct in (security.console_peers, technical_app):
        with pytest.raises(security.ConsolePeerError, match="CONSOLE_PEER_UNRESOLVED"):
            construct()


@pytest.mark.parametrize("rows", [
    "",                                                                   # no default route
    "eth0\t00000000\t010012AC\t0003\t0\t0\t0\t00000000\t0\t0\t0\n"
    "eth1\t00000000\t010013AC\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",       # two default routes
    "eth0\t00000000\t08080808\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",       # public gateway 8.8.8.8
    "eth0\t00000000\t0100007F\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",       # loopback gateway
    "eth0\t00000000\t00000000\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",       # unspecified gateway
    "eth0\t00000000\t0100FEA9\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",       # link-local gateway
    "eth0\t00000000\t00000000\t0001\t0\t0\t0\t00000000\t0\t0\t0\n",       # on-link route
    pytest.param("eth0\t00000000\t010012AC\t0001\t0\t0\t0\t00000000\t0\t0\t0\n",
                 id="private-gateway-without-gateway-flag"),
    "eth0\t00000000\t010012AC\t0002\t0\t0\t0\t00000000\t0\t0\t0\n",       # route down
    "eth0\t00000000\tZZZZ\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",           # malformed
    "eth0\t00000000\t010012AC\tZZZZ\t0\t0\t0\t00000000\t0\t0\t0\n",       # malformed flags
    "eth0\t00000000\t100000000\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",      # overflow
])
def test_unusable_route_tables_refuse_to_start(container, rows):
    container.write_text(HEADER + rows, encoding="utf-8")
    with pytest.raises(ValueError, match="CONSOLE_PEER_UNRESOLVED") as refused:
        technical_app()
    assert isinstance(refused.value, security.ConsolePeerError)
    assert refused.value.code == "CONSOLE_PEER_UNRESOLVED"
    if "\t010012AC\t0001\t" in rows:
        assert "expected one default gateway" in str(refused.value)
        assert "count=0" in str(refused.value)


@pytest.mark.parametrize("gateway", [
    "0.0.0.1", "0.255.255.254", "255.255.255.255", "240.0.0.1", "192.0.2.1",
    "198.51.100.1", "203.0.113.1", "198.18.0.1", "192.0.0.1", "192.0.0.170",
    "192.0.0.9", "100.64.0.1", "224.0.0.1", "8.8.8.8", "127.0.0.11",
    "169.254.1.1", "0.0.0.0", "172.32.0.1", "11.0.0.1",
])
def test_default_gateway_outside_rfc1918_refuses(container, gateway):
    kernel_gateway = ipaddress.IPv4Address(gateway).packed[::-1].hex().upper()
    container.write_text(BRIDGE_ROUTES.replace("010012AC", kernel_gateway), encoding="utf-8")
    with pytest.raises(security.ConsolePeerError, match="not a private bridge address") as refused:
        technical_app()
    assert refused.value.code == "CONSOLE_PEER_UNRESOLVED"
    assert "count=1" in str(refused.value) and gateway not in str(refused.value)


@pytest.mark.parametrize("gateway", ["172.18.0.1", "10.0.0.1", "192.168.65.1"])
def test_default_gateway_accepts_rfc1918_ranges(gateway):
    kernel_gateway = ipaddress.IPv4Address(gateway).packed[::-1].hex().upper()
    table = BRIDGE_ROUTES.replace("010012AC", kernel_gateway)
    assert security._default_gateway(table) == ipaddress.IPv4Address(gateway)


@pytest.mark.parametrize(("field", "malformed"), [
    (2, "0x010012AC"), (2, "0X010012AC"), (2, "0100_12AC"), (2, "+10012AC"),
    (2, "010012ac"), (2, "12AC"), (2, "100000000"), (2, "-1"),
    (3, "0x3"), (3, "0_003"), (3, "3"), (3, "+003"), (3, "000a"),
    *[(field, malformed) for field in (1, 7)
      for malformed in ("0000000", "0x00000000", "0000_0000", "+0000000", "ZZZZZZZZ")],
])
def test_default_route_fields_require_kernel_hex_format(container, field, malformed):
    fields = "eth0 00000000 010012AC 0003 0 0 0 00000000 0 0 0".split()
    fields[field] = malformed
    # A valid route beside malformed text must not hide a second default candidate.
    container.write_text(BRIDGE_ROUTES + "\t".join(fields) + "\n", encoding="utf-8")
    with pytest.raises(security.ConsolePeerError, match="malformed row") as refused:
        technical_app()
    assert refused.value.code == "CONSOLE_PEER_UNRESOLVED"


@pytest.mark.parametrize(("destination", "mask"), [
    ("000012AC", "00000000"), ("00000000", "0000FFFF"), ("000012AC", "0000FFFF"),
])
def test_nondefault_routes_in_kernel_form_are_skipped(destination, mask):
    table = BRIDGE_ROUTES + f"eth1\t{destination}\t0100000A\t0003\t0\t0\t0\t{mask}\t0\t0\t0\n"
    assert security._default_gateway(table) == ipaddress.IPv4Address("172.18.0.1")


@pytest.mark.parametrize("control", ["\x1c", "\x1d", "\x1e", "\x1f"],
                         ids=["file-separator", "group-separator", "record-separator", "unit-separator"])
@pytest.mark.parametrize("row_index", [1, 2], ids=["default-route", "nondefault-route"])
def test_interface_control_bytes_do_not_split_route_lines_or_fields(control, row_index):
    rows = BRIDGE_ROUTES.split("\n")
    fields = rows[row_index].split("\t")
    fields[0] = f"eth{control}0"
    # The kernel pads each output row with spaces; those are not field separators.
    rows[row_index] = "\t".join(fields) + " " * 16
    assert security._default_gateway("\n".join(rows)) == security._default_gateway(BRIDGE_ROUTES)


@pytest.mark.parametrize("row_index", [1, 2], ids=["default-route", "nondefault-route"])
def test_space_separated_route_rows_are_refused_even_with_kernel_values(row_index):
    row = BRIDGE_ROUTES.split("\n")[row_index].replace("\t", " ")
    with pytest.raises(security.ConsolePeerError, match="malformed row"):
        security._default_gateway(BRIDGE_ROUTES + row + "\n")


@pytest.mark.parametrize("row", [
    # The kernel writes every row in one form; any other row refuses the whole
    # table rather than being classified, default or not.
    "eth1 000012AC malformed malformed 0 0 0 0000FFFF 0 0 0",
    "eth1 000012ac 00000000 0001 0 0 0 0000ffff 0 0 0",
    "eth1 00000000 0100000A",
    "eth1 00000000 0100000A 0003 0 0 0",
    "eth1",
])
def test_a_row_not_in_kernel_form_refuses_the_table(container, row):
    container.write_text(BRIDGE_ROUTES + row + "\n", encoding="utf-8")
    with pytest.raises(security.ConsolePeerError, match="malformed row") as refused:
        technical_app()
    assert refused.value.code == "CONSOLE_PEER_UNRESOLVED"


def test_blank_lines_of_the_route_table_are_ignored():
    assert security._default_gateway(BRIDGE_ROUTES + "\n\n") == ipaddress.IPv4Address("172.18.0.1")


def test_services_without_console_documents_ignore_the_setting(container, monkeypatch):
    monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", "not-a-mode")
    monkeypatch.setattr(security, "_CONTAINER_MARKER", str(container.parent / "absent"), raising=False)
    app = FastAPI()
    security.install_mutation_auth(app)  # life/cendos shape: no session routes


def test_absent_route_table_refuses_to_start(container):
    container.unlink()
    with pytest.raises(ValueError, match="CONSOLE_PEER_UNRESOLVED") as refused:
        technical_app()
    assert isinstance(refused.value, security.ConsolePeerError)


def test_non_ascii_route_table_refuses_to_start(container):
    container.write_bytes(b"\xff")
    with pytest.raises(ValueError, match="CONSOLE_PEER_UNRESOLVED") as refused:
        technical_app()
    assert isinstance(refused.value, security.ConsolePeerError)


def test_default_gateway_parses_the_bridge_table():
    assert security._default_gateway(BRIDGE_ROUTES) == ipaddress.IPv4Address("172.18.0.1")


def test_console_peers_are_resolved_once_at_install(container, monkeypatch):
    import builtins

    opened = Mock(wraps=builtins.open)
    monkeypatch.setattr(builtins, "open", opened)
    app = technical_app()
    route_opens = [call for call in opened.call_args_list if str(call.args[0]) == str(container)]
    assert len(route_opens) == 1
    container.write_text(BRIDGE_ROUTES.replace("010012AC", "010013AC"), encoding="utf-8")
    with client(app, GATEWAY) as original, client(app, ("172.19.0.1", 40000)) as changed:
        code = mint(original).json()["code"]
        assert exchange(changed, code).status_code == 401
        assert exchange(original, code).status_code == 200
    assert [call for call in opened.call_args_list if str(call.args[0]) == str(container)] == route_opens


def test_empty_mode_uses_native_path_without_reading_container_files(container, monkeypatch):
    monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", "")
    monkeypatch.setattr(security, "_CONTAINER_MARKER", str(container.parent / "absent"), raising=False)
    container.unlink()
    app = technical_app()
    with client(app, ("127.0.0.1", 40000)) as local, client(app, GATEWAY) as gateway:
        code = mint(local).json()["code"]
        assert mint(gateway).status_code == 403
        assert exchange(gateway, code).status_code == 401
        assert exchange(local, code).status_code == 200


def test_startup_refusals_name_reason_and_count_without_addresses(container, monkeypatch):
    cases = [
        ("172.18.0.1", BRIDGE_ROUTES),
        ("docker-gateway", HEADER),
        ("docker-gateway", BRIDGE_ROUTES.replace("010012AC", "08080808")),
        ("docker-gateway", BRIDGE_ROUTES.replace("010012AC", "ZZZZ")),
    ]
    for mode, table in cases:
        monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", mode)
        container.write_text(table, encoding="utf-8")
        with pytest.raises(ValueError, match="CONSOLE_PEER_UNRESOLVED") as refused:
            technical_app()
        message = str(refused.value)
        assert "count=" in message
        assert "172.18.0.1" not in message and "8.8.8.8" not in message
    monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", "docker-gateway")
    container.unlink()
    with pytest.raises(ValueError, match="count="):
        technical_app()
    monkeypatch.setattr(security, "_CONTAINER_MARKER", str(container.parent / "absent"), raising=False)
    with pytest.raises(ValueError, match="count="):
        technical_app()


def test_compose_pins_console_peer_to_loopback_publishing():
    import yaml
    from ._source_tree import require_source_tree

    require_source_tree("docker-compose.yml")
    compose = yaml.safe_load((Path(__file__).resolve().parents[2] / "docker-compose.yml").read_text(encoding="utf-8"))
    services = compose["services"]
    assert services["aegle"]["environment"]["LIVEMORE_CONSOLE_PEER"] == "docker-gateway"
    for name, service in services.items():
        if name != "aegle":
            assert "LIVEMORE_CONSOLE_PEER" not in service["environment"]
        assert all(port.startswith("127.0.0.1:") for port in service["ports"])
        assert "network_mode" not in service and "networks" not in service
        assert "NET_RAW" in service["cap_drop"]


def test_native_services_drop_the_compose_peer_mode(monkeypatch, tmp_path):
    from livemorebio import cli

    monkeypatch.setenv("LIVEMORE_CONSOLE_PEER", "docker-gateway")
    monkeypatch.setattr(cli.R, "REG_DIR", str(tmp_path))
    assert "LIVEMORE_CONSOLE_PEER" not in cli._service_environment()
