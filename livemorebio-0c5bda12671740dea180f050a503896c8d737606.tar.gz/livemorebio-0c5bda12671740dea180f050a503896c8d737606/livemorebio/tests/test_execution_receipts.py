"""Durable receipt identity, separate from biological or physical qualification."""
from copy import deepcopy
import json

import pytest


def ledger(tmp_path):
    from livemorebio.aegle.execution_receipts import ExecutionReceiptLedger
    from livemorebio.tests.test_continuous_execution import manager, captured_source
    owner = manager(tmp_path)
    prepared = owner.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "receipt-test")
    owner.start(prepared["execution_id"], expected_revision=prepared["revision"], expected_source_generation="generation-a")
    frame = owner.advance_once(prepared["execution_id"])
    return ExecutionReceiptLedger(owner.store), owner, frame


def receipt(frame):
    # Internal persistence fixture, deliberately not an admitted LIFE wire record.
    return {"schema": "livemore.execution-observation-receipt.v1", "execution_id": frame["execution_id"],
        "frame_index": frame["frame_index"], "frame_hash": frame["frame_hash"],
        "source_snapshot_hash": frame["source_snapshot_hash"], "source_generation": frame["source_generation"],
        "device_id": "technical-device", "operator_id": "technical-operator",
        "envelope_id": "technical-envelope-1", "envelope_hash": "a" * 64, "manifest_hash": "b" * 64,
        "envelope": {"fixture": "PRIVATE TECHNICAL RECEIPT"}, "manifest": {"fixture": True},
        "admission": {"received_at": "2026-09-08T00:00:00Z"}}


def test_receipt_exact_retry_is_encrypted_and_timestamp_preserving(tmp_path):
    store, owner, frame = ledger(tmp_path)
    try:
        value = receipt(frame)
        assert store.admit(value) == value
        assert store.admit(value) == value
        assert store.get(value["envelope_id"]) == value
        assert store.latest(value["execution_id"], value["device_id"], value["operator_id"]) == value
        assert b"PRIVATE TECHNICAL RECEIPT" not in owner.store.path.read_bytes()
        assert b"technical-device" not in owner.store.path.read_bytes()
    finally:
        owner.close()


def test_existing_frame_cannot_be_restamped_as_a_new_envelope(tmp_path):
    store, owner, frame = ledger(tmp_path)
    try:
        value = receipt(frame)
        store.admit(value)
        changed = deepcopy(value)
        changed.update(envelope_id="technical-envelope-2", envelope_hash="c" * 64)
        changed["admission"]["received_at"] = "2026-09-08T01:00:00Z"
        with pytest.raises(ValueError):
            store.admit(changed)
        changed = deepcopy(value)
        changed["envelope"]["fixture"] = "different-content"
        with pytest.raises(ValueError):
            store.admit(changed)
    finally:
        owner.close()


@pytest.mark.parametrize("field,value", [("frame_hash", "f" * 64), ("source_snapshot_hash", "f" * 64),
    ("source_generation", "other-generation"), ("frame_index", 2), ("frame_index", True)])
def test_receipt_requires_exact_durably_committed_frame(tmp_path, field, value):
    store, owner, frame = ledger(tmp_path)
    try:
        candidate = receipt(frame) | {field: value}
        with pytest.raises(ValueError):
            store.admit(candidate)
    finally:
        owner.close()


def test_receipt_order_does_not_roll_back_latest_frame(tmp_path):
    store, owner, frame = ledger(tmp_path)
    try:
        first = receipt(frame)
        store.admit(first)
        second_frame = owner.advance_once(frame["execution_id"])
        second = receipt(second_frame) | {"envelope_id": "technical-envelope-2", "envelope_hash": "c" * 64}
        store.admit(second)
        assert store.admit(first) == first
        assert store.latest(first["execution_id"], first["device_id"], first["operator_id"]) == second
    finally:
        owner.close()


def test_receipt_counts_toward_global_payload_quota(tmp_path):
    store, owner, frame = ledger(tmp_path)
    try:
        with owner.store._connection() as connection:
            before = owner.store._totals(connection)[0]
        owner.store.quota_bytes = before + 4096 + 100
        with pytest.raises(ValueError):
            store.admit(receipt(frame))
        assert store.get("technical-envelope-1") is None
    finally:
        owner.close()


@pytest.mark.parametrize("column,replacement", [("frame_index", 99), ("binding_key", "e" * 64), ("series_key", "e" * 64)])
def test_clear_receipt_indexes_must_match_authenticated_payload(tmp_path, column, replacement):
    store, owner, frame = ledger(tmp_path)
    try:
        value = receipt(frame)
        store.admit(value)
        with owner.store._connection() as connection:
            connection.execute(f"UPDATE observation_receipts SET {column}=?", (replacement,))
        with pytest.raises(ValueError):
            store.get(value["envelope_id"])
        if column != "series_key":
            with pytest.raises(ValueError):
                store.latest(value["execution_id"], value["device_id"], value["operator_id"])
    finally:
        owner.close()
