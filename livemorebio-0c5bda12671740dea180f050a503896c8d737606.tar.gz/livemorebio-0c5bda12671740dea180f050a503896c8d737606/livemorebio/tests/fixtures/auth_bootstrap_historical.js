/* Automatic authorization for the launched loopback workbench.

   The server establishes an HttpOnly, SameSite session cookie. The bearer token
   never enters JavaScript, HTML, browser storage, URLs, or logs. CLI, SDK, and
   notebook clients continue to use the owner-only launcher token file. */
(() => {
  const nativeFetch = window.fetch.bind(window);
  const BOOTSTRAP_TIMEOUT_MS = 10000;
  let bootstrap = null;

  function unavailable() {
    const error = new Error("Automatic local session is unavailable. Run `livemore start` and reopen the product.");
    error.code = "LOCAL_SESSION_UNAVAILABLE";
    return error;
  }

  function callerAborted() {
    // An arbitrary caller-supplied abort reason must not become UI error text.
    return new DOMException("The request was canceled.", "AbortError");
  }

  function bootstrapFlight() {
    if (bootstrap) return bootstrap;
    const flight = { controller: new AbortController(), timer: null, promise: null };
    bootstrap = flight;
    // Defer native dispatch so even a synchronous transport failure belongs to
    // the published flight and follows the same fixed-error/reset path.
    const attempt = Promise.resolve().then(() => nativeFetch("/api/session/bootstrap", {
      method: "GET",
      credentials: "same-origin",
      headers: { "Accept": "application/json" },
      signal: flight.controller.signal,
    })).then(response => {
      if (response.ok) return true;
      throw unavailable();
    });
    const deadline = new Promise((resolve, reject) => {
      flight.timer = setTimeout(() => {
        reject(unavailable());
        flight.controller.abort();
      }, BOOTSTRAP_TIMEOUT_MS);
    });
    flight.promise = Promise.race([attempt, deadline]).catch(() => {
      if (bootstrap === flight) bootstrap = null;
      throw unavailable();
    }).finally(() => clearTimeout(flight.timer));
    return flight;
  }

  function waitForBootstrap(flight, signal) {
    if (!signal) return flight.promise;
    return new Promise((resolve, reject) => {
      const finish = (settle, value) => {
        signal.removeEventListener("abort", onAbort);
        settle(value);
      };
      const onAbort = () => finish(reject, callerAborted());
      signal.addEventListener("abort", onAbort, { once: true });
      // Keep rejection handling attached even after this waiter leaves: the
      // shared flight remains owned and bounded for any other callers.
      flight.promise.then(value => finish(resolve, value), error => finish(reject, error));
      if (signal.aborted) onAbort();
    });
  }

  async function ensureLocalSession() {
    return bootstrapFlight().promise;
  }

  window.lmbEnsureLocalSession = ensureLocalSession;
  window.fetch = async (input, init = {}) => {
    const url = new URL(typeof input === "string" ? input : input.url, location.href);
    let flight = null;
    if (url.origin === location.origin && url.pathname !== "/api/session/bootstrap") {
      // Web IDL treats undefined as absent, while an explicit null disables a
      // Request's signal. Forward the original Request without consuming it.
      const signal = init?.signal !== undefined ? init.signal : input?.signal;
      if (signal?.aborted) throw callerAborted();
      flight = bootstrapFlight();
      await waitForBootstrap(flight, signal);
      if (signal?.aborted) throw callerAborted();
      init = { ...init, credentials: "same-origin" };
    }
    const response = await nativeFetch(input, init);
    // A late response from an older local flight (or a foreign request) must
    // not invalidate a newer successful cookie bootstrap. Never auto-replay.
    if (response.status === 401 && flight && bootstrap === flight) bootstrap = null;
    return response;
  };
})();
