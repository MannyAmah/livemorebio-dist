"""Real-anatomy mesh layer — catalog integrity, provenance discipline, serving.

The mandate: every rendered organ is REAL anatomy (HRA / BodyParts3D) with
provenance, no placeholder or generated geometry anywhere. These tests pin
that contract at the registry, ontology-binding, and HTTP-serving levels.
"""
import json
from pathlib import Path
import tomllib

import pytest

from livemorebio.anatomy import meshes as AM
from livemorebio.anatomy.ontology import CORE_PATH
from livemorebio.tests.anatomy_fixtures import technical_glb


def test_server_extra_installs_bodyparts3d_converter():
    """A fresh server install must be able to materialise the muscle GLB."""
    project = tomllib.loads((Path(__file__).parents[2] / "pyproject.toml").read_text(encoding="utf-8"))
    assert "trimesh==5.0.0" in project["project"]["optional-dependencies"]["server"]
from livemorebio.engines.biology import ORGAN_ATLAS, ORGAN_SYSTEM


def test_catalog_covers_every_organ():
    assert set(AM.CATALOG) == set(ORGAN_ATLAS), \
        "every organ in the atlas must have a real-mesh catalog entry"


def test_catalog_entries_are_fully_attributed():
    for key, e in AM.CATALOG.items():
        assert e["license"] in ("CC-BY-4.0", "CC-BY-SA-2.1-JP"), key
        assert e["source"], key
        assert e["attribution"], key
        assert e["uberon"].startswith("UBERON:"), key
        assert e["fma"].startswith("FMA:"), key
        if e["kind"] == "hra-glb":
            assert e["url"].startswith("https://cdn.humanatlas.io/"), key
        elif e["kind"] == "bp3d-obj":
            assert e["fma_parts"], key
            assert e["archive"].startswith("https://dbarchive.biosciencedbc.jp/"), key
        else:
            pytest.fail(f"unknown catalog kind for {key}: {e['kind']}")


def test_no_generated_geometry_sources():
    """No AI-generated / unlicensed mesh hosts may enter the catalog (§4)."""
    allowed_hosts = ("cdn.humanatlas.io", "dbarchive.biosciencedbc.jp")
    for key, e in AM.CATALOG.items():
        url = e.get("url") or e.get("archive")
        assert any(h in url for h in allowed_hosts), (key, url)


def test_organ_system_binding_is_valid_ontology():
    core = json.loads(Path(CORE_PATH).read_text(encoding="utf-8"))
    system_ids = {s["id"] for s in core["systems"]}
    assert set(ORGAN_SYSTEM) == set(ORGAN_ATLAS)
    for oid, sys_id in ORGAN_SYSTEM.items():
        assert sys_id in system_ids, (oid, sys_id)


def test_atlas_meshes_are_local_asset_paths():
    for oid, meta in ORGAN_ATLAS.items():
        assert meta["mesh"] == f"/assets/anatomy/{oid}.glb", oid


def test_manifest_reports_catalog_and_cache_state(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))
    rows = AM.manifest()
    assert {r["key"] for r in rows} == set(AM.CATALOG)
    for r in rows:
        assert r["cached"] is False           # empty dir: nothing cached
        assert r["path"] == f"/assets/anatomy/{r['key']}.glb"
        assert "provenance" not in r


def test_ensure_mesh_unknown_key_raises():
    with pytest.raises(KeyError):
        AM.ensure_mesh("not-an-organ")


def test_provenance_sidecar_written_on_acquisition(tmp_path, monkeypatch):
    """Uses a stub fetch so the unit test needs no network: the provenance
    discipline (sidecar with sha256, license, retrieval time) is what's pinned."""
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))

    def fake_download(url, dest, timeout=120):
        Path(dest).write_bytes(technical_glb("provenance test"))
    monkeypatch.setattr(AM, "_download", fake_download)

    p = AM.ensure_mesh("liver")
    assert p.exists()
    prov = AM.provenance("liver")
    assert prov["license"] == "CC-BY-4.0"
    assert prov["uberon"] == "UBERON:0002107"
    assert len(prov["sha256"]) == 64
    assert prov["source_url"].startswith("https://cdn.humanatlas.io/")
    assert prov["retrieved_utc"].endswith("Z")
    rows = {r["key"]: r for r in AM.manifest()}
    assert rows["liver"]["cached"] is True
    assert rows["liver"]["provenance"]["sha256"] == prov["sha256"]


# ---------------------------------------------------------------------------
# HTTP layer (Aegle service)
# ---------------------------------------------------------------------------

@pytest.fixture()
def client():
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app
    return TestClient(app)


def test_api_manifest_route(client):
    r = client.get("/api/anatomy/manifest")
    assert r.status_code == 200
    assert {a["key"] for a in r.json()["assets"]} == set(AM.CATALOG)


def test_asset_route_unknown_is_404(client):
    assert client.get("/assets/anatomy/nope.glb").status_code == 404


def test_asset_route_serves_real_glb_with_provenance_headers(
    client, tmp_path, monkeypatch
):
    """Serve a provenance-bound mesh without relying on the network."""
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path))

    def fake_download(url, dest, timeout=120):
        Path(dest).write_bytes(technical_glb("route test"))

    monkeypatch.setattr(AM, "_download", fake_download)

    r = client.get("/assets/anatomy/liver.glb")
    assert r.status_code == 200
    assert r.content[:4] == b"glTF"          # technical transport; browser tests use real geometry
    assert r.headers["x-anatomy-license"] == "CC-BY-4.0"
    assert len(r.headers["x-anatomy-sha256"]) == 64


def test_api_biology_carries_anatomy_identity(client, monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-anatomy-test-token")
    organs = client.get("/api/biology", headers={"Authorization": "Bearer technical-anatomy-test-token"}).json()["organs"]
    assert organs
    for o in organs:
        an = o["anatomy"]
        assert an["uberon"].startswith("UBERON:")
        assert an["fma"].startswith("FMA:")
        assert an["system"] in {v for v in ORGAN_SYSTEM.values()}
        assert an["mesh_license"]
        assert o["mesh"].startswith("/assets/anatomy/")
