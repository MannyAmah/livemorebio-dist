"""Exact LIFE forwarding after durable gateway admission, including lost ACKs."""
from copy import deepcopy
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_execution_observations import continuous, delivery, product


def admitted_body(frame):
    body = delivery(frame)
    return {**body["envelope"], **{key: value for key, value in body["admission"].items() if key != "envelope_hash"},
            "manifest": body["manifest"], "evidence_references": []}


def acknowledgment(payload):
    model = payload["envelope"]["measurements"][0]["model_context"]
    parts = model["prediction_id"].split("-")
    return {"admission": "accepted", "projection": "applied", "execution_id": parts[1],
            "received_frame_index": int(parts[3]), "projected_frame_index": int(parts[3]),
            "envelope_id": payload["envelope"]["envelope_id"], "envelope_hash": payload["envelope"]["envelope_hash"],
            "evidence_class": "MODELED", "physical_equivalence_validated": False}


def test_gateway_receipt_forwarding_preserves_exact_time_hash_and_signature(continuous):
    from livemorebio.life_system.execution_delivery import forward_execution_receipt
    from livemorebio.security import verify_patch_admission
    record = admitted_body(continuous.frame)
    original = deepcopy(record)
    sent = []
    def deliver(payload):
        sent.append(deepcopy(payload))
        return acknowledgment(payload)
    source = SimpleNamespace(deliver_observation=deliver)
    first = forward_execution_receipt(record, source)
    assert first["aegle"]["status"] == "delivered"
    assert forward_execution_receipt(record, source) == first
    assert record == original and sent[0] == sent[1]
    assert sent[0]["admission"]["received_at"] == record["received_at"]
    assert verify_patch_admission(sent[0]["admission"], sent[0]["admission_signature"])


@pytest.mark.parametrize("change", [{"projection": "queued"}, {"envelope_hash": "f" * 64},
    {"physical_equivalence_validated": True}, {"projected_frame_index": 0}])
def test_reachable_peer_without_exact_projection_ack_is_not_delivered(continuous, change):
    from livemorebio.life_system.execution_delivery import forward_execution_receipt
    source = SimpleNamespace(deliver_observation=lambda payload: acknowledgment(payload) | change)
    assert forward_execution_receipt(admitted_body(continuous.frame), source)["aegle"]["status"] != "delivered"


def test_lost_response_does_not_fabricate_a_new_acquisition(continuous):
    from livemorebio.life_system.execution_delivery import forward_execution_receipt
    sent = []
    def deliver(payload):
        sent.append(deepcopy(payload))
        if len(sent) == 1:
            raise OSError("technical response-loss fixture")
        return acknowledgment(payload)
    source = SimpleNamespace(deliver_observation=deliver)
    record = admitted_body(continuous.frame)
    assert forward_execution_receipt(record, source)["aegle"]["status"] == "pending"
    assert forward_execution_receipt(record, source)["aegle"]["status"] == "delivered"
    assert sent[0] == sent[1]
