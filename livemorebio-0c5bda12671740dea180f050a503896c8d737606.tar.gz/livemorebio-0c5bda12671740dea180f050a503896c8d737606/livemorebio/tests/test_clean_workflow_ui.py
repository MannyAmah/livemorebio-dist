"""Execute the Biology entry script with unavailable graphics, not a source-string assertion."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess

from .biology_ui_fixtures import biology_controller_script
from ._node import require_node, run_node as _run_node


CONSOLE = Path(__file__).parents[1] / "aegle/console"


def test_biology_data_loads_and_retries_independently_of_graphics() -> None:
    node = require_node()
    script = biology_controller_script()
    program = r'''
const vm=require('node:vm');
const elements=new Map();
function el(id){if(!elements.has(id))elements.set(id,{textContent:'',innerHTML:'',style:{},dataset:{},disabled:false,handlers:{},addEventListener(k,v){this.handlers[k]=v},setAttribute(){},removeAttribute(){}});return elements.get(id)}
let calls=0;const timers=[];
const state={context_id:'a'.repeat(64),twin:{profile:'healthy',human:'reference preview',conditions:[],Si:1,Gb:90,gamma:1},organs:[{id:'heart',name:'Heart',status:'normal',metric:'rate',value:60,ratio:1}]};
const context={URLSearchParams,AbortController,location:{search:''},window:{},document:{hidden:false,getElementById:el,querySelector:el,createElement:()=>({getContext:()=>null}),addEventListener(){}},console:{warn(){}},fetch:async()=>{calls++;return{ok:calls!==2,status:calls===2?503:200,json:async()=>state}},setTimeout:(f,n)=>{timers.push({f,n});return timers.length},clearTimeout(){},setInterval(){throw Error('overlapping polling is prohibited')},performance:{now:()=>0}};
(async()=>{
 context.addEventListener=()=>{};
 await vm.runInNewContext('(async()=>{'+SCRIPT+'})()',context);
 for(let i=0;i<8;i++)await new Promise(setImmediate);
 if(!el('panel').innerHTML.includes('Heart'))throw Error('first load remained blank');
 const poll=timers.find(x=>x.n===8000);if(!poll)throw Error('no bounded second poll');
 await poll.f();
 if(!el('biology-status').textContent.includes('unavailable'))throw Error('HTTP error was hidden');
 if(!el('panel').innerHTML.includes('Heart'))throw Error('last good data was erased');
 await el('biology-retry').handlers.click();
 if(calls!==3||!el('panel').innerHTML.includes('Heart'))throw Error('retry did not recover');
 process.stdout.write('ok');
})().catch(e=>{console.error(e);process.exit(1)});
'''.replace("SCRIPT", json.dumps(script))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"


def test_cendos_starts_without_recalling_or_executing_a_saved_experiment() -> None:
    html = (CONSOLE / "cendos.html").read_text(encoding="utf-8")
    assert "loadLatestProtocol();" not in html
    assert 'id="preparation-tab"' in html
    assert 'id="history-tab"' in html
    assert 'id="new-experiment"' in html


def test_subject_lists_expose_pagination_and_search() -> None:
    for name in ("twins.html", "cohorts.html"):
        html = (CONSOLE / name).read_text(encoding="utf-8")
        for control in ("records-search", "records-page-size", "records-previous", "records-next", "records-page-status"):
            assert f'id="{control}"' in html


def test_metabolic_drawer_preserves_real_solver_and_reference_provenance() -> None:
    node = require_node()
    script = (CONSOLE / "lib/metabolic_biology.js").read_text(encoding="utf-8")
    script = re.sub(r"import .*?;", "", script).replace("export function", "function")
    program = r'''
const vm=require('node:vm');
const nodes=new Map();
const host={innerHTML:'',querySelector(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',value:'0',addEventListener(){}});return nodes.get(id)}};
const run={protocol_id:'cendos.human-gem-oxygen-capacity.v1',run_id:'protocol-ui-fixture',unit:'mmol/gDW/h',conditions:[{condition_id:'oxygen-0',objective_flux:2,solver_status:'optimal'}],controls:[],model:{release:'2.0.0',model_sha256:'model-digest',manifest:{commit:'pinned-commit'}},solver:{name:'glpk',versions:{cobra:'0.31.1',swiglpk:'5.0.12',python_libsbml:'5.20.5'},feasibility_tolerance:1e-7},reference_provenance:{state:'REFERENCE_BACKED',annotations:[{namespace:'ensembl',id:'ENSG000001'}],stoichiometry:{source:'pinned SBML'},gpr_graph:{source:'parsed model'}},input:{model_id:'human-gem'},input_sha256:'input-digest'};
const context={host,run,esc:x=>String(x??''),fmt:x=>String(x??'unavailable')};
vm.runInNewContext(SCRIPT+';renderMetabolicRun(host,run)',context);
const actual=JSON.parse(nodes.get('#metabolic-source').textContent);
for(const key of ['solver','reference_provenance','input_sha256','model']){
 if(JSON.stringify(actual[key])!==JSON.stringify(run[key]))throw Error('missing or altered provenance: '+key);
}
process.stdout.write('ok');
'''.replace("SCRIPT", json.dumps(script))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"


def test_unavailable_organs_and_cells_do_not_invent_measurements_or_activity() -> None:
    node = require_node()
    script = biology_controller_script()
    program = r'''
const vm=require('node:vm'),nodes=new Map(),labels=[];
const canvas=new Proxy({fillText:t=>labels.push(t)},{get:(o,k)=>k in o?o[k]:(()=>{})});
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',style:{},dataset:{},disabled:false,clientWidth:800,clientHeight:500,addEventListener(){},getContext:()=>canvas});return nodes.get(id)}
const unavailable={id:'kidney',name:'Kidney',status:'unknown',metric:'renal function',value:null,ratio:null,unit:'',evidence_state:'UNAVAILABLE',limitation:'No renal engine',targets:[],pathways:['renal clearance'],cell:{type:'Proximal tubule cell',render:'uptake',activity:null,quantities:[],evidence_state:'REFERENCE_ONLY',process:'Reference renal pathway',note:'No executable cellular transport'}};
const state={context_id:'a'.repeat(64),twin:{profile:'healthy',Si:0.0005,Gb:90,gamma:0.12,conditions:[]},organs:[unavailable,{...unavailable,id:'adipose',name:'Adipose',cell:{...unavailable.cell,render:'droplet'}}]};
const context={URLSearchParams,AbortController,location:{search:''},window:{},document:{hidden:false,getElementById:el,querySelector:el,createElement:()=>({getContext:()=>null}),addEventListener(){}},console:{warn(){}},fetch:async()=>({ok:true,status:200,json:async()=>state}),setTimeout:()=>1,clearTimeout(){},performance:{now:()=>0},devicePixelRatio:1,requestAnimationFrame(){throw Error('noncardiac animation is prohibited')},cancelAnimationFrame(){}};
(async()=>{
 context.addEventListener=()=>{};
 await vm.runInNewContext('(async()=>{'+SCRIPT+'})()',context);for(let i=0;i<6;i++)await new Promise(setImmediate);
 const overview=el('panel').innerHTML;
 if(overview.includes('null')||overview.includes('× ref'))throw Error('unknown ratio was rendered as a measured quantity');
 if(!overview.includes('unavailable')||!overview.includes('UNAVAILABLE'))throw Error('missing unavailable/evidence labels');
 context.window._sel('kidney');
 if(!el('panel').innerHTML.includes('No renal engine'))throw Error('missing applicability boundary');
 await context.window._cell('kidney');
 if(el('cellSide').innerHTML.includes('recorded membrane trace'))throw Error('noncardiac cell falsely claimed a membrane trace');
 await context.window._cell('adipose');
 if(labels.some(t=>t.includes('0%')||t.includes('lipid droplet load')))throw Error('unavailable adipose displayed a fabricated activity/load');
 process.stdout.write('ok');
})().catch(e=>{console.error(e);process.exit(1)});
'''.replace("SCRIPT", json.dumps(script))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"


def test_anatomy_hotspot_uses_same_unknown_color_as_organ() -> None:
    node = require_node()
    source = (CONSOLE / "lib/anatomy.js").read_text(encoding="utf-8")
    script = source.split("  function hotspotTexture(o) {", 1)[1].split("  function snapHotspot", 1)[0]
    program = r'''
const vm=require('node:vm');
const x={beginPath(){},roundRect(){},fill(){},stroke(){},fillText(){}};
const context={document:{createElement:()=>({getContext:()=>x})},THREE:{CanvasTexture:class{}},statusColor:()=>0x7a8f88};
vm.runInNewContext('function hotspotTexture(o){'+SCRIPT+';hotspotTexture({status:"unavailable",name:"Kidney"})',context);
if(x.strokeStyle!=='#7a8f88')throw Error('unknown organ label is not gray: '+x.strokeStyle);
'''.replace("SCRIPT", json.dumps(script))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_cell_replay_binds_context_invalidates_pending_data_and_resumes_after_refresh() -> None:
    node = require_node()
    script = biology_controller_script()
    program = r'''
const vm=require('node:vm'),nodes=new Map(),listeners={},frames=new Map();let frameId=0;
const canvas=new Proxy({},{get:()=>()=>{}});
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',style:{},dataset:{},disabled:false,clientWidth:800,clientHeight:500,addEventListener(){},getContext:()=>canvas});return nodes.get(id)}
const heart={id:'heart',name:'Heart',status:'parameter',metric:'IKr block',value:0,ratio:null,unit:'fraction',targets:[],pathways:[],cell:{type:'Myocyte',render:'cardiac',activity:null,quantities:[],evidence_state:'MODELED_BIOPHYSICAL'}};
let bodyContext='a'.repeat(64),traceContext='b'.repeat(64),bodyFailure=false,hold=false,release,traceRequests=0;
const state=()=>({context_id:bodyContext,twin:{profile:'healthy',conditions:[]},organs:[heart]});
const trace=()=>({context_id:traceContext,cardiac:{v:[-80,20,-80],cai:[0.0001,0.0002,0.0001],t_ms:[0,100,200]}});
const fetch=async path=>{if(path==='/api/biology')return{ok:!bodyFailure,status:bodyFailure?503:200,json:async()=>state()};traceRequests++;if(hold)await new Promise(resolve=>release=resolve);return{ok:true,json:async()=>trace()}};
const context={URLSearchParams,AbortController,location:{search:''},window:{},document:{hidden:false,getElementById:el,querySelector:el,createElement:()=>({getContext:()=>null}),addEventListener:(name,fn)=>listeners[name]=fn},console:{warn(){}},fetch,setTimeout:()=>1,clearTimeout(){},performance:{now:()=>1000},devicePixelRatio:1,requestAnimationFrame:fn=>{frames.set(++frameId,fn);return frameId},cancelAnimationFrame:id=>frames.delete(id)};
async function flush(){for(let i=0;i<8;i++)await new Promise(setImmediate)}
(async()=>{
 context.addEventListener=()=>{};
 await vm.runInNewContext('(async()=>{'+SCRIPT+'})()',context);await flush();
 await context.window._cell('heart');
 if(frames.size)throw Error('mismatched subject trace was animated');
 if(el('cellmodal').style.display!=='none')throw Error('mismatched context modal remained open');
 traceContext='a'.repeat(64);await context.window._cell('heart');if(!frames.size)throw Error('matching trace did not play');
 context.document.hidden=true;listeners.visibilitychange();await flush();
 if(frames.size)throw Error('hidden replay was not paused');
 context.document.hidden=false;listeners.visibilitychange();await flush();
 if(!frames.size)throw Error('replay did not resume after verified visible refresh');
 bodyFailure=true;listeners.visibilitychange();await flush();
 if(frames.size||!el('cell-data-status').textContent.includes('Replay paused'))throw Error('failed context refresh did not visibly pause replay');
 bodyFailure=false;listeners.visibilitychange();await flush();
 if(!frames.size)throw Error('replay did not recover after the same context refreshed');
 bodyContext='c'.repeat(64);listeners.visibilitychange();await flush();
 if(el('cellmodal').style.display!=='none'||frames.size)throw Error('context switch retained old cell replay');
 hold=true;const pending=context.window._cell('heart');await flush();
 bodyContext='d'.repeat(64);listeners.visibilitychange();await flush();traceContext='c'.repeat(64);release();await pending;
 if(el('cellmodal').style.display!=='none'||frames.size)throw Error('late old-context trace repainted modal');
 hold=false;bodyContext=null;listeners.visibilitychange();await flush();const before=traceRequests;await context.window._cell('heart');
 if(traceRequests!==before||el('cellmodal').style.display!=='none')throw Error('missing context did not fail closed');
 process.stdout.write('ok');
})().catch(e=>{console.error(e);process.exit(1)});
'''.replace("SCRIPT", json.dumps(script))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"
