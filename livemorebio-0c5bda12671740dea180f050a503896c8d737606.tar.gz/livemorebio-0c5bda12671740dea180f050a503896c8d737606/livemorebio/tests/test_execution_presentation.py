"""Display changes never rewrite numerical samples or advance receipt state."""
import json
from pathlib import Path
import subprocess

import pytest
from ._node import require_node

ROOT = Path(__file__).resolve().parents[2]
MODULE = ROOT / "livemorebio/aegle/console/lib/execution_presentation.js"


def node(script: str) -> None:
    result = subprocess.run(
        [require_node(), "--input-type=module", "-e",
         f"const h=await import({json.dumps(MODULE.as_uri())});" + script],
        capture_output=True, text=True, timeout=10, encoding="utf-8",
    )
    assert result.returncode == 0, result.stderr


def test_number_formatting_keeps_zero_sign_small_values_and_exact_raw_data():
    node("""
const assert=(await import('node:assert/strict')).default;
assert.equal(h.displayNumber(0),'0');assert.equal(h.displayNumber(-0),'0');
assert.equal(h.displayNumber(90.0628081675964),'90.0628');
assert.equal(h.displayNumber(-90.0628081675964),'-90.0628');
assert.equal(h.displayNumber(0.000003432935258),'3.43294e-6');
assert.equal(h.displayNumber(123456789),'1.23457e+8');
for(const value of [null,undefined,NaN,Infinity,-Infinity,'3',true])assert.equal(h.displayNumber(value),'Unavailable');
const samples=[{quantity:'glucose_mgdl',unit:'mg/dL',compartment:'plasma',native_times:[0,1],values:[90,90.0628081675964]}];
const original=JSON.stringify(samples),pre={textContent:''};h.updateExactSamples(pre,samples);
assert.equal(JSON.stringify(samples),original);assert.equal(JSON.parse(pre.textContent)[0].value,90.0628081675964);
assert.equal(JSON.parse(pre.textContent)[0].native_time,1);
assert.equal(h.quantityLabel('glucose_mgdl'),'Plasma glucose');assert.equal(h.quantityLabel('unknown'),'unknown');
""")


def test_preparation_disclosure_preserves_required_binding_and_user_open_state():
    node("""
const assert=(await import('node:assert/strict')).default,disclosure={open:false};
h.preparationPhase(disclosure,'initial');assert.equal(disclosure.open,true);
h.preparationPhase(disclosure,'prepared');assert.equal(disclosure.open,true);
h.preparationPhase(disclosure,'bound');assert.equal(disclosure.open,true);
h.preparationPhase(disclosure,'started');assert.equal(disclosure.open,false);
disclosure.open=true;h.preparationPhase(disclosure,'frame');assert.equal(disclosure.open,true);
h.preparationPhase(disclosure,'fixed');assert.equal(disclosure.open,false);
disclosure.open=true;h.preparationPhase(disclosure,'failed');assert.equal(disclosure.open,true);
""")


def test_raw_readout_changes_only_stable_pre_and_geometry_precedes_traces():
    source = (ROOT / "livemorebio/aegle/console/lib/continuous_execution.js").read_text(encoding="utf-8")
    assert '<details data-setup ' in source
    assert source.index('<section data-anatomy ') < source.index('<div data-quantities>')
    assert '<details data-exact-values>' in source
    assert 'updateExactSamples' in source
    assert 'preparationPhase' in source
    assert 'Reading the registered active twin…' not in source


@pytest.mark.parametrize("phase", ["waiting_for_engine", "streaming", "paused", "blocked", "interrupted", "stopped", "completed"])
@pytest.mark.parametrize("pending", [False, True])
def test_delivery_projection_distinguishes_inflight_from_blocked_without_writes(phase, pending):
    from copy import deepcopy
    from livemorebio.life_patch.virtual_execution import VirtualSessionManager
    record = {"state": phase, "pending": {"envelope": {"envelope_hash": "a" * 64}} if pending else None,
              "authorship": "engine", "last_forwarded": 2, "last_admitted": 2,
              "last_acknowledged_at": "2026-09-08T00:00:00Z", "receipt": None}
    original = deepcopy(record)
    projected = VirtualSessionManager._public(None, record)
    expected = "pending" if pending and phase in {"waiting_for_engine", "streaming"} else "blocked" if pending else "acknowledged"
    assert projected["delivery_status"] == expected
    assert projected["last_forwarded"] == 2
    assert projected["last_acknowledged_at"] == original["last_acknowledged_at"]
    assert projected["hardware_present"] is False
    assert record == original
