"""Real consumer handlers with authored UI seams; not coordinate-rendering proof."""
from pathlib import Path
import json
import subprocess

import pytest
from ._node import require_node


ROOT = Path(__file__).parents[2]
SOURCE = ROOT / "livemorebio/aegle/console/lib/execution_anatomy.js"


def execution_consumer(body: str) -> None:
    script = r"""
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(SOURCE,'utf8').replace(/^import .*;\n/gm,'').replace('export function','function');
const decode=s=>s.replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
const nodes=new Map(),calls=[],requests=[],mounts=[],explorers=[];
const names=['[data-section]','[data-depth]','[data-labels]','[data-home]','[data-retry]',
 '[data-scene]','[data-status]','[data-organ]','[data-detail]',
 '[data-molecular-inspector]','[data-molecular-feedback]'];
class Element {
 constructor(){this.handlers={};this.dataset={};this.value='';this.checked=true;this.disabled=false;this.textContent='';this.buttons=[];}
 set innerHTML(value){this.html=value;this.buttons=[];
  for(const match of value.matchAll(/<button\b[^>]*data-molecular-target="([^"]*)"[^>]*>/g)){
   const button=new Element();button.dataset.molecularTarget=decode(match[1]);this.buttons.push(button);
  }}
 get innerHTML(){return this.html||'';}
 addEventListener(name,fn){this.handlers[name]=fn;}
 querySelector(selector){assert(names.includes(selector),'unexpected selector '+selector);return nodes.get(selector);}
 querySelectorAll(selector){assert.equal(selector,'[data-molecular-target]');return this.buttons;}
 click(){return this.handlers.click?.({currentTarget:this,target:this});}
}
for(const name of names)nodes.set(name,new Element());
const host=new Element();nodes.get('[data-section]').value='off';nodes.get('[data-depth]').value='50';
const reference={schema:'livemore.biology-reference.v1',evidence_state:'REFERENCE_ONLY',reference_geometry:true,
 organs:[{id:'heart',name:'Heart',role:'Reference heart',value:null,metric:null,mesh:'/assets/anatomy/heart.glb',
 cell:{type:'Myocyte',process:'Reference',activity:null},targets:['KRAS','AMPK','UNKNOWN_TARGET'],pathways:[],anatomy:{}},
 {id:'liver',name:'Liver',role:'Reference liver',value:null,metric:null,mesh:'/assets/anatomy/liver.glb',
 cell:{type:'Hepatocyte',process:'Reference',activity:null},targets:['NR1I2'],pathways:[],anatomy:{}}]};
const execution={execution_id:'a'.repeat(32),source_snapshot_hash:'b'.repeat(64),selection:{twin_id:'technical-twin-a'}};
const original=JSON.stringify(execution);let fail=null;
const mountMolecularInspector=(node,options)=>{
 const record={node,options,opens:[],closes:0,disposals:0};mounts.push(record);
 if(fail==='mount')throw Error('PRIVATE secret-like authored error');
 return {open(target,...rest){record.opens.push([target,...rest]);if(fail==='open')return Promise.reject(Error('PRIVATE secret-like authored error'));return Promise.resolve();},
 close(){record.closes++;if(fail==='close')return Promise.reject(Error('PRIVATE secret-like authored error'));return Promise.resolve();},
 dispose(){record.disposals++;if(fail==='dispose')return Promise.reject(Error('PRIVATE secret-like authored error'));return Promise.resolve();}};
};
const createAnatomyExplorer=options=>{const e={options,setContext:id=>calls.push(['context',id]),setOrgans:organs=>calls.push(['organs',organs.length]),
 isolate:id=>calls.push(['isolate',id]),clearIsolation:()=>calls.push(['all']),clearClip:()=>calls.push(['clip-off']),
 setClip:(...args)=>calls.push(['clip',...args]),setLabels:v=>calls.push(['labels',v]),dispose:()=>calls.push(['dispose-geometry'])};explorers.push(e);return e;};
const context={mountMolecularInspector,AbortController,console,Promise,
 loadAnatomyDependencies:async()=>({THREE:{},GLTFLoader(){},OrbitControls(){},createAnatomyExplorer}),
 restoreAnatomyView:()=>{},setTimeout:()=>1,clearTimeout(){},
 fetch:async(url,options)=>{requests.push([url,options]);assert.equal(url,'/api/biology/reference');assert.equal(options.cache,'no-store');
 return {ok:true,json:async()=>reference};}};
vm.createContext(context);vm.runInContext(source,context);
const tick=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
const buttons=()=>nodes.get('[data-detail]').buttons;
let completed=false;process.on('beforeExit',()=>{if(!completed)process.exitCode=1;});
(async()=>{
const view=context.mountExecutionAnatomy(host,execution);await tick();
BODY
await view.dispose();await tick();completed=true;
})().catch(e=>{console.error(e.name,e.message);process.exitCode=1;});
""".replace("SOURCE", json.dumps(str(SOURCE))).replace("BODY", body)
    result = subprocess.run(
        [require_node(), "--eval", script],
        cwd=ROOT, capture_output=True, text=True, timeout=10, encoding="utf-8",
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_fixed_execution_targets_are_buttons_and_inspector_is_lazy():
    execution_consumer("""
assert.equal(mounts.length,0);assert.equal(buttons().length,3);
assert.deepEqual(buttons().map(b=>b.dataset.molecularTarget),reference.organs[0].targets);
assert(host.innerHTML.includes('data-molecular-inspector'));assert(host.innerHTML.includes('data-molecular-feedback'));
assert(nodes.get('[data-detail]').innerHTML.includes('type="button"'));
assert.equal(JSON.stringify(execution),original);assert.equal(requests.length,1);
""")


def test_each_exact_target_opens_without_active_state_or_experiment_request():
    execution_consumer("""
for(const b of buttons()){b.click();await tick();}
assert.equal(mounts.length,1);assert.deepEqual(mounts[0].opens,[['KRAS'],['AMPK'],['UNKNOWN_TARGET']]);
assert.equal(mounts[0].options.context.kind,'execution');assert.equal(mounts[0].options.context.mode,'EXECUTION_REFERENCE');
assert.deepEqual(JSON.parse(mounts[0].options.context.key),[execution.execution_id,execution.source_snapshot_hash,execution.selection.twin_id]);
assert.equal(requests.length,1);assert.equal(JSON.stringify(execution),original);
""")


def test_identity_is_captured_before_caller_object_changes():
    execution_consumer("""
execution.execution_id='c'.repeat(32);execution.source_snapshot_hash='d'.repeat(64);execution.selection.twin_id='other';
buttons()[0].click();await tick();const old=JSON.parse(original);
assert.deepEqual(JSON.parse(mounts[0].options.context.key),[old.execution_id,old.source_snapshot_hash,old.selection.twin_id]);
""")


@pytest.mark.parametrize("source", ["select", "geometry"])
def test_organ_switch_closes_old_reference_and_keeps_execution_identity(source):
    change = ("nodes.get('[data-organ]').handlers.change({target:{value:'liver'}});" if source == "select"
              else "explorers[0].options.onSelect(reference.organs[1]);")
    execution_consumer("""
buttons()[0].click();await tick();const key=mounts[0].options.context.key;
""" + change + """
await tick();assert.equal(mounts[0].closes,1);assert.equal(buttons().length,1);
buttons()[0].click();await tick();assert.equal(mounts.length,1);assert.equal(mounts[0].options.context.key,key);
assert.deepEqual(mounts[0].opens,[['KRAS'],['NR1I2']]);
""")


def test_graphics_retry_preserves_molecule_and_other_anatomy_controls():
    execution_consumer("""
buttons()[0].click();await tick();await nodes.get('[data-retry]').click();await tick();
assert.equal(mounts.length,1);assert.equal(mounts[0].closes,0);assert.equal(mounts[0].disposals,0);
nodes.get('[data-section]').value='x';nodes.get('[data-section]').handlers.change();
nodes.get('[data-depth]').value='75';nodes.get('[data-depth]').handlers.input();
nodes.get('[data-labels]').checked=false;nodes.get('[data-labels]').handlers.change();nodes.get('[data-home]').click();
assert(calls.some(row=>JSON.stringify(row)==='["clip","x",0.75]'));assert(calls.some(row=>row[0]==='all'));
assert(calls.some(row=>row[0]==='labels'&&row[1]===false));assert.equal(requests.length,1);
""")


def test_disposal_is_once_only_and_old_target_handler_cannot_reopen():
    execution_consumer("""
const old=buttons()[0];old.click();await tick();await view.dispose();await view.dispose();old.click();await tick();
assert.equal(mounts[0].disposals,1);assert.equal(mounts[0].opens.length,1);
""")


@pytest.mark.parametrize("failure", ["mount", "open"])
def test_open_failure_is_visible_fixed_feedback_without_private_details(failure):
    execution_consumer(f"fail={json.dumps(failure)};" + """
buttons()[0].click();await tick();
const text=nodes.get('[data-molecular-feedback]').textContent;
assert(text.includes('Molecular reference'));assert(!text.includes('PRIVATE'));assert(!text.includes('secret-like'));
""")


def test_rejected_close_is_observed_and_does_not_report_success():
    execution_consumer("""
buttons()[0].click();await tick();fail='close';nodes.get('[data-organ]').handlers.change({target:{value:'liver'}});await tick();
assert(nodes.get('[data-molecular-feedback]').textContent.includes('cleanup is unconfirmed'));
assert(!nodes.get('[data-molecular-feedback]').textContent.includes('PRIVATE'));
""")


def test_rejected_disposal_is_observed_not_an_unhandled_rejection():
    execution_consumer("""
buttons()[0].click();await tick();fail='dispose';await view.dispose();await tick();
assert.equal(host.dataset.molecularCleanup,'unconfirmed');assert.equal(mounts[0].disposals,1);
""")


def test_empty_targets_do_not_create_a_substitute_or_a_plugin():
    execution_consumer("""
reference.organs[1].targets=[];nodes.get('[data-organ]').handlers.change({target:{value:'liver'}});await tick();
assert.equal(buttons().length,0);assert.equal(mounts.length,0);assert.equal(requests.length,1);
""")
