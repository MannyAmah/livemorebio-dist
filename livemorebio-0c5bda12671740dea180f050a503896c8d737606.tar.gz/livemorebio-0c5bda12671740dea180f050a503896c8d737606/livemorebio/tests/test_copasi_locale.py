"""COPASI's locale change cannot make the product, or its tests, read UTF-8 as ASCII.

Importing COPASI (through ``basico``, which ``livemore doctor`` imports) runs
``setlocale(LC_ALL, "C")``. Outside Python's UTF-8 mode, every later ``open()``
or text-mode pipe without an ``encoding=`` then decoded as ASCII: a whole-suite
run under ``env -i ... LANG=en_US.UTF-8`` failed 272 tests after the doctor's
test had run, and ``GET /research`` failed in the same process. The suite had
passed only because ``install.sh``, the image and the hosted gate run it in
UTF-8 mode.

Each case runs in a new interpreter with UTF-8 mode switched off, because
COPASI changes the locale only when it is first imported and this process may
have imported it already.
"""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
CENDOS_UI_TESTS = ("livemorebio/tests/test_cendos_compact_members.py",
                   "livemorebio/tests/test_cendos_preparation_ui.py")

# Start from a UTF-8 character-type locale whatever the host's environment says,
# so that what changes it afterwards is the only thing being observed.
_PRELUDE = """
import locale, sys
assert not sys.flags.utf8_mode, "UTF-8 mode would hide the locale's encoding"
for name in ("C.UTF-8", "en_US.UTF-8", "UTF-8"):
    try:
        locale.setlocale(locale.LC_CTYPE, name)
        break
    except locale.Error:
        continue
else:
    raise SystemExit("this host has no UTF-8 locale to start from")

def utf8(encoding):
    return encoding.replace("-", "").replace("_", "").lower() == "utf8"

assert utf8(locale.getpreferredencoding(False))
"""


def _python(program: str) -> subprocess.CompletedProcess:
    environment = {name: value for name, value in os.environ.items()
                   if name not in {"PYTHONUTF8", "PYTHONIOENCODING", "PYTHONWARNINGS"}}
    return subprocess.run([sys.executable, "-X", "utf8=0", "-c", _PRELUDE + program],
                          cwd=REPOSITORY_ROOT, env=environment, capture_output=True,
                          encoding="utf-8", timeout=600)


def test_importing_copasi_switches_the_process_to_the_c_locale():
    """The control: without the guard, the import makes the default encoding ASCII.

    If this fails, the pinned COPASI no longer changes the locale on import and
    ``livemorebio._locale`` can be retired.
    """
    result = _python("import COPASI\nprint(locale.getpreferredencoding(False))")
    assert result.returncode == 0, result.stderr
    encoding = result.stdout.strip()
    assert encoding and encoding.replace("-", "").lower() != "utf8", encoding


def test_the_doctor_imports_copasi_without_changing_the_text_encoding():
    result = _python("""
from livemorebio import doctor
record = doctor._module("basico")
assert record["ok"], record
# basico must really have loaded COPASI here, not deferred it to a later call.
assert "COPASI" in sys.modules
assert utf8(locale.getpreferredencoding(False)), locale.getpreferredencoding(False)
print("ok", locale.setlocale(locale.LC_NUMERIC))
""")
    assert result.returncode == 0, result.stdout + result.stderr
    # COPASI keeps the C locale it wants for numbers; only LC_CTYPE is put back.
    assert result.stdout.split() == ["ok", "C"]


def test_research_page_and_cendos_ui_reads_survive_a_c_locale_after_copasi(tmp_path):
    """After COPASI, with a default encoding that is not UTF-8, the reads still hold.

    COPASI sets the C locale again whenever it loads a ``.cps`` file, and a host
    may run with any locale, so the locale is set to C here on purpose. The
    research page carries non-ASCII text, which an ASCII decode refuses.
    """
    result = _python(f"""
from pathlib import Path
from livemorebio import doctor
assert doctor._module("basico")["ok"]
locale.setlocale(locale.LC_CTYPE, "C")
assert not utf8(locale.getpreferredencoding(False)), locale.getpreferredencoding(False)

from fastapi import FastAPI
from fastapi.testclient import TestClient
from livemorebio.aegle import research_api
app = FastAPI()
app.include_router(research_api.router)
response = TestClient(app, raise_server_exceptions=False).get("/research")
assert response.status_code == 200, response.status_code
page = (Path(research_api.__file__).parent / "console" / "research.html").read_bytes().decode("utf-8")
assert any(ord(character) > 127 for character in page), "the page must exercise a non-ASCII decode"
assert response.text == page

import pytest
sys.exit(pytest.main(["-q", "-p", "no:cacheprovider", "--basetemp", {str(tmp_path / "inner")!r},
                      *{CENDOS_UI_TESTS!r}]))
""")
    assert result.returncode == 0, result.stdout[-6000:] + result.stderr[-4000:]
