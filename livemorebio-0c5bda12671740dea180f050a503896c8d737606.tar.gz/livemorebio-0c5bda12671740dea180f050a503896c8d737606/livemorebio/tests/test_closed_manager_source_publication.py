"""Closed execution ownership must not prevent source bookkeeping.

All records, candidates and ownership handles here are authored Python values.
The real manager has no background thread, native adapter, database or OS lock.
"""
from copy import deepcopy
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401


OWNER_ID = "execution-authored-retained-owner"


def forbidden(*args, **kwargs):
    pytest.fail("Unexpected storage, adapter or model operation")


class NoIOStore:
    """Deterministic failed cleanup, followed only by explicit retry success."""

    def __init__(self, calls):
        self.calls = calls
        self.fail = True
        self.owner = object()  # Not a file descriptor or an OS ownership lock.

    def get(self, identifier):
        from livemorebio.aegle.execution_contract import ExecutionError
        assert identifier == OWNER_ID
        self.calls.append("store-get-failed" if self.fail else "store-get-retry")
        if self.fail:
            raise ExecutionError("EXECUTION_STORAGE")
        return {"state": "stopped", "revision": 1}

    def release_owner(self, owner):
        from livemorebio.aegle.execution_contract import ExecutionError
        assert owner is self.owner
        self.calls.append("release-failed" if self.fail else "release-retry")
        if self.fail:
            raise ExecutionError("EXECUTION_STORAGE")

    create = update = acquire_owner = forbidden


@pytest.fixture
def publication(client, monkeypatch):
    from livemorebio.aegle import execution_api, server
    from livemorebio.aegle.execution import DENY_ALL, ExecutionManager
    from livemorebio.aegle.execution_contract import ExecutionError
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState

    calls = []
    scenario = {"close_at": "before", "outcome": "COMMITTED"}
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=server._model_fence_guard)
    generation = authority.generation
    store = NoIOStore(calls)
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=generation)
    manager._owners[OWNER_ID] = store.owner
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    before = {"twin_id": "twin-authored-closed-publication", "subject_id": "not-a-participant",
        "source_class": "SYNTHETIC", "display_label": "Authored boundary fixture",
        "lifecycle": "ACTIVE", "version": 2, "selection_mode": "model"}
    after = {**before, "version": 3}

    def unlocked():
        assert not authority._lock._is_owned()
        assert not execution_api._creation_lock._is_owned()
        assert not manager._lock._is_owned()

    def failed_shutdown():
        unlocked()
        calls.append("shutdown")
        with pytest.raises(ExecutionError) as failure:
            execution_api.shutdown_execution_manager()
        assert failure.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
        assert server._execution_manager_instance is manager and manager._closed
        assert manager._owners == {OWNER_ID: store.owner}
        assert manager._cleanup_pending == {OWNER_ID}
        assert manager._adapters == {} and manager._closing == set()

    old_model = SimpleNamespace(state=lambda: {"profile": "AUTHORED_OLD", "profile_params": {}})

    def candidate_state():
        if server._state.get("tw") is candidate:
            # A committed GET snapshot deliberately owns the authority. Only
            # construction/projection before publication must be fully unlocked.
            assert authority._lock._is_owned()
            assert not execution_api._creation_lock._is_owned() and not manager._lock._is_owned()
        else:
            unlocked()
        calls.append("candidate-state")
        return {"profile": "AUTHORED_NEW", "profile_params": {}}

    candidate = SimpleNamespace(state=candidate_state)
    initial = {"tw": old_model, "subject": deepcopy(before), "initialized": True,
        "observation_state": ObservationState(),
        "model_availability": model_availability(before, source_generation=generation)}
    old_actions = [object()]
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", old_actions)
    prepared = SimpleNamespace(record=deepcopy(after), active_before=deepcopy(before))

    class Registry:
        def prepare_activation(self, identifier, *, expected_version, request_id):
            assert authority._lock._is_owned()
            assert not execution_api._creation_lock._is_owned() and not manager._lock._is_owned()
            assert identifier == before["twin_id"] and expected_version == 2
            UUID(request_id)
            calls.append("prepare")
            return prepared

        def build_twin(self, record):
            unlocked()
            assert record == after
            calls.append("build")
            if scenario["close_at"] == "build":
                failed_shutdown()
            return candidate

        def commit_prepared_transition(self, value):
            assert value is prepared
            assert authority._lock._is_owned() and execution_api._creation_lock._is_owned()
            assert manager._lock._is_owned()
            assert server._state is initial and authority.generation == generation
            calls.append("commit:" + scenario["outcome"])
            return scenario["outcome"]

    original_assignment = manager.set_source_generation

    def assign(value):
        assert authority._lock._is_owned() and execution_api._creation_lock._is_owned()
        assert manager._lock._is_owned() and manager._closed
        calls.append("fence-deny" if value is DENY_ALL else "fence-new")
        original_assignment(value)

    original_invalidate = manager.invalidate_source

    def invalidate(value, reason):
        unlocked()
        assert not server._initialization_lock._is_owned()
        assert value == generation and authority.permitted_generation is manager._permitted_generation
        assert authority.permitted_generation != generation
        assert server._state["initialized"] is True
        calls.append("invalidate")
        return original_invalidate(value, reason)

    def publish(*args, **kwargs):
        unlocked()
        calls.append("publish")

    monkeypatch.setattr(manager, "set_source_generation", assign)
    monkeypatch.setattr(manager, "invalidate_source", invalidate)
    monkeypatch.setattr(server, "_snapshot_twin", publish)
    registry = Registry()
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    yield SimpleNamespace(server=server, api=execution_api, authority=authority, manager=manager,
        store=store, calls=calls, scenario=scenario, before=before, after=after, registry=registry,
        candidate=candidate, initial=initial, old_actions=old_actions, generation=generation,
        failed_shutdown=failed_shutdown, client=client, unlocked=unlocked)
    client.close()


@pytest.mark.parametrize("close_at", ["before", "build"])
@pytest.mark.parametrize("outcome", ["COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED", "UNCONFIRMED"])
def test_closed_shutdown_cannot_leave_old_identity_after_activation(publication, close_at, outcome):
    from livemorebio.aegle.execution import DENY_ALL
    t = publication
    t.scenario.update(close_at=close_at, outcome=outcome)
    if close_at == "before":
        t.failed_shutdown()
    response = t.client.post(f"/api/twins/{t.before['twin_id']}/activate", json={"expected_version": 2})
    uncertain = outcome == "UNCONFIRMED"
    # A retained closed executor cannot complete invalidation; its cleanup 503
    # must not erase an acknowledged registry commit or expose the old source.
    expected_code = "SELECTION_COMMIT_UNCONFIRMED" if uncertain else "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
    assert response.status_code == 503 and response.json()["code"] == expected_code
    UUID(response.headers["X-Request-ID"])
    assert response.headers["Cache-Control"] == "no-store"
    assert t.server._state is not t.initial and t.server._state["tw"] is t.candidate
    assert t.server._state["subject"] == t.server._subject_summary(t.after)
    assert t.server._state["observation_state"] is not t.initial["observation_state"]
    assert t.server._workspace_actions == [] and t.server._workspace_actions is not t.old_actions
    assert t.authority.permitted_generation is t.manager._permitted_generation
    if uncertain:
        assert t.authority.permitted_generation is DENY_ALL
    else:
        assert t.authority.generation != t.generation
        assert t.server._state["model_availability"]["state"] == "READY"
        assert t.server._state["model_availability"]["source_generation"] == t.authority.generation
    closure = ["shutdown", "store-get-failed", "release-failed"]
    expected = closure + ["prepare", "build"] if close_at == "before" else ["prepare", "build"] + closure
    expected += ["candidate-state", "commit:" + outcome, "fence-deny" if uncertain else "fence-new", "invalidate"]
    assert t.calls == expected + ([] if uncertain else ["publish"])
    state = t.client.get("/api/state")
    assert state.status_code == (503 if uncertain else 200)
    assert state.json().get("profile") != "AUTHORED_OLD"
    if uncertain:
        assert state.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    else:
        assert state.json()["profile"] == "AUTHORED_NEW"
    assert t.manager._closed and t.server._execution_manager_instance is t.manager
    assert t.manager._owners == {OWNER_ID: t.store.owner}
    assert t.manager._cleanup_pending == {OWNER_ID} and t.manager._adapters == {}
    # Neither publication nor the failed post-commit invalidation retries owner
    # cleanup. Only this second explicit shutdown is permitted to release it.
    permitted = t.authority.permitted_generation
    t.store.fail = False
    t.api.shutdown_execution_manager()
    assert t.calls[-2:] == ["store-get-retry", "release-retry"]
    assert t.server._execution_manager_instance is None and t.manager._closed
    assert t.manager._owners == {} and t.manager._cleanup_pending == set()
    assert t.authority.permitted_generation is permitted


@pytest.mark.parametrize("deny", [False, True])
def test_closed_fence_assignment_is_no_io_without_reopening_or_releasing(deny):
    from livemorebio.aegle.execution import DENY_ALL, ExecutionManager
    store = SimpleNamespace(**{name: forbidden for name in ("get", "update", "create", "acquire_owner", "release_owner")})
    manager = ExecutionManager(store, adapter_registry={}, run_background=False, permitted_generation="old")
    manager.close()
    owner = object()
    adapter = SimpleNamespace(close=forbidden, initialize=forbidden, advance=forbidden)
    manager._owners[OWNER_ID] = owner
    manager._adapters[OWNER_ID] = adapter
    manager._cleanup_pending.add(OWNER_ID)
    manager._next_due[OWNER_ID] = 1.0
    owners, adapters, pending, deadlines = manager._owners, manager._adapters, manager._cleanup_pending, manager._next_due
    value = DENY_ALL if deny else "new"
    manager.set_source_generation(value)
    assert manager._permitted_generation is value and manager._closed
    assert manager._owners is owners and owners == {OWNER_ID: owner}
    assert manager._adapters is adapters and adapters == {OWNER_ID: adapter}
    assert manager._cleanup_pending is pending and pending == {OWNER_ID}
    assert manager._next_due is deadlines and deadlines == {}
    assert manager._thread is manager._lease_thread is None


@pytest.mark.parametrize("invalid", [None, True, False, 1, "", " ", [], {}])
def test_closed_invalid_fence_keeps_identity_and_deadlines(invalid):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_contract import ExecutionError
    manager = ExecutionManager(SimpleNamespace(), adapter_registry={}, run_background=False, permitted_generation="old")
    manager.close()
    manager._next_due[OWNER_ID] = 1.0
    with pytest.raises(ExecutionError) as failure:
        manager.set_source_generation(invalid)
    assert failure.value.code == "EXECUTION_INVALID"
    assert manager._permitted_generation == "old" and manager._closed
    assert manager._next_due == {OWNER_ID: 1.0}


@pytest.mark.parametrize("operation", ["prepare", "fork", "start", "resume", "bind", "renew", "advance"])
def test_closed_producers_remain_refused_at_their_existing_read_boundary(operation):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_contract import (
        CARDIAC, CARDIAC_INITIAL, ExecutionError, checkpoint, seal_source,
    )
    reads = []

    def get(identifier):
        reads.append(identifier)
        return {}  # _check must reject closed before consuming record fields.

    store = SimpleNamespace(get=get, create=forbidden, update=forbidden,
                            acquire_owner=forbidden, release_owner=forbidden)
    manager = ExecutionManager(store, adapter_registry={}, run_background=False, permitted_generation="old")
    manager.close()
    # A fixed data-only valid envelope reaches prepare's open check without any
    # model/file capture. No adapter may use this authored identity or vector.
    source = {"schema": "livemore.execution-source.v1", "source_generation": "old",
        "selection": {"subject_id": "authored", "twin_id": "authored", "twin_version": 1,
            "cohort_id": None, "member_id": None, "run_id": None, "condition_id": "baseline",
            "stage": "cardiac", "source_data_class": "SYNTHETIC"},
        "engine_contract_id": CARDIAC, "model_identity": {"technical_fixture": True},
        "parameters": {"ikr_block": 0.0}, "parameter_provenance": {},
        "schedule": {"period_ms": 1000.0, "pulse_ms": 0.5, "offset_ms": 50.0},
        "native_axis": {"unit": "ms", "maximum": 1_800_000.0}}
    source["initialization"] = {"method": "pinned_cellml_then_reference_pacing", "prepace_cycles": 5,
                                "checkpoint": checkpoint(source, 0.0, CARDIAC_INITIAL)}
    source = seal_source(source)
    policy = {"end_native": 1000.0, "frame_period_s": 1.0, "time_scale": 1.0}
    control = {"expected_revision": 1, "expected_source_generation": "old"}
    operations = {
        "prepare": lambda: manager.prepare(source, policy, "authored-closed"),
        "fork": lambda: manager.fork_checkpoint(OWNER_ID, source, policy=policy,
            idempotency_key="authored-closed", expected_parent_revision=1),
        "start": lambda: manager.start(OWNER_ID, **control),
        "resume": lambda: manager.resume(OWNER_ID, **control),
        "bind": lambda: manager.bind_consumer(OWNER_ID, "a" * 32, "b" * 64, **control),
        "renew": lambda: manager.renew_consumer(OWNER_ID, "a" * 32, "b" * 64,
                                                 expected_source_generation="old"),
        "advance": lambda: manager.advance_once(OWNER_ID),
    }
    with pytest.raises(ExecutionError) as failure:
        operations[operation]()
    assert failure.value.code == "EXECUTION_CLOSED"
    assert reads == ([OWNER_ID] if operation in {"start", "resume", "bind"} else [])
    assert manager._closed and manager._permitted_generation == "old"
    assert manager._owners == manager._adapters == manager._next_due == {}


@pytest.mark.parametrize("close_at,fail_at", [("before", "read"), ("before", "confirm"), ("build", "confirm")])
def test_closed_manager_startup_uncertainty_denies_source_without_fatal_static_failure(publication, monkeypatch, close_at, fail_at):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.model_source import SourceSelectionUnconfirmed
    from livemorebio.aegle.subjects import SubjectRegistryError
    t = publication
    t.initial["initialized"] = False
    captured = SimpleNamespace(record=deepcopy(t.before))
    t.scenario["close_at"] = close_at

    def read(*, action, request_id, _checked_snapshot):
        assert t.authority._lock._is_owned()
        assert not t.api._creation_lock._is_owned() and not t.manager._lock._is_owned()
        assert action == "inspect" and _checked_snapshot is True
        UUID(request_id)
        t.calls.append("read")
        if fail_at == "read":
            raise SubjectRegistryError("REGISTRY_STORAGE_UNAVAILABLE", "Authored checked read failed")
        return captured

    def build(record):
        t.unlocked()
        assert record == captured.record
        t.calls.append("build")
        if close_at == "build":
            t.failed_shutdown()
        return t.candidate

    def confirm(*, expected_record, request_id, _expected_snapshot):
        assert t.authority._lock._is_owned() and t.api._creation_lock._is_owned()
        assert t.manager._lock._is_owned()
        assert expected_record == captured.record and _expected_snapshot is captured
        UUID(request_id)
        t.calls.append("confirm")
        raise SubjectRegistryError("REGISTRY_STORAGE_UNAVAILABLE", "Authored checked confirmation failed")

    monkeypatch.setattr(t.registry, "active_twin", forbidden, raising=False)
    monkeypatch.setattr(t.registry, "audited_active_twin", read, raising=False)
    monkeypatch.setattr(t.registry, "confirm_active_selection", confirm, raising=False)
    monkeypatch.setattr(t.registry, "build_twin", build)
    if close_at == "before":
        t.failed_shutdown()
    t.server._ensure_selected_state()
    assert t.server._state["initialized"] is True
    assert t.authority.permitted_generation is DENY_ALL and t.manager._permitted_generation is DENY_ALL
    assert t.server._execution_manager_instance is t.manager and t.manager._closed
    assert t.manager._owners == {OWNER_ID: t.store.owner} and t.manager._adapters == {}
    assert t.manager._cleanup_pending == {OWNER_ID}
    closure = ["shutdown", "store-get-failed", "release-failed"]
    expected = closure + ["read"] if close_at == "before" else ["read", "build"] + closure
    if fail_at == "confirm":
        expected += (["build"] if close_at == "before" else []) + ["candidate-state", "confirm"]
    assert t.calls == expected + ["fence-deny", "invalidate"]
    assert t.client.get("/").status_code == 200
    for path in ("/api/state", "/api/cendos/current-source"):
        response = t.client.get(path)
        assert response.status_code == 503 and response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        assert "AUTHORED_OLD" not in response.text
    response = t.client.post("/api/workspace/actions", json={})
    assert response.status_code == 503 and response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    with pytest.raises(SourceSelectionUnconfirmed):
        t.authority.capture(forbidden)
    before_repeat = list(t.calls)
    t.server._ensure_selected_state()
    assert t.calls == before_repeat and "publish" not in t.calls
    assert t.manager._owners == {OWNER_ID: t.store.owner}
    t.store.fail = False
    t.api.shutdown_execution_manager()
    assert t.calls[-2:] == ["store-get-retry", "release-retry"]
    assert t.server._execution_manager_instance is None and t.manager._closed
    assert t.manager._owners == {} and t.manager._cleanup_pending == set()
    assert t.authority.permitted_generation is DENY_ALL
