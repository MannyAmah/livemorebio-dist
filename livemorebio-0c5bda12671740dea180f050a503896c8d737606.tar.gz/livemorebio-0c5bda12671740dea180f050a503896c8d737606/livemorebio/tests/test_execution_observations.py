"""Real numerical worker delivery checks; not physical/clinical validation."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_execution_api import product, prepare, control, HEADERS


@pytest.fixture
def continuous(product, monkeypatch):
    from livemorebio.aegle.execution import ExecutionManager
    product.manager.close()
    product.manager = ExecutionManager(product.manager.store, run_background=False)
    product.authority._invalidate = product.manager.invalidate_source
    monkeypatch.setattr(product.api, "_manager", lambda: product.manager)
    product.twin.observations = {"glucose_mgdl": {"value": 104., "provenance": "calibrated", "mode": "physical"}}
    product.twin.patch = {"connected": True, "mode": "physical"}
    product.twin.applied = ["existing entry"]
    product.twin.execution_observations = {}
    product.record["subject_id"] = "pseudonym-technical"
    product.record["patch_bindings"] = [{"device_id": "v3-technical", "mode": "virtual", "protocol_version": "3.0"}]
    from livemorebio.aegle import server
    server._state["subject"]["subject_id"] = product.record["subject_id"]
    prepared = prepare(product)
    prepared = product.manager.bind_consumer(prepared["execution_id"], "a" * 32, prepared["source_snapshot_hash"],
        expected_revision=prepared["revision"], expected_source_generation=prepared["source_generation"])
    assert control(product, prepared, "start").status_code == 200
    product.frame = product.manager.advance_once(prepared["execution_id"])
    yield product
    product.manager.close()


def delivery(frame):
    from livemorebio.life_patch.protocol_v3 import ManifestV3, TelemetryEnvelopeV3
    from livemorebio.security import sign_patch_admission
    from livemorebio.tests.test_patch_protocol_v3 import manifest_payload, envelope_payload
    raw_manifest = manifest_payload()
    raw_manifest["capabilities"] = [{"signal": "glucose_mgdl", "unit": "mg/dL", "channel": "chem",
                                     "provenance": "modeled", "cartridge_id": None}]
    manifest = ManifestV3(raw_manifest)
    raw = envelope_payload()
    timestamp = (datetime.fromisoformat(frame["generated_at"].replace("Z", "+00:00")) + timedelta(milliseconds=1)).isoformat()
    raw.update(subject_id=frame["selection"]["subject_id"], manifest_hash=manifest.capability_hash,
               envelope_id=f"virtual-{'a'*32}-{frame['frame_index']}", sequence=frame["frame_index"],
               captured_at=timestamp, acquisition_start=timestamp, acquisition_end=timestamp)
    acquired = frame["generated_monotonic_s"] + .001
    raw["clock"].update(session_id="a"*32, monotonic_start_s=acquired, monotonic_end_s=acquired)
    value = next(row["values"][-1] for row in frame["series"] if row["quantity"] == "glucose_mgdl")
    raw["measurements"] = [{"measurement_id": f"glucose-{frame['frame_index']}", "signal": "glucose_mgdl",
        "unit": "mg/dL", "provenance": "modeled", "kind": "scalar", "value": value,
        "quality_status": "pass", "calibration_status": "not_applicable", "quality_flags": [],
        "context": {"endpoint": "glucose_mgdl", "biofluid": "plasma", "compartment": "plasma", "site": None,
                    "assay_id": None, "cartridge_id": None, "calibration_id": None,
                    "derivation_id": "metabolic-plasma-glucose-identity-v1"},
        "model_context": {"prediction_id": f"execution-{frame['execution_id']}-frame-{frame['frame_index']}",
                          "condition_id": frame["selection"]["condition_id"], "model_time_min": frame["native_end"],
                          "model_id": "metabolic-continuous-v1", "mapping_id": "metabolic-plasma-glucose-identity-v1"}}]
    envelope = TelemetryEnvelopeV3(raw)
    admission = {"admission": "accepted", "admitted_at": timestamp, "received_at": timestamp,
                 "device_id": envelope.device_id, "mode": "virtual", "envelope_hash": envelope.envelope_hash,
                 "capability_hash": manifest.capability_hash, "manifest_hash": manifest.capability_hash}
    return {"envelope": envelope.to_dict(), "manifest": manifest.to_dict(), "admission": admission,
            "admission_signature": sign_patch_admission(admission)}


def admit(product, body, *, now=None):
    from livemorebio.aegle.execution_observations import admit_execution_observation
    selection = deepcopy(product.frame["selection"])
    with product.authority.observation():
        return admit_execution_observation(product.manager, product.twin, selection, product.authority.generation,
            [{"device_id": "v3-technical", "mode": "virtual", "protocol_version": "3.0"}], body,
            now=now or datetime.now(timezone.utc) + timedelta(seconds=1))


def test_exact_delivery_retry_does_not_replace_physical_or_model_state(continuous):
    value = delivery(continuous.frame)
    before = deepcopy(vars(continuous.twin))
    first = admit(continuous, value)
    assert first["admission"] == "accepted" and first["projection"] == "applied"
    assert admit(continuous, value) == first
    for key in ("observations", "patch", "profile", "applied", "meals"):
        assert vars(continuous.twin)[key] == before[key]
    assert len(continuous.twin.execution_observations) == 1


@pytest.mark.parametrize("sequence", [0, 18])
def test_device_sequence_is_independent_of_numerical_frame_index(continuous, sequence):
    from livemorebio.life_patch.protocol_v3 import TelemetryEnvelopeV3
    from livemorebio.security import sign_patch_admission
    body = delivery(continuous.frame)
    body["envelope"].pop("envelope_hash")
    body["envelope"]["sequence"] = sequence
    body["envelope"] = TelemetryEnvelopeV3(body["envelope"]).to_dict()
    body["admission"]["envelope_hash"] = body["envelope"]["envelope_hash"]
    body["admission_signature"] = sign_patch_admission(body["admission"])
    response = admit(continuous, body)
    assert response["received_frame_index"] == continuous.frame["frame_index"] == 1
    assert response["projection"] == "applied"


@pytest.mark.parametrize("age", [-.001, 30.001])
def test_wall_clock_cannot_hide_stale_or_future_monotonic_source(continuous, age):
    from livemorebio.life_patch.protocol_v3 import TelemetryEnvelopeV3
    from livemorebio.security import sign_patch_admission
    body = delivery(continuous.frame)
    body["envelope"].pop("envelope_hash")
    acquired = continuous.frame["generated_monotonic_s"] + age
    body["envelope"]["clock"].update(monotonic_start_s=acquired, monotonic_end_s=acquired)
    body["envelope"] = TelemetryEnvelopeV3(body["envelope"]).to_dict()
    body["admission"]["envelope_hash"] = body["envelope"]["envelope_hash"]
    body["admission_signature"] = sign_patch_admission(body["admission"])
    with pytest.raises(ValueError):
        admit(continuous, body)


@pytest.mark.parametrize("field,value", [("value", 99.), ("provenance", "technical_fixture"),
    ("model_context.condition_id", "wrong-condition"), ("model_context.model_time_min", 500.),
    ("context.compartment", "interstitial_fluid"), ("context.site", "chest")])
def test_signed_but_wrong_mapping_cannot_project(continuous, field, value):
    from livemorebio.life_patch.protocol_v3 import TelemetryEnvelopeV3
    from livemorebio.security import sign_patch_admission
    body = delivery(continuous.frame)
    row = body["envelope"]["measurements"][0]
    keys = field.split(".")
    (row if len(keys) == 1 else row[keys[0]])[keys[-1]] = value
    body["envelope"].pop("envelope_hash")
    body["envelope"] = TelemetryEnvelopeV3(body["envelope"]).to_dict()
    body["admission"]["envelope_hash"] = body["envelope"]["envelope_hash"]
    body["admission_signature"] = sign_patch_admission(body["admission"])
    with pytest.raises(ValueError):
        admit(continuous, body)
    assert continuous.twin.execution_observations == {}


def test_receipt_survives_projection_failure_and_exact_retry(continuous, monkeypatch):
    from livemorebio.aegle import execution_observations as module
    from livemorebio.aegle.execution_receipts import ExecutionReceiptLedger
    value = delivery(continuous.frame)
    original = module.project_receipt
    monkeypatch.setattr(module, "project_receipt", lambda *args: (_ for _ in ()).throw(RuntimeError("test projection failure")))
    with pytest.raises(RuntimeError):
        admit(continuous, value)
    stored = ExecutionReceiptLedger(continuous.manager.store).get(value["envelope"]["envelope_id"])
    assert stored is not None
    assert continuous.twin.execution_observations == {}
    monkeypatch.setattr(module, "project_receipt", original)
    assert admit(continuous, value)["projection"] == "applied"


def test_newer_frame_survives_older_exact_retry(continuous):
    first = delivery(continuous.frame)
    admit(continuous, first)
    second_frame = continuous.manager.advance_once(continuous.frame["execution_id"])
    second = delivery(second_frame)
    admit(continuous, second)
    result = admit(continuous, first)
    assert result["projected_frame_index"] == second_frame["frame_index"]


def test_source_replacement_cannot_project_existing_receipt(continuous):
    value = delivery(continuous.frame)
    admit(continuous, value)
    with continuous.authority.mutation("test-source-change"):
        pass
    with pytest.raises(ValueError):
        admit(continuous, value)


def test_storage_failure_does_not_project_or_replace_physical_values(continuous, monkeypatch):
    from livemorebio.aegle.execution_receipts import ExecutionReceiptLedger
    from livemorebio.aegle.execution_contract import ExecutionError
    def fail(*args):
        raise ExecutionError("EXECUTION_STORAGE")
    monkeypatch.setattr(ExecutionReceiptLedger, "admit", fail)
    with pytest.raises(ValueError):
        admit(continuous, delivery(continuous.frame))
    assert continuous.twin.execution_observations == {}
    assert continuous.twin.observations["glucose_mgdl"]["value"] == 104.


def test_first_forward_lost_then_paused_allows_exact_original_delivery(continuous):
    value = delivery(continuous.frame)
    state = continuous.manager.status(continuous.frame["execution_id"])
    assert control(continuous, state, "pause").status_code == 200
    assert admit(continuous, value)["projection"] == "applied"
    assert continuous.manager.status(state["execution_id"])["state"] == "paused"


def test_technical_worker_cannot_claim_engine_measurement(product):
    from livemorebio.aegle.execution_observations import admit_execution_observation
    from livemorebio.aegle import server
    product.record["subject_id"] = "pseudonym-technical"
    server._state["subject"]["subject_id"] = product.record["subject_id"]
    prepared = prepare(product)
    prepared = product.manager.bind_consumer(prepared["execution_id"], "a" * 32, prepared["source_snapshot_hash"],
        expected_revision=prepared["revision"], expected_source_generation=prepared["source_generation"])
    assert control(product, prepared, "start").status_code == 200
    product.frame = product.manager.advance_once(prepared["execution_id"])
    with pytest.raises(ValueError):
        admit(product, delivery(product.frame))


def test_acquisition_cannot_be_restamped_outside_frame_age_budget(continuous):
    from livemorebio.life_patch.protocol_v3 import TelemetryEnvelopeV3
    from livemorebio.security import sign_patch_admission
    value = delivery(continuous.frame)
    future = (datetime.fromisoformat(continuous.frame["generated_at"].replace("Z", "+00:00")) + timedelta(seconds=31)).isoformat()
    value["envelope"].pop("envelope_hash")
    value["envelope"].update(captured_at=future, acquisition_start=future, acquisition_end=future)
    value["envelope"] = TelemetryEnvelopeV3(value["envelope"]).to_dict()
    value["admission"].update(envelope_hash=value["envelope"]["envelope_hash"], received_at=future, admitted_at=future)
    value["admission_signature"] = sign_patch_admission(value["admission"])
    with pytest.raises(ValueError):
        admit(continuous, value, now=datetime.fromisoformat(future) + timedelta(seconds=1))


@pytest.mark.parametrize("age,accepted", [(30., True), (30.000001, False), (-.000001, False)])
def test_source_age_budget_boundaries_are_independent_of_future_clock(continuous, age, accepted):
    from livemorebio.life_patch.protocol_v3 import TelemetryEnvelopeV3
    from livemorebio.security import sign_patch_admission
    value = delivery(continuous.frame)
    generated = datetime.fromisoformat(continuous.frame["generated_at"].replace("Z", "+00:00"))
    timestamp = (generated + timedelta(seconds=age)).isoformat()
    value["envelope"].pop("envelope_hash")
    value["envelope"].update(captured_at=timestamp, acquisition_start=timestamp, acquisition_end=timestamp)
    value["envelope"] = TelemetryEnvelopeV3(value["envelope"]).to_dict()
    value["admission"].update(envelope_hash=value["envelope"]["envelope_hash"], received_at=timestamp, admitted_at=timestamp)
    value["admission_signature"] = sign_patch_admission(value["admission"])
    if accepted:
        assert admit(continuous, value, now=generated + timedelta(seconds=32))["projection"] == "applied"
    else:
        with pytest.raises(ValueError):
            admit(continuous, value, now=generated + timedelta(seconds=32))


def test_projection_keys_different_executions_and_preserves_retired_source(continuous, monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution_observations import project_receipt
    from livemorebio.aegle.execution_receipts import ExecutionReceiptLedger
    value = delivery(continuous.frame)
    admit(continuous, value)
    receipt = ExecutionReceiptLedger(continuous.manager.store).get(value["envelope"]["envelope_id"])
    # Projection-only technical identity test; not an additional admitted measurement.
    project_receipt(continuous.twin, receipt | {"execution_id": "b" * 32, "frame_index": 50})
    assert len(continuous.twin.execution_observations) == 2
    before = deepcopy(vars(continuous.twin))
    execution_id = continuous.frame["execution_id"]
    frames = continuous.manager.frames(execution_id)["frames"]
    monkeypatch.setattr(server, "_execution_manager_instance", continuous.manager)
    server._invalidate_model_source(continuous.authority.generation, "test-change")
    assert vars(continuous.twin) == before
    assert ExecutionReceiptLedger(continuous.manager.store).get(value["envelope"]["envelope_id"]) == receipt
    retired = continuous.manager.status(execution_id)
    assert retired["source_valid"] is False and retired["state"] == "paused"
    assert retired["failure_code"] == "MODEL_SOURCE_CHANGED"
    assert continuous.manager.advance_once(execution_id) is None
    assert control(continuous, retired, "start").status_code == 409
    assert continuous.manager.frames(execution_id)["frames"] == frames


def test_actual_numerical_frame_signed_delivery_round_trip_over_http(continuous):
    body = delivery(continuous.frame)
    first = continuous.client.post("/api/execution-observations", json=body, headers=HEADERS)
    assert first.status_code == 200, first.text
    again = continuous.client.post("/api/execution-observations", json=body, headers=HEADERS)
    assert again.status_code == 200 and again.json() == first.json()
    response = continuous.client.get(f"/api/executions/{continuous.frame['execution_id']}/observations", headers=HEADERS)
    assert response.status_code == 200
    stream = response.json()["streams"][0]
    assert stream["frame_hash"] == continuous.frame["frame_hash"]
    assert stream["observations"]["glucose_mgdl"]["envelope_hash"] == body["envelope"]["envelope_hash"]
    invalid = deepcopy(body)
    invalid["admission_signature"] = "é" * 64
    rejected = continuous.client.post("/api/execution-observations", json=invalid, headers=HEADERS)
    assert rejected.status_code == 422
    assert continuous.twin.observations["glucose_mgdl"]["value"] == 104.


def test_unbound_virtual_device_names_the_missing_prerequisite(continuous):
    """An unbound probe is an operator prerequisite, not an unspecified input error."""
    from livemorebio.aegle.execution_observations import admit_execution_observation
    from livemorebio.aegle.execution_contract import ExecutionError

    selection = deepcopy(continuous.frame["selection"])
    with continuous.authority.observation():
        with pytest.raises(ExecutionError) as caught:
            admit_execution_observation(continuous.manager, continuous.twin, selection,
                continuous.authority.generation, [], delivery(continuous.frame),
                now=datetime.now(timezone.utc) + timedelta(seconds=1))
    assert caught.value.code == "PATCH_BINDING_REQUIRED"
    assert "bound" in str(caught.value).lower()
