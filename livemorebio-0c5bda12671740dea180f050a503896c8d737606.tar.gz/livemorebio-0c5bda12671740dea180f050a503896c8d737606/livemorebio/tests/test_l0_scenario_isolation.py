"""Technical reference twins only: HTTP scenarios never alter selected state."""
from __future__ import annotations

import hashlib
import json

from fastapi.testclient import TestClient
import pytest

from livemorebio.aegle import server
from livemorebio.aegle.model_source import ModelSourceAuthority
from livemorebio.aegle.observation_state import ObservationState
from livemorebio.aegle.runtime import AegleTwin


ROUTES = ("/api/stimulate", "/api/workspace/actions")


def live_hash(twin: AegleTwin) -> str:
    """Include the mutable native model, not only its displayed output arrays."""
    content = {"state": twin.state(), "native_model": twin.heart._m.code() if twin.heart else None,
               "meals": twin.meals, "initial_profile": twin._initial_profile_values}
    return hashlib.sha256(json.dumps(content, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()


@pytest.fixture
def technical_selection(monkeypatch, request):
    # L0-R2: only the cardiac parameter requires the pinned numerical asset.
    if getattr(request.node, "callspec", None) and request.node.callspec.params.get("kind") == "cardiac_drug":
        request.getfixturevalue("pinned_cardiac_asset")
    twin = AegleTwin("healthy")
    authority = ModelSourceAuthority()
    publications = []
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-l0-scenario-token")
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_workspace_actions", [])
    monkeypatch.setattr(server, "_state", {"tw": twin, "subject": None, "initialized": True,
                                          "observation_state": ObservationState()})
    monkeypatch.setattr(server, "_snapshot_twin", lambda *args: publications.append(args))
    client = TestClient(server.app, raise_server_exceptions=False,
                        headers={"Authorization": "Bearer technical-l0-scenario-token"})
    return twin, authority, publications, client


@pytest.mark.parametrize("route", ROUTES)
@pytest.mark.parametrize("kind,params", [
    ("meal", {"grams": 25, "minute": 0}),
    ("cardiac_drug", {"ikr_block": 0.5}),
    ("metabolic_drug", {"name": "metformin", "dose": 1.0}),
])
def test_scenario_changes_its_result_but_not_the_live_twin(technical_selection, route, kind, params):
    twin, authority, publications, client = technical_selection
    before, generation = live_hash(twin), authority.generation
    original = twin.state()

    response = client.post(route, json={"kind": kind, "params": params})

    assert response.status_code == 200, response.text
    assert server._state["tw"] is twin
    assert live_hash(twin) == before
    assert authority.generation == generation
    assert publications == []
    payload = response.json()
    assert payload["scenario"] == {"code": "ISOLATED_SCENARIO", "source_generation": generation,
                                   "live_twin_unchanged": True}
    result = payload["workspace"]["twin"] if route.endswith("actions") else payload
    assert result["applied"] != original["applied"]
    if kind == "cardiac_drug":
        assert result["cardiac"]["apd90_ms"] > original["cardiac"]["apd90_ms"]
    else:
        assert result["metabolic"]["glucose"] != original["metabolic"]["glucose"]


@pytest.mark.parametrize("route", ROUTES)
def test_missing_cardiac_asset_is_typed_http_refusal(technical_selection, monkeypatch, tmp_path, route):
    from livemorebio import model_assets

    _, authority, publications, client = technical_selection
    monkeypatch.setattr(model_assets, "_cardiac_path",
                        lambda: tmp_path / "technical-models" / "cardiac" / "missing.cellml")
    twin = AegleTwin("healthy")
    server._state["tw"] = twin
    before, generation = live_hash(twin), authority.generation

    response = client.post(route, json={"kind": "cardiac_drug", "params": {"ikr_block": 0.5}})

    assert response.status_code == 422, response.text
    assert response.json()["code"] == "CARDIAC_MODEL_NOT_INSTALLED"
    assert live_hash(twin) == before
    assert authority.generation == generation
    assert publications == []


@pytest.mark.parametrize("route", ROUTES)
def test_partial_scenario_failure_preserves_live_state_and_generation(technical_selection, monkeypatch, route, pinned_cardiac_asset):
    twin, authority, publications, client = technical_selection
    before, generation = live_hash(twin), authority.generation

    def technical_failure(self):
        self.heart._m.get("IKr.ikr_scale").set_rhs(0.2)
        self.observations["technical_marker"] = {"data_class": "technical_fixture", "value": 999}
        raise ValueError("technical scenario solver failure")

    monkeypatch.setattr(AegleTwin, "_recompute", technical_failure)
    response = client.post(route, json={"kind": "meal", "params": {"grams": 25}})

    assert response.status_code == 422, response.text
    assert response.json()["code"]
    assert server._state["tw"] is twin
    assert live_hash(twin) == before
    assert authority.generation == generation
    assert publications == []
