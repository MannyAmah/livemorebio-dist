"""Technical fixtures only: request failures must never disclose person-shaped input."""
from __future__ import annotations

import base64
from contextlib import contextmanager
import http.client
import io
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[2]
TECHNICAL_NAME = "TECHNICAL Jane Q Testperson"
TECHNICAL_MRN = "TECHNICAL-MRN-778812"
TECHNICAL_BIOMARKER = "TECHNICAL HbA1c 9.4% glucose 212 mg/dL"
TECHNICAL_VALUE = f"{TECHNICAL_NAME} {TECHNICAL_MRN} {TECHNICAL_BIOMARKER}"
TECHNICAL_TOKEN = "technical-error-regression-operator-not-real"
SERVICES = {
    "aegle": "livemorebio.aegle.server",
    "life": "livemorebio.life_system.service",
    "cendos": "livemorebio.cendos.service",
}
_CHILD = '''
import asyncio, importlib, json, sys
import uvicorn
from fastapi import Request
from uvicorn.protocols.http.h11_impl import H11Protocol
from uvicorn.server import ServerState
module = importlib.import_module(sys.argv[1])
app = module.app
@app.post("/technical-error/{record_id}")
async def technical_error(record_id: str, req: Request):
    body = await req.json()
    raise ValueError(str(body["technical_value"]) + record_id + req.query_params["technical_query"])
if sys.argv[1].endswith("aegle.server"):
    # Explicit technical reference-model setup, never a person's runtime state.
    from livemorebio.aegle.runtime import AegleTwin
    module._state["tw"] = AegleTwin()
    module._state["initialized"] = True
class TechnicalMemoryTransport(asyncio.Transport):
    def __init__(self):
        self.output = bytearray()
        self.closed = False
    def get_extra_info(self, name, default=None):
        return {"sockname": ("127.0.0.1", 18991), "peername": ("127.0.0.1", 18992)}.get(name, default)
    def write(self, data):
        self.output.extend(data)
    def is_closing(self):
        return self.closed
    def close(self):
        self.closed = True
    def pause_reading(self):
        pass
    def resume_reading(self):
        pass
async def run():
    request = json.load(sys.stdin)
    config = uvicorn.Config(app, log_level="warning", lifespan="off", proxy_headers=False)
    state = ServerState()
    protocol = H11Protocol(config=config, server_state=state, app_state={})
    transport = TechnicalMemoryTransport()
    protocol.connection_made(transport)
    body = json.dumps(request["body"]).encode() if request["body"] is not None else b""
    head = (request["method"] + " " + request["path"] + " HTTP/1.1\\r\\n"
            "Host: 127.0.0.1:18991\\r\\nContent-Type: application/json\\r\\n"
            "Authorization: Bearer " + request["token"] + "\\r\\n"
            "Content-Length: " + str(len(body)) + "\\r\\n\\r\\n").encode()
    protocol.data_received(head + body)
    await asyncio.gather(*list(state.tasks))
    protocol.connection_lost(None)
    sys.stdout.buffer.write(transport.output)
asyncio.run(run())
'''


@contextmanager
def running_service(tmp_path: Path, service: str, *, provision_storage_key: bool = False):
    """Run real uvicorn HTTP parsing/ASGI logging with an in-memory transport.

    The managed sandbox refuses even loopback bind. This exercises uvicorn's
    actual RequestResponseCycle and error logger without opening any socket.
    """
    base = tmp_path / service
    for folder in ("home", "tmp", "data"):
        (base / folder).mkdir(parents=True, exist_ok=True)
    env = {key: value for key, value in os.environ.items()
           if not key.startswith("LIVEMORE_")}
    env.update(HOME=str(base / "home"), TMPDIR=str(base / "tmp"),
               LIVEMORE_DATA_DIR=str(base / "data"),
               LIVEMORE_API_TOKEN=TECHNICAL_TOKEN, PYTHONPATH=str(ROOT),
               PYTHONDONTWRITEBYTECODE="1")
    if provision_storage_key:
        # A configured sink is needed to reach input conversion; missing-key
        # refusal is a separate boundary and must not make this privacy test hollow.
        env["LIVEMORE_PATCH_STORAGE_KEY"] = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("ascii")
    log = base / "technical-service.log"
    def request(path: str, body: object = None, *, method: str = "POST"):
        result = subprocess.run(
            [sys.executable, "-B", "-c", _CHILD, SERVICES[service]],
            cwd=ROOT, env=env, capture_output=True, timeout=30,
            input=json.dumps({"path": path, "body": body, "method": method,
                              "token": TECHNICAL_TOKEN}).encode(),
        )
        log.write_bytes(result.stderr)
        assert result.returncode == 0, result.stderr.decode()

        class TechnicalResponseSocket:
            def makefile(self, mode):
                return io.BytesIO(result.stdout)

        response = http.client.HTTPResponse(TechnicalResponseSocket())
        response.begin()
        return response.status, dict(response.getheaders()), response.read().decode()

    yield request, log


def assert_private_failure(status: int, headers: dict, response: str,
                           log: str, route: str) -> None:
    assert status == 500
    for technical_value in (TECHNICAL_NAME, TECHNICAL_MRN, TECHNICAL_BIOMARKER):
        assert technical_value not in log
        assert technical_value not in response
    payload = json.loads(response)
    assert payload["code"] == "INTERNAL_ERROR"
    assert payload["error"] == "The request could not be completed."
    request_id = payload["request_id"]
    assert request_id and headers["x-request-id"] == request_id
    assert request_id in log and route in log
    assert "Traceback" not in log


@pytest.mark.parametrize("service", list(SERVICES))
def test_API_3_unhandled_exception_logs_only_type_route_method_request_id(tmp_path, service):
    with running_service(tmp_path, service) as (request, log):
        result = request("/technical-error/TECHNICAL-PATH-778812?technical_query=TECHNICAL-QUERY-212",
                         {"technical_value": TECHNICAL_VALUE})
    text = log.read_text(encoding="utf-8")
    assert_private_failure(*result, text, "/technical-error/{record_id}")
    assert "TECHNICAL-PATH-778812" not in text
    assert "TECHNICAL-QUERY-212" not in text
    assert "ValueError" in text and "POST" in text


@pytest.mark.parametrize("service,path,body", [
    # L0-R15 round 1: a technical id, so the request reaches the numeric conversion under test.
    ("life", "/human", {"id": "LMB-1", "age": TECHNICAL_VALUE}),
    ("life", "/human", {"id": "LMB-1", "lifestyle": TECHNICAL_VALUE}),
    ("aegle", "/api/trajectory", {"kcal_intake": TECHNICAL_VALUE}),
    ("aegle", "/api/validate", {"n": TECHNICAL_VALUE}),
])
def test_PHI_1_reported_conversion_failures_do_not_leak(tmp_path, service, path, body):
    with running_service(tmp_path, service) as (request, log):
        result = request(path, body)
    assert_private_failure(*result, log.read_text(encoding="utf-8"), path)


def test_API_9_evidence_error_uses_fixed_response_and_request_id(tmp_path):
    with running_service(tmp_path, "aegle") as (request, log):
        result = request("/api/evidence/%00", method="GET")
    assert_private_failure(*result, log.read_text(encoding="utf-8"), "/api/evidence/{package_id}")
    assert "contains control characters" not in result[2]


def test_PHI_6_lab_conversion_error_never_echoes_submitted_value(tmp_path):
    with running_service(tmp_path, "cendos", provision_storage_key=True) as (request, log):
        status, _, response = request("/evidence/lab-results", {
            "subject_pseudonymized": True, "subject_id": "pseudonym-technical-0001",
            "result_id": "technical-lab-result", "endpoint": "glucose",
            "value": TECHNICAL_VALUE,
        })
    assert status == 422
    for technical_value in (TECHNICAL_NAME, TECHNICAL_MRN, TECHNICAL_BIOMARKER):
        assert technical_value not in response and technical_value not in log.read_text(encoding="utf-8")
    assert json.loads(response)["error"] == "Lab result fields must have valid values and types."


@pytest.mark.parametrize("body", [
    {"compound": "technical-compound", "dose": TECHNICAL_VALUE},
    {"compound": "technical-compound", "mode": "parametric", "si_boost": TECHNICAL_VALUE},
])
def test_PHI_6_screen_conversion_error_never_echoes_submitted_value(tmp_path, body):
    with running_service(tmp_path, "aegle") as (request, log):
        status, _, response = request("/api/screen", body)
    assert status == 400
    for technical_value in (TECHNICAL_NAME, TECHNICAL_MRN, TECHNICAL_BIOMARKER):
        assert technical_value not in response and technical_value not in log.read_text(encoding="utf-8")


@pytest.mark.parametrize("field", ["weight_kg", "age"])
def test_PHI_6_cohort_conversion_error_never_echoes_submitted_value(tmp_path, field):
    from dataclasses import asdict
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY

    member = {"member_id": "technical-cohort-member", "age": 50,
              "model_parameters": asdict(HEALTHY), "genome": {}}
    if field == "age":
        member["age"] = TECHNICAL_VALUE
    else:
        member["model_parameters"][field] = TECHNICAL_VALUE
    cohort = {"source_class": "REFERENCE_GROUNDED_SYNTHETIC",
              "stratum": "dpp-high-risk-metabolic", "members": [member]}
    with running_service(tmp_path, "cendos") as (request, log):
        status, _, response = request("/protocols/metformin-cohorts", {
            "cohort_a": cohort, "cohort_b": cohort,
        })
    assert status == 422
    assert json.loads(response)["code"] == "INVALID_PROTOCOL"
    for technical_value in (TECHNICAL_NAME, TECHNICAL_MRN, TECHNICAL_BIOMARKER):
        assert technical_value not in response and technical_value not in log.read_text(encoding="utf-8")


def test_PHI_6_current_source_age_is_refused_before_conversion(monkeypatch):
    """The current source validator already prevents the suspected age leak."""
    from dataclasses import asdict
    from fastapi.testclient import TestClient
    from livemorebio.cendos import service
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY
    from livemorebio.tests.cendos_source_fixtures import technical_source

    envelope = technical_source({
        "profile": HEALTHY.name, "profile_params": asdict(HEALTHY),
        "pk_context": {"age": TECHNICAL_VALUE, "genome": {},
                       "evidence_class": "REFERENCE_INITIALIZED"},
    })
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TECHNICAL_TOKEN)
    monkeypatch.setattr(service, "_read_current_source", lambda: envelope)
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin"},
                                          headers={"Authorization": "Bearer " + TECHNICAL_TOKEN})
    assert response.status_code == 503
    assert response.json()["code"] == "CLIENT_RESPONSE"
    for technical_value in (TECHNICAL_NAME, TECHNICAL_MRN, TECHNICAL_BIOMARKER):
        assert technical_value not in response.text
