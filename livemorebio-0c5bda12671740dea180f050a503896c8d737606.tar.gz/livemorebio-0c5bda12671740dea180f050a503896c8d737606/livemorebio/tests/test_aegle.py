"""The Aegle twin must REACT to stimuli (re-simulated), and must not fake systems."""
from dataclasses import replace

from livemorebio.aegle.runtime import AegleTwin


def test_twin_reacts_to_stimuli(pinned_cardiac_asset):
    tw = AegleTwin("type-2-diabetes")
    s0 = tw.state()
    apd0 = s0["cardiac"]["apd90_ms"]; g0 = s0["metabolic"]["mean_glucose"]
    s1 = tw.stimulate("cardiac_drug", ikr_block=0.6)
    assert s1["cardiac"]["apd90_ms"] > apd0 + 30        # hERG block -> APD prolongation
    s2 = tw.stimulate("metabolic_drug", name="metformin", dose=1.0)
    assert s2["metabolic"]["mean_glucose"] < g0         # metformin -> lower glycemia


def test_systems_status_is_honest(pinned_cardiac_asset):
    tw = AegleTwin("healthy")
    st = tw.state()
    status = {s["id"]: s["status"] for s in st["systems"]}
    assert status["cardiac"] == "alive" and status["metabolic"] == "alive"
    assert status["neural"] == "pending"                # unbuilt systems never shown alive
    assert len(st["cardiac"]["v"]) == len(st["cardiac"]["cai"]) > 10


def test_metformin_pk_uses_the_active_profile_weight():
    tw = AegleTwin("type-2-diabetes")
    tw.profile = replace(tw.profile, weight_kg=112.5)

    tw.stimulate("metabolic_drug", name="metformin", dose=1.0)

    assert tw.pk_last["individualization"]["weight_kg"] == 112.5
