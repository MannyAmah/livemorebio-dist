"""Authored offline one-skin diagnostic guards; no browser, asset or listener I/O."""
from __future__ import annotations

import importlib.util
import json
from contextlib import nullcontext
from pathlib import Path
import subprocess

import pytest
from ._node import NODE, require_node, require_playwright, run_node as _run_node

ROOT = Path(__file__).resolve().parents[2]


def node(code: str) -> None:
    # The diagnostic requires Playwright. Without it these checks cannot run,
    # and a client who has not installed it must still be able to install the
    # product: the installer runs this suite and refuses on failure.
    require_playwright()
    script = "const h=require('./tools/check_atlas_request_diagnostic.cjs');const a=require('node:assert/strict');\n" + code
    result = _run_node([NODE, "-e", script], cwd=ROOT,
                            capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.fixture
def supervisor():
    spec = importlib.util.spec_from_file_location("skin_supervisor", ROOT / "tools/check_atlas_presentation.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_closed_supervisor_dispatch_preserves_presentation_default(supervisor, tmp_path):
    require_node()
    config = tmp_path / "browser-config.json"
    command, seconds = supervisor.browser_command("presentation", config)
    assert command == [NODE, str(ROOT / "tools/check_atlas_presentation.cjs"), str(config)]
    assert seconds == 190
    command, seconds = supervisor.browser_command("skin-terminal", config)
    assert command == [NODE, str(ROOT / "tools/check_atlas_request_diagnostic.cjs"), "--skin-config", str(config)]
    assert seconds == 105
    for bad in ("", "unknown", "../diagnostic", None):
        with pytest.raises(supervisor.PresentationError):
            supervisor.browser_command(bad, config)


@pytest.mark.parametrize("check", ["presentation", "skin-terminal"])
def test_actual_supervisor_main_dispatch_config_and_label_without_processes(supervisor, tmp_path, monkeypatch, check):
    require_node()
    from livemorebio import build_info
    root = tmp_path / "livemore-atlas-presentation-authored"
    root.mkdir(mode=0o700)
    cache = tmp_path / "public-atlas" / "atlas"
    cache.mkdir(parents=True)
    (cache / "active.json").write_text(json.dumps({"manifest_sha256": supervisor.MANIFEST, "receipt_id": supervisor.RECEIPT}), encoding="utf-8")
    monkeypatch.setattr(supervisor, "ANATOMY", cache.parent)
    monkeypatch.setattr(supervisor, "free_ports", lambda: None)
    technical_env = {"PATH": "/technical", **{
        f"LIVEMORE_{role}_IDENTITY_AUTHORITY": f"http://127.0.0.1:{8910 + offset}"
        for offset, role in enumerate(("AEGLE", "LIFE", "CENDOS"))}}
    monkeypatch.setattr(supervisor, "prepare_owned_environment", lambda parent: (root, technical_env))
    monkeypatch.setattr(supervisor, "prepare_observation_fixture", lambda env: {"source_class": "REAL_HUMAN", "version": 2})
    monkeypatch.setattr(supervisor, "startup_deadline", nullcontext)
    monkeypatch.setattr(supervisor, "cache_inventory", lambda _path: {str(i): {} for i in range(16)})
    monkeypatch.setattr(build_info, "source_fingerprint", lambda *_: "a" * 64)
    monkeypatch.setattr(supervisor, "health", lambda port: {"port": port})
    monkeypatch.setattr(supervisor, "require_health", lambda value, name, source, previous=None: {"service": name})
    monkeypatch.setattr(supervisor, "process_snapshot", lambda: {})
    monkeypatch.setattr(supervisor, "remaining_descendants", lambda *_: [])
    monkeypatch.setattr(supervisor, "record_listener_inspection", lambda report: report.update(listener_state="AUTHORED_NO_PROBE"))
    launched, waits, saved = [], [], {}
    class Child:
        def poll(self): return None
    def launch(command, **kwargs):
        launched.append(command)
        return Child()
    monkeypatch.setattr(supervisor.subprocess, "Popen", launch)
    monkeypatch.setattr(supervisor, "wait_browser", lambda child, rows, timeout: waits.append(timeout) or 0)
    monkeypatch.setattr(supervisor, "cleanup_children", lambda children: [{"reaped": True} for child in children])
    monkeypatch.setattr(supervisor, "write_private", lambda file, value: saved.update({file.name: value}))
    args = ["technical", "--output-parent", str(tmp_path)]
    if check != "presentation": args += ["--check", check]
    monkeypatch.setattr(supervisor.sys, "argv", args)
    assert supervisor.main() == 0
    assert len(launched) == 4
    assert waits == [190 if check == "presentation" else 105]
    assert saved["browser-config.json"].get("check_kind") == (None if check == "presentation" else check)
    report = saved["supervision.json"]
    assert report["full_acceptance"] is False
    if check == "presentation":
        assert report["ordinary_check"] == "REQUIRES_INDEPENDENT_VISUAL_REVIEW"
        assert "diagnostic_check" not in report
    else:
        assert "ordinary_check" not in report
        assert report["diagnostic_check"] == "REQUIRES_INDEPENDENT_CAUSE_REVIEW_NOT_ACCEPTANCE"
        assert launched[-1][-2:] == ["--skin-config", str(root / "browser-config.json")]


CONFIG = r"""
const config={base:'http://127.0.0.1:8910',out:'/tmp/livemore-atlas-presentation-authored',
 source:'a'.repeat(64),manifest:'8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a',
 receipt:'083b2f038e74476ebfcef07e4a22f7c2',check_kind:'skin-terminal',static_paths:['/lib/atlas_reference_requests.js','/lib/atlas_reference_contract.js'],
 fixture:{twin_id:'twin-'+'b'.repeat(32),subject_id:'pseudonym-technical-atlas-presentation',
 display_label:'Authored software-only Atlas check, not a participant',source_class:'REAL_HUMAN',version:2},
 services:Object.fromEntries(['Aegle','LIFE','Cendos'].map((name,i)=>[name,{schema:'livemore.build-identity.v1',
 source_sha256:'a'.repeat(64),process_instance:(i+1).toString().repeat(8)+'-1111-4111-8111-111111111111',
 started_at:'2026-09-08T00:00:00+00:00'}]))};
"""


def test_dynamic_config_and_private_file_contract_preserves_old_pin():
    node(CONFIG + r"""
const before=JSON.stringify(h.PIN);a.equal(h.validateSkinConfig(config).source,config.source);
for(const key of ['check_kind','source','manifest','receipt']){
 const bad=structuredClone(config);bad[key]='invalid';a.throws(()=>h.validateSkinConfig(bad),{code:'SOURCE_MISMATCH'});
}
const info={isFile:()=>true,isDirectory:()=>false,isSymbolicLink:()=>false,nlink:1,uid:12,mode:0o100600,size:500};
const dir={...info,isFile:()=>false,isDirectory:()=>true,mode:0o40700};
h.requireSkinConfigFile('/tmp/livemore-atlas-presentation-authored/browser-config.json',info,dir,12);
for(const [field,value] of [['nlink',2],['uid',99],['mode',0o100644],['size',1048577]])
 a.throws(()=>h.requireSkinConfigFile('/tmp/livemore-atlas-presentation-authored/browser-config.json',{...info,[field]:value},dir,12),{code:'SOURCE_MISMATCH'});
a.throws(()=>h.requireSkinConfigFile('/tmp/other/browser-config.json',info,dir,12),{code:'SOURCE_MISMATCH'});
a.equal(JSON.stringify(h.PIN),before);
""")


def test_skin_row_and_route_firewall_exact_one_get():
    node(CONFIG + r"""
const skin=h.requireSkinAsset({asset_key:'skin',bytes:4901056,sha256:'e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a'});
for(const delta of [{asset_key:'heart'},{bytes:4901055},{sha256:'b'.repeat(64)}])a.throws(()=>h.requireSkinAsset({...skin,...delta}),{code:'SOURCE_MISMATCH'});
const gate=h.createSkinFirewall(config),base=config.base,url=base+'/assets/anatomy/atlas/'+config.manifest+'/skin.glb';
for(const p of ['/__atlas_request_probe__/skin-terminal-v1','/lib/atlas_reference_requests.js','/lib/atlas_reference_contract.js'])a.notEqual(gate.admit('GET',base+p),'REJECT');
a.equal(gate.admit('GET',url),'ASSET');
a.throws(()=>gate.admit('GET',url),{code:'UNAUTHORIZED_REQUEST'});
for(const raw of [url+'?x=1',url.replace('skin','heart'),base+'/',base+'/api/biology',base+'/api/anatomy/mesh/heart','https://other.invalid/x'])
 a.throws(()=>gate.admit('GET',raw),{code:'UNAUTHORIZED_REQUEST'});
a.throws(()=>h.createSkinFirewall(config).admit('HEAD',url),{code:'UNAUTHORIZED_REQUEST'});
a.deepEqual(gate.snapshot(),{document:1,request_module:1,contract_module:1,skin:1});
""")


def test_fetch_observer_returns_native_promise_and_never_reads_or_cancels():
    node(r"""
(async()=>{
let calls=0,clock=2,metadata=0;const response={get body(){throw Error('NO_BODY_ACCESS')}};
const promise=Promise.resolve(response),signal=new AbortController();
const observer=h.observeSkinFetch((url,opts)=>{calls++;a.equal(opts.signal,signal.signal);return promise;},'/skin',()=>clock,()=>metadata++);
const options={method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:signal.signal};
a.equal(observer.fetch('/skin',options),promise);a.equal(await promise,response);a.equal(calls,1);
a.throws(()=>observer.fetch('/skin',options));clock=7;signal.abort();
a.equal(observer.snapshot().abort_ms,7);a.equal(observer.snapshot().abort_observed,true);
observer.dispose();a.equal(metadata,2);
const throwing=h.observeSkinFetch(()=>promise,'/skin',()=>2,()=>{throw Error('PRIVATE')});
a.equal(throwing.fetch('/skin',{...options,signal:new AbortController().signal}),promise);
a.equal(throwing.snapshot().observer_state,'DIAGNOSTIC_OBSERVER_FAILED');throwing.dispose();
})().catch(e=>{console.error(e);process.exitCode=1});
""")


@pytest.mark.parametrize("terminal", ["FINISHED", "FAILED"])
def test_cdp_terminal_settles_without_body_or_response_finished(terminal):
    node(CONFIG + "const outcome=" + json.dumps(terminal) + r""";
(async()=>{
const observer=h.createSkinProtocolObserver(config,()=>10),url=config.base+'/assets/anatomy/atlas/'+config.manifest+'/skin.glb';
observer.request({requestId:'private-id',timestamp:1,type:'Fetch',request:{url,method:'GET'}});
if(outcome==='FAILED')observer.failed({requestId:'private-id',timestamp:2,errorText:'net::ERR_ABORTED PRIVATE',canceled:true});
else observer.finished({requestId:'private-id',timestamp:2,encodedDataLength:4901400});
a.equal((await observer.settled).terminal,outcome);
const row=observer.snapshot();a.equal(row.request_sequence,1);a.equal(row.resource_type,'Fetch');
a.equal(row.canceled,outcome==='FAILED'?true:null);a.equal(row.blocked_reason,null);a.equal(row.cors_reason,null);
a.equal(row.encoded_data_length,outcome==='FAILED'?null:4901400);a.equal(row.failure_code,outcome==='FAILED'?'ERR_ABORTED':null);
a.ok(!JSON.stringify(row).includes('private-id'));a.ok(!JSON.stringify(row).includes('PRIVATE'));
observer.finalize();observer.finished({requestId:'private-id',timestamp:3});a.deepEqual(observer.snapshot(),row);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


@pytest.mark.parametrize("bad", ["duplicate", "foreign", "nan", "negative", "boolean", "redirect"])
def test_protocol_incoherent_events_reject_without_raw_details(bad):
    node(CONFIG + "const bad=" + json.dumps(bad) + r""";
const o=h.createSkinProtocolObserver(config),url=config.base+'/assets/anatomy/atlas/'+config.manifest+'/skin.glb';
const request={requestId:'secret',timestamp:1,type:'Fetch',request:{url,method:'GET'}};o.request(request);
if(bad==='duplicate')a.throws(()=>o.request(request),{code:'DIAGNOSTIC_OBSERVER_FAILED'});
else if(bad==='redirect')a.throws(()=>o.request({...request,redirectResponse:{status:302}}),{code:'DIAGNOSTIC_OBSERVER_FAILED'});
else a.throws(()=>o.failed({requestId:bad==='foreign'?'other':'secret',timestamp:bad==='nan'?NaN:bad==='negative'?-1:2,
 canceled:bad==='boolean'?'true':false,errorText:'PRIVATE'}),{code:'DIAGNOSTIC_OBSERVER_FAILED'});
o.finalize();
""")


def test_dynamic_resource_and_network_mappers_do_not_borrow_old_pin():
    node(CONFIG + r"""
const asset=h.requireSkinAsset({asset_key:'skin',bytes:4901056,sha256:'e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a'});
const row=h.resourceRows([asset],[],config);a.equal(row[0].state,'UNAVAILABLE');a.equal(row[0].values,null);
const collector=h.createRequestCollector([asset],()=>3,config),r={};
collector.begin(r,config.base+'/assets/anatomy/atlas/'+config.manifest+'/skin.glb','GET');
collector.terminal(r,'FAILED','net::ERR_ABORTED');a.equal(collector.snapshot().requests[0].terminal,'FAILED');
collector.finalize();collector.dispose();
""")


def test_fixed_metadata_get_never_follows_redirect_or_reads_asset():
    node(CONFIG + r"""
(async()=>{
const calls=[];let disposed=0;const context={request:{get:async(url,opts)=>{calls.push({url,opts});return {status:()=>302,json:()=>{throw Error('NO_JSON')},dispose:async()=>disposed++}}}};
const budget={remaining:()=>1234,run:f=>f()};
await a.rejects(h.skinMetadata(context,config,'/api/build',budget),{code:'SOURCE_MISMATCH'});
a.equal(calls[0].opts.maxRedirects,0);a.equal(calls[0].opts.timeout,1234);a.equal(disposed,1);
await a.rejects(h.skinMetadata(context,config,'/assets/anatomy/atlas/x/skin.glb',budget),{code:'UNAUTHORIZED_REQUEST'});
a.equal(calls.length,1);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_collection_book_is_not_transport_or_acceptance_pass():
    node(r"""
const e=h.newSkinEvidence();a.equal(e.acceptance_pass,false);a.equal(e.transport_outcome,'UNAVAILABLE');
a.deepEqual(e.stages.map(s=>[s.id,s.state]),[['source-preflight','NOT_RUN'],['single-skin-observation','NOT_RUN'],['final-fence','NOT_RUN']]);
""")


def test_evidence_write_deadline_is_separate_and_fixed():
    node(r"""
(async()=>{
let timer,delay,cleared=false;const clock={setTimeout:(f,ms)=>{timer=f;delay=ms;return 1},clearTimeout:()=>cleared=true};
const task=h.writeSkinEvidence(()=>new Promise(()=>{}),clock);await Promise.resolve();a.equal(delay,5000);timer();
await a.rejects(task,{code:'DIAGNOSTIC_EVIDENCE_WRITE_FAILED'});a.equal(cleared,true);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_browser_entry_observes_one_original_load_without_disposal_or_response_access():
    node(r"""
(async()=>{
let loads=0,factories=0,fetches=0,disposes=0;const signals=[],snapshots=[];
const native=Promise.resolve(new ArrayBuffer(4901056));let originalTask;
function factory({fetchImpl}){factories++;return {load(manifest,asset){loads++;
 const signal=new AbortController().signal;signals.push(signal);
 originalTask=fetchImpl('/skin',{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal});return originalTask;
},dispose(){disposes++}};}
const asset={asset_key:'skin',bytes:4901056,sha256:'e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a'};
const delivery=h.createSkinMetadataDelivery(snapshot=>snapshots.push(snapshot));
const result=h.startSkinBrowser(factory,h.wrapRequestFactory,h.observeSkinFetch,asset,'/skin','a'.repeat(64),
 delivery,()=>{fetches++;return native;});
a.equal(result,originalTask);a.equal(result,native);await result;await Promise.resolve();
a.equal(factories,1);a.equal(loads,1);a.equal(fetches,1);a.equal(disposes,0);
a.equal(snapshots.at(-1).application.loads[0].resolved_bytes,4901056);
a.equal(snapshots.at(-1).fetch.abort_observed,false);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_skin_build_requires_start_times_and_dynamic_instance_identity():
    node(CONFIG + r"""
const build={...config.services.Aegle,identity_scope:'startup_source'};
const services=Object.fromEntries(Object.entries(config.services).map(([name,row],i)=>[name,
 {up:true,service:name,port:8910+i,build:{...row,identity_scope:'startup_source'}}]));
h.requireSkinBuild(build,services,config);
for(const change of ['started_at','process_instance','source_sha256']){
 const bad=structuredClone(services);bad.LIFE.build[change]='invalid';
 a.throws(()=>h.requireSkinBuild(build,bad,config),{code:'SOURCE_MISMATCH'});
}
""")


def test_failing_dynamic_preflight_writes_all_pending_cases_and_never_launches():
    node(CONFIG + r"""
(async()=>{
const fs=require('node:fs/promises'),acceptance=require('./tools/check_atlas_browser.cjs');
const originalRead=fs.readFile;let written=null,launches=0;
fs.lstat=async file=>file.endsWith('.json')?{isFile:()=>true,isSymbolicLink:()=>false,nlink:1,uid:process.getuid(),mode:0o100600,size:500}:
 {isDirectory:()=>true,isSymbolicLink:()=>false,uid:process.getuid(),mode:0o40700};
fs.readFile=async(file,...args)=>String(file).endsWith('browser-config.json')?JSON.stringify(config):originalRead(file,...args);
fs.writeFile=async(file,bytes)=>{written=JSON.parse(bytes)};acceptance.packageFingerprint=async()=>'f'.repeat(64);
const key=(process.env.LIVEMORE_PLAYWRIGHT_MODULE||'/nonexistent/livemore/playwright/index.js');
require.cache[key]={id:key,filename:key,loaded:true,exports:{chromium:{launch:()=>{launches++;throw Error('NO_LAUNCH')}}}};
const result=await h.mainSkin(config.out+'/browser-config.json');
a.equal(launches,0);a.equal(result.primary_failure,'SOURCE_MISMATCH');a.equal(result.cleanup,'SETTLED');
a.equal(result.teardown.attribution_complete,true);a.equal(result.failure_before_cleanup,'SOURCE_MISMATCH');
a(result.teardown.roles.every(r=>r.allocation==='NOT_REQUESTED'&&r.close==='NOT_STARTED'));
a.deepEqual(written.stages.map(s=>s.state),['FAIL','NOT_RUN','NOT_RUN']);a.equal(written.acceptance_pass,false);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_observation_deadline_freezes_before_owned_closure():
    node(r"""
(async()=>{
let now=0,alarm;const order=[];
const clock={now:()=>now,setTimeout:(f,ms)=>{if(ms===90000)alarm=f;return 1},clearTimeout:()=>{}};
const budget=h.createDiagnosticBudget(clock,()=>order.push('freeze'));
budget.own({close:async()=>order.push('close')});now=90000;alarm();
a.equal(await budget.finish(),'SETTLED');a.deepEqual(order,['freeze','close']);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


RUNNER = CONFIG + r"""
const fs=require('node:fs/promises'),acceptance=require('./tools/check_atlas_browser.cjs'),shared=require('./tools/check_continuous_browser.cjs');
const {EventEmitter}=require('node:events');
const sourceBytes=require('node:fs').readFileSync('./livemorebio/aegle/console/lib/atlas_reference_requests.js');
const skin={asset_key:'skin',bytes:4901056,sha256:'e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a'};
const url=config.base+'/assets/anatomy/atlas/'+config.manifest+'/skin.glb';
const calls={launch:0,gets:[],routes:[],commands:[],detach:0,closed:[],finished:0,body:0,writes:0};
let routeHandler,binding,written,pageURL='about:blank',phaseReached=null,rejectHeld,heldAllocationResolve;
let now=0;const timers=new Map();let timerId=0;
const clock={now:()=>now,setTimeout:(f,ms)=>{const id=++timerId;timers.set(id,{f,ms});return id},clearTimeout:id=>timers.delete(id)};
function fire(ms){const row=[...timers.values()].find(t=>t.ms===ms);a.ok(row,'required fixed deadline missing');now+=ms;row.f();}
const stall=label=>{phaseReached=label;return new Promise((_,reject)=>rejectHeld=reject)};
fs.lstat=async file=>file.endsWith('.json')?{isFile:()=>true,isSymbolicLink:()=>false,nlink:1,uid:process.getuid(),mode:0o100600,size:500}:
 {isDirectory:()=>true,isSymbolicLink:()=>false,uid:process.getuid(),mode:0o40700};
fs.readFile=async file=>String(file).endsWith('browser-config.json')?JSON.stringify(config):sourceBytes;
fs.writeFile=async(file,bytes)=>{calls.writes++;written=JSON.parse(bytes)};
acceptance.packageFingerprint=async()=>config.source;
shared.readVisibilityRuntime=async()=>({playwright:'1.58.2',playwright_core:'1.58.2',
 chromium_source_sha256:'08f14f9abc4bde5b36a0679889de05e8c3c0ebbf7e15c3bafc3639830e01c174',factory_source_sha256:'406a2ce0e50bf6c695a0fa018ac3dec505b60836710bbab797e11730c51917cc'});
shared.nativeVisibilityPreflight=async()=>({authored_native_visibility_standin:true});
const build={...config.services.Aegle,identity_scope:'startup_source'};
const services=Object.fromEntries(Object.entries(config.services).map(([name,row],i)=>[name,{up:true,service:name,port:8910+i,build:{...row,identity_scope:'startup_source'}}]));
const workspace={schema:'livemore.multiscale-workspace.v1',subject:{...config.fixture,lifecycle:'ACTIVE'},
 model_availability:{schema:'livemore.model-availability.v1',state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED',selection_mode:'observations_only',
 preparation_available:false,twin_id:config.fixture.twin_id,twin_version:2,source_generation:'c'.repeat(32)},context_id:'d'.repeat(64),
 twin:{metabolic:null,cardiac:null,active_execution:null},multiscale:{biological_time:{axes:[]},active_execution:null}};
const status={state:'available',available:true,manifest_sha256:config.manifest,source_id:'bp3d-4.0-20130619-surface-core-v1',patient_registered:false,
 manifest:{members:Array.from({length:489},()=>({})),assets:[skin,...['heart','liver','pancreas','right-kidney','left-kidney','right-lung','left-lung','brain'].map(asset_key=>({...skin,asset_key}))]}};
const cdp=new EventEmitter();cdp.send=async command=>{calls.commands.push(command);if(variant==='cdp-stall')return stall('cdp-stall');};
cdp.detach=async()=>{calls.detach++;if(variant==='detach-stall'){phaseReached='detach-stall';return new Promise(()=>{})}rejectHeld?.(Error('AUTHORED_CLOSED'));if(variant==='detach-fails')throw Error('PRIVATE_DETACH');};
const page=new EventEmitter();page.setDefaultTimeout=()=>{};page.mainFrame=()=>page;page.url=()=>pageURL;
page.close=async()=>{calls.closed.push('page');rejectHeld?.(Error('AUTHORED_CLOSED'));};
page.exposeBinding=async(name,fn)=>{a.equal(name,'__atlasSkinMetadata');binding=fn};
async function routed(raw){calls.routes.push(raw);let action=null;await routeHandler({request:()=>({url:()=>raw,method:()=> 'GET',redirectedFrom:()=>null}),
 fulfill:async()=>{action='fulfill'},continue:async()=>{action='continue'},abort:async()=>{action='abort'}});a.notEqual(action,'abort');}
page.goto=async raw=>{pageURL=raw;await routed(raw)};
page.evaluate=async program=>{
 if(typeof program==='function')return [];
 a.equal(program,h.skinBrowserProgram(config));
 await routed(config.base+'/lib/atlas_reference_requests.js');await routed(config.base+'/lib/atlas_reference_contract.js');await routed(url);
 const request={url:()=>url,method:()=> 'GET',failure:()=>({errorText:'net::ERR_ABORTED PRIVATE'}),timing:()=>({responseEnd:20})};
 page.emit('request',request);cdp.emit('Network.requestWillBeSent',{requestId:'private-protocol-id',timestamp:1,type:'Fetch',request:{url,method:'GET'}});
 page.emit('response',{request:()=>request,status:()=>200,headers:()=>({'content-type':'model/gltf-binary','x-livemore-source-sha256':config.source,
 'x-livemore-process-instance':config.services.Aegle.process_instance,'x-content-sha256':skin.sha256,'x-atlas-manifest-sha256':config.manifest}),
 finished:()=>{calls.finished++;return new Promise(()=>{})},body:()=>{calls.body++;throw Error('NO_BODY')}});
 if(variant==='load-stall')return stall('load-stall');
 const failed=variant==='failed';page.emit(failed?'requestfailed':'requestfinished',request);
 cdp.emit(failed?'Network.loadingFailed':'Network.loadingFinished',{requestId:'private-protocol-id',timestamp:2,type:'Fetch',errorText:'net::ERR_ABORTED PRIVATE',canceled:true,encodedDataLength:4901400});
 const native=Promise.resolve(new ArrayBuffer(skin.bytes));
 const factory=({fetchImpl})=>({load:()=>fetchImpl(new URL(url).pathname,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:new AbortController().signal}),dispose:()=>{throw Error('NO_DISPOSE')}});
 return h.orchestrateSkinBrowser(h.startSkinBrowser,factory,h.wrapRequestFactory,h.observeSkinFetch,h.createSkinMetadataDelivery,
 skin,new URL(url).pathname,config.manifest,value=>binding({page,frame:page},value),()=>native);
};
const context={route:async(_pattern,fn)=>{routeHandler=fn;if(variant==='route-stall')return stall('route-stall')},newPage:async()=>page,
 newCDPSession:async()=>{if(['late-cdp','never-cdp'].includes(variant)){phaseReached=variant;return new Promise(resolve=>heldAllocationResolve=resolve)}return cdp},
 close:async()=>{calls.closed.push('context');rejectHeld?.(Error('AUTHORED_CLOSED'));},request:{get:async(raw,options)=>{
 calls.gets.push({raw,options});const endpoint=new URL(raw).pathname;
 const value={'/api/build':build,'/api/services':services,'/api/workspace':workspace,'/api/anatomy/atlas-reference':status}[endpoint];
 a.ok(value||endpoint==='/api/session/bootstrap');
 return {status:()=>endpoint==='/api/session/bootstrap'?204:200,json:async()=>value,dispose:async()=>{}};
 }}};
const browser={version:()=> 'authored-browser-standin',newContext:async()=>context,close:async()=>{calls.closed.push('browser');rejectHeld?.(Error('AUTHORED_CLOSED'));}};
const modulePath=(process.env.LIVEMORE_PLAYWRIGHT_MODULE||'/nonexistent/livemore/playwright/index.js');
require.cache[modulePath]={id:modulePath,filename:modulePath,loaded:true,exports:{chromium:{launch:async()=>{calls.launch++;return browser}}}};
"""


@pytest.mark.parametrize("variant", ["finished", "failed", "route-stall", "cdp-stall", "load-stall", "late-cdp", "never-cdp", "detach-fails", "detach-stall"])
def test_actual_runner_terminal_collection_or_bounded_stall_keeps_partial_evidence(variant):
    node("const variant=" + json.dumps(variant) + ";\n" + RUNNER + r"""
(async()=>{
const task=h.mainSkin(config.out+'/browser-config.json',{clock});
if((variant.includes('stall')&&variant!=='detach-stall')||['late-cdp','never-cdp'].includes(variant)){
 for(let i=0;!phaseReached&&i<100;i++)await new Promise(setImmediate);
 a.equal(phaseReached,variant);fire(90000);
 if(variant==='late-cdp')heldAllocationResolve(cdp);
 if(variant==='never-cdp'){
  for(let i=0;![...timers.values()].some(t=>t.ms===5000)&&i<100;i++)await new Promise(setImmediate);
  fire(5000);
 }
}
if(variant==='detach-stall'){
 for(let i=0;!phaseReached&&i<100;i++)await new Promise(setImmediate);
 a.equal(phaseReached,'detach-stall');fire(5000);
}
const result=await task;a.equal(result.cleanup,['never-cdp','detach-fails','detach-stall'].includes(variant)?'CLEANUP_UNCONFIRMED':'SETTLED');a.equal(calls.finished,0);a.equal(calls.body,0);a.equal(calls.writes,1);
a.equal(result.acceptance_pass,false);a.equal(written.acceptance_pass,false);
a.ok(calls.closed.includes('browser'));a.ok(calls.closed.includes('context'));
if(variant==='finished'||variant==='failed'){
 a.equal(result.collection_pass,true);a.equal(result.primary_failure,null);a.equal(result.transport_outcome,variant.toUpperCase());
 a.deepEqual(result.stages.map(s=>s.state),['PASS','PASS','PASS']);a.equal(result.resource_timing[0].state,'UNAVAILABLE');
 a.equal(calls.gets.length,9);a.ok(calls.gets.every(c=>c.options.maxRedirects===0));a.equal(calls.routes.filter(p=>p===url).length,1);
 a.deepEqual(calls.commands,['Network.enable']);a.equal(calls.detach,1);
}else if(['never-cdp','detach-fails','detach-stall'].includes(variant)){
 a.equal(result.collection_pass,false);a.equal(result.primary_failure,'CLEANUP_UNCONFIRMED');
}else{
 a.equal(result.collection_pass,false);a.equal(result.primary_failure,'DIAGNOSTIC_DEADLINE');a.equal(result.stages.at(-1).state,'NOT_RUN');
 if(variant==='load-stall'){a.equal(result.network.requests.length,1);a.equal(result.protocol.terminal,'PENDING');}
}
a.ok(!JSON.stringify(written).includes('private-protocol-id'));a.ok(!JSON.stringify(written).includes('PRIVATE'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


@pytest.mark.parametrize("fault", ["none", "listener", "freeze", "collector", "source-and-close", "write"])
def test_actual_runner_teardown_attribution_and_primary_failure_preservation(fault):
    node("const variant='finished',fault=" + json.dumps(fault) + ";\n" + RUNNER + r"""
(async()=>{
let complete=false;process.on('beforeExit',()=>{if(!complete)process.exitCode=1});
if(fault==='listener')page.off=()=>{throw Error('PRIVATE_LISTENER')};
const originalClone=global.structuredClone,originalClear=Map.prototype.clear;
if(fault==='freeze'){
 let fingerprints=0;acceptance.packageFingerprint=async()=>{fingerprints++;return config.source};
 global.structuredClone=value=>{if(fingerprints>=3&&value?.context_sequence===1)throw Error('PRIVATE_FREEZE');return originalClone(value)};
}
// The collector owns the request->row Map; affect only that exact row shape.
if(fault==='collector'){
 Map.prototype.clear=function(){if([...this.values()].some(r=>r?.context_sequence===1))throw Error('PRIVATE_COLLECTOR');return originalClear.call(this)};
}
if(fault==='source-and-close'){
 let fingerprints=0;acceptance.packageFingerprint=async()=>++fingerprints>=3?'f'.repeat(64):config.source;
 context.close=async()=>{calls.closed.push('context');throw Error('PRIVATE_CLOSE')};
}
if(fault==='write')fs.writeFile=async()=>{calls.writes++;throw Error('PRIVATE_WRITE')};
let result;try{result=await h.mainSkin(config.out+'/browser-config.json',{clock})}
finally{global.structuredClone=originalClone;Map.prototype.clear=originalClear}
a.ok(result.teardown);a.equal(result.teardown.roles.length,4);a.equal(result.teardown.attribution_complete,true);
a.deepEqual(calls.closed,['page','context','browser']);a.equal(calls.detach,1);
if(fault==='none'){a.equal(result.cleanup,'SETTLED');a.equal(result.failure_before_cleanup,null)}
else if(fault==='source-and-close'){
 a.equal(result.failure_before_cleanup,'SOURCE_MISMATCH');a.equal(result.primary_failure,'CLEANUP_UNCONFIRMED');
 a.equal(result.teardown.roles.find(r=>r.role==='context').close,'REJECTED');
}else if(fault==='listener'){
 a.equal(result.primary_failure,'CLEANUP_UNCONFIRMED');a.equal(result.teardown.phases.find(r=>r.phase==='listener_remove').status,'REJECTED');
}else if(fault==='freeze'||fault==='collector'){
 a.equal(result.primary_failure,'CLEANUP_UNCONFIRMED');a.equal(result.teardown.phases.find(r=>r.phase===(fault==='freeze'?'freeze':'collector_dispose')).status,'REJECTED');
}else if(fault==='write'){a.equal(result.primary_failure,'DIAGNOSTIC_EVIDENCE_WRITE_FAILED');a.equal(result.collection_pass,false)}
a(!JSON.stringify(result).includes('PRIVATE'));complete=true;
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_actual_runner_teardown_alarm_freeze_failure_is_not_relabelled_success():
    node("const variant='load-stall';\n" + RUNNER + r"""
(async()=>{
let complete=false;process.on('beforeExit',()=>{if(!complete)process.exitCode=1});
const originalClone=global.structuredClone;
global.structuredClone=value=>{if(value?.context_sequence===1)throw Error('PRIVATE_FREEZE');return originalClone(value)};
let result;try{
 const task=h.mainSkin(config.out+'/browser-config.json',{clock});
 for(let i=0;!phaseReached&&i<100;i++)await new Promise(setImmediate);
 a.equal(phaseReached,'load-stall');fire(90000);result=await task;
}finally{global.structuredClone=originalClone}
a.equal(result.failure_before_cleanup,'DIAGNOSTIC_DEADLINE');a.equal(result.primary_failure,'CLEANUP_UNCONFIRMED');
const s=result.teardown;a.equal(s.phases.find(r=>r.phase==='freeze').status,'REJECTED');
a.equal(s.phases.find(r=>r.phase==='before_cancel').status,'REJECTED');a.equal(s.first_failure.phase,'freeze');
a.equal(s.roles.filter(r=>r.close==='FULFILLED').length,4);a.equal(calls.detach,1);
a(!JSON.stringify(result).includes('PRIVATE'));complete=true;
})().catch(e=>{console.error(e);process.exitCode=1});
""")
