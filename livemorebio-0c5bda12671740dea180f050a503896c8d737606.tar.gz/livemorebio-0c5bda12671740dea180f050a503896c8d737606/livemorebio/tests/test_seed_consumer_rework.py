"""Reference identities and annotations stay distinct from unknowns and risk."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path

import pytest

from livemorebio.life_system.reference import build_seed
from livemorebio.life_system.reference.knowledgebase import KnowledgeBase

CLINICAL_LABELS = [
    "Type 2 diabetes mellitus", "Type 1 diabetes mellitus", "Coronary artery disease",
    "Hypertension", "nonalcoholic fatty liver", "COPD", "Non-small cell lung cancer",
    "Colorectal cancer", "Alzheimer disease", "Parkinson disease", "Obesity",
    "Rheumatoid arthritis", "Asthma", "Breast cancer", "Melanoma",
    "Congestive heart failure", "familial hypercholesterolemia", "Prostate cancer",
    "Osteoporosis", "inflammatory bowel disease",
]

PUBLISHED_LABELS = json.loads((Path(__file__).parent / "fixtures/note_extraction_stable.json").read_text(encoding="utf-8"))["published_labels"]


@pytest.mark.parametrize("case", PUBLISHED_LABELS, ids=lambda case: case["replacement"])
def test_all_twenty_published_labels_resolve_or_have_explicit_typed_refusal(case):
    from ._source_tree import REPOSITORY_ROOT, git_executable, require_git_checkout
    from livemorebio.life_system.reference.human_builder import HumanBuilder, HumanSpec

    required = os.environ.get("LIVEMORE_REQUIRE_STABLE_HISTORY") == "1"
    try:
        require_git_checkout("published condition-label compatibility")
    except pytest.skip.Exception:
        assert not required, "STABLE_HISTORY_REQUIRED: published condition labels require a git checkout"
        raise
    old = subprocess.run([git_executable(), "show", "stable-6588707:livemorebio/life_system/seed/diseases.json"],
                         cwd=REPOSITORY_ROOT, capture_output=True, text=True, check=False, encoding="utf-8")
    if old.returncode:
        assert not required, "STABLE_HISTORY_REQUIRED: fetch tag stable-6588707 before compatibility verification"
        shallow = subprocess.run([git_executable(), "rev-parse", "--is-shallow-repository"],
                                 cwd=REPOSITORY_ROOT, capture_output=True, text=True, check=True, encoding="utf-8")
        assert shallow.stdout.strip() == "true", old.stderr
        pytest.skip("STABLE_HISTORY_UNAVAILABLE: shallow checkout lacks published condition labels")
    labels = [row.get("name") or row["query"] for row in json.loads(old.stdout)]
    assert len(labels) == 20
    matches = [label for label in labels if hashlib.sha256(label.encode()).hexdigest() == case["sha256"]]
    assert len(matches) == 1
    label = matches[0]
    kb = KnowledgeBase()
    human = HumanBuilder(kb).build(HumanSpec(id="TECH-LEGACY-LABEL", conditions=[label]))
    if case["resolves"]:
        assert kb.disease(label)["doid"] == kb.disease(case["replacement"])["doid"]
        assert human.reference["conditions"]
        assert not human.reference["unresolved_conditions"]
    else:
        assert kb.disease(label) is None
        assert human.reference["conditions"] == []
        assert human.reference["unresolved_conditions"] == [kb.unresolved_condition(label)]
        assert human.reference["unresolved_conditions"][0]["reason_code"] == "REFERENCE_DISEASE_UNRESOLVED"


def test_published_label_oracle_includes_all_twenty_with_six_explicit_refusals():
    assert len(PUBLISHED_LABELS) == len({row["sha256"] for row in PUBLISHED_LABELS}) == 20
    assert {row["replacement"] for row in PUBLISHED_LABELS if not row["resolves"]} == {
        "hypertension", "chronic obstructive pulmonary disease", "obesity",
        "congestive heart failure", "osteoporosis", "inflammatory bowel disease",
    }
    kb = KnowledgeBase()
    assert all(kb.disease(row["replacement"]) is not None for row in PUBLISHED_LABELS)


@pytest.mark.parametrize("missing", ["checkout", "shallow-tag", "full-tag"])
@pytest.mark.parametrize("required", [False, True])
def test_published_label_history_requirement_fails_instead_of_skipping(monkeypatch, missing, required):
    from . import _source_tree

    if required:
        monkeypatch.setenv("LIVEMORE_REQUIRE_STABLE_HISTORY", "1")
    else:
        monkeypatch.delenv("LIVEMORE_REQUIRE_STABLE_HISTORY", raising=False)

    def require_checkout(_purpose):
        if missing == "checkout":
            pytest.skip("NOT_A_GIT_CHECKOUT: technical absent-history fixture")

    def missing_tag(command, **_kwargs):
        if "show" in command:
            return subprocess.CompletedProcess(command, 1, "", "technical missing tag")
        assert command[1:] == ["rev-parse", "--is-shallow-repository"]
        return subprocess.CompletedProcess(command, 0, "true" if missing == "shallow-tag" else "false", "")

    monkeypatch.setattr(_source_tree, "require_git_checkout", require_checkout)
    monkeypatch.setattr(_source_tree, "git_executable", lambda: "technical-git")
    monkeypatch.setattr(subprocess, "run", missing_tag)
    if required:
        try:
            with pytest.raises(AssertionError, match="STABLE_HISTORY_REQUIRED"):
                test_all_twenty_published_labels_resolve_or_have_explicit_typed_refusal(PUBLISHED_LABELS[0])
        except pytest.skip.Exception as error:
            pytest.fail(f"Required historical compatibility must fail, not skip: {error}")
    elif missing == "full-tag":
        with pytest.raises(AssertionError, match="technical missing tag"):
            test_all_twenty_published_labels_resolve_or_have_explicit_typed_refusal(PUBLISHED_LABELS[0])
    else:
        reason = "NOT_A_GIT_CHECKOUT" if missing == "checkout" else "STABLE_HISTORY_UNAVAILABLE"
        with pytest.raises(pytest.skip.Exception, match=reason):
            test_all_twenty_published_labels_resolve_or_have_explicit_typed_refusal(PUBLISHED_LABELS[0])


def test_all_seed_diseases_have_exact_ontology_identity_and_sourced_clinical_names():
    kb = KnowledgeBase()
    assert len(kb.diseases) == 20
    assert all(d["doid"] and d["resolution_status"] == "resolved_exact" for d in kb.diseases)
    expected_ids = ["DOID:9352", "DOID:9744", "DOID:3393", "DOID:10763", "DOID:0080208",
                    "DOID:3083", "DOID:3908", "DOID:9256", "DOID:10652", "DOID:14330",
                    "DOID:9970", "DOID:7148", "DOID:2841", "DOID:1612", "DOID:1909",
                    "DOID:6000", "DOID:13810", "DOID:10283", "DOID:11476", "DOID:0050589"]
    assert [kb.disease(name)["doid"] for name in CLINICAL_LABELS] == expected_ids
    for name, doid in {
        "type 1 diabetes mellitus": "DOID:9744", "chronic obstructive pulmonary disease": "DOID:3083",
        "congestive heart failure": "DOID:6000", "familial hypercholesterolemia": "DOID:13810",
        "nonalcoholic fatty liver disease": "DOID:0080208",
    }.items():
        assert kb.disease(name)["doid"] == doid


@pytest.mark.parametrize("name", CLINICAL_LABELS + list(build_seed.DISEASE_NAMES))
def test_note_extractor_recognises_sourced_clinical_names_and_curated_queries(name):
    # L0-R15: the extractor's vocabulary still consumes every sourced name; reading
    # a note with it is refused in this release.
    from livemorebio.life_system.extract import ClinicalExtractor, note_label
    from .test_l0_clinical_note_gate import assert_note_refused
    kb = KnowledgeBase()
    disease = kb.disease(name)
    assert disease is not None
    extractor = ClinicalExtractor(kb)
    assert note_label(disease) in set(extractor.disease_terms.values())
    assert_note_refused(lambda: extractor.extract(f"Known condition: {name}."))


def test_short_gene_symbols_require_explicit_genetic_context():
    # L0-R15: the symbols stay in the vocabulary; reading any text for them is
    # refused in this release, so the short-symbol matching rule is not reached.
    from livemorebio.life_system.extract import ClinicalExtractor
    from .test_l0_clinical_note_gate import assert_note_refused
    extractor = ClinicalExtractor()
    assert {"AR", "KIT"} <= extractor.gene_syms
    assert_note_refused(lambda: extractor.extract("AR murmur noted. KIT negative."))
    assert_note_refused(lambda: extractor.extract("AR gene mutation detected."))


def test_unknown_conditions_have_a_typed_entry_and_do_not_apply_presets():
    from livemorebio.life_system.reference.human_builder import HumanSpec, HumanBuilder
    from livemorebio.life_system.reference.knowledgebase import ReferenceReason
    kb = KnowledgeBase()
    kb.diseases.append({"query": "unknown diabetes", "name": "Unknown diabetes", "doid": None,
                        "resolution_status": "unresolved_no_exact_match", "genes": ["INS"]})
    kb._index()
    assert kb.disease("unknown diabetes") is None
    assert kb.resolve("unknown diabetes") is None
    assert kb.summary()["unresolved_diseases"] == 1
    human = HumanBuilder(kb).build(HumanSpec(conditions=["unknown diabetes"]))
    assert human.reference["conditions"] == []
    assert human.reference["unresolved_conditions"][0]["reason_code"] == ReferenceReason.DISEASE_UNRESOLVED
    assert human.reference["unresolved_conditions"][0]["resolution_status"] == "unresolved_no_exact_match"


def test_t2d_enrichment_removes_identity_from_an_actually_conflicting_cohort():
    from livemorebio.life_system.population import LifeSystem
    from livemorebio.sdk import Platform
    kb = KnowledgeBase()
    baseline = LifeSystem().generate(50, seed=0)
    assert any(kb.disease(c)["doid"] == "DOID:9744" for h in baseline for c in h.conditions)
    platform = Platform()
    platform.cohort(50, seed=0, indication="type-2-diabetes")
    assert len(platform._cohort) == 50
    assert all(kb.disease(c)["doid"] != "DOID:9744" for h in platform._cohort for c in h.conditions)
    assert all(not c.casefold().startswith("type 1") for h in platform._cohort for c in h.conditions)


def test_graph_never_stringifies_absent_identifiers_and_marks_curated_indications():
    from livemorebio.life_system.graph import KnowledgeGraph
    graph = KnowledgeGraph()
    assert not any('"None"' in line for line in graph.export_cypher())
    assert all(d.get("chembl") for _, d in graph.g.nodes(data=True) if d["kind"] == "Drug")
    assert all(d["source"] == "curated_unsourced" and d["executable"] is False
               for _, _, d in graph.g.edges(data=True) if d["rel"] == "TREATS")
    assert graph.stats()["membership_status"] == "not_distributed"


def test_alias_search_and_missing_annotation_status():
    from livemorebio.life_system.retrieval import SubstrateIndex
    index = SubstrateIndex()
    assert any(kind == "Disease" and "pulmonary" in name.casefold()
               for kind, name, _ in index.query("COPD"))
    result = index.query_with_status("glucose metabolism", kind="Gene")
    assert result["annotation_status"] == "not_distributed"
    assert result["reason_code"] == "REFERENCE_ANNOTATION_NOT_DISTRIBUTED"


def test_association_provenance_and_seed_hashes():
    kb = KnowledgeBase()
    for disease in kb.diseases:
        assert disease["category"] == "" and disease["pathways"] == []
        for association in disease["gene_associations"]:
            assert association["score_type"] == "overall_direct_association"
            assert association["datatype_scores"]
            assert association["evidence_type"] == "association"
            assert association["executable"] is False
            assert association["release"]
    for name, expected in kb.meta["output_sha256"].items():
        assert hashlib.sha256((Path(build_seed.SEED) / name).read_bytes()).hexdigest() == expected
    assert kb.pathways["membership_status"] == "not_distributed"
    assert kb.meta["removed"] and kb.meta["unresolved"] == []
    for source in ("Reactome", "HGNC", "Disease Ontology", "Open Targets Platform"):
        record = kb.meta["source_records"][source]
        assert record["license_verified_at"] == "2026-10-04"
        assert record["license_verifier"]
        assert record["release"] or record["release_unversioned_reason"]


def test_association_cut_includes_all_tied_scores():
    rows = [{"targetId": f"ENSG{i:011}", "score": 1 if i == 0 else 0.5,
             "evidenceCount": 1} for i in range(23)]
    assert len(build_seed.select_associations(rows, limit=20)) == 23


@pytest.mark.parametrize("identifier", [prefix + "12345" for prefix in ("C", "K", "R", "M", "N", "G", "map", "ko")])
def test_replacement_guard_rejects_all_restricted_identifier_classes(identifier):
    with pytest.raises(build_seed.SeedBuildError):
        build_seed.encode_replacement({"value": identifier})


def test_ontology_definition_uses_definition_property_not_curator_comment():
    class Reader:
        def json(self, source, url):
            if "/api/search?" in url:
                return {"response": {"numFound": 1, "docs": [{"obo_id": "DOID:1",
                    "label": "example", "iri": "http://example.test/DOID_1",
                    "description": ["curator comment", "true definition"]}]}}
            return {"http://purl.obolibrary.org/obo/IAO_0000115": {"value": "true definition"},
                    "http://www.w3.org/2000/01/rdf-schema#comment": "curator comment"}
    assert build_seed._disease_identity(Reader(), "example")["description"] == "true definition"


def test_graph_association_edges_keep_scores_release_and_evidence_type():
    from livemorebio.life_system.graph import KnowledgeGraph
    graph = KnowledgeGraph()
    edges = [d for _, _, d in graph.g.edges(data=True) if d["rel"] == "ASSOCIATED_WITH"]
    assert edges
    assert all(d["evidence_type"] == "association" and d["release"] and isinstance(d["score"], float)
               and d["executable"] is False for d in edges)


def test_vocabulary_separates_unknowns_and_exposes_identity(monkeypatch):
    from livemorebio.life_system import knowledge
    from livemorebio.aegle import server
    kb = KnowledgeBase()
    kb.diseases.append({"query": "unresolved technical fixture", "name": "Unresolved technical fixture",
                        "doid": None, "genes": [], "resolution_status": "unresolved_no_exact_match"})
    kb._index()
    monkeypatch.setattr(knowledge, "get_kb", lambda: kb)
    data = json.loads(server.api_vocab().body)
    assert data["n_conditions"] == len(kb.diseases) == 20
    assert "Unresolved technical fixture" not in data["conditions"]
    assert len(data["unresolved_conditions"]) == 1
    assert all(data["condition_meta"][name]["doid"] for name in data["conditions"])
    assert data["unresolved_conditions"][0]["reason_code"] == "REFERENCE_DISEASE_UNRESOLVED"


def test_unresolved_identity_is_preserved_when_reindexing():
    kb = KnowledgeBase()
    kb.diseases.append({"query": "technical unknown", "doid": None, "genes": [],
                        "resolution_status": "unresolved_no_exact_match"})
    kb._index()
    kb._index()
    assert kb.summary()["unresolved_diseases"] == 1


def test_real_reference_graph_uses_neo4j_compatible_properties(monkeypatch):
    from livemorebio.life_system.graph import KnowledgeGraph
    from livemorebio.scientific_sources.graph_backends import Neo4jBackend
    calls = []
    class Session:
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def run(self, statement, **params):
            values = params["properties"]
            assert all(value is None or isinstance(value, (str, int, float, bool)) for value in values.values())
            calls.append(values)
    class Driver:
        def session(self, **kwargs):
            return Session()
        def close(self):
            pass
    monkeypatch.setattr(Neo4jBackend, "_driver", lambda self: Driver())
    result = KnowledgeGraph().load_neo4j(uri="bolt://example.test:7687", user="technical", password="fixture-only")
    assert result["loaded"]
    associations = [row for row in calls if row.get("evidence_type") == "association"]
    assert associations and all(isinstance(row["score"], float) for row in associations)
    assert all(row["executable"] is False and json.loads(row["datatype_scores_json"]) for row in associations)


def test_chembl_release_is_bound_to_the_open_targets_release_configuration():
    record = KnowledgeBase().meta["source_records"]["ChEMBL"]
    assert record["release"] == "37"
    assert record["release_source_url"] == "https://ftp.ebi.ac.uk/pub/databases/opentargets/platform/26.09/etc/config/pis_chembl.yaml"
    assert len(record["requests"]) == 1
    assert record["requests"][0]["url"] == record["release_source_url"]
    # Current release config is independently fetched and pinned in the refresh receipt.
    assert record["requests"][0]["sha256"] == "f0e8200e5ba56809607f3cb4cb8c452b29822f3cf15e172ad075d36bc6670861"
