"""Fixed authored feedback DOM and runner contracts, never actual browser QA."""
import copy
import json

import pytest

from .test_legacy_preview_browser_harness import harness, js, mounted, _authored_browser_receipt


CHECKS = [('desktop-modeless','unavailable','info',False), ('desktop-pending','pending','hidden',False),
    ('desktop-ready','computed','hidden',True), ('desktop-unknown','unavailable','hidden',False),
    ('mobile-ready','computed','hidden',True), ('mobile-unknown','unavailable','hidden',False),
    ('mobile-modeless','unavailable','info',False)]
LABELS = ['legacy-cardiac-state','legacy-cardiac-provenance','legacy-cardiac-time']


def feedback_rows():
    rows=[]
    for name,mode,banner,layout in CHECKS:
        width,height=(390,844) if name.startswith('mobile') else (1440,1000)
        rows.append({'id':name,'mode':mode,'banner':banner,'layout':layout,'snapshot':{
            'observed_mode':mode,'same_banner':True,'singleton':True,'banner_matches':True,
            'banner_hidden':banner=='hidden','banner_empty':banner=='hidden',
            'provenance_class':True,'provenance_title':True,'horizontal_overflow':False,
            'viewport':{'width':width,'height':height},'scroll':{'x':0,'y':100},
            'nav':{'x':0,'y':0,'width':width,'height':64},
            'labels':[{'id':key,'present':True,'copy_matches':True,'hit':True,
                'box':{'x':20,'y':100+i*80,'width':200,'height':24}} for i,key in enumerate(LABELS)]}})
        if name in ('desktop-pending','desktop-unknown','mobile-unknown'):
            rows[-1]['snapshot']['cleared']={k:True for k in ('metrics','note','numerical','canvases','heart','metabolic')}
    return rows


DOM = r"""
const vm=require('node:vm'),names=['legacy-cardiac-state','legacy-cardiac-provenance','legacy-cardiac-time'];
const copies={computed:['Calculated response','computed','calculated beat · milliseconds'],pending:['Update pending','pending','update pending'],unavailable:['No current trace','unavailable','no current trace']};
const titles={computed:'Calculated cardiac trace from the current model state. This is not a physical observation or continuous acquisition.',pending:'A numerical update is pending; no new response is confirmed.',unavailable:'No current numerical cardiac trace.'};
let mode='computed',bannerMode='hidden',damage='',raf=0;
const box=(x,y,width,height)=>({x,y,width,height,right:x+width,bottom:y+height});
const banner={get hidden(){return bannerMode==='hidden'&&damage!=='banner_visible'},get textContent(){return damage==='banner_stale'?'PRIVATE_SENTINEL':bannerMode==='hidden'?'':'Model unavailable. No previous subject physiology is shown.'},dataset:{kind:'info'}};
const nav={getBoundingClientRect:()=>box(0,0,390,64)};
const labels=names.map((id,i)=>({id,get textContent(){return damage==='copy'&&i===0?'PRIVATE_SENTINEL':copies[mode][i]},
 get className(){return damage==='class'?'prov-engine':mode==='computed'?'prov prov-engine':'prov'},
 get title(){return damage==='title'?'PRIVATE_SENTINEL':titles[mode]},contains:x=>x===labels[i],
 getBoundingClientRect:()=>box(damage==='left'?-1:20,damage==='nav'?20:100+i*80,damage==='nan'?NaN:200,damage==='zero'?0:24),
 getClientRects(){return[this.getBoundingClientRect()]}}));
const document={documentElement:{get scrollWidth(){return damage==='overflow'?800:390}},
 querySelector:s=>s==='.lmb-nav'?nav:s==='#__banner'?(damage==='identity'?{}:banner):null,
 querySelectorAll:s=>s==='#__banner'?(damage==='duplicate'?[banner,{}]:[banner]):[],
 getElementById:id=>names.includes(id)?(damage==='missing'&&id===names[2]?null:labels[names.indexOf(id)]):
  id==='legacy-run-experiment'?{disabled:true}:id==='o-cardiac'?{getAttribute:()=> 'translate(105,104)'}:
  id==='o-metabolic'?{getAttribute:()=> '#728b88'}:['cell','trace','metab'].includes(id)?{width:1,height:1,getContext:()=>({getImageData:()=>({data:[0,0,0,0]})})}:{textContent:''},
 elementFromPoint:(_x,y)=>damage==='hit'?{}:labels.find(x=>{const b=x.getBoundingClientRect();return y>=b.y&&y<=b.bottom})};
const context={document,banner,innerWidth:390,innerHeight:844,scrollX:0,scrollY:100,
 getComputedStyle:()=>({display:banner.hidden?'none':'block'}),requestAnimationFrame:fn=>{raf++;fn()}};
function snapshot(clear=false){context.options={mode,banner:bannerMode,layout:mode==='computed',clear};
 return vm.runInNewContext('('+h.readFeedbackSnapshot.toString()+')(banner,options)',context)}
"""


def test_exact_sixteen_images_original_fourteen_subsequence_and_unchanged_budgets():
    h=harness()
    original=('desktop-modeless','desktop-error','desktop-pending','desktop-later-winner','desktop-cleanup',
        'desktop-note-before','desktop-unknown','desktop-twins-recovery','desktop-life-inspection','desktop-history',
        'mobile-error','mobile-note-before','mobile-unknown','mobile-refreshed')
    assert tuple(x for x in h.IMAGES if not x.endswith('-cardiac'))==original
    assert len(h.IMAGES)==16
    assert h.IMAGES[4]=='desktop-cardiac' and h.IMAGES[11]=='mobile-cardiac'
    assert h.LIMITS==dict(startup_s=45,browser_s=180,action_s=10,held_s=2,total_s=350,
        requests=256,posts=4,images=16,evidence_bytes=64*1024*1024)
    js('a.deepEqual(h.IMAGES,'+json.dumps(h.IMAGES)+');')


@pytest.mark.parametrize('mode,banner', [('computed','hidden'),('pending','hidden'),('unavailable','hidden'),('unavailable','info')])
def test_actual_serialized_reader_safe_copy_and_same_evaluation_clear(mode,banner):
    js(DOM+'mode='+json.dumps(mode)+';bannerMode='+json.dumps(banner)+r""";
(async()=>{const s=await snapshot(true);h.requireFeedbackSnapshot(s,{mode,banner:bannerMode,layout:mode==='computed'});
a.equal(raf,2);a.deepEqual(Object.keys(s.cleared),['metrics','note','numerical','canvases','heart','metabolic']);a(Object.values(s.cleared).every(x=>x===true));
a.equal(s.observed_mode,mode);a(!JSON.stringify(s).includes('Model unavailable'));a(!JSON.stringify(s).includes('Calculated cardiac trace'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


@pytest.mark.parametrize('damage', ['copy','class','title','missing','identity','duplicate','banner_visible',
    'banner_stale','overflow','left','nav','nan','zero','hit'])
def test_actual_reader_fails_closed_after_known_good_snapshot(damage):
    js(DOM+r"""(async()=>{const o={mode,banner:bannerMode,layout:true};h.requireFeedbackSnapshot(await snapshot(),o);
damage="""+json.dumps(damage)+r""";const s=await snapshot();a.throws(()=>h.requireFeedbackSnapshot(s,o),e=>e.message==='CURRENT_FEEDBACK_FAILED');
a(!JSON.stringify(s).includes('PRIVATE_SENTINEL'));
})().catch(e=>{console.error(e);process.exitCode=1});""")


def test_both_admitters_require_all_seven_fixed_rows_with_valid_first():
    rows=feedback_rows();h=harness();h._admit_feedback_checks(rows)
    js('h.requireFeedbackRows('+json.dumps(rows)+');')
    for field in ('absent','duplicate','order','mode','hidden','copy','layout','viewport','hit','title','boolean'):
        bad=copy.deepcopy(rows)
        if field=='absent':bad.pop()
        elif field=='duplicate':bad.append(bad[0])
        elif field=='order':bad[0],bad[1]=bad[1],bad[0]
        elif field=='mode':bad[2]['snapshot']['observed_mode']='pending'
        elif field=='hidden':bad[1]['snapshot']['banner_empty']=False
        elif field=='copy':bad[1]['snapshot']['labels'][0]['copy_matches']=False
        elif field=='layout':bad[2]['layout']=False
        elif field=='viewport':bad[2]['snapshot']['viewport']['width']=390
        elif field=='hit':bad[2]['snapshot']['labels'][2]['hit']=False
        elif field=='title':bad[2]['snapshot']['provenance_title']=False
        else:bad[2]['snapshot']['labels'][0]['box']['x']=True
        with pytest.raises((ValueError,TypeError,KeyError)):h._admit_feedback_checks(bad)
        js('a.throws(()=>h.requireFeedbackRows('+json.dumps(bad)+'));')


@pytest.mark.parametrize('damage', ['missing','empty','false','extra'])
def test_parent_and_browser_require_original_six_clear_flags_at_three_checkpoints(damage):
    h=harness();rows=feedback_rows();h._admit_feedback_checks(rows)
    js('h.requireFeedbackRows('+json.dumps(rows)+');')
    for index in (1,3,5):
        bad=copy.deepcopy(rows)
        if damage=='missing':bad[index]['snapshot'].pop('cleared')
        elif damage=='empty':bad[index]['snapshot']['cleared']={}
        elif damage=='false':bad[index]['snapshot']['cleared']['canvases']=False
        else:bad[index]['snapshot']['cleared']['unknown']=True
        with pytest.raises((ValueError,TypeError,KeyError)):h._admit_feedback_checks(bad)
        js('a.throws(()=>h.requireFeedbackRows('+json.dumps(bad)+'));')


def test_mounted_runner_retains_seven_rows_and_sixteen_images_with_same_four_posts():
    mounted('normal',r"""
a.equal(status,0);a.equal(postCount,4);a.equal(finalReceipt.images.length,16);
a.deepEqual(finalReceipt.feedback_checks.map(x=>x.id),['desktop-modeless','desktop-pending','desktop-ready','desktop-unknown','mobile-ready','mobile-unknown','mobile-modeless']);
h.requireFeedbackRows(finalReceipt.feedback_checks);a(finalReceipt.cases.every(x=>x.status==='PASS'));
a.deepEqual(finalReceipt.followup_gets,[1,1,1,1]);a.equal(finalReceipt.actual_mutations,0);
for(const name of ['desktop-cardiac','mobile-cardiac']){const x=finalReceipt.images.find(x=>x.name===name);a.equal(x.feedback_id,name.startsWith('desktop')?'desktop-ready':'mobile-ready');a.equal(x.unoccluded,true);}
for(const key of ['pending_clear','unknown_clear','mobile_clear'])a(Object.values(finalReceipt[key]).every(x=>x===true));
""")


@pytest.mark.parametrize('mode', ['feedback_pending_stale','feedback_cardiac_hit'])
def test_mounted_feedback_failure_is_retained_before_assert_and_does_not_continue(mode):
    mounted(mode,r"""
a.equal(status,1);a.equal(finalReceipt.primary_failure,'CURRENT_FEEDBACK_FAILED');a.equal(finalReceipt.posts,1);
a.equal(finalReceipt.cases[1].status,'FAIL');a(finalReceipt.cases.slice(2).every(x=>x.status==='NOT_RUN'));
const s=finalReceipt.feedback_checks.at(-1).snapshot;a(s);a(mode==='feedback_pending_stale'?s.banner_empty===false:s.labels.some(x=>x.hit===false));
a(!finalReceipt.images.some(x=>x.name==='desktop-cardiac'));a(calls.includes('browser-close'));a(!JSON.stringify(finalReceipt).includes('PRIVATE'));
""")


@pytest.mark.parametrize('damage', ['missing','duplicate','false','missing_image_proof'])
def test_parent_rejects_feedback_tampering_despite_sixteen_valid_images(tmp_path,damage):
    h=harness();record=_authored_browser_receipt(h,tmp_path)
    file=tmp_path/'browser-result.json'
    def save():file.write_text(json.dumps(record), encoding="utf-8");file.chmod(0o600)
    save();assert h.admit_browser_result(tmp_path,source='a'*64,pins={'browser':'b'*64},services={},exit_code=0)['images_verified']==16
    if damage=='missing':record.pop('feedback_checks')
    elif damage=='duplicate':record['feedback_checks'].append(record['feedback_checks'][0])
    elif damage=='false':record['feedback_checks'][1]['snapshot']['banner_empty']=False
    else:record['images'][4].pop('feedback_id')
    save()
    with pytest.raises(h.HarnessError):h.admit_browser_result(tmp_path,source='a'*64,pins={'browser':'b'*64},services={},exit_code=0)


def test_exact_retained_failed_attempt_heading_geometry_only_is_admissible():
    """Technical c_1ximjr desktop-ready values, not promotion of its failed receipt."""
    rows=feedback_rows();s=rows[2]['snapshot']
    s.update(scroll={'x':0,'y':155.5},nav={'x':0,'y':-155.5,'width':1430,'height':60})
    for label,values in zip(s['labels'], [(527.3046875,73.796875,107.59375,12.5),
        (639.28125,71.75,72.9609375,18.25),(559.1015625,499,238.421875,12.5)]):
        label['box']=dict(zip(('x','y','width','height'),values))
    harness()._admit_feedback_checks(rows)
    js('h.requireFeedbackRows('+json.dumps(rows)+');')


@pytest.mark.parametrize('nav,accepted', [
    ((0,-155.5,1430,60),True), ((0,1000,1430,60),True), ((-500,0,100,300),True),
    ((1440,0,100,300),True), ((0,-24,1430,64),True), ((0,980,1430,64),True),
    ((0,0,1430,100),True), ((0,-20,1430,150),False), ((0,90,1430,100),False),
    ((0,-155,0,60),False), ((0,-155,1430,-1),False), ((0,float('nan'),1430,60),False)])
def test_both_admitters_use_only_visible_nav_intersection(nav,accepted):
    h=harness();rows=feedback_rows();h._admit_feedback_checks(rows)
    rows[2]['snapshot']['nav']=dict(zip(('x','y','width','height'),nav))
    if accepted:h._admit_feedback_checks(rows)
    else:
        with pytest.raises((ValueError,TypeError,KeyError)):h._admit_feedback_checks(rows)
    js(('h.requireFeedbackRows('+json.dumps(rows)+');') if accepted else
        'a.throws(()=>h.requireFeedbackRows('+json.dumps(rows)+'));')


@pytest.mark.parametrize('damage', ['above','below','zero','nonfinite','hit','overflow'])
def test_offscreen_nav_never_excuses_label_clipping_hit_or_overflow(damage):
    h=harness();rows=feedback_rows();rows[2]['snapshot']['nav']['y']=-155.5
    h._admit_feedback_checks(rows);js('h.requireFeedbackRows('+json.dumps(rows)+');')
    s=rows[2]['snapshot'];box=s['labels'][0]['box']
    if damage=='above':box['y']=-1
    elif damage=='below':box['y']=990
    elif damage=='zero':box['width']=0
    elif damage=='nonfinite':box['x']=float('nan')
    elif damage=='hit':s['labels'][0]['hit']=False
    else:s['horizontal_overflow']=True
    with pytest.raises((ValueError,TypeError,KeyError)):h._admit_feedback_checks(rows)
    js('a.throws(()=>h.requireFeedbackRows('+json.dumps(rows)+'));')


def test_serialized_reader_preserves_negative_raw_nav_and_native_label_hits():
    js(DOM+r"""(async()=>{nav.getBoundingClientRect=()=>box(0,-155.5,390,60);
const s=await snapshot();a.equal(s.nav.y,-155.5);a(s.labels.every(x=>x.hit===true));
h.requireFeedbackSnapshot(s,{mode,banner:bannerMode,layout:true});a.equal(s.nav.y,-155.5);
})().catch(e=>{console.error(e);process.exitCode=1});""")
