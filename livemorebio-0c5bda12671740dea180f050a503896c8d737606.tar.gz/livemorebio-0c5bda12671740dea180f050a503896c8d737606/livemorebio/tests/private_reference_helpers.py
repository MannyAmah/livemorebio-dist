"""Explicit skips only for a publisher-marked public projection."""
from __future__ import annotations
import json
import os
from pathlib import Path
import pytest
from tools.public_distribution import is_private_only
from livemorebio.reference_errors import ReferenceReason

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]


def is_public_projection(root: Path | None = None) -> bool:
    """The publisher's audience marker, never an image or environment declaration."""
    root = REPOSITORY_ROOT if root is None else root
    marker = root / '.livemore-distribution.json'
    if not marker.is_file() or (root / '.git').exists():
        return False
    try:
        data = json.loads(marker.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return False
    return data == {'schema': 'livemore.distribution.v1', 'audience': 'public'}


def assert_public_projection_has_no_private_files(
    root: Path | None = None, *, installed_cardiac: bool = False,
) -> None:
    """Keep archive policy strict; L0-R2 permits one verified installed asset."""
    root = REPOSITORY_ROOT if root is None else root
    if not is_public_projection(root):
        return
    installed_path = None
    if installed_cardiac is True:
        from livemorebio import model_assets

        assert Path(model_assets.__file__).resolve().parents[1] == root.resolve(), (
            'PUBLIC_INSTALLED_MODEL_ROOT_MISMATCH: verification must use this installed package')
        installed_path = model_assets.verified_cardiac_path()
    retained = []
    for directory, directories, files in os.walk(root, followlinks=False):
        for name in [*files, *(name for name in directories if (Path(directory) / name).is_symlink())]:
            path = Path(directory) / name
            relative = path.relative_to(root).as_posix()
            # Compare locations without resolving a symlink into an allowance.
            if is_private_only(relative) and path.absolute() != installed_path:
                retained.append(relative)
    assert not retained, f'PUBLIC_PRIVATE_FILE_RETAINED: {sorted(retained)}'


def private_reference_is_omitted(path: Path, *, root: Path | None = None) -> bool:
    """Only a missing policy-private path in a marked public tree is omitted."""
    root = REPOSITORY_ROOT if root is None else root
    relative = path.resolve().relative_to(root.resolve()).as_posix()
    return not path.exists() and is_private_only(relative) and is_public_projection(root)


def require_private_reference_data(*paths: Path, root: Path | None = None) -> None:
    """Missing private inputs are failures unless the publisher omitted them."""
    root = REPOSITORY_ROOT if root is None else root
    for path in paths:
        relative = path.resolve().relative_to(root.resolve()).as_posix()
        assert is_private_only(relative), f'not a private reference: {relative}'
    missing = [path for path in paths if not path.exists()]
    if not missing:
        return
    assert all(private_reference_is_omitted(path, root=root) for path in missing), (
        'PRIVATE_REFERENCE_MISSING: private checkout is incomplete')
    pytest.skip(ReferenceReason.DATA_NOT_DISTRIBUTED + ': private reference data is omitted from the public archive.')
