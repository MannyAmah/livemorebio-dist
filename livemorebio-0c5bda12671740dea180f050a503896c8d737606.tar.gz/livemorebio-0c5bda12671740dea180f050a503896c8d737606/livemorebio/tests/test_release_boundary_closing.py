"""Publisher controls use emitted archives and hostile inputs, not policy echoes."""
from __future__ import annotations

import hashlib
import io
import os
from pathlib import Path
import subprocess
import sys
import tarfile

import pytest

from ._source_tree import REPOSITORY_ROOT, require_git_checkout


def _tar(files: dict[str, bytes], prefix: str, *, link: bytes | None = None) -> bytes:
    buffer = io.BytesIO()
    directories = {""}
    for name in files:
        directories.update(str(parent) + "/" for parent in Path(name).parents if str(parent) != ".")
    with tarfile.open(fileobj=buffer, mode="w") as archive:
        for name in sorted(directories):
            item = tarfile.TarInfo(prefix + name)
            item.type = tarfile.DIRTYPE
            archive.addfile(item)
        for name, value in sorted(files.items()):
            item = tarfile.TarInfo(prefix + name)
            item.size = len(value)
            archive.addfile(item, io.BytesIO(value))
        if link is not None:
            item = tarfile.TarInfo(prefix + "unreviewed-link")
            item.type = link
            item.linkname = "README.md"
            archive.addfile(item)
    return buffer.getvalue()


def _member_paths(archive: tarfile.TarFile, prefix: str) -> list[str]:
    return sorted(member.name[len(prefix):].rstrip("/") + ("/" if member.isdir() else "")
                  for member in archive if member.name.rstrip("/") != prefix.rstrip("/"))


@pytest.fixture
def committed_release(tmp_path, monkeypatch):
    """Read-only git responses isolate commit data from a dirty checkout."""
    from tools import build_release
    from tools import public_distribution

    commit = "a" * 40
    prefix = f"livemorebio-{commit}/"
    policy = Path(public_distribution.__file__).read_bytes()
    files = {
        "LICENSE": b"technical license\n", "THIRD_PARTY_NOTICES.md": b"technical notices\n",
        "install.sh": b"#!/bin/sh\necho committed\n", "README.md": b"technical readme\n",
        "tools/public_distribution.py": policy,
        "tools/build_release.py": Path(build_release.__file__).read_bytes(),
        "tools/public_release_manifest.txt": b"",
    }
    expected = sorted([*files, "tools/", ".livemore-distribution.json"])
    files["tools/public_release_manifest.txt"] = ("\n".join(expected) + "\n").encode()
    checkout = tmp_path / "checkout"
    checkout.mkdir()
    (checkout / "install.sh").write_bytes(files["install.sh"])
    publisher = checkout / "tools" / "build_release.py"
    publisher.parent.mkdir()
    publisher.write_bytes(files["tools/build_release.py"])
    monkeypatch.setattr(build_release, "REPOSITORY_ROOT", checkout)
    monkeypatch.setattr(build_release, "__file__", str(publisher))

    def git_run(command, **kwargs):
        assert command[0] == "git"
        if command[1] == "rev-parse":
            value = (("b" * 40) if command[-1] == "annotated-release" else commit).encode() + b"\n"
        elif command[1] == "archive":
            value = _tar(files, prefix)
        elif command[1] == "show":
            name = command[2].split(":", 1)[1]
            if name not in files:
                raise subprocess.CalledProcessError(128, command, stderr=b"missing file")
            value = files[name]
        else:
            raise AssertionError(command)
        return subprocess.CompletedProcess(command, 0,
                                           value.decode() if kwargs.get("text") else value)

    monkeypatch.setattr(build_release.subprocess, "run", git_run)
    return build_release, files, checkout, prefix


def test_archive_is_independent_of_uncommitted_policy_and_installer(committed_release, tmp_path, monkeypatch):
    build_release, _, checkout, _ = committed_release
    from tools import public_distribution
    first = build_release.build(tmp_path / "first", ref="HEAD", channel="stable", audience="public")
    (checkout / "install.sh").write_text("uncommitted installer\n", encoding="utf-8")
    monkeypatch.setattr(public_distribution, "is_private_only", lambda path: path == "README.md")
    second = build_release.build(tmp_path / "second", ref="HEAD", channel="stable", audience="public")
    assert first["sha256"] == second["sha256"]
    assert Path(first["installer"]).read_bytes() == Path(second["installer"]).read_bytes()


def test_publisher_refuses_its_uncommitted_source_before_output(committed_release, tmp_path):
    build_release, _, checkout, _ = committed_release
    publisher = checkout / "tools" / "build_release.py"
    publisher.write_bytes(publisher.read_bytes() + b"\n# unreviewed publisher change\n")
    output = tmp_path / "release"
    with pytest.raises(SystemExit, match="RELEASE_PUBLISHER_MISMATCH.*tools/build_release.py"):
        build_release.build(output, ref="HEAD", channel="stable", audience="public")
    assert not output.exists()


def test_annotated_tag_names_the_commit_and_builds_identical_bytes(committed_release, tmp_path):
    build_release, _, _, _ = committed_release
    by_commit = build_release.build(tmp_path / "commit", ref="HEAD", channel="stable", audience="public")
    by_tag = build_release.build(tmp_path / "tag", ref="annotated-release", channel="stable", audience="public")
    assert by_tag["commit"] == by_commit["commit"]
    assert by_tag["sha256"] == by_commit["sha256"]
    assert Path(by_tag["archive"]).name == Path(by_commit["archive"]).name


def test_verifier_clears_inherited_pytest_options_and_runs_offline_suite(tmp_path, monkeypatch):
    from tools import verify_public_release as verifier
    monkeypatch.setenv("PYTEST_ADDOPTS", "-k hidden_selection")
    monkeypatch.setenv("PYTEST_PLUGINS", "unreviewed_plugin")
    captured = {}

    def run(command, **kwargs):
        captured.update(command=command, **kwargs)
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(verifier.subprocess, "run", run)
    assert verifier.run_suite(tmp_path, genome_models=0, cardiac_models=0) == 0
    assert "PYTEST_ADDOPTS" not in captured["env"]
    assert "PYTEST_PLUGINS" not in captured["env"]
    assert captured["command"][-3:] == [str(tmp_path), "-m", "not network"]
    assert '"-rfEs"' in captured["command"][6]


@pytest.mark.parametrize("cardiac_models", [None, 0, 1])
def test_verifier_defaults_to_required_cardiac_with_explicit_base_only(
        tmp_path: Path, monkeypatch: pytest.MonkeyPatch, cardiac_models: int | None) -> None:
    """Technical subprocess recorder: no model acquisition or process launch."""
    from tools import verify_public_release as verifier

    captured = {}
    staged = []
    cached = tmp_path / "technical-cached.cellml"

    def stage(source: Path, cardiac_model: Path | None = None) -> Path:
        staged.append((source, cardiac_model))
        return cached

    def run(command: list[str], **kwargs) -> subprocess.CompletedProcess[str]:
        captured.update(command=command, **kwargs)
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(verifier, "stage_cardiac_asset", stage, raising=False)
    monkeypatch.setattr(verifier.subprocess, "run", run)
    options = {} if cardiac_models is None else {"cardiac_models": cardiac_models}
    assert verifier.run_suite(tmp_path, genome_models=0, cardiac_model=cached, **options) == 0
    required = cardiac_models != 0
    assert captured["env"]["LIVEMORE_TEST_CARDIAC"] == ("1" if required else "0")
    assert staged == ([(tmp_path, cached)] if required else [])


@pytest.fixture
def technical_cardiac_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> tuple[Path, bytes]:
    """Pinned technical stand-in bytes only, never a physiological model."""
    from livemorebio import model_assets

    payload = b"<technical-cardiac-fixture/>\n"
    cached = tmp_path / "technical-cached.cellml"
    cached.write_bytes(payload)
    manifest = {"assets": {"cellml": {
        "filename": "technical-model.cellml", "size_bytes": len(payload),
        "sha256": hashlib.sha256(payload).hexdigest(),
    }}}
    monkeypatch.setattr(model_assets, "asset_manifest", lambda model: manifest)
    monkeypatch.setattr(model_assets, "verified_cardiac_path", lambda: cached)
    return cached, payload


@pytest.mark.parametrize("explicit_cache", [False, True])
def test_verifier_stages_only_verified_cardiac_bytes_outside_the_archive(
        tmp_path: Path, technical_cardiac_cache: tuple[Path, bytes], explicit_cache: bool) -> None:
    from tools import verify_public_release as verifier

    cached, payload = technical_cardiac_cache
    source = tmp_path / "technical-extracted"
    source.mkdir()
    archive = tmp_path / "technical-public.tar.gz"
    archive.write_bytes(b"technical immutable archive stand-in")
    archive_before = archive.read_bytes()
    result = verifier.stage_cardiac_asset(source, cardiac_model=cached if explicit_cache else None)

    assert result == source / "models" / "cardiac" / "technical-model.cellml"
    assert result.read_bytes() == payload
    assert archive.read_bytes() == archive_before
    assert cached.read_bytes() == payload
    # A verified installed copy needs no second source read or acquisition.
    assert verifier.stage_cardiac_asset(source, cardiac_model=tmp_path / "absent-cache") == result


@pytest.mark.parametrize("problem", ["missing", "mismatched", "oversized", "symlink"])
def test_verifier_rejects_missing_or_unpinned_cardiac_cache_before_staging(
        tmp_path: Path, technical_cardiac_cache: tuple[Path, bytes], problem: str) -> None:
    from tools import verify_public_release as verifier

    cached, payload = technical_cardiac_cache
    candidate = tmp_path / "technical-candidate.cellml"
    if problem == "mismatched":
        candidate.write_bytes(b"x" * len(payload))
    elif problem == "oversized":
        candidate.write_bytes(payload + b"x")
    elif problem == "symlink":
        candidate.symlink_to(cached)
    source = tmp_path / "technical-extracted"
    source.mkdir()
    with pytest.raises((OSError, ValueError), match="CARDIAC"):
        verifier.stage_cardiac_asset(source, cardiac_model=candidate)
    assert not (source / "models" / "cardiac" / "technical-model.cellml").exists()


def test_verifier_refuses_to_replace_a_mismatched_installed_cardiac_file(
        tmp_path: Path, technical_cardiac_cache: tuple[Path, bytes]) -> None:
    from tools import verify_public_release as verifier

    cached, _ = technical_cardiac_cache
    source = tmp_path / "technical-extracted"
    target = source / "models" / "cardiac" / "technical-model.cellml"
    target.parent.mkdir(parents=True)
    target.write_bytes(b"technical wrong installed bytes")
    with pytest.raises(ValueError, match="CARDIAC_MODEL_HASH_MISMATCH"):
        verifier.stage_cardiac_asset(source, cardiac_model=cached)
    assert target.read_bytes() == b"technical wrong installed bytes"


def test_verifier_bootstrap_verifies_cardiac_from_the_extracted_package(
        tmp_path: Path) -> None:
    """Technical package writes a marker; the bootstrap never starts pytest."""
    from tools.verify_public_release import _TEST_BOOTSTRAP

    source = tmp_path / "technical-public"
    package = source / "livemorebio"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "model_assets.py").write_text('''from pathlib import Path
def verified_asset(model):
    assert model == "cardiac"
    Path(__file__).with_name("technical-verified").write_text("technical cardiac verified", encoding="utf-8")
    return {"model_sha256": "technical-digest"}
''', encoding="utf-8")
    probe = '''import pathlib, runpy, sys
def run_tests(*args, **kwargs):
    assert (pathlib.Path(sys.path[0]) / "livemorebio" / "technical-verified").is_file()
runpy.run_module = run_tests
'''
    environment = {**os.environ, "LIVEMORE_TEST_GENOME_MODELS": "0", "LIVEMORE_TEST_CARDIAC": "1"}
    result = subprocess.run([sys.executable, "-I", "-B", "-c", probe + _TEST_BOOTSTRAP, str(source)],
                            capture_output=True, text=True, env=environment, encoding="utf-8")
    assert result.returncode == 0, result.stdout + result.stderr


@pytest.mark.parametrize("missing", ["LICENSE", "THIRD_PARTY_NOTICES.md", "install.sh"])
def test_missing_committed_release_input_refuses_before_output(committed_release, tmp_path, missing):
    build_release, files, _, _ = committed_release
    del files[missing]
    output = tmp_path / "release"
    with pytest.raises(SystemExit, match="RELEASE_INPUT_MISSING.*" + missing):
        build_release.build(output, ref="HEAD", channel="stable", audience="public")
    assert not output.exists()


@pytest.mark.parametrize("mutation", ["added", "removed", "case-variant"])
def test_manifest_rejects_unreviewed_archive_membership(committed_release, tmp_path, mutation):
    build_release, files, _, _ = committed_release
    if mutation == "added":
        files["unreviewed.txt"] = b"technical fixture"
    elif mutation == "removed":
        del files["README.md"]
    else:
        files["Readme.md"] = files.pop("README.md")
    with pytest.raises(ValueError, match="PUBLIC_MANIFEST_MISMATCH"):
        build_release.build(tmp_path / "release", ref="HEAD", channel="stable", audience="public")


@pytest.mark.parametrize("kind", [tarfile.SYMTYPE, tarfile.LNKTYPE], ids=["symbolic", "hard"])
def test_publisher_rejects_links_before_filtering(kind):
    from tools.build_release import _filter_tar
    with pytest.raises(ValueError, match="UNSAFE_ARCHIVE_MEMBER"):
        _filter_tar(_tar({"README.md": b"ok"}, "test/", link=kind), "test/")


@pytest.mark.parametrize("path", ["Docs/solutions/x.md", "DOCS/HANDOFF.md", "Trials/synthetic.json",
                                   "Livemorebio/discovery/data/technical.json", "Tools/OSP_stage_b.py"])
def test_private_roots_are_case_insensitive(path):
    from tools.public_distribution import is_private_only
    assert is_private_only(path)


def test_public_manifest_is_exact_sorted_actual_publisher_output(tmp_path):
    require_git_checkout("checking the public archive manifest")
    from tools.build_release import build
    result = build(tmp_path, ref=os.environ.get("LIVEMORE_REVIEW_ARCHIVE_REF", "HEAD"),
                   channel="stable", audience="public")
    prefix = f"livemorebio-{result['commit']}/"
    with tarfile.open(result["archive"]) as archive:
        member = archive.extractfile(prefix + "tools/public_release_manifest.txt")
        assert member is not None
        expected = member.read().decode().splitlines()
        assert expected == sorted(set(expected))
        assert _member_paths(archive, prefix) == expected


def test_verifier_refuses_reused_extraction_directory(committed_release, tmp_path):
    from tools.verify_public_release import build_projection
    destination = tmp_path / "verification"
    _, source = build_projection(destination, "HEAD")
    stale = source / "stale.txt"
    stale.write_text("technical stale evidence", encoding="utf-8")
    with pytest.raises(ValueError, match="EXTRACTION_DIRECTORY_NOT_EMPTY"):
        build_projection(destination, "HEAD")
    assert stale.read_text(encoding="utf-8") == "technical stale evidence"


def test_verifier_bootstrap_cannot_import_omitted_module_from_editable_finder(tmp_path):
    from tools.verify_public_release import _TEST_BOOTSTRAP
    source = tmp_path / "public"
    package = source / "livemorebio"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("", encoding="utf-8")
    private = tmp_path / "private_report.py"
    private.write_text("SECRET_FALLBACK = True\n", encoding="utf-8")
    probe = '''import importlib.util, runpy, sys
private_filename = sys.argv[2]
class Finder:
    __module__ = "__editable___technical_private_finder"
    @classmethod
    def find_spec(cls, fullname, path=None, target=None):
        if fullname == "livemorebio.report":
            return importlib.util.spec_from_file_location(fullname, private_filename)
sys.meta_path.append(Finder)
def run_tests(*args, **kwargs):
    try:
        import livemorebio.report
    except ModuleNotFoundError:
        return
    raise AssertionError("PRIVATE_EDITABLE_FALLBACK")
runpy.run_module = run_tests
'''
    # The bootstrap checks the Human-GEM asset when LIVEMORE_TEST_GENOME_MODELS=1,
    # by importing a module this stand-in package does not have. The installer and
    # the hosted Installer job both set that switch, and the child inherited it, so
    # a default client install stopped at this test. The asset is not what this
    # test is about; the child runs with the switch off.
    environment = {**os.environ, "LIVEMORE_TEST_GENOME_MODELS": "0", "LIVEMORE_TEST_CARDIAC": "0"}
    result = subprocess.run([sys.executable, "-I", "-B", "-c", probe + _TEST_BOOTSTRAP,
                             str(source), str(private)], capture_output=True, text=True,
                            env=environment, encoding="utf-8")
    assert result.returncode == 0, result.stdout + result.stderr
