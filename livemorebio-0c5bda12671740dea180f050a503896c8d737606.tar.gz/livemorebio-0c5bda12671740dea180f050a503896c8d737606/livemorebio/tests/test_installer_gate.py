"""Gate orchestration with a technical archive; no dependencies or services installed."""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

import pytest

from ._source_tree import git_executable, no_git_checkout_reason, source_tree_only

@pytest.fixture()
def gate_module():
    from tools import installer_gate
    return installer_gate


@pytest.fixture()
def technical_release(gate_module, monkeypatch):
    commit = "a" * 40
    behavior = {"mode": "success"}

    def build(python, pinned, audience, output, environment):
        assert pinned == commit
        assert audience == "public"
        assert list(Path(environment["HOME"]).iterdir()) == []
        output.mkdir()
        installer = b'''#!/bin/bash
set -euo pipefail
[[ -z "${LIVEMORE_AEGLE_URL-}" ]]
[[ -n "$LIVEMORE_ARCHIVE" && -n "$LIVEMORE_SHA256" ]]
base="$HOME/.local/share/livemorebio"
release="$base/releases/$LIVEMORE_REF"
mkdir -p "$release" "$HOME/.local/bin"
printf '[LivemoreBio] Running the complete release test suite...\\n'
'''
        mode = behavior["mode"]
        if mode == "no-enclosing-git":
            installer += b'''if git rev-parse --show-toplevel >"$HOME/enclosing-git.txt" 2>&1; then
    echo 'archive discovered an enclosing checkout' >&2
    exit 33
fi
'''
        if mode == "failure":
            installer += b"exit 17\n"
        else:
            if mode != "no-marker":
                installer += b'''printf 'commit=%s\\n' "$LIVEMORE_REF" >"$release/.livemore-install-complete"
'''
            target = '"$release"' if mode != "wrong-current" else '"$base/wrong"'
            installer += f'ln -s {target} "$base/current"\n'.encode()
            installer += b'''printf '#!/bin/sh\\nexit 0\\n' >"$HOME/.local/bin/livemore"
chmod +x "$HOME/.local/bin/livemore"
printf '[LivemoreBio] Installation complete.\\n'
'''
        archive = output / f"livemorebio-{commit}.tar.gz"
        with tarfile.open(archive, "w:gz") as bundle:
            entry = tarfile.TarInfo(f"livemorebio-{commit}/install.sh")
            entry.size = len(installer)
            bundle.addfile(entry, io.BytesIO(installer))
        return {"commit": commit, "archive": str(archive),
                "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}

    monkeypatch.setattr(gate_module, "_resolve_commit", lambda ref: commit)
    monkeypatch.setattr(gate_module, "_build_release", build)
    return behavior


def _run(gate_module, output):
    return gate_module.run_gate(output=output, ref="HEAD", audience="public",
                                python=Path(sys.executable), models="none",
                                guard_dir=None, guard_log=None)


def test_gate_runs_archive_installer_and_records_activation_then_cleans_home(
    gate_module, technical_release, tmp_path, monkeypatch
):
    monkeypatch.setenv("LIVEMORE_AEGLE_URL", "http://127.0.0.1:18860")
    output = tmp_path / "gate"
    receipt = _run(gate_module, output)
    assert receipt["status"] == "passed"
    assert receipt["commit"] == "a" * 40
    assert json.loads((output / "receipt.json").read_text(encoding="utf-8")) == receipt
    assert (output / "archive-install.sh").is_file()
    assert "Installation complete." in (output / "install.log").read_text(encoding="utf-8")
    for name in ("home", "tmp", "data", "toolchain"):
        assert not (output / name).exists()


@pytest.mark.parametrize("mode", ["failure", "no-marker", "wrong-current"])
def test_gate_refuses_installer_failure_or_incomplete_activation(
    gate_module, technical_release, tmp_path, mode
):
    technical_release["mode"] = mode
    output = tmp_path / "gate"
    with pytest.raises((RuntimeError, subprocess.CalledProcessError)):
        _run(gate_module, output)
    assert not (output / "receipt.json").exists()
    assert not (output / "home").exists()
    assert not (output / "tmp").exists()


def test_gate_refuses_a_reused_output_without_touching_it(gate_module, tmp_path):
    sentinel = tmp_path / "sentinel"
    sentinel.write_text("keep", encoding="utf-8")
    with pytest.raises(FileExistsError):
        _run(gate_module, tmp_path)
    assert sentinel.read_text(encoding="utf-8") == "keep"


@source_tree_only(".git")
@pytest.mark.skipif(git_executable() is None, reason=no_git_checkout_reason("technical git histories"))
def test_gate_archive_cannot_borrow_an_enclosing_git_checkout(gate_module, technical_release, tmp_path):
    enclosing = tmp_path / "technical-checkout"
    enclosing.mkdir()
    subprocess.run([git_executable(), "init", "-q", str(enclosing)], check=True)
    technical_release["mode"] = "no-enclosing-git"
    receipt = _run(gate_module, enclosing / "gate")
    assert receipt["status"] == "passed"


@pytest.mark.parametrize("in_venv", [False, True])
def test_gate_python_launcher_loads_guard_even_with_isolated_python(gate_module, tmp_path, in_venv):
    guard = tmp_path / "guard"
    guard.mkdir()
    inherited_guard = getattr(sys.modules.get("sitecustomize"), "__file__", None)
    safety_bootstrap = f"import runpy\nrunpy.run_path({inherited_guard!r})\n" if inherited_guard else ""
    (guard / "sitecustomize.py").write_text(safety_bootstrap + "import os\nos.environ['TECHNICAL_GUARD_LOADED']='1'\n", encoding="utf-8")
    toolchain = tmp_path / "toolchain"
    toolchain.mkdir()
    launcher = gate_module._guarded_python(Path(sys.executable), toolchain, guard)
    executable = launcher
    if in_venv:
        venv = tmp_path / "new-venv"
        subprocess.run([str(launcher), "-m", "venv", "--without-pip", str(venv)], check=True)
        executable = venv / "bin/python"
    result = subprocess.run([str(executable), "-I", "-B", "-c",
                             "import os; assert os.environ['TECHNICAL_GUARD_LOADED'] == '1'"],
                            env=dict(os.environ), capture_output=True, text=True, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("failure", ["missing", "broken"])
def test_gate_new_venv_refuses_to_start_without_a_working_guard(gate_module, tmp_path, failure):
    guard = tmp_path / "guard"
    guard.mkdir()
    guard_file = guard / "sitecustomize.py"
    guard_file.write_text("# Technical guard before fault injection.\n", encoding="utf-8")
    toolchain = tmp_path / "toolchain"
    toolchain.mkdir()
    launcher = gate_module._guarded_python(Path(sys.executable), toolchain, guard)
    venv = tmp_path / "new-venv"
    subprocess.run([str(launcher), "-m", "venv", "--without-pip", str(venv)], check=True)
    if failure == "missing":
        guard_file.unlink()
    else:
        guard_file.write_text("raise RuntimeError('technical broken guard')\n", encoding="utf-8")
    result = subprocess.run([str(venv / "bin/python"), "-I", "-B", "-c", "pass"],
                            env=dict(os.environ), capture_output=True, text=True, encoding="utf-8")
    assert result.returncode == 78, result.stderr
