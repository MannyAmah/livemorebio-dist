"""Technical UI contracts only; actual publisher rendering is an independent gate."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest
from ._node import flush_js, require_node, run_node as _run_node

CONSOLE = Path(__file__).parents[1] / "aegle/console"


def node(program: str) -> str:
    runtime = require_node()
    result = _run_node([runtime,"--input-type=module","--eval",program],capture_output=True,text=True,timeout=20, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    return result.stdout


def technical_manifest():
    declaration = json.loads((Path(__file__).parents[1]/"anatomy/atlas/bp3d-4.0-20130619-surface-core-v1.json").read_text(encoding="utf-8"))
    members = {m["element_id"]:m for m in declaration["members"]}
    assets=[]
    for group in declaration["groups"]:
        nodes=[{"element_id":key,"node_name":"bp3d:"+key,"mesh_name":"bp3d-mesh:"+key,"node_index":i+1,"mesh_index":i,
                "asset_key":group["asset_key"],"memberships":[{"asset_key":group["asset_key"],"logic":group["logic"],"fma":group["fma"]}]}
               for i,key in enumerate(sorted(group["element_ids"]))]
        assets.append({"asset_key":group["asset_key"],"sha256":"b"*64,"bytes":100,"audit":{"element_ids":sorted(group["element_ids"]),"nodes":nodes,
                      "triangles":sum(members[key]["triangles"] for key in group["element_ids"]),
                      "vertices":sum(members[key]["vertices"] for key in group["element_ids"]),
                      "native_bounds_mm":[[-335,-247,-79],[334,47,1642]],"world_bounds_m":[[-.335,-.079,-.047],[.334,1.642,.247]]}})
    return {"schema":"livemore.atlas-reference.v1","source_id":declaration["source_id"],"evidence_state":"REFERENCE_ONLY",
            "patient_registered":False,"groups":declaration["groups"],"members":declaration["members"],"assets":assets,
            "conversion":{"root_matrix_column_major":[.001,0,0,0,0,0,-.001,0,0,.001,0,0,0,0,0,1]},
            "rights":{"license":"CC-BY-4.0","historical_notice":"CC-BY-SA-2.1-JP"}}


def test_reference_manifest_keeps_exact_source_nodes_units_and_no_patient_claim():
    module=(CONSOLE/"lib/atlas_reference_contract.js").as_uri()
    result=node(f"""import {{validateAtlasManifest,assetURL}} from {json.dumps(module)};
const source={json.dumps(technical_manifest())};const before=JSON.stringify(source);
const result=validateAtlasManifest(source,'a'.repeat(64));
if(result.members.length!==489||result.assets.length!==9||JSON.stringify(source)!==before)throw Error('source mutated');
if(assetURL('a'.repeat(64),'heart')!=='/assets/anatomy/atlas/'+ 'a'.repeat(64)+'/heart.glb')throw Error('wrong route');
console.log('ok');""")
    assert result.strip()=="ok"


@pytest.mark.parametrize("change",["patient","scale","missing","duplicate","node_boolean","wrong_hash","wrong_membership"])
def test_malformed_or_ambiguous_manifest_rejected(change):
    manifest=technical_manifest()
    if change=="patient":manifest["patient_registered"]=True
    elif change=="scale":manifest["conversion"]["root_matrix_column_major"][0]=1
    elif change=="missing":manifest["members"].pop()
    elif change=="duplicate":manifest["assets"][1]["asset_key"]="skin"
    elif change=="node_boolean":manifest["assets"][0]["audit"]["nodes"][0]["node_index"]=True
    elif change=="wrong_hash":manifest["assets"][0]["sha256"]="bad"
    else:manifest["assets"][0]["audit"]["nodes"][0]["memberships"]=[{"fma":"wrong"}]
    module=(CONSOLE/"lib/atlas_reference_contract.js").as_uri()
    assert node(f"""import {{validateAtlasManifest}} from {json.dumps(module)};
let rejected=false;try{{validateAtlasManifest({json.dumps(manifest)},'a'.repeat(64))}}catch{{rejected=true}}
if(!rejected)throw Error('accepted malformed source');console.log('ok');""").strip()=="ok"


def test_asset_requests_are_hash_bound_deduplicated_cancelable_and_never_install():
    module=(CONSOLE/"lib/atlas_reference_requests.js").as_uri()
    assert node(f"""import {{createAtlasAssetRequests}} from {json.dumps(module)};
const bytes=new TextEncoder().encode('TECHNICAL NOT GLB');const hash=Buffer.from(await crypto.subtle.digest('SHA-256',bytes)).toString('hex');
let calls=0,resolve;const fetchImpl=async(url,init)=>{{calls++;if(init.method&&init.method!=='GET')throw Error('mutating asset load');await new Promise(r=>resolve=r);return new Response(bytes,{{headers:{{'Content-Type':'model/gltf-binary','X-Content-SHA256':hash,'X-Atlas-Manifest-SHA256':'a'.repeat(64)}}}})}};
const requests=createAtlasAssetRequests({{fetchImpl}}),asset={{asset_key:'skin',sha256:hash,bytes:bytes.length}};
const one=requests.load('a'.repeat(64),asset),two=requests.load('a'.repeat(64),asset);
if(one!==two)throw Error('duplicate owned request');resolve();await one;
if(calls!==1)throw Error('duplicate fetch');requests.dispose();
let rejected=false;try{{await requests.load('a'.repeat(64),asset)}}catch{{rejected=true}}if(!rejected)throw Error('disposed request accepted');console.log('ok');""").strip()=="ok"


@pytest.mark.parametrize("fault",["hash","header","length","type","redirect"])
def test_asset_requests_reject_wrong_bytes_and_metadata(fault):
    module=(CONSOLE/"lib/atlas_reference_requests.js").as_uri()
    assert node(f"""import {{createAtlasAssetRequests}} from {json.dumps(module)};
const fault={json.dumps(fault)},bytes=new TextEncoder().encode('TECHNICAL NOT GLB'),hash=Buffer.from(await crypto.subtle.digest('SHA-256',bytes)).toString('hex');
const requests=createAtlasAssetRequests({{fetchImpl:async()=>new Response(bytes,{{status:fault==='redirect'?302:200,headers:{{'Content-Type':fault==='type'?'text/html':'model/gltf-binary','X-Content-SHA256':fault==='header'?'0'.repeat(64):hash,'X-Atlas-Manifest-SHA256':'a'.repeat(64)}}}})}});
let rejected=false;try{{await requests.load('a'.repeat(64),{{asset_key:'skin',sha256:fault==='hash'?'0'.repeat(64):hash,bytes:bytes.length+(fault==='length'?1:0)}})}}catch{{rejected=true}}requests.dispose();
if(!rejected)throw Error('wrong asset admitted');console.log('ok');""").strip()=="ok"


def test_renderer_mount_is_dedicated_whole_person_not_legacy_montage_or_scalar_tint():
    html=(CONSOLE/"workspace.html").read_text(encoding="utf-8")
    script=(CONSOLE/"lib/workspace.js").read_text(encoding="utf-8")
    assert 'id="atlas-reference-host"' in html
    assert 'id="living-body"' not in html
    assert "mountAtlasReference" in script
    assert "--metabolic-intensity" not in script
    assert "createAnatomyExplorer" not in script
    for identifier in ("focus-readout","time-slider","glucose-chart","insulin-chart","intervention-form","open-biology-context"):
        assert f'id="{identifier}"' in html


@pytest.mark.parametrize("fault", [None, "node", "source", "root", "extra", "uri"])
def test_loaded_source_node_binding_uses_parser_indices_not_sanitized_names(fault):
    module=(CONSOLE/"lib/atlas_reference_loader.js").as_uri()
    assert node(f"""import {{bindAtlasPartition}} from {json.dumps(module)};
const fault={json.dumps(fault)},M=[.001,0,0,0,0,0,-.001,0,0,.001,0,0,0,0,0,1],I=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const member={{element_id:'FJ1',source_sha256:'b'.repeat(64)}},audit={{element_id:'FJ1',node_name:'bp3d:FJ1',node_index:1,mesh_name:'bp3d-mesh:FJ1',mesh_index:0}};
const object={{name:'bp3dFJ1',userData:{{name:'bp3d:FJ1',element_id:'FJ1',source_sha256:'b'.repeat(64)}},isMesh:true,matrix:{{elements:I}},children:[],geometry:{{}}}};
const root={{name:'bp3d-native',matrix:{{elements:M}},children:[object]}};
const scene={{matrix:{{elements:I}},children:[root],traverse(fn){{fn(this);fn(root);fn(object)}}}};
const json={{asset:{{version:'2.0'}},scene:0,scenes:[{{nodes:[0]}}],nodes:[{{name:'bp3d-native',matrix:M,children:[1]}},{{name:'bp3d:FJ1',mesh:0}}],meshes:[{{name:'bp3d-mesh:FJ1',extras:{{element_id:'FJ1',source_sha256:'b'.repeat(64)}},primitives:[{{attributes:{{POSITION:0,NORMAL:1}},indices:2,mode:4}}]}}],buffers:[{{byteLength:12}}],bufferViews:[],accessors:[]}};
if(fault==='node')audit.node_index=2;if(fault==='source')object.userData.source_sha256='c'.repeat(64);if(fault==='root')root.matrix.elements=I;
if(fault==='extra')json.animations=[];if(fault==='uri')json.buffers[0].uri='https://not-admitted.invalid';
const parser={{json,associations:new Map([[root,{{nodes:0}}],[object,{{nodes:1,meshes:0}}]])}};
let rejected=false,result;try{{result=bindAtlasPartition({{scene,parser}},{{audit:{{nodes:[audit]}}}},new Map([['FJ1',member]]))}}catch{{rejected=true}}
if(fault&&!rejected)throw Error('ambiguous GLB accepted');if(!fault&&(rejected||result.get('FJ1')!==object))throw Error('exact node binding failed');console.log('ok');""").strip()=="ok"


def test_partition_queue_draws_skin_before_internals_and_cancels_stale_work():
    module=(CONSOLE/"lib/atlas_reference_loader.js").as_uri()
    assert node(f"""import {{loadAtlasPartitions}} from {json.dumps(module)};
const events=[],assets=[{{asset_key:'skin'}},...Array.from({{length:8}},(_,i)=>({{asset_key:'internal-'+i}}))];let active=0,max=0,disposed=false;
await loadAtlasPartitions(assets,async asset=>{{active++;max=Math.max(active,max);events.push('start-'+asset.asset_key);await new Promise(r=>setTimeout(r,1));active--;events.push('draw-'+asset.asset_key)}},()=>disposed);
if(events[0]!=='start-skin'||events[1]!=='draw-skin'||max!==2)throw Error('surface/concurrency contract');
let calls=0;await loadAtlasPartitions(assets,async()=>{{calls++;disposed=true}},()=>disposed);if(calls!==1)throw Error('stale load continued');console.log('ok');""").strip()=="ok"


def test_real_pinned_loader_preserves_converted_technical_source_association():
    import base64
    from livemorebio.anatomy import _atlas_geometry as geometry
    from livemorebio.tests.test_atlas_reference_geometry import technical_obj
    raw, member = technical_obj()
    parsed = geometry.parse_obj(raw, member)
    content = geometry.convert_partition("skin", [parsed])
    audit = geometry.verify_partition(content, "skin", [parsed])
    assert node(f"""import {{GLTFLoader}} from {json.dumps((CONSOLE/'lib/anatomy_vendor.js').as_uri())};
import {{inspectAtlasGLB,bindAtlasPartition}} from {json.dumps((CONSOLE/'lib/atlas_reference_loader.js').as_uri())};
const bytes=Uint8Array.from(Buffer.from({json.dumps(base64.b64encode(content).decode())},'base64')).buffer;
inspectAtlasGLB(bytes);const gltf=await new GLTFLoader().parseAsync(bytes,'');
const result=bindAtlasPartition(gltf,{{audit:{json.dumps(audit)}}},new Map([[{json.dumps(member['element_id'])},{json.dumps(member)}]]));
if(result.size!==1)throw Error('actual pinned loader lost technical source');console.log('ok');""").strip()=="ok"


def test_reference_view_retry_retains_controls_without_physiological_inputs():
    module=(CONSOLE/"lib/atlas_reference_scene.js").as_uri()
    assert node(f"""import {{atlasViewState}} from {json.dumps(module)};
const source={{selected:'FJ2810',isolated:true,labels:true,axis:'z',depth:.27,skinOpacity:.4,groups:['skin','heart'],camera:{{position:[1,2,3],target:[0,1,0]}}}};
const next=atlasViewState(source);source.groups.push('brain');source.camera.position[0]=90;
if(next.axis!=='z'||next.depth!==.27||!next.labels||!next.isolated||next.groups.length!==2||next.camera.position[0]!==1)throw Error('retry lost or aliased state');
for(const invalid of [{{depth:NaN}},{{axis:'invented'}},{{groups:['made-up']}},{{skinOpacity:2}}]){{let rejected=false;try{{atlasViewState(invalid)}}catch{{rejected=true}}if(!rejected)throw Error('bad view state');}}
console.log('ok');""").strip()=="ok"


def test_mounted_missing_reference_requires_one_explicit_install_and_disposes_requests():
    module=(CONSOLE/"lib/atlas_reference.js").as_uri()
    assert node(f"""import {{mountAtlasReference}} from {json.dumps(module)};
const all=[];class E{{constructor(){{this.handlers={{}};this.dataset={{}};this.children=[];this.value='';this.style={{}};all.push(this)}}addEventListener(k,v){{this.handlers[k]=v}}removeEventListener(k){{delete this.handlers[k]}}setAttribute(){{}}append(...items){{this.children.push(...items)}}replaceChildren(...items){{this.children=items}}}}
const elements=new Map(),host=new E();host.querySelector=s=>{{if(!elements.has(s))elements.set(s,new E());return elements.get(s)}};host.querySelectorAll=s=>s==='[data-group]'?all.filter(e=>e.dataset.group):[];
globalThis.document={{hidden:false,createElement:()=>new E(),createTextNode:text=>({{textContent:text}}),addEventListener(){{}},removeEventListener(){{}}}};
const status={{schema:'livemore.atlas-reference-status.v1',source_id:'bp3d-4.0-20130619-surface-core-v1',state:'missing',available:false,reference_geometry:true,patient_registered:false,manifest:null,manifest_sha256:null,reason:'No admitted reference'}};
let posts=0,gets=0,finish,signal;const fetchImpl=async(url,init)=>{{if(init.method==='POST'){{posts++;signal=init.signal;return new Promise(resolve=>finish=resolve)}}gets++;return Response.json(status)}};
const mounted=mountAtlasReference(host,{{fetchImpl}});const flush=async()=>{{for(let i=0;i<30;i++)await new Promise(setImmediate)}};await flush();
if(posts!==0||gets!==1||host.dataset.referenceState!=='unavailable')throw Error('missing source caused hidden action');
const action=elements.get('[data-install]').handlers.click();elements.get('[data-install]').handlers.click();await flush();if(posts!==1)throw Error('duplicate install');
finish(Response.json({{error:'Technical rejection'}},{{status:503}}));await action;await flush();if(posts!==1||gets!==2)throw Error('mutation retried automatically');
const second=elements.get('[data-install]').handlers.click();await flush();mounted.dispose();if(!signal.aborted)throw Error('owned request not canceled on close');finish(Response.json(status));await second;
console.log('ok');""").strip()=="ok"


def test_mounted_reference_cancels_hidden_load_and_restores_same_source_retry_state():
    module=(CONSOLE/"lib/atlas_reference.js").as_uri()
    assert node(f"""import {{mountAtlasReference}} from {json.dumps(module)};
import {{atlasViewState}} from {json.dumps((CONSOLE/'lib/atlas_reference_scene.js').as_uri())};
const all=[],handlers={{}};class E{{constructor(){{this.handlers={{}};this.dataset={{}};this.children=[];this.value='';this.style={{}};all.push(this)}}addEventListener(k,v){{this.handlers[k]=v}}removeEventListener(k){{delete this.handlers[k]}}setAttribute(){{}}append(...items){{this.children.push(...items)}}replaceChildren(...items){{this.children=items}}}}
const elements=new Map(),host=new E();host.querySelector=s=>{{if(!elements.has(s))elements.set(s,new E());return elements.get(s)}};host.querySelectorAll=s=>s==='[data-group]'?all.filter(e=>e.dataset.group):[];
globalThis.document={{hidden:false,createElement:()=>new E(),createTextNode:text=>({{textContent:text}}),addEventListener(k,v){{handlers[k]=v}},removeEventListener(k){{delete handlers[k]}}}};
const manifest={json.dumps(technical_manifest())},bytes=new Uint8Array(100),hash=Buffer.from(await crypto.subtle.digest('SHA-256',bytes)).toString('hex');manifest.assets.forEach(a=>a.sha256=hash);
const status={{schema:'livemore.atlas-reference-status.v1',source_id:manifest.source_id,state:'available',available:true,reference_geometry:true,patient_registered:false,manifest,manifest_sha256:'a'.repeat(64)}};
let held,hold=true,applied=0,created=[],visibleCount=0;const fetchImpl=async(url,init)=>{{if(url.startsWith('/api/'))return Response.json(status);if(hold)await new Promise(resolve=>held=resolve);return new Response(bytes,{{headers:{{'Content-Type':'model/gltf-binary','X-Content-SHA256':hash,'X-Atlas-Manifest-SHA256':'a'.repeat(64)}}}})}};
const createScene=config=>{{let state=atlasViewState(config.initialView);created.push(state);return {{async addPartition(a,b,current){{if(!current())throw Error('canceled');applied++}},view:()=>atlasViewState(state),update:next=>state=atlasViewState(next),select:id=>{{state.selected=id;config.onSelect(id)}},visible:()=>visibleCount++,dispose(){{}},metrics:()=>({{loaded_elements:applied}})}}}};
{flush_js(40)}const mounted=mountAtlasReference(host,{{fetchImpl,loadDependencies:async()=>({{}}),createScene}});await flush();
document.hidden=true;handlers.visibilitychange();hold=false;held();await flush();if(applied!==0)throw Error('hidden stale source appended');
document.hidden=false;handlers.visibilitychange();await flush();if(applied!==9||host.dataset.referenceState!=='ready'||visibleCount!==2)throw Error('visible resume failed');
elements.get('[data-axis]').value='z';elements.get('[data-axis]').handlers.change();elements.get('[data-depth]').value='.37';elements.get('[data-depth]').handlers.input();elements.get('[data-labels]').checked=true;elements.get('[data-labels]').handlers.change();
elements.get('[data-skin]').handlers.click();elements.get('[data-isolate]').handlers.click();elements.get('[data-retry]').handlers.click();await flush();
const restored=created.at(-1);if(created.length!==2||restored.axis!=='z'||restored.depth!==.37||!restored.labels||!restored.isolated||!restored.selected)throw Error('retry controls not restored');
mounted.dispose();console.log('ok');""").strip()=="ok"


def test_scene_controls_preserve_actual_loaded_vertex_coordinates_and_cancel_late_parse():
    import base64
    from livemorebio.anatomy import _atlas_geometry as geometry
    from livemorebio.tests.test_atlas_reference_geometry import technical_obj
    raw, member = technical_obj()
    part = geometry.parse_obj(raw, member)
    content = geometry.convert_partition("skin", [part])
    audit = geometry.verify_partition(content, "skin", [part])
    assert node(f"""import * as vendor from {json.dumps((CONSOLE/'lib/anatomy_vendor.js').as_uri())};
import {{createAtlasReferenceScene}} from {json.dumps((CONSOLE/'lib/atlas_reference_scene.js').as_uri())};
class E{{constructor(){{this.clientWidth=600;this.clientHeight=600;this.style={{}};this.handlers={{}}}}setAttribute(){{}}addEventListener(k,v){{this.handlers[k]=v}}removeEventListener(k){{delete this.handlers[k]}}replaceChildren(){{}}append(){{}}getBoundingClientRect(){{return {{width:90,height:20}}}}}}
globalThis.document={{hidden:false,createElement:()=>new E()}};globalThis.window={{devicePixelRatio:1}};globalThis.ResizeObserver=class{{observe(){{}}disconnect(){{}}}};
let queued=[],disposed=0,drawn;globalThis.requestAnimationFrame=fn=>{{queued.push(fn);return queued.length}};globalThis.cancelAnimationFrame=id=>{{queued[id-1]=null}};
class Renderer{{constructor(){{this.domElement=new E();this.info={{render:{{calls:1,triangles:1}},memory:{{geometries:1}}}}}}setPixelRatio(v){{this.dpr=v}}getPixelRatio(){{return this.dpr}}setSize(){{}}render(scene){{scene.updateMatrixWorld(true);drawn=scene}}dispose(){{disposed++}}forceContextLoss(){{}}}}
class Controls{{constructor(){{this.target=new vendor.THREE.Vector3()}}addEventListener(){{}}removeEventListener(){{}}update(){{}}dispose(){{}}}}
const input={{host:new E(),vendor:{{...vendor,THREE:{{...vendor.THREE,WebGLRenderer:Renderer}},OrbitControls:Controls}},manifest:{{members:[{json.dumps(member)}],assets:[{{asset_key:'skin',audit:{json.dumps(audit)}}}]}}}};
const bytes=Uint8Array.from(Buffer.from({json.dumps(base64.b64encode(content).decode())},'base64')).buffer,asset=input.manifest.assets[0],view=createAtlasReferenceScene(input);
await view.addPartition(asset,bytes);let object;drawn.traverse(item=>{{if(item.isMesh)object=item}});const before=[...object.geometry.attributes.position.array],world=object.matrixWorld.elements.slice();
view.select({json.dumps(member['element_id'])});view.update({{axis:'z',depth:.37,labels:true,isolated:true,skinOpacity:.4}});view.frameSelected();view.home('back');
for(const fn of queued.splice(0))fn?.();if(JSON.stringify(before)!==JSON.stringify([...object.geometry.attributes.position.array])||JSON.stringify(world)!==JSON.stringify(object.matrixWorld.elements))throw Error('view changed source coordinates');
if(queued.length)throw Error('idle rendering was scheduled');view.dispose();if(disposed!==1)throw Error('renderer not disposed');
const late=createAtlasReferenceScene(input);let rejected=false;try{{await late.addPartition(asset,bytes,()=>false)}}catch{{rejected=true}}if(!rejected||late.metrics().loaded_groups!==0)throw Error('stale parsed asset appended');late.dispose();console.log('ok');""").strip()=="ok"
