"""HTTP execution ownership; technical fixtures are not physical evidence."""
from copy import deepcopy
from dataclasses import asdict
from types import SimpleNamespace
import json
import threading

import pytest
from fastapi.testclient import TestClient

TOKEN = "execution-api-technical-token-only"
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Idempotency-Key": "technical-prepare"}


@pytest.fixture
def product(tmp_path, monkeypatch):
    from livemorebio.aegle import server, execution_api
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, MetabolicProfile
    from livemorebio.tests.test_continuous_execution import TechnicalAdapter

    store = ExecutionStore(tmp_path / "execution.sqlite3", key=b"x" * 32)
    manager = ExecutionManager(store, {"metabolic-continuous-v1": TechnicalAdapter}, run_background=False)
    authority = ModelSourceAuthority(manager.invalidate_source)
    record = {"subject_id": "technical-subject", "twin_id": "twin-technical", "version": 1,
              "source_class": "SYNTHETIC", "lifecycle": "ACTIVE"}
    twin = SimpleNamespace(profile=MetabolicProfile(**asdict(HEALTHY)), meals=[(0., 75.)],
                           parameter_provenance=lambda: {"Gb": {"evidence_class": "REFERENCE_INITIALIZED"}})
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    monkeypatch.setattr(server, "_state", {"tw": twin, "subject": deepcopy(record)})
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(active_twin=lambda: deepcopy(record)))
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(execution_api, "_manager", lambda: manager)
    monkeypatch.setattr(execution_api, "_check_runtime_identity", lambda: None)
    value = SimpleNamespace(client=TestClient(server.app), manager=manager, authority=authority,
                            record=record, twin=twin, api=execution_api)
    yield value
    manager.close()


def prepare_body(product):
    return {"engine_contract_id": "metabolic-continuous-v1",
            "expected_source_generation": product.authority.generation,
            "expected_twin_id": product.record["twin_id"], "expected_twin_version": 1,
            "policy": {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}}


def prepare(product):
    response = product.client.post("/api/executions", json=prepare_body(product), headers=HEADERS)
    assert response.status_code == 201, response.text
    return response.json()


def control(product, record, action):
    return product.client.post(f"/api/executions/{record['execution_id']}/{action}",
        json={"expected_revision": record["revision"], "expected_source_generation": record["source_generation"]},
        headers=HEADERS)


def test_all_execution_routes_require_auth_before_store_access(product, monkeypatch):
    monkeypatch.setattr(product.api, "_manager", lambda: pytest.fail("unauthenticated store access"))
    for method, path in [("get", "/api/executions/capabilities"), ("get", "/api/executions/" + "a" * 32),
                         ("get", "/api/executions/" + "a" * 32 + "/frames"), ("post", "/api/executions")]:
        response = getattr(product.client, method)(path)
        assert response.status_code == 401
        assert "no-store" in response.headers["cache-control"]


def test_consumer_bind_and_renew_are_source_bound_revision_safe(product):
    state = prepare(product)
    body = {"session_id": "a" * 32, "source_snapshot_hash": state["source_snapshot_hash"],
            "expected_revision": state["revision"], "expected_source_generation": state["source_generation"]}
    response = product.client.post(f"/api/executions/{state['execution_id']}/consumer", json=body, headers=HEADERS)
    assert response.status_code == 200, response.text
    assert response.json()["consumer_lease"]["state"] == "valid"
    revision = response.json()["revision"]
    body.pop("expected_revision")
    response = product.client.post(f"/api/executions/{state['execution_id']}/consumer/renew", json=body, headers=HEADERS)
    assert response.status_code == 200 and response.json()["revision"] == revision
    response = product.client.post(f"/api/executions/{state['execution_id']}/consumer/renew",
        json=body | {"session_id": "b" * 32}, headers=HEADERS)
    assert response.status_code == 409


def test_observation_routes_require_auth_and_empty_selected_stream(product, monkeypatch):
    state = prepare(product)
    response = product.client.get(f"/api/executions/{state['execution_id']}/observations", headers=HEADERS)
    assert response.status_code == 200 and response.json()["streams"] == []
    monkeypatch.setattr(product.api, "_manager", lambda: pytest.fail("unauthenticated store access"))
    assert product.client.post("/api/execution-observations", json={}).status_code == 401
    assert product.client.get(f"/api/executions/{state['execution_id']}/observations").status_code == 401


@pytest.mark.parametrize("raw", ['[]', '{"policy":{},"policy":{}}', '{"x":NaN}',
    '{"x":' + '[' * 70 + '0' + ']' * 70 + '}', '{"padding":"' + 'x' * 17000 + '"}'])
def test_strict_bounded_request_rejects_without_execution(product, raw):
    response = product.client.post("/api/executions", content=raw, headers=HEADERS)
    assert response.status_code == 422
    assert response.json()["code"] == "EXECUTION_INVALID"
    assert "padding" not in response.text


@pytest.mark.parametrize("extra", [{"source": {}}, {"physical_validation": True}, {"state_values": [1, 2, 3]}])
def test_client_cannot_supply_source_or_physical_status(product, extra):
    response = product.client.post("/api/executions", json=prepare_body(product) | extra, headers=HEADERS)
    assert response.status_code == 422


def test_preview_and_registry_version_mismatch_cannot_prepare(product, monkeypatch):
    from livemorebio.aegle import server
    monkeypatch.setattr(server, "_state", {"tw": product.twin, "subject": None})
    response = product.client.get("/api/executions/capabilities", headers=HEADERS)
    assert response.status_code == 200
    assert response.json()["preparation_available"] is False
    assert response.json()["reason"] == "EXECUTION_SOURCE_REQUIRED"
    assert product.client.post("/api/executions", json=prepare_body(product), headers=HEADERS).status_code == 409


def test_unbound_selected_record_has_usable_capabilities_but_no_source_capture(product, monkeypatch):
    from livemorebio.aegle import server

    availability = {"schema": "livemore.model-availability.v1", "state": "UNAVAILABLE",
        "reason_code": "MODEL_BINDING_REQUIRED", "selection_mode": "observations_only",
        "twin_id": product.record["twin_id"], "twin_version": 1,
        "source_generation": product.authority.generation, "preparation_available": False}
    monkeypatch.setattr(server, "_state", {"tw": None, "subject": deepcopy(product.record),
        "initialized": True, "model_availability": availability})
    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("unavailable numerical capture reached registry"))
    response = product.client.get("/api/executions/capabilities", headers=HEADERS)
    assert response.status_code == 200
    assert response.json()["model_availability"] == availability
    assert response.json()["preparation_available"] is False
    assert response.json()["reason"] == "MODEL_BINDING_REQUIRED"
    response = product.client.post("/api/executions", json=prepare_body(product), headers=HEADERS)
    assert response.status_code == 409 and response.json()["code"] == "MODEL_BINDING_REQUIRED"


def test_version_coercion_and_source_mismatch_reject(product):
    for version in [True, "1", 2]:
        body = prepare_body(product) | {"expected_twin_version": version}
        response = product.client.post("/api/executions", json=body, headers=HEADERS)
        assert response.status_code in (409, 422)
    product.record["version"] = 2
    assert product.client.post("/api/executions", json=prepare_body(product), headers=HEADERS).status_code == 409


def test_prepare_idempotency_and_control_cursor_binding(product):
    first = prepare(product)
    again = prepare(product)
    assert first["execution_id"] == again["execution_id"]
    changed = prepare_body(product)
    changed["policy"]["end_native"] = 2.
    assert product.client.post("/api/executions", json=changed, headers=HEADERS).status_code == 409
    running = control(product, first, "start").json()
    product.manager.advance_once(first["execution_id"])
    page = product.client.get(f"/api/executions/{first['execution_id']}/frames", headers=HEADERS).json()
    assert page["frames"][0]["evidence_class"] == "TECHNICAL_FIXTURE"
    assert page["frames"][0]["selection"]["subject_id"] == "technical-subject"
    paused = control(product, page["execution"], "pause")
    assert paused.status_code == 200
    assert paused.json()["state"] == "paused"
    assert control(product, paused.json(), "resume").status_code == 200
    state = product.manager.status(running["execution_id"])
    assert control(product, state, "stop").json()["state"] == "stopped"


def test_source_change_between_precondition_and_start_is_fenced(product, monkeypatch):
    record = prepare(product)
    original = product.manager.start
    def raced_start(*args, **kwargs):
        with product.authority.mutation("technical-switch"):
            pass
        return original(*args, **kwargs)
    monkeypatch.setattr(product.manager, "start", raced_start)
    response = control(product, record, "start")
    assert response.status_code == 409
    assert product.manager.frames(record["execution_id"])["frames"] == []


def test_source_change_during_native_initialization_cannot_deadlock_or_commit(product):
    from livemorebio.tests.test_continuous_execution import TechnicalAdapter
    entered, finish = threading.Event(), threading.Event()
    class SlowAdapter(TechnicalAdapter):
        def initialize(self):
            entered.set()
            assert finish.wait(3)
            return super().initialize()
    product.manager._registry = {"metabolic-continuous-v1": SlowAdapter}
    record = prepare(product)
    responses = []
    worker = threading.Thread(target=lambda: responses.append(control(product, record, "start")))
    try:
        worker.start()
        assert entered.wait(3)
        with product.authority.mutation("technical-switch"):
            pass
        finish.set()
        worker.join(3)
        assert not worker.is_alive()
        assert responses[0].status_code in (409, 503)
        assert product.manager.frames(record["execution_id"])["frames"] == []
    finally:
        finish.set()
        worker.join(3)


def test_audit_failure_prevents_source_read_and_safe_errors(product, monkeypatch):
    from livemorebio.aegle.execution_contract import ExecutionError
    def broken(*args, **kwargs):
        raise ExecutionError("EXECUTION_STORAGE")
    monkeypatch.setattr(product.manager.store, "begin_access", broken)
    monkeypatch.setattr(product.api, "_source_selection", lambda *args, **kwargs: pytest.fail("read before audit"))
    response = product.client.get("/api/executions/capabilities", headers=HEADERS)
    assert response.status_code == 503
    assert response.json()["code"] == "EXECUTION_STORAGE"


@pytest.mark.parametrize("code,status", [
    ("EXECUTION_CLEANUP_UNCONFIRMED", 503), ("MODEL_BINDING_REQUIRED", 409),
    ("MODEL_CONTEXT_INVALID", 409), ("MODEL_CONTEXT_UNSUPPORTED", 409),
    ("MODEL_CONTEXT_SOURCE_MISMATCH", 409), ("SELECTION_COMMIT_UNCONFIRMED", 503),
])
def test_known_scientific_and_cleanup_failures_survive_audit_and_api(product, code, status):
    from livemorebio.aegle.execution_contract import ExecutionError
    from livemorebio.aegle.model_contexts import ModelContextError
    from livemorebio.aegle.model_source import SourceSelectionUnconfirmed

    def fail(_manager):
        if code == "SELECTION_COMMIT_UNCONFIRMED":
            raise SourceSelectionUnconfirmed()
        if code.startswith("MODEL_"):
            raise ModelContextError(code)
        raise ExecutionError(code)

    response = product.api._operate("capabilities", fail)
    assert response.status_code == status
    assert json.loads(response.body)["code"] == code
    assert response.headers["X-Livemore-Request-Id"]


def test_missing_explicit_store_and_runtime_drift_are_unavailable(product, monkeypatch):
    from livemorebio.aegle.execution_contract import ExecutionError
    def drift():
        raise ExecutionError("EXECUTION_RESTART_REQUIRED")
    monkeypatch.setattr(product.api, "_check_runtime_identity", drift)
    response = product.client.post("/api/executions", json=prepare_body(product), headers=HEADERS)
    assert response.status_code == 503
    assert response.json()["code"] == "EXECUTION_RESTART_REQUIRED"


def test_actual_manager_requires_explicit_private_store_and_key(tmp_path, monkeypatch):
    from livemorebio.aegle import server, execution_api
    from livemorebio.aegle.execution_contract import ExecutionError
    monkeypatch.setattr(server, "_execution_manager_instance", None)
    monkeypatch.delenv("LIVEMORE_EXECUTION_STORE", raising=False)
    with pytest.raises(ExecutionError, match="contract"):
        execution_api._manager()
    monkeypatch.setenv("LIVEMORE_EXECUTION_STORE", str(tmp_path / "execution.sqlite3"))
    monkeypatch.setattr(execution_api, "patch_storage_key", lambda **kwargs: None)
    with pytest.raises(ExecutionError):
        execution_api._manager()
    assert not (tmp_path / "execution.sqlite3").exists()
    monkeypatch.setattr(execution_api, "patch_storage_key", lambda **kwargs: b"q" * 32)
    first = execution_api._manager()
    assert execution_api._manager() is first
    execution_api.shutdown_execution_manager()
    assert server._execution_manager_instance is None
    assert first._closed


def test_actual_runtime_fingerprint_guard_rejects_changed_source(monkeypatch):
    from livemorebio import build_info
    from livemorebio.aegle import execution_api
    from livemorebio.aegle.execution_contract import ExecutionError
    original = build_info.build_identity()["source_sha256"]
    monkeypatch.setattr(build_info, "source_fingerprint", lambda path: "different")
    with pytest.raises(ExecutionError) as error:
        execution_api._check_runtime_identity()
    assert error.value.code == "EXECUTION_RESTART_REQUIRED"
    monkeypatch.setattr(build_info, "source_fingerprint", lambda path: original)
    execution_api._check_runtime_identity()


def test_fork_requires_exact_source_and_retains_parent_full_state(product):
    record = prepare(product)
    control(product, record, "start")
    product.manager.advance_once(record["execution_id"])
    paused = control(product, product.manager.status(record["execution_id"]), "pause").json()
    body = prepare_body(product) | {"expected_parent_revision": paused["revision"]}
    response = product.client.post(f"/api/executions/{record['execution_id']}/fork-checkpoint", json=body,
        headers=HEADERS | {"Idempotency-Key": "technical-fork"})
    assert response.status_code == 201, response.text
    fork = response.json()
    assert fork["checkpoint_parent"]["execution_id"] == record["execution_id"]
    assert fork["native_time"] == 1.
    assert fork["execution_id"] != record["execution_id"]
    product.twin.profile.Gb = 91.
    mismatch = product.client.post(f"/api/executions/{record['execution_id']}/fork-checkpoint", json=body,
        headers=HEADERS | {"Idempotency-Key": "technical-fork-mismatch"})
    assert mismatch.status_code == 409


def test_frames_are_bound_paginated_and_request_identity_headers_are_present(product):
    record = prepare(product)
    control(product, record, "start")
    product.manager.advance_once(record["execution_id"])
    path = f"/api/executions/{record['execution_id']}/frames"
    response = product.client.get(path, headers=HEADERS)
    assert len(response.headers["x-livemore-source-sha256"]) == 64
    assert len(response.headers["x-livemore-process-instance"]) == 36
    assert len(response.headers["x-livemore-request-id"]) == 32
    assert "no-store" in response.headers["cache-control"]
    for query in ["?limit=0", "?limit=501", "?after_frame=-1", "?limit=1&limit=2", "?source=other"]:
        assert product.client.get(path + query, headers=HEADERS).status_code == 422
    after = product.client.get(path + "?after_frame=1&limit=1", headers=HEADERS).json()
    assert after["frames"] == []
    assert after["next_after_frame"] == 1
    absent = product.client.get("/api/executions/" + "b" * 32 + "/frames", headers=HEADERS)
    assert absent.status_code == 422
    assert "technical-subject" not in absent.text


def test_outcome_audit_failure_retains_committed_prepare_and_retry_identity(product, monkeypatch):
    from livemorebio.aegle.execution_contract import ExecutionError
    finish = product.manager.store.finish_access
    def fail(*args, **kwargs):
        raise ExecutionError("EXECUTION_STORAGE")
    monkeypatch.setattr(product.manager.store, "finish_access", fail)
    response = product.client.post("/api/executions", json=prepare_body(product), headers=HEADERS)
    assert response.status_code == 503
    assert response.headers["x-livemore-request-id"]
    with product.manager.store._connection() as connection:
        assert connection.execute("SELECT COUNT(*) FROM executions").fetchone()[0] == 1
        assert connection.execute("SELECT COUNT(*) FROM access_audit WHERE outcome IS NULL").fetchone()[0] == 1
    monkeypatch.setattr(product.manager.store, "finish_access", finish)
    assert prepare(product)["state"] == "prepared"
    with product.manager.store._connection() as connection:
        assert connection.execute("SELECT COUNT(*) FROM executions").fetchone()[0] == 1


def test_native_metabolic_execution_uses_same_http_contract(product):
    product.manager._registry = None
    original = deepcopy(asdict(product.twin.profile))
    record = prepare(product)
    started = control(product, record, "start")
    assert started.status_code == 200, started.text
    product.manager.advance_once(record["execution_id"])
    response = product.client.get(f"/api/executions/{record['execution_id']}/frames", headers=HEADERS)
    assert response.status_code == 200
    page = response.json()
    assert page["execution"]["authorship"] == "engine"
    frame = page["frames"][0]
    assert frame["evidence_class"] == "MODELED"
    assert frame["independent_physical_validation"] is False
    assert frame["native_end"] == 1.
    assert {row["quantity"] for row in frame["series"]} == {
        "glucose_mgdl", "insulin_action_per_min", "insulin_uU_ml"}
    assert all(row["native_times"][-1] == 1. for row in frame["series"])
    assert frame["runtime_identity"]["solver"] != "technical_fixture"
    assert asdict(product.twin.profile) == original
    assert control(product, page["execution"], "pause").status_code == 200


def test_runtime_drift_after_prepare_blocks_start_and_resume_but_not_inspection_or_stop(product, monkeypatch):
    from livemorebio.aegle.execution_contract import ExecutionError
    record = prepare(product)
    def changed():
        raise ExecutionError("EXECUTION_RESTART_REQUIRED")
    monkeypatch.setattr(product.api, "_check_runtime_identity", changed)
    assert control(product, record, "start").status_code == 503
    assert product.manager.status(record["execution_id"])["state"] == "prepared"
    monkeypatch.setattr(product.api, "_check_runtime_identity", lambda: None)
    running = control(product, record, "start").json()
    paused = control(product, running, "pause").json()
    monkeypatch.setattr(product.api, "_check_runtime_identity", changed)
    assert control(product, paused, "resume").status_code == 503
    assert product.client.get(f"/api/executions/{record['execution_id']}", headers=HEADERS).status_code == 200
    assert control(product, paused, "stop").status_code == 200


@pytest.mark.parametrize("method,path", [("get", "/api/executions/capabilities"), ("post", "/api/executions")])
def test_non_ascii_auth_rejects_before_store_read(product, monkeypatch, method, path):
    monkeypatch.setattr(product.api, "_manager", lambda: pytest.fail("malformed credentials reached store"))
    client = TestClient(product.client.app, raise_server_exceptions=False)
    response = getattr(client, method)(path, headers=[(b"Authorization", b"Bearer \xc3\xa9")])
    assert response.status_code == 401
    assert "no-store" in response.headers["cache-control"]
