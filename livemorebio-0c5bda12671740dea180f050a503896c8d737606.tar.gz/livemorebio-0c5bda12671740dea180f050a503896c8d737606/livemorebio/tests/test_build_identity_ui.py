"""Pure browser formatting must not call an old or mixed service set a matched build."""
from pathlib import Path
import json
import shutil
import subprocess

import pytest
from ._node import require_node, run_node as _run_node


def test_build_labels_and_service_matching():
    node = require_node()
    module = Path(__file__).parents[1] / "aegle/console/lib/build_identity.js"
    code = r"""
import assert from 'node:assert/strict';
import {describeBuild, compareServiceBuilds} from MODULE;
const local={schema:'livemore.build-identity.v1',identity_scope:'startup_source',
source_sha256:'a'.repeat(64),commit:'b'.repeat(40),package_version:'0.1.0',process_instance:'aegle'};
assert.match(describeBuild(local).label,/bbbbbbbb/);
assert.match(describeBuild(local).detail,/process start/);
assert.match(describeBuild({...local,commit:'<secret>'}).label,/no VCS/);
assert.equal(describeBuild(null).label,'Build identity unavailable');
assert.equal(describeBuild({...local,source_sha256:'bad'}).label,'Build identity unavailable');
const services=Object.fromEntries(['Aegle','LIFE','Cendos'].map(service=>
[service,{up:true,service,build:{...local,process_instance:service}}]));
assert.deepEqual(compareServiceBuilds(local,services),[]);
const current={...local,schema:'livemore.build-identity.v2',fingerprint_scope:'runtime_code_and_public_reference_assets.v2'};
assert.match(describeBuild(current).label,/bbbbbbbb/);
assert.equal(describeBuild({...current,fingerprint_scope:'unknown'}).label,'Build identity unavailable');
assert.deepEqual(compareServiceBuilds(current,services),['Aegle different build','LIFE different build','Cendos different build']);

services.LIFE.build.source_sha256='c'.repeat(64);
assert.deepEqual(compareServiceBuilds(local,services),['LIFE different build']);
services.LIFE={up:true,service:'Cendos',build:local};
assert.deepEqual(compareServiceBuilds(local,services),['LIFE service identity mismatch']);
services.LIFE={up:true,service:'LIFE'};
assert.deepEqual(compareServiceBuilds(local,services),['LIFE build unknown']);
services.LIFE={up:false};
assert.deepEqual(compareServiceBuilds(local,services),['LIFE unavailable']);
services.LIFE={up:true,service:'LIFE',build:{...local,schema:'wrong'}};
assert.deepEqual(compareServiceBuilds(local,services),['LIFE build unknown']);
assert.ok(compareServiceBuilds(null,{}).length);
""".replace("MODULE", repr(module.as_uri()))
    result = _run_node([node, "--input-type=module", "-e", code], capture_output=True,
                            text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_build_monitor_refresh_failure_and_disposal():
    node = require_node()
    module = Path(__file__).parents[1] / "aegle/console/lib/build_identity.js"
    code = r"""
import assert from 'node:assert/strict';
import {watchBuildIdentity} from MODULE;
const timers=new Map(); let serial=0, calls=0, fail=false, pending=null;
const updates=[],errors=[];
const flush=()=>new Promise(resolve=>setImmediate(resolve));
const monitor=watchBuildIdentity({
  read:async()=>{calls++; if(pending)await pending; if(fail)throw Error('offline');return calls;},
  onUpdate:value=>updates.push(value),onError:()=>errors.push('unavailable'),
  schedule:(fn,ms)=>{timers.set(++serial,{fn,ms});return serial;},cancel:id=>timers.delete(id),
});
await flush(); assert.deepEqual(updates,[1]);
assert.equal([...timers.values()].filter(t=>t.ms===10000).length,1);
fail=true; await monitor.refresh(); assert.deepEqual(errors,['unavailable']);
fail=false; await monitor.refresh(); assert.deepEqual(updates,[1,3]);
let release; pending=new Promise(resolve=>release=resolve);
const current=monitor.refresh(); monitor.refresh(); await flush(); assert.equal(calls,4);
monitor.dispose(); release(); await current;
assert.deepEqual(updates,[1,3]); assert.equal(timers.size,0);
await monitor.refresh(); assert.equal(calls,4);
""".replace("MODULE", repr(module.as_uri()))
    result = _run_node([node, "--input-type=module", "-e", code], capture_output=True,
                            text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


MOUNT_PREAMBLE = r"""
import assert from 'node:assert/strict';
import {mountBuildIdentity, watchBuildIdentity} from MODULE;
const timers=new Map(), roots=[], listeners=new Map(), pageListeners=new Map();let serial=0;
globalThis.setTimeout=(fn,ms)=>{timers.set(++serial,{fn,ms});return serial};
globalThis.clearTimeout=id=>timers.delete(id);
const element=()=>({id:'',style:{},dataset:{},children:[],textContent:'',append(...nodes){this.children.push(...nodes)},setAttribute(){}});
globalThis.document={hidden:false,getElementById:id=>roots.find(node=>node.id===id),createElement:element,
  body:{append:node=>roots.push(node)},addEventListener:(name,fn)=>listeners.set(name,fn),removeEventListener:(name,fn)=>{if(listeners.get(name)===fn)listeners.delete(name)}};
globalThis.window={addEventListener:(name,fn)=>pageListeners.set(name,fn)};
const local={schema:'livemore.build-identity.v1',identity_scope:'startup_source',source_sha256:'a'.repeat(64),package_version:'0.1.0'};
const services=Object.fromEntries(['Aegle','LIFE','Cendos'].map(service=>[service,{up:true,service,build:local}]));
const requests=[],bodies=[];
const response=(url,body,ok=true)=>({ok,json:async()=>{bodies.push(url);return body}});
const responders={'/api/build':()=>response('/api/build',local),'/api/services':()=>response('/api/services',services)};
globalThis.fetch=(url,options)=>{requests.push({url,...options});return Promise.resolve(responders[url](options.signal))};
const flush=()=>new Promise(resolve=>setImmediate(resolve));
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject}};
const fire=ms=>{const entry=[...timers].find(([,value])=>value.ms===ms);assert(entry,'missing timer '+ms);timers.delete(entry[0]);entry[1].fn()};
const root=()=>roots[0],label=()=>root().children[0].textContent;
const dispose=()=>pageListeners.get('pagehide')();
"""


def run_mounted(body: str) -> None:
    node = require_node()
    module = Path(__file__).parents[1] / "aegle/console/lib/build_identity.js"
    code = MOUNT_PREAMBLE.replace("MODULE", repr(module.as_uri())) + "\n" + body
    result = _run_node([node, "--input-type=module", "-e", code], capture_output=True,
                            text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_mounted_build_read_consumes_both_successful_bodies() -> None:
    run_mounted(r"""
mountBuildIdentity();await flush();
assert.deepEqual(requests.map(row=>row.url),['/api/build','/api/services']);
assert(requests.every(row=>row.cache==='no-store'));
assert.equal(requests[0].signal,requests[1].signal);
assert.deepEqual(bodies,['/api/build','/api/services']);assert.equal(root().dataset.state,'matched');
assert.equal([...timers.values()].filter(row=>row.ms===10000).length,1);
dispose();assert.equal(timers.size,0);assert.equal(listeners.size,0);
""")


@pytest.mark.parametrize("kind", ["json", "null", "malformed", "absent"])
def test_mounted_build_failure_owns_body_and_pending_companion(kind: str) -> None:
    run_mounted("const kind=" + json.dumps(kind) + r""";
const companion=deferred();
responders['/api/build']=()=>kind==='absent'?undefined:{ok:false,json:async()=>{bodies.push('/api/build');if(kind==='malformed')throw Error('PRIVATE_ERROR_BODY');return kind==='null'?null:{message:'PRIVATE_ERROR_BODY'}}};
responders['/api/services']=()=>companion.promise;
mountBuildIdentity();await flush();
assert.equal(requests.length,2);assert.equal(label(),'Identifying running build…');
assert.equal([...timers.values()].filter(row=>row.ms===8000).length,1,'failure abandoned pending companion');
assert.deepEqual(bodies,kind==='absent'?[]:['/api/build']);
companion.resolve(response('/api/services',services));await flush();
assert.equal(root().dataset.state,'unavailable');assert.equal(label(),'Build identity unavailable');
assert(root().children.every(node=>!node.textContent.includes('PRIVATE_ERROR_BODY')));
assert(bodies.includes('/api/services'));dispose();assert.equal(timers.size,0);
""")


@pytest.mark.parametrize("kind", ["null", "malformed", "absent"])
def test_mounted_bad_success_response_never_claims_matching_builds(kind: str) -> None:
    run_mounted("const kind=" + json.dumps(kind) + r""";
responders['/api/build']=()=>kind==='absent'?undefined:{ok:true,json:async()=>{if(kind==='malformed')throw Error('PRIVATE_ERROR_BODY');return null}};
mountBuildIdentity();await flush();assert.notEqual(root().dataset.state,'matched');
assert(label().startsWith('Build identity unavailable'));dispose();assert.equal(timers.size,0);
""")


def test_mounted_pending_error_body_is_bounded_by_owned_timeout() -> None:
    run_mounted(r"""
const body=deferred();responders['/api/build']=()=>({ok:false,json:()=>{bodies.push('/api/build');return body.promise}});
mountBuildIdentity();await flush();assert.deepEqual(bodies,['/api/build','/api/services']);
assert.equal(label(),'Identifying running build…');fire(8000);await flush();
assert(requests.every(row=>row.signal.aborted));assert.equal(root().dataset.state,'unavailable');
const poll=[...timers.keys()];body.resolve({message:'PRIVATE_ERROR_BODY'});await flush();
assert.equal(root().dataset.state,'unavailable');assert.deepEqual([...timers.keys()],poll);
dispose();assert.equal(timers.size,0);
""")


def test_mounted_synchronous_fetch_failure_still_owns_companion() -> None:
    run_mounted(r"""
const companion=deferred();responders['/api/build']=()=>{throw Error('PRIVATE_FETCH_ERROR')};
responders['/api/services']=()=>companion.promise;
mountBuildIdentity();await flush();assert.equal(requests.length,2);
assert.equal(label(),'Identifying running build…');
companion.resolve(response('/api/services',services));await flush();
assert.equal(root().dataset.state,'unavailable');assert(bodies.includes('/api/services'));dispose();
""")


def test_monitor_catches_synchronous_read_failure() -> None:
    run_mounted(r"""
let reads=0,errors=0;const monitor=watchBuildIdentity({read:()=>{reads++;throw Error('PRIVATE_READ_ERROR')},onUpdate:()=>assert.fail('invalid update'),onError:()=>errors++});
await flush();assert.equal(reads,1);assert.equal(errors,1);
assert.equal([...timers.values()].filter(row=>row.ms===10000).length,1);
monitor.dispose();assert.equal(timers.size,0);
""")


def test_mounted_disposal_before_deferred_dispatch_starts_no_requests() -> None:
    run_mounted(r"""
mountBuildIdentity();dispose();await flush();assert.equal(requests.length,0);
assert.equal(label(),'Identifying running build…');assert.equal(timers.size,0);assert.equal(listeners.size,0);
""")


def test_mounted_disposal_aborts_pending_body_and_suppresses_late_update() -> None:
    run_mounted(r"""
const body=deferred();responders['/api/build']=()=>({ok:true,json:()=>{bodies.push('/api/build');return body.promise}});
mountBuildIdentity();await flush();assert.deepEqual(bodies,['/api/build','/api/services']);
dispose();assert(requests.every(row=>row.signal.aborted));assert.equal(timers.size,0);
body.resolve(local);await flush();assert.equal(label(),'Identifying running build…');
assert.equal(root().dataset.state,undefined);assert.equal(timers.size,0);assert.equal(listeners.size,0);
""")


def test_mounted_disposal_between_read_and_fetch_jobs_starts_no_requests() -> None:
    run_mounted(r"""
mountBuildIdentity();await Promise.resolve();dispose();await flush();
assert.equal(requests.length,0);assert.equal(timers.size,0);assert.equal(listeners.size,0);
""")


def test_monitor_old_timeout_and_settlement_cannot_touch_new_flight() -> None:
    run_mounted(r"""
const first=deferred(),second=deferred(),signals=[],updates=[];let errors=0;
const monitor=watchBuildIdentity({read:signal=>{signals.push(signal);return signals.length===1?first.promise:second.promise},onUpdate:value=>updates.push(value),onError:()=>errors++});
await flush();const staleDeadline=[...timers.values()].find(row=>row.ms===8000).fn;
fire(8000);await flush();assert.equal(errors,1);assert(signals[0].aborted);
const current=monitor.refresh();assert.equal(monitor.refresh(),current);await flush();assert.equal(signals.length,2);
const ownedTimers=[...timers.keys()];staleDeadline();first.resolve('old');await flush();
assert(!signals[1].aborted,'old deadline aborted new controller');assert.deepEqual([...timers.keys()],ownedTimers);
assert.deepEqual(updates,[]);assert.equal(errors,1);
second.resolve('current');await current;assert.deepEqual(updates,['current']);
assert.equal([...timers.values()].filter(row=>row.ms===10000).length,1);monitor.dispose();assert.equal(timers.size,0);
""")
