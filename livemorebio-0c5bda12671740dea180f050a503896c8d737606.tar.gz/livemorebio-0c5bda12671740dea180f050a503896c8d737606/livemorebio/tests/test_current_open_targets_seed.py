"""Current descriptive references have reconstructable API receipts."""
import json
import re

import pytest

from livemorebio.life_system.reference import build_seed


def test_current_open_targets_release_and_per_record_queries():
    data = json.loads((build_seed.SEED / "diseases.json").read_text(encoding="utf-8"))
    meta = json.loads((build_seed.SEED / "meta.json").read_text(encoding="utf-8"))
    source = meta["source_records"]["Open Targets Platform"]
    assert source["release"] == "26.09"
    assert source["currency_status"] == "current_at_retrieval"
    for disease in data:
        assert disease["open_targets_release"] == source["release"]
        assert disease["open_targets_id_status"] == "current_at_retrieval"
        for record in [disease, *disease["gene_associations"]]:
            receipt = record["open_targets_provenance"]
            assert receipt["release"] == source["release"]
            assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", receipt["retrieved_at"])
            assert receipt["query"].startswith("query")
            assert receipt["variables"]["id"] == disease["open_targets_id"]
            assert re.fullmatch(r"[0-9a-f]{64}", receipt["response_sha256"])
            assert receipt["method"] == "POST"
            assert receipt["url"] == build_seed.OT_API
    drugs = json.loads((build_seed.SEED / "drugs.json").read_text(encoding="utf-8"))
    assert len(drugs) == 10
    for drug in drugs:
        assert drug["release"] == source["release"]
        assert drug["resolution_status"] == "resolved_exact"
        assert drug["open_targets_provenance"]["variables"]["id"] == drug["chembl"]


def test_current_liver_join_carries_upstream_obsolete_identifier_evidence():
    liver = next(d for d in json.loads((build_seed.SEED / "diseases.json").read_text(encoding="utf-8"))
                 if d["doid"] == "DOID:0080208")
    assert liver["open_targets_id"] == "EFO_1001248"
    assert liver["open_targets_mapping"]["method"] == "upstream_obsolete_term"
    assert "EFO_0003095" in liver["open_targets_mapping"]["obsolete_terms"]


def test_every_alias_is_an_independently_sourced_ontology_term():
    for disease in json.loads((build_seed.SEED / "diseases.json").read_text(encoding="utf-8")):
        assert disease["alias_status"] == "reviewed_open_ontology_terms"
        assert {row["alias"] for row in disease["alias_provenance"]} == set(disease["aliases"])
        for row in disease["alias_provenance"]:
            assert row["source"] in {"Disease Ontology", "Open Targets ontology"}
            assert row["source_field"] in {"label", "exact_synonym"}
            assert row["alias"].casefold() == row["source_term"].casefold()
            assert row["source_url"].startswith("https://")
            assert row["ontology_id"]


def test_resolver_requires_unique_current_crossreference_or_obsolete_identity():
    rows = [{"id": "EFO_1001248", "dbXRefs": [], "obsoleteTerms": ["EFO_0003095"]}]
    assert build_seed.resolve_open_targets_disease("DOID:0080208", rows, previous_id="EFO_0003095") == "EFO_1001248"
    assert build_seed.resolve_open_targets_disease("DOID:0080208", rows, previous_id="EFO_other") is None
    assert build_seed.resolve_open_targets_disease("DOID:0080208", rows + [{"id": "EFO_other", "dbXRefs": ["DOID:0080208"]}], previous_id="EFO_0003095") is None


def test_association_pagination_refuses_unsorted_scores_before_cutting():
    from livemorebio.life_system.reference.current_open_targets import direct_associations
    class Reader:
        def graphql(self, query, variables):
            rows = [{"score": score, "target": {"id": f"ENSG{i:011}"},
                     "datatypeScores": [{"id": "technical", "score": score}]}
                    for i, score in enumerate([0.2, 0.8] + [0.1] * 19)]
            return {"disease": {"associatedTargets": {"count": 1000, "rows": rows}}}, {"sha256": "a" * 64}
    with pytest.raises(build_seed.SeedBuildError) as caught:
        direct_associations(Reader(), "technical-disease", "26.09")
    assert caught.value.reason_code == "REFERENCE_SEED_SOURCE_INVALID"


def test_repeat_refresh_preserves_the_verified_obsolete_mapping_anchor():
    from livemorebio.life_system.reference.current_open_targets import current_disease
    current = {"id": "EFO_1001248", "name": "technical label", "dbXRefs": [],
               "obsoleteTerms": ["EFO_0003095"], "synonyms": []}
    class Reader:
        def graphql(self, query, variables):
            if "mapIds" in query:
                data = {"mapIds": {"mappings": [{"term": "technical", "hits": [{"id": current["id"]}]}]}}
            else:
                data = {"disease": current if variables["id"] == current["id"] else None}
            return data, {"sha256": "a" * 64}
    disease = {"query": "technical", "doid": "DOID:0080208", "open_targets_id": current["id"],
               "open_targets_mapping": {"previous_id": "EFO_0003095"}}
    assert current_disease(Reader(), disease, "26.09") == current
    assert disease["open_targets_mapping"]["method"] == "upstream_obsolete_term"


def test_read_transport_retries_transient_failure_without_changing_source(monkeypatch):
    import io
    calls = []
    class Opener:
        def open(self, request, timeout):
            calls.append(request.full_url)
            if len(calls) == 1:
                raise OSError("technical transient")
            return io.BytesIO(b'{"data": {"ok": true}}')
    monkeypatch.setattr(build_seed.urllib.request, "build_opener", lambda *args: Opener())
    # L0-R16: a product document, since the egress check admits only the product's own documents.
    from livemorebio.life_system.reference.current_open_targets import VERSION_QUERY
    data, _ = build_seed.OpenSourceReader().graphql(VERSION_QUERY)
    assert data == {"ok": True}
    assert calls == [build_seed.OT_API, build_seed.OT_API]


def test_invalid_graphql_json_exposes_exact_failing_request_and_response(monkeypatch):
    import io
    class Opener:
        def open(self, request, timeout):
            return io.BytesIO(b"technical malformed response")
    monkeypatch.setattr(build_seed.urllib.request, "build_opener", lambda *args: Opener())
    from livemorebio.life_system.reference.current_open_targets import VERSION_QUERY
    with pytest.raises(build_seed.SeedBuildError) as caught:
        build_seed.OpenSourceReader().graphql(VERSION_QUERY)
    assert caught.value.request["query"] == VERSION_QUERY
    assert caught.value.response == "technical malformed response"


def test_current_drug_synonym_schema_resolves_label_and_source_objects():
    from livemorebio.life_system.reference import current_open_targets
    record = current_open_targets.normalize_drug_identity({
        "id": "CHEMBL1201631", "name": "INSULIN HUMAN",
        "synonyms": [{"label": "insulin", "source": "ChEMBL"}],
    })
    assert build_seed.resolve_exact("insulin", [record])["id"] == "CHEMBL1201631"
    assert record["synonym_sources"] == [{"label": "insulin", "source": "ChEMBL"}]


def test_trial_intervention_labels_do_not_establish_chemical_identity():
    from livemorebio.life_system.reference.current_open_targets import normalize_drug_identity
    records = [normalize_drug_identity(row) for row in [
        {"id": "CHEMBL121", "name": "ROSIGLITAZONE",
         "synonyms": [{"label": "metformin", "source": "AACT"}]},
        {"id": "CHEMBL1431", "name": "METFORMIN",
         "synonyms": [{"label": "metformin", "source": "ChEMBL"}]},
    ]]
    assert build_seed.resolve_exact("metformin", records)["id"] == "CHEMBL1431"
