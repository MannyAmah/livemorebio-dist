"""Repairing a journal keeps every record the current protocol still accepts."""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from livemorebio.life_patch import journal_repair
from livemorebio.life_patch.gateway import LifePatchGateway, PatchJournalInvalid


@pytest.fixture()
def admitted_journal(tmp_path):
    """Real records, written by the gateway itself rather than hand-built."""
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.tests.test_patch_protocol_v3 import NOW, envelope_payload, manifest_payload

    path = tmp_path / "admitted.jsonl"
    gateway = LifePatchGateway(str(path))
    gateway.register(decode_manifest(manifest_payload()))
    # The fixture payloads carry a fixed capture time, so pin the admission clock.
    gateway._admission._now = lambda: NOW
    for sequence in (1, 2, 3):
        payload = {**envelope_payload(), "sequence": sequence,
                   "envelope_id": f"v3-envelope-{sequence}"}
        payload.pop("envelope_hash", None)
        gateway.admit(decode_envelope(payload))
    return path


@pytest.fixture()
def journal(tmp_path, admitted_journal):
    """A journal of real admitted records, with one legacy record prepended."""
    path = tmp_path / "patch-telemetry.jsonl"
    # A record complete in every respect except the one rule a later protocol
    # tightened: the subject ID is a clinical descriptor where an opaque
    # pseudonym is now required. Derived from a valid payload so that the
    # rejection is that rule and not an unrelated field.
    from livemorebio.tests.test_patch_protocol_v3 import envelope_payload

    rejected = dict(envelope_payload())
    rejected.pop("envelope_hash", None)
    rejected["subject_id"] = "type-2-diabetes"
    legacy = json.dumps(rejected, sort_keys=True, separators=(",", ":"))
    lines = [legacy.encode() + b"\n"] + admitted_journal.read_bytes().splitlines(keepends=True)
    path.write_bytes(b"".join(lines))
    os.chmod(path, 0o600)
    return path


def test_inspect_names_the_rejected_record_and_changes_nothing(journal):
    before = journal.read_bytes()
    report = journal_repair.inspect_journal(journal)
    assert report["total_records"] == len(before.splitlines())
    assert report["valid_records"] == report["total_records"] - 1
    assert [item["record_number"] for item in report["invalid_records"]] == [1]
    assert "pseudonym" in report["invalid_records"][0]["reason"]
    assert report["repaired"] is False and journal.read_bytes() == before


def test_quarantine_without_apply_reports_but_does_not_write(journal):
    before = journal.read_bytes()
    report = journal_repair.quarantine_journal(journal, apply=False)
    assert report["repaired"] is False
    assert journal.read_bytes() == before
    assert not Path(report["quarantine_file"]).exists()


def test_quarantine_keeps_valid_records_byte_for_byte(journal):
    original = journal.read_bytes().splitlines(keepends=True)
    report = journal_repair.quarantine_journal(journal, apply=True)

    assert report["repaired"] is True
    assert report["valid_records"] == len(original) - 1
    # The surviving records are copied, never re-encoded: sealed records would
    # not survive a round trip through json.dumps.
    assert journal.read_bytes() == b"".join(original[1:])
    assert journal_repair.inspect_journal(journal)["invalid_records"] == []


def test_quarantined_record_is_preserved_verbatim_with_its_rule(journal):
    original_first = journal.read_bytes().splitlines(keepends=True)[0]
    report = journal_repair.quarantine_journal(journal, apply=True)

    entries = [json.loads(line) for line in Path(report["quarantine_file"]).read_text(encoding="utf-8").splitlines()]
    assert len(entries) == 1
    entry = entries[0]
    assert entry["reason_code"] == "PATCH_JOURNAL_INVALID"
    assert entry["source_record_number"] == 1 and "pseudonym" in entry["reason"]
    assert entry["record_line"].encode("utf-8", errors="surrogateescape") == original_first


def test_repaired_journal_lets_the_gateway_open(journal):
    with pytest.raises(PatchJournalInvalid):
        LifePatchGateway(str(journal))
    journal_repair.quarantine_journal(journal, apply=True)
    LifePatchGateway(str(journal))  # opens without raising


def test_repeated_repair_appends_and_never_truncates_the_sidecar(journal):
    first = journal_repair.quarantine_journal(journal, apply=True)
    sidecar = Path(first["quarantine_file"])
    kept = sidecar.read_bytes()

    # A second repair of an already-clean journal must leave the sidecar alone.
    second = journal_repair.quarantine_journal(journal, apply=True)
    assert second["invalid_records"] == [] and second["repaired"] is False
    assert sidecar.read_bytes() == kept


def test_a_clean_journal_reports_no_repair_needed(admitted_journal):
    report = journal_repair.inspect_journal(admitted_journal)
    assert report["invalid_records"] == [] and report["valid_records"] == report["total_records"]


def test_a_missing_journal_is_refused_by_name(tmp_path):
    with pytest.raises(journal_repair.JournalRepairError, match="does not exist"):
        journal_repair.inspect_journal(tmp_path / "absent.jsonl")


def test_a_truncated_record_is_not_silently_discarded(tmp_path, admitted_journal):
    """A damaged file is not a protocol mismatch; repairing it is not this tool's job."""
    path = tmp_path / "patch-telemetry.jsonl"
    path.write_bytes(admitted_journal.read_bytes().rstrip(b"\n"))
    os.chmod(path, 0o600)
    with pytest.raises(journal_repair.JournalRepairError, match="truncated"):
        journal_repair.inspect_journal(path)


def test_a_named_missing_path_reports_the_path_not_a_lock_problem(tmp_path):
    """Observed on a fresh install: the parent chmod failed first on a directory
    the operator does not own, so a wrong path was reported as a lock fault."""
    with pytest.raises(journal_repair.JournalRepairError, match="does not exist"):
        journal_repair.inspect_journal(tmp_path / "nested" / "absent.jsonl")


def test_repair_does_not_change_the_mode_of_a_directory_it_did_not_create(tmp_path, admitted_journal):
    shared = tmp_path / "shared"
    shared.mkdir(mode=0o755)
    shared.chmod(0o755)
    target = shared / "patch-telemetry.jsonl"
    target.write_bytes(admitted_journal.read_bytes())
    os.chmod(target, 0o600)
    before = os.stat(shared).st_mode

    journal_repair.inspect_journal(target)
    assert os.stat(shared).st_mode == before


def test_cli_reports_a_missing_default_journal_as_healthy(tmp_path, monkeypatch, capsys):
    """A fresh install has no journal yet. That is not a fault to alarm a client."""
    import sys

    from livemorebio import cli, registry

    monkeypatch.setattr(registry, "REG_DIR", str(tmp_path))
    monkeypatch.setattr(cli.R, "REG_DIR", str(tmp_path))
    monkeypatch.delenv("LIVEMORE_PATCH_JOURNAL", raising=False)
    monkeypatch.setattr(sys, "argv", ["livemore", "patch-journal", "verify"])

    with pytest.raises(SystemExit) as exit_code:
        cli.main()
    assert exit_code.value.code == 0
    assert "no patch journal yet" in capsys.readouterr().out


def test_cli_still_fails_on_a_path_the_operator_named(tmp_path, monkeypatch, capsys):
    """A typo must not be reported as healthy just because nothing is there."""
    import sys

    from livemorebio import cli

    monkeypatch.setattr(sys, "argv", ["livemore", "patch-journal", "verify",
                                      "--journal", str(tmp_path / "typo.jsonl")])
    with pytest.raises(SystemExit) as exit_code:
        cli.main()
    assert exit_code.value.code == 2
    assert "does not exist" in capsys.readouterr().out
