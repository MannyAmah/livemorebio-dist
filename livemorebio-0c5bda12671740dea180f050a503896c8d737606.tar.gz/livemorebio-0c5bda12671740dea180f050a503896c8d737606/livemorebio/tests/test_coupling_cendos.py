"""Cendos in-silico assays and the metabolic->cardiac cross-scale coupling."""
import pytest
from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, T2D
from livemorebio.engines.metabolic.interventions import metformin, plant_compound
from livemorebio.cendos.assays import ogtt_effect
from livemorebio.engines.coupling.metabolic_cardiac import (
    MetabolicCardiacTwin, hyperglycemia_to_ikr_block)

MEALS = [(0, 60), (300, 75), (660, 90)]


def test_cendos_metformin_lowers_glucose_burden():
    eff = ogtt_effect(T2D, metformin(T2D, dose=1.0))
    assert eff["delta_iAUC"] < 0
    assert eff["treated"]["peak"] < eff["baseline"]["peak"]
    assert eff["decision"] in ("EFFECT", "WEAK")


def test_cendos_plant_effect_requires_compound_specific_evidence():
    with pytest.raises(ValueError, match="qualified"):
        plant_compound(T2D, "berberine-axis", si_boost=0.35, gb_drop=0.08)


def test_hyperglycemia_map_is_monotonic():
    assert hyperglycemia_to_ikr_block(90) == 0.0
    assert hyperglycemia_to_ikr_block(250) > hyperglycemia_to_ikr_block(150) > 0.0


def test_coupling_diabetes_prolongs_apd(pinned_cardiac_asset):
    shared = MetabolicCardiacTwin(HEALTHY).heart          # reuse one compiled cell
    healthy = MetabolicCardiacTwin(HEALTHY, cardiac=shared).run(MEALS, beats=5)
    t2d = MetabolicCardiacTwin(T2D, cardiac=shared).run(MEALS, beats=5)
    assert t2d["mean_glucose"] > healthy["mean_glucose"]
    assert t2d["ikr_block"] > healthy["ikr_block"]
    assert t2d["apd90_ms"] >= healthy["apd90_ms"]
