"""L0-R9 named skip legs; offline readers, never a hosted/root run."""
from __future__ import annotations

import os
from pathlib import Path
import re
import subprocess
import sys
import textwrap
import xml.etree.ElementTree as ET

import pytest

from ._source_tree import require_git_checkout, source_tree_only


ROOT = Path(__file__).resolve().parents[2]
WINDOWS_STEP = "Run exactly four PowerShell identity generator cases"
OWNERSHIP_STEP = "Run the one foreign-owner case as root"
OWNERSHIP_NODE = (
    "livemorebio/tests/test_stable_new7_native_acl.py::"
    "test_native_actual_foreign_owned_credential_is_unchanged_when_chown_is_available"
)


def test_public_manifest_covers_every_tracked_public_path_in_byte_order():
    """Check the pending manifest without requiring a commit of the repair."""
    require_git_checkout("checking the tracked public manifest")
    from tools.public_distribution import is_private_only

    tracked = subprocess.run(["git", "ls-files", "-z"], cwd=ROOT,
                             capture_output=True, text=True, encoding="utf-8", check=True)
    files = {name for name in tracked.stdout.split("\0") if name and not is_private_only(name)}
    expected = files | {".livemore-distribution.json"}
    for name in files:
        expected.update(parent.as_posix() + "/" for parent in Path(name).parents if parent != Path("."))
    manifest = (ROOT / "tools/public_release_manifest.txt").read_text(encoding="utf-8").splitlines()
    assert manifest == sorted(set(manifest), key=lambda name: name.encode("utf-8"))
    assert set(manifest) == expected, (
        f"PUBLIC_MANIFEST_MISMATCH: missing={sorted(expected - set(manifest))}; "
        f"extra={sorted(set(manifest) - expected)}"
    )


def _step(workflow: str, name: str) -> tuple[str, str]:
    text = (ROOT / ".github/workflows" / workflow).read_text(encoding="utf-8")
    match = re.search(rf"^      - name: {re.escape(name)}\n(.*?)(?=^      - |\Z)",
                      text, re.M | re.S)
    assert match is not None, f"L0-R9 needs its named leg: {name}"
    return text, match.group(1)


@source_tree_only(".github/workflows/platforms.yml")
def test_l0_r9_windows_provisions_only_pytest_and_preserves_the_refusal_steps():
    text, run = _step("platforms.yml", WINDOWS_STEP)
    job = text.split("  windows-native:\n", 1)[1]
    _, provision = _step("platforms.yml", "Install the PowerShell case test runner")
    assert "shell: pwsh" in provision
    assert "python -m pip install pytest==9.1.1" in provision
    assert 'if ($LASTEXITCODE -ne 0)' in provision
    assert job.index("Install the PowerShell case test runner") < job.index(WINDOWS_STEP)
    assert re.findall(r"^      - name: (.+)$", job, re.M) == [
        "Install without the hashed POSIX lock",
        "The package imports and the doctor explains the platform",
        "Operational commands refuse with guidance rather than failing obscurely",
        "Install the PowerShell case test runner", WINDOWS_STEP,
    ]
    assert 'if ($code -ne 1)' in job and 'FAIL platform Windows' in job
    assert 'if ($code -ne 2)' in job and 'refusal must name the supported path' in job
    assert "shell: pwsh" in run
    assert "python -B -m pytest --noconftest -p no:cacheprovider -q -rfEs " in run
    assert "livemorebio/tests/test_stable_new5c_pass_r_docs.py -k powershell_identity_generator" in run
    assert '--junitxml="$junit"' in run
    assert run.count('if ($LASTEXITCODE -ne 0)') == 2
    assert "[guid]::NewGuid()" in run
    for name in ("HOME", "USERPROFILE", "TMPDIR", "TEMP", "TMP", "LIVEMORE_DATA_DIR"):
        assert f"$env:{name} = " in run


@source_tree_only(".github/workflows/installer.yml")
def test_l0_r9_only_the_foreign_owner_node_runs_as_root_after_the_release_gate():
    text, run = _step("installer.yml", OWNERSHIP_STEP)
    assert "if: runner.os == 'macOS'" in run and "shell: bash" in run
    assert text.index("name: Run complete release gate") < text.index(f"name: {OWNERSHIP_STEP}")
    assert 'ownership_root="$(mktemp -d "$RUNNER_TEMP/l0-ownership-XXXXXXXX")"' in run
    assert 'mkdir "$ownership_root/home" "$ownership_root/tmp" "$ownership_root/data"' in run
    # A restrictive sudo umask must not leave the caller unable to read JUnit.
    assert ': > "$ownership_root/ownership.xml"' in run
    assert run.index(': > "$ownership_root/ownership.xml"') < run.index("sudo env -i ")
    logical = re.sub(r"\\\n\s*", " ", run)
    commands = [line.strip() for line in logical.splitlines() if line.strip().startswith("sudo ")]
    assert len(commands) == 1
    command = commands[0]
    assert command.startswith("sudo env -i ")
    for setting in ('HOME="$ownership_root/home"', 'TMPDIR="$ownership_root/tmp"',
                    'LIVEMORE_DATA_DIR="$ownership_root/data"', 'PYTHONPATH="$PWD"',
                    'PYTHONDONTWRITEBYTECODE=1', 'PYTHONUTF8=1'):
        assert setting in command
    assert f'"$ownership_python" -B -m pytest -p no:cacheprovider -q -rfEs {OWNERSHIP_NODE} ' in command
    assert '--junitxml="$ownership_root/ownership.xml"' in command
    assert run.count("-m pytest") == 1
    assert "sudo" not in text[:text.index(f"      - name: {OWNERSHIP_STEP}")].split("name: Run complete release gate", 1)[1]


def _checker(workflow: str) -> str:
    _, run = _step(workflow, WINDOWS_STEP if workflow == "platforms.yml" else OWNERSHIP_STEP)
    if workflow == "platforms.yml":
        match = re.search(r"^          @'\n(.*?)^          '@ \| python - \"\$junit\"$", run, re.M | re.S)
    else:
        match = re.search(r"^          python - \"\$ownership_root/ownership.xml\" <<'PY'\n(.*?)^          PY$", run, re.M | re.S)
    assert match is not None, "the leg must check its actual JUnit counts"
    return textwrap.dedent(match.group(1))


@source_tree_only(".github/workflows/installer.yml", ".github/workflows/platforms.yml")
@pytest.mark.parametrize("workflow,expected", [("platforms.yml", 4), ("installer.yml", 1)])
@pytest.mark.parametrize("outcome", ["pass", "skip", "failure", "error", "missing", "extra", "count-lie"])
def test_l0_r9_junit_checker_requires_exactly_the_named_pass_count(tmp_path, workflow, expected, outcome):
    checker = _checker(workflow)
    suites = ET.Element("testsuites")
    suite = ET.SubElement(suites, "testsuite", tests=str(expected), failures="0", errors="0", skipped="0")
    for index in range(expected):
        ET.SubElement(suite, "testcase", name=f"technical-case-{index}")
    if outcome in {"skip", "failure", "error"}:
        tag = "skipped" if outcome == "skip" else outcome
        ET.SubElement(suite[0], tag)
        suite.set({"skip": "skipped", "failure": "failures", "error": "errors"}[outcome], "1")
    elif outcome == "missing":
        suite.remove(suite[-1])
        suite.set("tests", str(expected - 1))
    elif outcome == "extra":
        ET.SubElement(suite, "testcase", name="technical-extra")
        suite.set("tests", str(expected + 1))
    elif outcome == "count-lie":
        ET.SubElement(suite[0], "skipped")
    report = tmp_path / "technical-junit.xml"
    report.write_text(ET.tostring(suites, encoding="unicode"), encoding="utf-8")
    result = subprocess.run([sys.executable, "-B", "-c", checker, str(report)],
                            capture_output=True, text=True, encoding="utf-8", timeout=10)
    assert (result.returncode == 0) is (outcome == "pass"), result.stderr


@source_tree_only(".github/workflows/platforms.yml")
def test_l0_r9_windows_collection_does_not_import_the_posix_suite_conftest(tmp_path):
    """Actual collection of the four cases, with POSIX-only imports refused."""
    _, run = _step("platforms.yml", WINDOWS_STEP)
    assert "--noconftest" in run
    guard = tmp_path / "windows_collection_guard.py"
    guard.write_text(textwrap.dedent('''\
        import importlib.abc
        import sys

        class RejectPosixSuiteImports(importlib.abc.MetaPathFinder):
            def find_spec(self, fullname, path=None, target=None):
                if fullname == "fcntl" or fullname.startswith("pandas"):
                    raise ImportError("technical native-Windows collection boundary: " + fullname)

        sys.meta_path.insert(0, RejectPosixSuiteImports())
    '''), encoding="utf-8")
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join((str(tmp_path), str(ROOT), environment.get("PYTHONPATH", "")))
    command = [sys.executable, "-B", "-m", "pytest", "--noconftest", "-p", "no:cacheprovider",
               "-p", "windows_collection_guard", "--collect-only", "-q",
               "livemorebio/tests/test_stable_new5c_pass_r_docs.py", "-k", "powershell_identity_generator"]
    result = subprocess.run(command, env=environment, cwd=ROOT, capture_output=True,
                            text=True, encoding="utf-8", timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr
    selected = [line for line in result.stdout.splitlines() if "::test_documented_powershell_identity_generator_is_canonical[" in line]
    assert len(selected) == 4 and len(set(selected)) == 4
