"""Technical absent-asset UI fixtures; no person, service or biological evidence."""
from __future__ import annotations

import json

from .test_legacy_preview_recovery_ui import check
from .test_legacy_preview_recovery_clients import preview
from .test_workspace_stream_ui import CONSOLE, javascript
from ._node import require_node, run_node


def test_legacy_current_read_accepts_only_a_complete_typed_cardiac_absence():
    check(r'''
function absent(){const x=ready();for(const k of ['t_ms','v','cai'])x.cardiac[k]=[];
 for(const k of ['vrest','vpeak','apd90_ms','cai_peak_uM'])x.cardiac[k]=null;
 x.cardiac.reason_code='CARDIAC_MODEL_NOT_INSTALLED';x.cardiac.reason='Technical fixture: missing pinned asset.';return x}
for(const code of ['CARDIAC_MODEL_NOT_INSTALLED','CARDIAC_MODEL_HASH_MISMATCH','CARDIAC_MODEL_UNSAFE_PATH']){
 const x=absent();x.cardiac.reason_code=code;const {owner,seen}=fixture({request:async()=>reply(x)});
 await owner.refreshCurrent();assert.equal(seen.published.length,1,'typed absent cardiac state rejected');
 assert.equal(seen.published[0].value.metabolic.mean_glucose,90.5);
 const ticket=owner.beginNumericalAction();assert(ticket,'independent metabolic scenario disabled');owner.finishNumericalAction(ticket);owner.dispose();
}
for(const damage of [x=>{delete x.cardiac.reason_code},x=>{x.cardiac.reason_code='UNKNOWN'},
 x=>{delete x.cardiac.reason},x=>{x.cardiac.reason=''},x=>{x.cardiac.v=[-80]},
 x=>{x.cardiac.apd90_ms=0},x=>{delete x.cardiac.cai_peak_uM},x=>{x.cardiac.hr_bpm=null},
 x=>{x.metabolic.glucose=[]}]){
 const x=absent();damage(x);const {owner,seen}=fixture({request:async()=>reply(x)});
 await owner.refreshCurrent();assert.equal(seen.published.length,0,'malformed absent shape admitted');
 assert.equal(owner.beginNumericalAction(),null);owner.dispose();
}
const x=ready();x.cardiac.reason_code='CARDIAC_MODEL_NOT_INSTALLED';x.cardiac.reason='Technical conflict';
const {owner,seen}=fixture({request:async()=>reply(x)});await owner.refreshCurrent();
assert.equal(seen.published.length,0,'refusal with numerical ventricular results admitted');owner.dispose();
''')


def test_legacy_absent_asset_keeps_metabolic_readout_and_never_animates_a_cell():
    html = (CONSOLE / "index.html").read_text(encoding="utf-8")
    prefix = "const $=" + html.split("<script>\nconst $=", 1)[1].split("// ===== Experiment / perturbation builder =====", 1)[0]
    render = "function render(){" + html.split("function render(){", 1)[1].split("// --- reactive metabolic curves ---", 1)[0]
    beat = "function beat(now){" + html.split("function beat(now){", 1)[1].split("function drawCell(", 1)[0]
    state = preview()
    for key in ("t_ms", "v", "cai"):
        state["cardiac"][key] = []
    for key in ("vrest", "vpeak", "apd90_ms", "cai_peak_uM"):
        state["cardiac"][key] = None
    state["cardiac"].update(reason_code="CARDIAC_MODEL_NOT_INSTALLED", reason="Technical fixture: absent pinned asset.")
    program = r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();let painted=0,metabolic=0,cleared=0;
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',hidden:false,style:{},dataset:{},width:1,height:1,
 classList:{toggle(){},remove(){}},setAttribute(){},addEventListener(){},replaceChildren(){},
 getContext:()=>({clearRect(){cleared++}}),querySelector:()=>({setAttribute(){}})});return nodes.get(id)}
const context={document:{getElementById:el,querySelectorAll:()=>[]},window:{addEventListener(){}},
 requestAnimationFrame(){},drawCell(){painted++},drawTrace(){painted++},console,technical:STATE};vm.createContext(context);
vm.runInContext(PREFIX,context);context.drawMetab=()=>metabolic++;context.paintBody=()=>{};
vm.runInContext('let LASTRUN=null,t0=0;function renderExtract(){};'+RENDER+BEAT,context);
vm.runInContext('S=technical;render();beat(500)',context);
a.equal(el('mMean').textContent,90.5);a.equal(metabolic,1);
for(const id of ['mVpeak','mApd','mCai','mBlk'])a.equal(el(id).textContent,'Unavailable');
a.match(el('cardNote').textContent,/CARDIAC_MODEL_NOT_INSTALLED/);
a(!el('cardNote').innerHTML.includes('the cell reacts'),'uncomputed ventricular physiology claimed');
a.equal(painted,0,'unavailable cell animated');a(cleared>=2,'old ventricular canvases not cleared');
'''
    for marker, value in {"STATE": state, "PREFIX": prefix, "RENDER": render, "BEAT": beat}.items():
        program = program.replace(marker, json.dumps(value))
    result = run_node([require_node(), "--eval", program], capture_output=True, text=True,
                      encoding="utf-8", timeout=15)
    assert result.returncode == 0, result.stderr


def test_workspace_null_apd_is_unavailable_without_a_fabricated_zero_delta():
    javascript(r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:''});return nodes.get(id)}
const context={document:{querySelector:el},URLSearchParams,technical:fixture(),escapeHTML:String,
 fmt:(value,digits)=>Number(value).toFixed(digits)};
vm.runInNewContext(PROJECTIONS+'\n'+CONTROLLER,context);
vm.runInNewContext('drawChart=()=>{};WORKSPACE=technical;',context);
for(const [baseline,treated] of [[null,null],[300,null],[null,300]]){
 context.technical.multiscale.comparison.baseline.apd90_ms=baseline;
 context.technical.multiscale.comparison.treated.apd90_ms=treated;
 vm.runInNewContext('renderComparison()',context);
 a.match(el('#key-metrics').innerHTML,/Ventricular APD90<\/span><strong>Unavailable<\/strong>/);
 a(!el('#chart-provenance').textContent.includes('CiPA ventricular cell'),'unavailable engine credited');
}
context.technical.multiscale.comparison.baseline.apd90_ms=250;
context.technical.multiscale.comparison.treated.apd90_ms=300;
vm.runInNewContext('renderComparison()',context);
a.match(el('#key-metrics').innerHTML,/Ventricular APD90<\/span><strong>\+50\.0 ms<\/strong>/);
a(el('#chart-provenance').textContent.includes('CiPA ventricular cell'));
''')


def test_legacy_organ_readout_does_not_credit_an_unavailable_ventricular_engine():
    html = (CONSOLE / "index.html").read_text(encoding="utf-8")
    body = "const ORGAN_SVG=" + html.split("const ORGAN_SVG=", 1)[1].split("function render(){", 1)[0]
    program = r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',style:{},setAttribute(){}});return nodes.get(id)}
const technical={organs:[{id:'heart',name:'Technical heart reference',status:'unavailable',
 reason_code:'CARDIAC_MODEL_NOT_INSTALLED',cell:{render:null,reason_code:'CARDIAC_MODEL_NOT_INSTALLED'}}]};
const context={$:el,esc:String,S:{context_id:null},legacyPreviewRecovery:{captureEpoch:()=>({}),isCurrent:()=>true},
 fetch:async()=>({ok:true,json:async()=>technical})};vm.createContext(context);
vm.runInContext(BODY,context);
(async()=>{await vm.runInContext('paintBody()',context);const text=el('organReadout').innerHTML;
 a(text.includes('Unavailable'));a(text.includes('CARDIAC_MODEL_NOT_INSTALLED'));
 a(!text.includes('AP · Ca²⁺ model'));a(!text.includes('>engine<'));a(!text.includes('width:100%'));
})().catch(error=>{console.error(error);process.exitCode=1});
'''.replace("BODY", json.dumps(body))
    result = run_node([require_node(), "--eval", program], capture_output=True, text=True,
                      encoding="utf-8", timeout=15)
    assert result.returncode == 0, result.stderr
