"""Technical fixtures for wire compatibility, never physical-device validation."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone

import pytest

from livemorebio.life_patch.protocol import ProtocolViolation
from ._timing import wait_seconds


NOW = datetime(2026, 9, 8, tzinfo=timezone.utc)


def manifest_payload(mode="virtual"):
    return {
        "schema_version": "livemore.life-patch.manifest.v3",
        "protocol_version": "3.0", "device_id": "v3-technical", "mode": mode,
        "hardware_revision": "B0-EVT-target", "configuration_id": "core-fixture-1",
        "firmware_version": "fixture-3.0", "firmware_hash": "a" * 64,
        "hardware_present": mode != "virtual",
        "capabilities": [{"signal": "hr_bpm", "unit": "bpm", "channel": "ecg",
                          "provenance": "technical_fixture" if mode == "virtual" else "derived",
                          "cartridge_id": None}],
        "safe_commands": ["request_quality_check"],
    }


def envelope_payload(mode="virtual"):
    from livemorebio.life_patch.protocol_v3 import ManifestV3
    manifest = ManifestV3.from_dict(manifest_payload(mode))
    return {
        "schema_version": "livemore.life-patch.telemetry.v3", "protocol_version": "3.0",
        "envelope_id": "v3-envelope", "device_id": manifest.device_id,
        "subject_id": "pseudonym-fixture", "subject_pseudonymized": True,
        "sequence": 1, "mode": mode, "manifest_hash": manifest.capability_hash,
        "firmware_hash": "a" * 64, "captured_at": "2026-09-08T00:00:00Z",
        "acquisition_start": "2026-09-08T00:00:00Z",
        "acquisition_end": "2026-09-08T00:00:00Z",
        "clock": {"session_id": "boot-fixture", "monotonic_start_s": 12.0,
                  "monotonic_end_s": 12.0, "utc_uncertainty_s": 0.01},
        "measurements": [{
            "measurement_id": "hr-1", "signal": "hr_bpm", "unit": "bpm",
            "provenance": "technical_fixture" if mode == "virtual" else "derived",
            "kind": "scalar", "value": 72.0,
            "quality_status": "pass", "calibration_status": "not_applicable",
            "quality_flags": [],
            "context": {"endpoint": "hr_bpm", "biofluid": None, "site": "chest",
                        "compartment": "cardiovascular", "assay_id": None,
                        "cartridge_id": None, "calibration_id": None,
                        "derivation_id": "fixture-hr-algorithm"},
        }],
    }


def test_v2_golden_hashes_and_dispatch_are_unchanged():
    from livemorebio.life_patch.protocol import (
        DeviceMode, TelemetryEnvelope, TelemetryMeasurement, manifest_for,
        decode_envelope, decode_manifest,
    )
    manifest = manifest_for("v2-technical", DeviceMode.VIRTUAL)
    envelope = TelemetryEnvelope(
        "v2-envelope", "v2-technical", "pseudonym-fixture", 7, NOW, DeviceMode.VIRTUAL,
        (TelemetryMeasurement("hr_bpm", 72.0, "bpm", "direct"),),
    )
    assert manifest.capability_hash == "c842f19a47fec80baeffe42d47bc6e0eb75f2a9d259e189d12a6f17cd42842df"
    assert envelope.envelope_hash == "6dea9fa2f7018b49316aede60bd77d29a9f821df99d3947ce39878cd38171057"
    assert decode_manifest(manifest.to_dict()).to_dict() == manifest.to_dict()
    assert decode_envelope(envelope.to_dict()).to_dict() == envelope.to_dict()


def test_v3_round_trip_is_immutable_and_projects_full_lineage():
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.protocol_v3 import normalize_observations
    manifest = decode_manifest(manifest_payload())
    raw = envelope_payload()
    envelope = decode_envelope(raw)
    raw["measurements"][0]["value"] = 999
    assert decode_envelope(envelope.to_dict()).to_dict() == envelope.to_dict()
    assert decode_manifest(manifest.to_dict()).capability_hash == manifest.capability_hash
    projected = normalize_observations(envelope, received_at=NOW + timedelta(seconds=2))
    row = projected["hr_bpm"]
    assert row["value"] == 72
    assert row["mode"] == "virtual"
    assert row["provenance"] == "technical_fixture"
    assert row["envelope_hash"] == envelope.envelope_hash
    assert row["received_at"] == "2026-09-08T00:00:02Z"
    assert row["clock"]["session_id"] == "boot-fixture"
    assert row["context"]["derivation_id"] == "fixture-hr-algorithm"
    row["context"]["site"] = "changed"
    assert normalize_observations(envelope)["hr_bpm"]["context"]["site"] == "chest"


@pytest.mark.parametrize("mutation", [
    lambda p: p.update(protocol_version="2.0"),
    lambda p: p.update(sequence=True),
    lambda p: p.update(sequence=1.5),
    lambda p: p.update(sequence="1"),
    lambda p: p.update(sequence=10 ** 1000),
    lambda p: p.update(subject_pseudonymized="true"),
    lambda p: p.update(acquisition_start="2026-09-08T00:01:00Z"),
    lambda p: p.update(captured_at="2026-09-08T00:01:00Z"),
    lambda p: p["clock"].update(monotonic_end_s=11.0),
    lambda p: p["clock"].update(utc_uncertainty_s=-1),
    lambda p: p["measurements"][0].update(value=True),
    lambda p: p["measurements"][0].update(value=float("nan")),
    lambda p: p["measurements"][0].update(value="72"),
    lambda p: p["measurements"][0].update(unit="mg/dL"),
    lambda p: p["measurements"][0].update(provenance="raw"),
    lambda p: p["measurements"][0].update(quality_status="reject"),
    lambda p: p["measurements"][0].update(calibration_status="failed"),
    lambda p: p["measurements"][0].update(unknown_lineage="private note"),
    lambda p: p["measurements"].append(deepcopy(p["measurements"][0])),
    lambda p: p.update(extra={"deep": ["x"] * 20000}),
])
def test_v3_rejects_invalid_or_unbounded_input_without_echo(mutation):
    from livemorebio.life_patch.protocol import decode_envelope
    raw = envelope_payload()
    mutation(raw)
    with pytest.raises(ProtocolViolation) as caught:
        decode_envelope(raw)
    assert "private note" not in str(caught.value)


def test_v3_tampered_lineage_cannot_reuse_hash():
    from livemorebio.life_patch.protocol import decode_envelope
    raw = decode_envelope(envelope_payload()).to_dict()
    raw["measurements"][0]["context"]["site"] = "wrist"
    with pytest.raises(ProtocolViolation, match="hash"):
        decode_envelope(raw)


def test_modeled_requires_explicit_model_context_and_cannot_be_physical():
    from livemorebio.life_patch.protocol import decode_envelope
    raw = envelope_payload()
    row = raw["measurements"][0]
    row["provenance"] = "modeled"
    with pytest.raises(ProtocolViolation):
        decode_envelope(raw)
    row["model_context"] = {
        "prediction_id": "frozen-prediction", "condition_id": "control",
        "model_time_min": 2.0, "model_id": "technical-linear-fixture",
        "mapping_id": "technical-identity",
    }
    assert decode_envelope(raw).mode.value == "virtual"
    raw["mode"] = "physical"
    with pytest.raises(ProtocolViolation):
        decode_envelope(raw)


def test_v2_projection_keeps_missing_lineage_unknown():
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for
    from livemorebio.life_patch.protocol_v3 import normalize_observations
    envelope = VirtualLifePatch(manifest_for("legacy", DeviceMode.VIRTUAL)).emit(
        "pseudonym-fixture", {"hr_bpm": 72}, captured_at=NOW,
    )
    row = normalize_observations(envelope)["hr_bpm"]
    assert row["mode"] == "virtual"
    assert row["provenance"] == "legacy_unknown"
    assert row["clock"] is None and row["model_context"] is None
    assert row["received_at"] is None
    assert row["envelope_hash"] == envelope.envelope_hash


def test_waveforms_stay_linked_source_blocks_not_scalar_evidence():
    from livemorebio.life_patch.protocol import decode_envelope
    from livemorebio.life_patch.protocol_v3 import normalize_observations
    from livemorebio.life_patch.evidence import to_evidence_measurements
    raw = envelope_payload()
    row = raw["measurements"][0]
    row.update(signal="ppg_au", unit="AU", kind="waveform", samples=[1.0, 2.0, 1.0], sample_period_s=0.5)
    del row["value"]
    row["context"]["endpoint"] = "ppg_au"
    raw["acquisition_start"] = "2026-09-07T23:59:59Z"
    raw["clock"]["monotonic_start_s"] = 11.0
    envelope = decode_envelope(raw)
    projected = normalize_observations(envelope)["ppg_au"]
    assert projected["value"] is None
    assert "samples" not in projected
    assert projected["source_block"]["sample_count"] == 3
    assert projected["source_block"]["envelope_hash"] == envelope.envelope_hash
    assert to_evidence_measurements(envelope, tenant_id="fixture", received_at=NOW) == ()
    row["samples"] = [0.0] * 4097
    with pytest.raises(ProtocolViolation):
        decode_envelope(raw)


def test_v3_gateway_binds_registered_manifest_and_preserves_restart(tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest, DeviceMode, manifest_for
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    gateway.register(manifest_for("legacy", DeviceMode.VIRTUAL))
    manifest = decode_manifest(manifest_payload())
    gateway.register(manifest)
    gateway._admission._now = lambda: NOW
    envelope = decode_envelope(envelope_payload())
    admitted = gateway.admit(envelope)
    assert admitted["manifest"] == manifest.to_dict()
    assert admitted["manifest_hash"] == manifest.capability_hash
    restored = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    assert restored.manifest("legacy").protocol_version == "2.0"
    assert restored.manifest(manifest.device_id).capability_hash == manifest.capability_hash
    assert restored.next_sequence(manifest.device_id) == 2
    restored._admission._now = lambda: NOW
    with pytest.raises(ProtocolViolation, match="replayed"):
        restored.admit(envelope)
    raw = envelope_payload()
    raw.update(sequence=2, manifest_hash="b" * 64)
    with pytest.raises(ProtocolViolation, match="manifest"):
        restored.admit(decode_envelope(raw))
    assert restored.next_sequence(manifest.device_id) == 2


def test_v3_manifest_capabilities_and_clock_reset_are_admission_gates(tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW
    gateway.admit(decode_envelope(envelope_payload()))
    raw = envelope_payload()
    raw["sequence"] = 2
    raw["clock"].update(monotonic_start_s=1, monotonic_end_s=1)
    with pytest.raises(ProtocolViolation, match="clock"):
        gateway.admit(decode_envelope(raw))
    raw = envelope_payload()
    raw["sequence"] = 2
    raw["measurements"][0].update(signal="hrv_ms", unit="ms")
    raw["measurements"][0]["context"]["endpoint"] = "hrv_ms"
    with pytest.raises(ProtocolViolation, match="capability"):
        gateway.admit(decode_envelope(raw))
    assert gateway.next_sequence("v3-technical") == 2


def test_failed_manifest_load_does_not_silently_erase_registration(tmp_path, monkeypatch):
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = tmp_path / "technical.devices.json"
    path.write_text('{"bad":{"schema_version":"unsupported"}}', encoding="utf-8")
    with pytest.raises(ValueError):
        LifePatchGateway(str(tmp_path / "technical.jsonl"))
    assert path.read_text(encoding="utf-8") == '{"bad":{"schema_version":"unsupported"}}'


def test_clock_mapping_jump_is_rejected_after_restart(tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = str(tmp_path / "technical.jsonl")
    gateway = LifePatchGateway(path)
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW
    gateway.admit(decode_envelope(envelope_payload()))
    restored = LifePatchGateway(path)
    restored._admission._now = lambda: NOW + timedelta(seconds=60)
    raw = envelope_payload()
    raw.update(sequence=2, captured_at="2026-09-08T00:01:00Z",
               acquisition_start="2026-09-08T00:01:00Z", acquisition_end="2026-09-08T00:01:00Z")
    # Only one monotonic second elapsed, but UTC jumped by a minute.
    raw["clock"].update(monotonic_start_s=13, monotonic_end_s=13)
    with pytest.raises(ProtocolViolation, match="clock"):
        restored.admit(decode_envelope(raw))
    raw["clock"].update(session_id="new-boot", monotonic_start_s=0, monotonic_end_s=0)
    assert restored.admit(decode_envelope(raw))["sequence"] == 2


def test_failed_append_and_registration_do_not_consume_prior_state(tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    manifest = decode_manifest(manifest_payload())
    gateway.register(manifest)
    gateway._admission._now = lambda: NOW
    append = gateway._append
    monkeypatch.setattr(gateway, "_append", lambda *a, **k: (_ for _ in ()).throw(OSError("fixture disk full")))
    with pytest.raises(OSError):
        gateway.admit(decode_envelope(envelope_payload()))
    assert gateway.next_sequence(manifest.device_id) == 0
    monkeypatch.setattr(gateway, "_append", append)
    gateway.admit(decode_envelope(envelope_payload()))
    prior = gateway.device_path.read_bytes()
    raw = manifest_payload()
    raw["device_id"] = "another-technical-device"
    monkeypatch.setattr("os.replace", lambda *a: (_ for _ in ()).throw(OSError("fixture replace failed")))
    with pytest.raises(OSError):
        gateway.register(decode_manifest(raw))
    assert gateway.manifest(raw["device_id"]) is None
    assert gateway.device_path.read_bytes() == prior


def test_manifest_temporary_symlink_cannot_overwrite_other_file(tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import decode_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    untouched = tmp_path / "unrelated-technical.txt"
    untouched.write_text("preserve", encoding="utf-8")
    gateway.device_path.with_suffix(".json.tmp").symlink_to(untouched)
    gateway.register(decode_manifest(manifest_payload()))
    assert untouched.read_text(encoding="utf-8") == "preserve"


def test_v3_physical_journal_encryption_evidence_and_manifest_substitution(tmp_path, monkeypatch):
    import base64
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.evidence import to_evidence_measurements
    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", base64.urlsafe_b64encode(b"v" * 32).decode())
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    manifest = decode_manifest(manifest_payload("physical"))
    gateway.register(manifest)
    gateway._admission._now = lambda: NOW
    envelope = decode_envelope(envelope_payload("physical"))
    with pytest.raises(ValueError, match="consent"):
        to_evidence_measurements(envelope, tenant_id="fixture", received_at=NOW)
    measurements = to_evidence_measurements(
        envelope, tenant_id="fixture", received_at=NOW,
        consent_scope=("technical-test",), chain_of_custody=("synthetic-test-fixture",),
    )
    assert measurements[0].role.value == "baseline_input"
    assert envelope.envelope_hash in measurements[0].payload.method
    gateway.admit(envelope)
    stored = gateway.journal_path.read_text(encoding="utf-8")
    assert "pseudonym-fixture" not in stored and "hr_bpm" not in stored
    restored = LifePatchGateway(str(gateway.journal_path))
    assert restored.latest()["envelope_hash"] == envelope.envelope_hash
    changed = manifest_payload("physical")
    changed["configuration_id"] = "changed-cartridge"
    with pytest.raises(ValueError, match="new device identity"):
        restored.register(decode_manifest(changed))


def test_unknown_qc_is_not_promoted_and_commands_follow_manifest(tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.evidence import to_evidence_measurements
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    raw = envelope_payload()
    raw["measurements"][0].update(quality_status="unknown", calibration_status="unknown")
    rows = to_evidence_measurements(decode_envelope(raw), tenant_id="fixture", received_at=NOW)
    assert rows[0].payload.quality_status.value == "not_assessed"
    assert rows[0].payload.calibration_status.value == "not_assessed"
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    gateway.register(decode_manifest(manifest_payload()))
    with pytest.raises(ValueError, match="capabilities"):
        gateway.issue_command(device_id="v3-technical", command="start_chemistry_session", parameters={})


def test_inferred_physical_scalar_is_not_promoted_to_observed_evidence():
    from livemorebio.life_patch.protocol import decode_envelope
    from livemorebio.life_patch.evidence import to_evidence_measurements
    raw = envelope_payload("physical")
    raw["measurements"][0]["provenance"] = "inferred"
    rows = to_evidence_measurements(
        decode_envelope(raw), tenant_id="fixture", received_at=NOW,
        consent_scope=("technical-test",), chain_of_custody=("technical-fixture",),
    )
    assert rows == ()


def test_future_packet_is_rejected_at_gateway_and_receipt_is_preserved(tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW
    with pytest.raises(ProtocolViolation, match="receipt"):
        gateway.admit(decode_envelope(envelope_payload()), received_at=NOW - timedelta(seconds=1))
    assert gateway.next_sequence("v3-technical") == 0
    accepted = gateway.admit(decode_envelope(envelope_payload()), received_at=NOW + timedelta(seconds=1))
    assert accepted["received_at"] == "2026-09-08T00:00:01Z"
    assert accepted["captured_at"] == "2026-09-08T00:00:00Z"


@pytest.mark.parametrize("mutation", [
    lambda p: p.update(protocol_version="2.0"),
    lambda p: p.update(hardware_present="false"),
    lambda p: p.update(hardware_present=True),
    lambda p: p.update(firmware_hash="not-a-hash"),
    lambda p: p.update(hardware_revision="unreviewed-hardware"),
    lambda p: p.update(configuration_id="contains private free text"),
    lambda p: p.update(safe_commands=["deliver_drug"]),
    lambda p: p.update(safe_commands=["request_quality_check"] * 2),
    lambda p: p["capabilities"][0].update(channel="chem"),
    lambda p: p["capabilities"][0].update(provenance="raw"),
    lambda p: p["capabilities"].append(deepcopy(p["capabilities"][0])),
    lambda p: p["capabilities"][0].update(extra="private prose"),
])
def test_manifest_rejects_invalid_claims_and_unknown_fields(mutation):
    from livemorebio.life_patch.protocol import decode_manifest
    raw = manifest_payload()
    mutation(raw)
    with pytest.raises(ProtocolViolation) as caught:
        decode_manifest(raw)
    assert "private" not in str(caught.value)


def test_trusted_manifest_binding_rejects_substitution():
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    from livemorebio.life_patch.protocol_v3 import validate_manifest_binding
    manifest = decode_manifest(manifest_payload())
    for changes in ({"firmware_hash": "b" * 64}, {"device_id": "another-device"}):
        packet = envelope_payload()
        packet.update(changes)
        with pytest.raises(ProtocolViolation):
            validate_manifest_binding(manifest, decode_envelope(packet))
    packet = envelope_payload()
    packet["measurements"][0]["context"]["cartridge_id"] = "unregistered-cartridge"
    with pytest.raises(ProtocolViolation, match="cartridge"):
        validate_manifest_binding(manifest, decode_envelope(packet))


def test_v3_quality_derivation_and_waveform_timing_fail_closed():
    from livemorebio.life_patch.protocol import decode_envelope
    for mutate in (
        lambda p: p["measurements"][0]["context"].update(derivation_id=None),
        lambda p: p["measurements"][0].update(quality_flags=["motion_artifact"]),
    ):
        packet = envelope_payload("physical")
        mutate(packet)
        with pytest.raises(ProtocolViolation):
            decode_envelope(packet)
    packet = envelope_payload()
    packet["measurements"][0].update(kind="waveform", samples=[70, 71], sample_period_s=1)
    del packet["measurements"][0]["value"]
    with pytest.raises(ProtocolViolation, match="timing"):
        decode_envelope(packet)


def test_unknown_and_mixed_wire_versions_are_not_silently_upgraded():
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    for decoder, payload in ((decode_manifest, manifest_payload()), (decode_envelope, envelope_payload())):
        payload["protocol_version"] = "999"
        with pytest.raises(ProtocolViolation, match="unsupported"):
            decoder(payload)
        with pytest.raises(ProtocolViolation):
            decoder([])


def test_quality_flag_duplicates_are_checked_after_identifier_normalization():
    from livemorebio.life_patch.protocol import decode_envelope
    packet = envelope_payload()
    packet["measurements"][0].update(
        quality_status="degraded", quality_flags=["motion", " motion "],
    )
    with pytest.raises(ProtocolViolation, match="duplicated"):
        decode_envelope(packet)


@pytest.mark.parametrize("restart", [False, True])
def test_new_clock_session_does_not_allow_reordered_acquisition(tmp_path, monkeypatch, restart):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_envelope, decode_manifest
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = str(tmp_path / "technical.jsonl")
    gateway = LifePatchGateway(path)
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW
    gateway.admit(decode_envelope(envelope_payload()))
    if restart:
        gateway = LifePatchGateway(path)
        gateway._admission._now = lambda: NOW
    packet = envelope_payload()
    packet.update(sequence=2, captured_at="2026-09-07T23:59:30Z",
                  acquisition_start="2026-09-07T23:59:30Z", acquisition_end="2026-09-07T23:59:30Z")
    packet["clock"].update(session_id="different-boot", monotonic_start_s=0, monotonic_end_s=0)
    with pytest.raises(ProtocolViolation, match="acquisition"):
        gateway.admit(decode_envelope(packet))
    assert gateway.next_sequence("v3-technical") == 2
    assert len(gateway.telemetry()) == 1


@pytest.mark.parametrize("command,parameters", [
    ("request_burst", {"duration_seconds": 5, "channels": ["chem"]}),
    ("start_chemistry_session", {"duration_seconds": 10, "analytes": ["glucose_mgdl"]}),
])
def test_v3_command_parameters_cannot_address_unregistered_capabilities(tmp_path, monkeypatch, command, parameters):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    payload = manifest_payload()
    payload["safe_commands"] = ["request_burst", "start_chemistry_session"]
    gateway.register(decode_manifest(payload))
    with pytest.raises(ProtocolViolation, match="capabilit"):
        gateway.issue_command(device_id="v3-technical", command=command, parameters=parameters)
    assert gateway.commands() == []
    accepted = gateway.issue_command(
        device_id="v3-technical", command="request_burst",
        parameters={"duration_seconds": 5, "channels": ["ecg"]},
    )
    assert accepted.parameters["channels"] == ["ecg"]


@pytest.mark.parametrize("version", ["2.0", "3.0"])
def test_existing_gateway_instances_refresh_durable_replay_state(tmp_path, monkeypatch, version):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import (
        decode_manifest, decode_envelope, manifest_for, DeviceMode, VirtualLifePatch,
    )
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = str(tmp_path / "technical.jsonl")
    first, second = LifePatchGateway(path), LifePatchGateway(path)
    if version == "3.0":
        manifest, envelope = decode_manifest(manifest_payload()), decode_envelope(envelope_payload())
    else:
        manifest = manifest_for("legacy", DeviceMode.VIRTUAL)
        envelope = VirtualLifePatch(manifest).emit("pseudonym-fixture", {"hr_bpm": 72}, captured_at=NOW)
    for gateway in (first, second):
        gateway.register(manifest)
        gateway._admission._now = lambda: NOW
    first.admit(envelope)
    with pytest.raises(ProtocolViolation, match="replayed"):
        second.admit(envelope)
    assert second.next_sequence(manifest.device_id) == 2
    assert len(second.telemetry()) == 1


def test_existing_gateways_do_not_overwrite_other_device_registrations(tmp_path, monkeypatch):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = str(tmp_path / "technical.jsonl")
    first, second = LifePatchGateway(path), LifePatchGateway(path)
    first.register(decode_manifest(manifest_payload()))
    other = manifest_payload()
    other["device_id"] = "another-technical-device"
    second.register(decode_manifest(other))
    restored = LifePatchGateway(path)
    assert restored.manifest("v3-technical") is not None
    assert first.manifest("another-technical-device") is not None


def _competing_gateway_admission(path, ready, release, result, allocate=False):
    """Spawn-safe technical worker; no operational stores, network, or services."""
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_envelope
    gateway = LifePatchGateway(path)
    gateway._admission._now = lambda: NOW
    ready.put(True)
    if not release.wait(10):
        result.put("test-timeout")
        return
    try:
        if allocate:
            with gateway.transaction():
                packet = envelope_payload()
                packet["sequence"] = gateway.next_sequence("v3-technical")
                record = gateway.admit(decode_envelope(packet))
                result.put(record["sequence"])
            return
        gateway.admit(decode_envelope(envelope_payload()))
    except ProtocolViolation:
        result.put("rejected")
    else:
        result.put("accepted")


@pytest.mark.parametrize("allocate", [False, True])
def test_two_processes_cannot_admit_the_same_sequence(tmp_path, monkeypatch, allocate):
    import multiprocessing
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = str(tmp_path / "technical.jsonl")
    gateway = LifePatchGateway(path)
    gateway.register(decode_manifest(manifest_payload()))
    context = multiprocessing.get_context("spawn")
    ready, result, release = context.Queue(), context.Queue(), context.Event()
    workers = [context.Process(target=_competing_gateway_admission,
                               args=(path, ready, release, result, allocate)) for _ in range(2)]
    try:
        for worker in workers:
            worker.start()
        for _ in workers:
            assert ready.get(timeout=10) is True
        release.set()
        expected = [0, 1] if allocate else ["accepted", "rejected"]
        assert sorted(result.get(timeout=10) for _ in workers) == expected
        assert len(gateway.telemetry()) == (2 if allocate else 1)
    finally:
        release.set()
        for worker in workers:
            worker.join(timeout=wait_seconds(10))
            if worker.is_alive():
                worker.terminate()
                worker.join(timeout=wait_seconds(5))
        ready.close()
        result.close()


def test_durable_refresh_rejects_incomplete_journal_without_erasing_it(tmp_path, monkeypatch):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest, decode_envelope
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW
    gateway.admit(decode_envelope(envelope_payload()))
    with gateway.journal_path.open("ab") as stream:
        stream.write(b'{"partial":')
    damaged = gateway.journal_path.read_bytes()
    with pytest.raises(ValueError, match="journal"):
        gateway.next_sequence("v3-technical")
    assert gateway.journal_path.read_bytes() == damaged


def test_invalid_clock_record_cannot_partially_advance_replay_refresh(tmp_path, monkeypatch):
    import json
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest, decode_envelope
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW
    row = gateway.admit(decode_envelope(envelope_payload()))
    gateway.next_sequence("v3-technical")
    row.update(sequence=2, clock={})
    with gateway.journal_path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row) + "\n")
    damaged = gateway.journal_path.read_bytes()
    for _ in range(2):
        with pytest.raises(ValueError, match="journal"):
            gateway.next_sequence("v3-technical")
        assert gateway._admission.last_sequence("v3-technical") == 1
    assert gateway.journal_path.read_bytes() == damaged
    with pytest.raises(ValueError, match="journal"):
        LifePatchGateway(str(gateway.journal_path))


def test_retired_session_cannot_return_with_a_reset_monotonic_clock(tmp_path, monkeypatch):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest, decode_envelope
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = str(tmp_path / "technical.jsonl")
    gateway = LifePatchGateway(path)
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW + timedelta(seconds=2)
    gateway.admit(decode_envelope(envelope_payload()))
    packet = envelope_payload()
    packet.update(sequence=2, captured_at="2026-09-08T00:00:01Z",
                  acquisition_start="2026-09-08T00:00:01Z", acquisition_end="2026-09-08T00:00:01Z")
    packet["clock"].update(session_id="different-boot", monotonic_start_s=0, monotonic_end_s=0)
    gateway.admit(decode_envelope(packet))
    gateway = LifePatchGateway(path)
    gateway._admission._now = lambda: NOW + timedelta(seconds=2)
    packet.update(sequence=3, captured_at="2026-09-08T00:00:02Z",
                  acquisition_start="2026-09-08T00:00:02Z", acquisition_end="2026-09-08T00:00:02Z")
    packet["clock"]["session_id"] = "boot-fixture"
    with pytest.raises(ProtocolViolation, match="session"):
        gateway.admit(decode_envelope(packet))
    assert gateway.next_sequence("v3-technical") == 3


def test_old_out_of_capability_command_is_not_reissued_by_idempotency(tmp_path, monkeypatch):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest, PatchCommand
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    raw = manifest_payload()
    raw["safe_commands"] = ["request_burst"]
    gateway.register(decode_manifest(raw))
    old = PatchCommand("technical-command", "v3-technical", "request_burst",
                       {"duration_seconds": 5, "channels": ["chem"]}, NOW, NOW + timedelta(seconds=10))
    with gateway.transaction():
        gateway._append(gateway.command_path, {"record_type": "command", **old.to_dict()})
    before = gateway.command_path.read_bytes()
    with pytest.raises(ProtocolViolation, match="capabilit"):
        gateway.issue_command(device_id=old.device_id, command=old.command,
                              parameters=dict(old.parameters), command_id=old.command_id)
    assert gateway.command_path.read_bytes() == before


def test_lock_contention_is_bounded_and_ownership_is_transaction_scoped(tmp_path, monkeypatch):
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    path = str(tmp_path / "technical.jsonl")
    first, second = LifePatchGateway(path), LifePatchGateway(path)
    second._lock_timeout_seconds = 0
    with first.transaction():
        with first.transaction():
            assert first.next_sequence("unregistered-fixture") == 0
        with pytest.raises(ValueError, match="busy"):
            second.next_sequence("unregistered-fixture")
    assert second.next_sequence("unregistered-fixture") == 0


@pytest.mark.parametrize("unsafe_link", ["symlink", "hardlink"])
def test_lock_file_cannot_follow_or_modify_other_files(tmp_path, monkeypatch, unsafe_link):
    import os
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    unrelated = tmp_path / "preserved-fixture"
    unrelated.write_text("preserve", encoding="utf-8")
    mode_before = unrelated.stat().st_mode
    path = tmp_path / "technical.lock"
    if unsafe_link == "symlink":
        path.symlink_to(unrelated)
    else:
        os.link(unrelated, path)
    with pytest.raises(ValueError, match="lock"):
        LifePatchGateway(str(tmp_path / "technical.jsonl"))
    assert unrelated.read_text(encoding="utf-8") == "preserve"
    assert unrelated.stat().st_mode == mode_before


def test_lock_descriptor_closes_when_unlock_fails(tmp_path, monkeypatch):
    import fcntl
    import os
    from livemorebio.life_patch.gateway import LifePatchGateway
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    original_flock = fcntl.flock
    failed_descriptor = []

    def fail_unlock(descriptor, operation):
        if operation == fcntl.LOCK_UN:
            failed_descriptor.append(descriptor)
            raise OSError("technical unlock failure")
        original_flock(descriptor, operation)

    monkeypatch.setattr(fcntl, "flock", fail_unlock)
    with pytest.raises(ValueError, match="lock"):
        gateway.next_sequence("unregistered-fixture")
    assert len(failed_descriptor) == 1
    with pytest.raises(OSError):
        os.fstat(failed_descriptor[0])


@pytest.mark.parametrize("store_name", ["journal_path", "device_path", "command_path"])
@pytest.mark.parametrize("unsafe_link", ["symlink", "hardlink"])
def test_store_aliases_cannot_bypass_the_shared_lock(tmp_path, monkeypatch, store_name, unsafe_link):
    import os
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest, decode_envelope
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    original = LifePatchGateway(str(tmp_path / "original.jsonl"))
    original.register(decode_manifest(manifest_payload()))
    original._admission._now = lambda: NOW
    original.admit(decode_envelope(envelope_payload()))
    original.issue_command(device_id="v3-technical", command="request_quality_check", parameters={})
    alias = LifePatchGateway(str(tmp_path / "alias.jsonl"))
    target, link = getattr(original, store_name), getattr(alias, store_name)
    before = target.read_bytes()
    mode_before = target.stat().st_mode
    if unsafe_link == "symlink":
        link.symlink_to(target)
    else:
        os.link(target, link)
    with pytest.raises(ValueError, match="safely|unsafe"):
        restored = LifePatchGateway(str(alias.journal_path))
        restored.commands()
    assert target.read_bytes() == before
    assert target.stat().st_mode == mode_before


def test_replay_refresh_decodes_only_newly_appended_records(tmp_path, monkeypatch):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import decode_manifest, decode_envelope
    monkeypatch.delenv("LIVEMORE_PATCH_STORAGE_KEY", raising=False)
    gateway = LifePatchGateway(str(tmp_path / "technical.jsonl"))
    gateway.register(decode_manifest(manifest_payload()))
    gateway._admission._now = lambda: NOW + timedelta(seconds=3)
    original_read = gateway._read_records
    decoded_counts = []

    def record_reads(stream):
        records = original_read(stream)
        decoded_counts.append(len(records))
        return records

    monkeypatch.setattr(gateway, "_read_records", record_reads)
    for sequence in range(1, 4):
        packet = envelope_payload()
        stamp = (NOW + timedelta(seconds=sequence)).isoformat()
        packet.update(sequence=sequence, captured_at=stamp, acquisition_start=stamp, acquisition_end=stamp)
        packet["clock"].update(monotonic_start_s=12 + sequence, monotonic_end_s=12 + sequence)
        gateway.admit(decode_envelope(packet))
        gateway.next_sequence("v3-technical")
    assert sum(decoded_counts) == 3
    assert max(decoded_counts) == 1
