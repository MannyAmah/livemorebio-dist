"""PHI-1 wrapper failures; all names, identifiers and values are technical fixtures."""
from __future__ import annotations

import importlib
import logging
from types import SimpleNamespace

from fastapi.testclient import TestClient
import pytest


TECHNICAL_VALUE = "TECHNICAL Jane TESTONLY MRN-778812 HbA1c-9.4"
TECHNICAL_TOKEN = "technical-wrapper-regression-not-a-real-token"
AUDIT_REQUEST_ID = "b" * 32
RECORD_ID = "a" * 32


@pytest.mark.parametrize("module_name,service_name,template", [
    ("livemorebio.aegle.execution_api", "livemorebio.aegle.server",
     "/api/executions/{execution_id}"),
    ("livemorebio.life_system.virtual_execution_api", "livemorebio.life_system.service",
     "/patch/virtual/sessions/{session_id}"),
])
def test_PHI_1_execution_wrapper_logs_only_safe_diagnostic(
    monkeypatch, caplog, module_name, service_name, template,
):
    module = importlib.import_module(module_name)
    service = importlib.import_module(service_name)
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TECHNICAL_TOKEN)
    finished = []

    def technical_failure(*args, **kwargs):
        raise RuntimeError(TECHNICAL_VALUE)

    store = SimpleNamespace(
        begin_access=lambda *args, **kwargs: AUDIT_REQUEST_ID,
        finish_access=lambda *args: finished.append(args),
    )
    manager = SimpleNamespace(store=store, status=technical_failure)
    monkeypatch.setattr(module, "_manager", lambda: manager)
    caplog.set_level(logging.ERROR)
    path = template.replace("{execution_id}", RECORD_ID).replace("{session_id}", RECORD_ID)
    response = TestClient(service.app).get(
        path, headers={"Authorization": "Bearer " + TECHNICAL_TOKEN},
    )

    assert response.status_code == 503
    assert response.json() == {
        "code": "EXECUTION_STORAGE",
        "error": "Execution storage is unavailable or failed integrity checks.",
    }
    assert response.headers["X-Livemore-Request-Id"] == AUDIT_REQUEST_ID
    assert finished == [(AUDIT_REQUEST_ID, "EXECUTION_STORAGE")]
    assert TECHNICAL_VALUE not in response.text
    assert TECHNICAL_VALUE not in caplog.text
    assert "Traceback" not in caplog.text
    assert RECORD_ID not in caplog.text
    assert "RuntimeError" in caplog.text
    assert "GET" in caplog.text and template in caplog.text
    assert AUDIT_REQUEST_ID in caplog.text
