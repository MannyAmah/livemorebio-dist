"""L0-R27: identifiers never read as a clinical note's contact number; real numbers still do."""
from __future__ import annotations

import random
import uuid

import pytest

from livemorebio.clinical_note_gate import carries_clinical_note_marks


def test_the_uuid_that_was_refused_is_an_identifier():
    # A gate run refused this request identifier as a telephone number ("698243-0406").
    assert not carries_clinical_note_marks("fd698243-0406-4d40-b08b-de447ee10b56")


def test_one_hundred_thousand_random_uuids_carry_no_mark():
    rng = random.Random(20261106)
    for _ in range(100_000):
        identifier = str(uuid.UUID(int=rng.getrandbits(128), version=4))
        assert not carries_clinical_note_marks(identifier), identifier
        assert not carries_clinical_note_marks(identifier.upper()), identifier


@pytest.mark.parametrize("text", [
    "call 555-123-4567", "555-123-4567", "(555) 123-4567", "555.123.4567",
    "phone: 555 123 4567", "tel:555-123-4567", "x 555-123-4567",
])
def test_a_standalone_telephone_number_is_still_a_mark(text):
    assert carries_clinical_note_marks(text)


def test_an_upper_case_uuid_is_not_an_age_with_a_sex_letter():
    assert not carries_clinical_note_marks("A336EEBD-107F-4A6B-A9A4-C1574AB809B7")


def test_marks_beside_an_identifier_still_count():
    assert carries_clinical_note_marks("fd698243-0406-4d40-b08b-de447ee10b56 MRN 8823")
    assert carries_clinical_note_marks("device A336EEBD-107F-4A6B-A9A4-C1574AB809B7, 58F, chief complaint")


@pytest.mark.parametrize("text", [
    "alice@fd698243-0406-4d40-b08b-de447ee10b56.example.com",
    "fd698243-0406-4d40-b08b-de447ee10b56@example.com",
    "contact A336EEBD-107F-4A6B-A9A4-C1574AB809B7@clinic.example.org",
])
def test_an_e_mail_address_built_around_a_uuid_is_still_a_mark(text):
    # Review 9: masking a UUID must not hide the e-mail address it sits in.
    assert carries_clinical_note_marks(text)
