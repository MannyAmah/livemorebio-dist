"""Admission boundary shared by the registry and both protocol services."""
from __future__ import annotations

from typing import Any

PUBLIC_REFERENCE_SCHEMA = "livemore.public-reference-cohort.v1"
PUBLIC_REFERENCE_GENERATION = "joint_public_records_without_replacement"
PUBLIC_REFERENCE_MEMBER_SCHEMA = "livemore.frozen-public-reference-member.v1"


class ReferenceModelBindingRequired(ValueError):
    code = "REFERENCE_MODEL_BINDING_REQUIRED"

    def __init__(self) -> None:
        super().__init__("This descriptive public-reference record has no qualified model binding. Inspect its source facts or qualify a model-specific binding before experimentation.")


def is_public_reference(record: Any) -> bool:
    if not isinstance(record, dict):
        return False
    return (record.get("source_class") == "PUBLIC_REFERENCE"
            or record.get("evidence_state") == "PUBLIC_REFERENCE"
            or (isinstance(record.get("schema"), str) and record["schema"] in {PUBLIC_REFERENCE_SCHEMA, PUBLIC_REFERENCE_MEMBER_SCHEMA, "livemore.joint-public-reference-member.v1"})
            or record.get("generation_method") == PUBLIC_REFERENCE_GENERATION
            or record.get("source_id") == "nhanes-2021-2023-joint-public-v1")


def ensure_cohort_executable(record: Any) -> None:
    # Old frozen cohort contracts remain valid. A caller cannot override the new
    # record's missing scientific binding by changing a stratum or boolean flag.
    if is_public_reference(record) or (isinstance(record, dict) and (
            record.get("executable") is False
            or ("model_binding" in record and record["model_binding"] is None)
            or is_public_reference(record.get("reference"))
            or (isinstance(record.get("members"), list) and any(
                is_public_reference(member) or (isinstance(member, dict) and (
                    is_public_reference(member.get("reference"))
                    or member.get("executable") is False
                    or ("model_binding" in member and member["model_binding"] is None)))
                for member in record["members"])) )):
        raise ReferenceModelBindingRequired()
