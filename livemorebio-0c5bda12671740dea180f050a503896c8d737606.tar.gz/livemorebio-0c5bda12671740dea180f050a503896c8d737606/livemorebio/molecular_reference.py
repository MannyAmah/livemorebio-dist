"""Version-pinned public structure references, never a physiology execution path.

Coordinates are original archive bytes. Identity, species and construct coverage
are admitted explicitly; a missing mapping never triggers a first-hit web search.
"""
from __future__ import annotations

import hashlib
from importlib.resources import files
from importlib.resources.abc import Traversable
import json
import os
from pathlib import Path
import re
import stat
from typing import Any

_CATALOG_SHA256 = "1ce5cd1c67a9bf33d2f2b2f2942adb02b1608743186074279262fac110584032"
_CATALOG_BYTES = 67_867
_COORDINATE_LIMIT = 8 * 1024 * 1024


class MolecularReferenceError(Exception):
    """A public fixed code without caller input, local paths or exception text."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Molecular reference request could not be fulfilled.")


def _asset_root() -> Traversable:
    return files("livemorebio").joinpath("scientific_sources", "data", "molecular")


def _verified_bytes(asset: Traversable, size: int, digest: str) -> bytes:
    try:
        if isinstance(asset, Path):
            # No-follow plus nonblocking open also prevents a replaced FIFO from
            # hanging a reference request. Package contents are not user uploads.
            flags = os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0)
            if asset.is_symlink():
                raise OSError("Linked package asset")
            with os.fdopen(os.open(asset, flags), "rb") as stream:
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_size != size:
                    raise OSError("Invalid package asset")
                raw = stream.read(size + 1)
        else:
            # importlib also supports a wheel read directly through a zip importer.
            with asset.open("rb") as stream:
                raw = stream.read(size + 1)
        if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
            raise OSError("Package asset integrity mismatch")
        return raw
    except (OSError, ValueError):
        raise MolecularReferenceError("MOLECULAR_SOURCE_UNAVAILABLE") from None


def catalog() -> dict[str, Any]:
    """Return a fresh descriptor tree from the exact reviewed catalog bytes."""
    raw = _verified_bytes(_asset_root().joinpath("catalog.json"), _CATALOG_BYTES, _CATALOG_SHA256)
    # Checking the pinned bytes before decoding excludes unreviewed JSON schemas
    # and means callers can safely modify their detached copy without cache races.
    return json.loads(raw)


def lookup(target: str) -> dict[str, Any]:
    """Look up an explicit target without selecting a patient or invoking a model."""
    if not isinstance(target, str) or re.fullmatch(r"[A-Z][A-Z0-9_-]{0,23}", target) is None:
        raise MolecularReferenceError("MOLECULAR_INVALID_TARGET")
    data = catalog()
    mapping = data["targets"].get(target, {
        "structure_id": None, "status": "MAPPING_UNAVAILABLE",
        "reason_code": "SOURCE_MAPPING_NOT_ADMITTED", "related_structure_ids": [],
    })
    descriptor = data["structures"].get(mapping["structure_id"])
    accessions = {
        accession
        for entity in (descriptor["polymer_entities"] if descriptor else [])
        for accession in entity["uniprot_accessions"]
    }
    return {
        "gene": target, "status": mapping["status"], "reason_code": mapping["reason_code"],
        "pdb": mapping["structure_id"],
        "uniprot": next(iter(accessions)) if len(accessions) == 1 else None,
        "reference": descriptor,
        "related_references": [data["structures"][entry] for entry in mapping["related_structure_ids"]],
    }


def read_coordinates(digest: str) -> tuple[bytes, dict[str, Any]]:
    """Read one admitted original file; the caller never supplies a filesystem path."""
    if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise MolecularReferenceError("MOLECULAR_NOT_FOUND")
    descriptor = next((entry for entry in catalog()["structures"].values()
                       if entry["coordinate_sha256"] == digest), None)
    if descriptor is None:
        raise MolecularReferenceError("MOLECULAR_NOT_FOUND")
    if not 0 < descriptor["coordinate_bytes"] <= _COORDINATE_LIMIT:
        raise MolecularReferenceError("MOLECULAR_SOURCE_UNAVAILABLE")
    asset = _asset_root().joinpath(descriptor["pdb_id"] + ".cif")
    return _verified_bytes(asset, descriptor["coordinate_bytes"], digest), descriptor
