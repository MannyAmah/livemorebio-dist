# Stable maintenance release notes

This release updates reference-data provenance, extraction boundaries and public
packaging. It is research software, not a clinically qualified risk model.

- Disease identities use exact Disease Ontology concepts. Only common clinical
  aliases independently supported by open ontology records are retained, with
  a source for each. Exact resolver lookups and the library builder expose typed
  reasons for unresolved conditions; twin intake routes behave differently, as
  described below.
- Open Targets associations and drug identities use release **26.09**, retrieved
  **2026-10-04** through its public API. Each record retains its release, query,
  retrieval date and response digest. Current identifiers replace retired IDs.
  ChEMBL records use **37**. Association scores and evidence datatypes are
  descriptive evidence, not causal effects or individual risk estimates.
- Note reading retains the published case-insensitive `htn`, `t2dm`, `t2d`
  and `cad` shorthand, including mixed case. Other reviewed acronyms require
  their original case. The complete input-class differences from the published
  extractor are listed below. Recognized conditions can change modeled heart
  rate, heart-rate variability and the paced cardiac action potential through
  unchanged rules. This literal extractor does not perform general negation,
  certainty or family-history reasoning.
- The research score uses a fixed eleven-locus constant: metabolic HNF1B,
  IGF2BP2, KCNJ11, PPARG, TCF7L2 and WFS1; cardiovascular APOB, LDLR and PCSK9;
  inflammatory IL23R; neurological LRRK2. Open GWAS trait records support axis
  membership; frozen inherited effects were selected without a trait filter.
  Membership and summation order come from the published KEGG-selected panel;
  the retained genes now have independent GWAS citations, not a new panel design.
  The four retained axes and biomarker offsets are bit-identical to the stable
  baseline for the same complete inputs. Oncologic and unknown axes raise
  `PRS_AXIS_NOT_DISTRIBUTED`; incomplete or invalid genotypes expose typed reasons
  and per-axis coverage. HNF1B's inherited effect has the opposite diabetes
  direction, WFS1's effect is below the genome-wide significance threshold, and
  APOB's stored endpoint is dyslipidemia. Compatibility is not scientific
  qualification, and these scores must not be interpreted as clinical risk.
- T2D-enriched cohorts exclude conflicting T1D conditions by concept identity.
  Label and cohort corrections can change screen audit digests for identical
  seeds; such changes do not establish physical outcomes or revised drug equations.
- The public archive includes client documentation and an explicit audience
  marker. Frozen research executors and their dependent tests are omitted.
  Tests with unavailable private evidence report a typed skip; damaged private
  checkouts fail. Restricted narrative annotations and plant-reference data are
  absent, and narrower keyword-search coverage is reported explicitly.
- Build identity is **livemore.build-identity.v2**, with fingerprint scope
  `runtime_code_and_public_reference_assets.v2`. Optional private discovery data
  no longer participates; public and private product fingerprints agree. Older
  identity records remain readable, but their hashes must not be compared across
  fingerprint scopes.
  A new launcher does not upgrade a process that is already running: stop and
  restart **all services together** after upgrade. Mixed service releases
  refuse execution-source compatibility until their identities agree.
- The cardiac CellML source bytes and equations are unchanged. Source attribution
  includes the encoding workspace, base model and historical acquisition boundary.
  Third-party terms are recorded in [the notices](../THIRD_PARTY_NOTICES.md).
- The source catalog retains resource names, valid endpoint URLs and routing
  metadata. Publisher descriptions, article-title suffixes and non-URL endpoint
  values are omitted. The Python package-data manifest excludes plant book files.

## Note-reading compatibility

The comparison executes the published `stable-6588707` extractor and this release
on the same technical notes. It covers every term in either condition vocabulary,
case and punctuation variants, both gene vocabularies with and without genetic
context, both drug vocabularies, and the negative controls. It is a finite grammar
comparison, not a claim to enumerate every possible clinical sentence.

- Newly recognized condition spellings: `hypertension`, `obesity`, `osteoporosis`,
  `chronic obstructive pulmonary disease`, `congestive heart failure`,
  `inflammatory bowel disease`, `type 1 diabetes`, `Parkinson's disease`,
  `lung non-small cell carcinoma`, `metabolic dysfunction-associated steatotic
  liver disease`, and `diabetes mellitus, type 2`. Newly recognized acronyms:
  `COPD`, `CHF`, `IBD`, `IDDM`, `NIDDM`. Example: `67 y/o M with COPD and CHF`
  now attaches two conditions. Lowercase versions of these new acronyms remain
  unrecognized. Bare `heart failure` is unrecognized in both versions.
- Removed ambiguous recognition: lowercase or mixed-case `ad` (for example,
  `eat ad lib` or `Ad`) no longer implies Alzheimer disease; uppercase `AD`
  remains recognized. This is the only rejected published shorthand.
- Renamed condition output: `HTN`, `htn` and `high blood pressure` now return
  `Hypertension`. Notes containing the former hypertension, obesity or osteoporosis
  labels return their broader current labels through literal word matches.
  The former heart-failure label identified in the table below no longer matches.
- Punctuation boundaries: the old COPD and bowel-disease display labels ended
  with parenthetical acronyms. The published extractor's trailing word boundary
  could miss the whole label at sentence end; the independently sourced shorter
  phrases now match within it. For example, `COPD.` is recognized as the current condition. Commas in the reviewed diabetes
  phrase are optional; other embedded-word boundaries remain excluded.
- Gene vocabulary follows the replaced reference seed: 325 gene symbols become
  recognizable and 99 cease being recognizable, including when accompanied by
  `gene`. Examples are `ABCG8 gene` (added) and `ABCB1 gene` (removed). Short
  symbols also require an adjacent genetic cue: `INS` alone no
  longer extracts a gene, while `INS gene` does. The underlying engine variant
  definitions and effects are unchanged. No drug, age or sex output differences
  were observed in the comparison corpus.

The restored shorthand is literal, including the published release's false
positives. `cad` in `cad renal transplant` attaches coronary artery disease;
`htn` after pulmonary, portal or intracranial attaches systemic hypertension.
The guard for the full phrase `pulmonary hypertension` does not guard `htn`.
For the technical note `49 yo M s/p cad renal transplant 2015`, both releases
compute HR **73.2 bpm**, HRV **24 ms**, APD90 **268 ms**. Removing `cad` from that
same note gives **69.2 bpm**, **37 ms**, **271 ms** in both releases: the coronary
match adds **4 bpm**. These are parser effects, not a justified diagnosis.
Extending the non-systemic hypertension guard to abbreviations would change
published behavior and needs a later release under the biological change contract.

Each class of note that changes modeled cardiac values has an example below.
Arrows compare the published release with this release; all notes are technical
fixtures. The former heart-failure label is identified by the digest beginning
`e2c1dded` in the affected-record table, without reproducing its wording.

| Technical note | Modeled HR (bpm) | HRV (ms) | APD90 (ms) |
|---|---:|---:|---:|
| `67 y/o M with COPD` | 70.6 → 76.6 | 36 → 31 | 271 → 267 |
| `67 y/o M with CHF` | 70.6 → 84.6 | 36 → 17 | 271 → 262 |
| `67 y/o M with ` followed by the former heart-failure label | 84.6 → 70.6 | 17 → 36 | 262 → 271 |
| `67 y/o M with COPD and CHF` | 70.6 → 90.6 | 36 → 14 | 271 → 258 |

Measurement method: each exact note was passed to the real in-process
`Platform.patient(note=...)` in this release and separately in the published
product. Each run used an empty temporary data directory, default lifestyle
**0.6**, no supplied genotype and no interventions. HR is the twin's computed
`resting_hr`; HRV and APD90 come from its computed cardiac state. APD90 is action
potential duration at **90%** repolarization: it moves because the unchanged
cardiac simulation is paced at the modeled heart rate. The SDK/API summary rounds
HR to whole bpm, so the combined example displays **71 → 91 bpm**. These are
calculated research-model outputs, not measured human outcomes.

Exact resolver lookups differ from scanning a note. All twenty published display
labels are tested: fourteen resolve and six give `REFERENCE_DISEASE_UNRESOLVED`.
For those six, the `HumanBuilder` library function returns an unresolved entry and
applies no condition preset, so its baseline values may differ from the old release.
Twin requests through SDK `Platform.patient(conditions=[...])`, the console API's
custom-human `/api/stimulate` route, and LIFE `/human` do not validate condition
names in either release. These routes accept each retired label without an
unresolved warning, preserve the string as typed, and retain its published-release
behavior. The typed refusal described above belongs to the resolver and library
builder, not these intake routes. The console's condition picker lists current
names; an API/SDK caller or a stored record can still supply an old string.
Re-select the current condition only when it matches the intended concept; the
affected-record table does not assert clinical equivalence. Existing saved twins
keep their stored strings; this release does not migrate them or recompute saved
reports.

The six retired labels are identified below by current condition and SHA-256 of
the exact published display label. Their restricted source wording is not copied
back into this release. Digest identification is not a runtime alias. Any future
authored compatibility mapping requires separate scientific and
licensing review.

| Current condition to re-select | SHA-256 of retired display label |
|---|---|
| Hypertension | `77d56334766287a523abd52632376a3aae199bf9d1bc6fb3bbe3bc8ca46d659d` |
| Chronic obstructive pulmonary disease | `3d1dd9e6987f9729e98ccabe6b6660887148f72a27aea3cd46a734fd2e406a3d` |
| Obesity | `56e310443c4c69cefd26c96ec57837a28ed445da8086cf112c0d98c7f7950d59` |
| Congestive heart failure | `e2c1ddede09c0712966e7a4032c3416ac2bbddb25254e7a3d27ced56b1c09a98` |
| Osteoporosis | `8bcc79e1be6c092b0ab45b1a1b82f88c55f454f8a7bbf9fd81ac398984dfb31f` |
| Inflammatory bowel disease | `3895316066e3ccaa2541e21e03c68fb26aad75a2b27a7555123b573482c94c6b` |

The library-only `describe()` builder additionally shortens familial
hypercholesterolemia and chronic obstructive pulmonary disease to legacy preset
keys that no longer resolve. It now reports an unresolved condition and keeps
baseline cholesterol or smoking/inflammation values. Pass the full condition to
`HumanSpec.conditions` and inspect unresolved entries; this maintenance release
does not change the builder's physiological presets.

Other numerical values above were checked by running this release's product
loaders: `ClinicalExtractor().kb` supplies the recorded Open Targets and ChEMBL
release/retrieval metadata; `prs.panel_summary()` and its loaded panel give the
eleven loci and four axes; `build_identity()` supplies the identity schema and
fingerprint scope. Set comparison of the two running extractors' `gene_syms`
gives the added/removed symbol counts. Passing every published display label
through the current `KnowledgeBase.disease` gives the resolution counts; each
affected label was also passed through `HumanBuilder`, SDK intake and both
in-process API routes. Table digests were recomputed from those exact input
strings. This checks bundled provenance, not a fresh upstream retrieval.
