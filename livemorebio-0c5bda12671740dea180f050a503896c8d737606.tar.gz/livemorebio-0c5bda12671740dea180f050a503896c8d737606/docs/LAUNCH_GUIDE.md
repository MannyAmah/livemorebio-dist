# Launching and operating LivemoreBio

This guide covers stable maintenance release **0.1.0**. After installation,
run `livemore --version` to see the installed product version; this release
prints `LivemoreBio 0.1.0` without starting or contacting a service. For a
running Docker stack, use `docker compose exec aegle livemore --version`.

This guide launches the local research product: LIFE on `127.0.0.1:8851`, Aegle on
`127.0.0.1:8850`, and Cendos on `127.0.0.1:8852`. It is for model-only pharmaceutical
hypothesis triage. It is not approved for production PHI, clinical decisions, dosing,
device control, or regulator-facing evidence claims. It is not a patient-data environment:
never enter patient data into it.

Local service identity is checked before first-party programmatic clients send
credentials. It does not authenticate the browser's HTTP origin or encrypt local
traffic. On a native stack, a relay would have to hold the genuine service's own
bound address; the genuine service holds that address while running. The remaining
relay is the Compose case: depending on Docker's publishing mode, another account
can hold the published origin while the container remains reachable at its bridge
address. Run the local stack on a machine whose other accounts you trust. On a
shared workstation, or for real patient data, use the hosted deployment when it
exists. NEW-5b belongs to I2. This release does not support production PHI.
The private launch channel prevents the console code appearing in browser-launch
arguments. Saved screen reports at
`/api/screen/{run_id}/report.md` and `report.audit.json` are sensitive operator
artifacts even when their inputs are synthetic. They require the operator bearer
or a valid console session, with authentication checked before any run lookup,
including unknown ids. Success and refusal responses use `Cache-Control: no-store`.
With same-origin console download links, the browser sends the HttpOnly session
cookie; native SDK/tools use the bearer. Never put the bearer in browser JavaScript or a URL.

## 1. Verify and install

The public installer downloads the published release without a GitHub account.
Requirements:

- Python 3.11 (`python3.11`)
- Bash 3.2+, `curl`, and `tar` (included on supported macOS and Linux hosts)

Verify the release values and run this block:

At each release go, the author publishes the installer SHA-256, archive SHA-256
and distribution commit on both a release in the **Livemore-Biosciences
organisation on GitHub** and a page on **livemorebiosciences.com**. These channels
must be independently administered from the GitHub account that owns the
download repository. Users may check either channel; the installer and archive
digests must match on both, as must the distribution commit. Stop if they differ.

The author fills the five placeholders below at the go in externally served
guides and the weekly workflow. For a bundled guide, replace the placeholders
with the published URLs and values before installation. Confirm the release
values against either channel before running this block. Do not take the expected
digests from the installer, archive or `stable.json` on the download host.
Unfilled placeholders, download failures and checksum mismatches stop before
the installer runs. L0 uses these digests without release signing (F-06).

```bash
(
  set -euo pipefail
  org_release_url='{ORG_RELEASE_URL}'
  livemorebiosciences_url='{LIVEMOREBIOSCIENCES_URL}'
  installer_sha256='{INSTALLER_SHA256}'
  archive_sha256='{ARCHIVE_SHA256}'
  dist_commit='{DIST_COMMIT}'
  [[ $org_release_url == https://github.com/Livemore-Biosciences/*/releases/* && $org_release_url != *'{'* && $org_release_url != *'}'* ]] || { printf '%s\n' 'Set the Livemore-Biosciences GitHub release URL.' >&2; exit 1; }
  [[ $livemorebiosciences_url == https://livemorebiosciences.com/* && $livemorebiosciences_url != *'{'* && $livemorebiosciences_url != *'}'* ]] || { printf '%s\n' 'Set the livemorebiosciences.com release page URL.' >&2; exit 1; }
  [[ $installer_sha256 =~ ^[0-9a-fA-F]{64}$ && $archive_sha256 =~ ^[0-9a-fA-F]{64}$ ]] || { printf '%s\n' 'Set both published SHA-256 digests.' >&2; exit 1; }
  [[ $dist_commit =~ ^[0-9a-f]{40}$ ]] || { printf '%s\n' 'Set the published distribution commit.' >&2; exit 1; }
  archive_sha256=$(printf '%s' "$archive_sha256" | tr 'A-F' 'a-f') || exit $?
  installer_file=$(mktemp) || exit $?
  trap 'rm -f "$installer_file"' EXIT
  curl -fsSL --connect-timeout 15 --max-time 120 --retry 3 \
    "https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/$dist_commit/install.sh" >"$installer_file" || exit $?
  test -s "$installer_file" || { printf '%s\n' 'Empty installer; refusing execution.' >&2; exit 1; }
  if command -v sha256sum >/dev/null 2>&1; then
    actual=$(sha256sum < "$installer_file") || exit $?
  else
    actual=$(shasum -a 256 < "$installer_file") || exit $?
  fi
  actual=${actual%% *}
  expected=$(printf '%s' "$installer_sha256" | tr 'A-F' 'a-f') || exit $?
  [[ $actual == "$expected" ]] || { printf '%s\n' 'Installer checksum mismatch; refusing execution.' >&2; exit 1; }
  LIVEMORE_SHA256="$archive_sha256" bash "$installer_file"
)
```

The installer:

1. reads the public release manifest, downloads its archive, and verifies the
   recorded SHA-256 before extracting it;
2. installs into `~/.local/share/livemorebio/releases/<commit>/`;
3. creates an isolated Python 3.11 environment and installs the exact
   `dev,kernels,server,notebooks` dependency graph from a hash-verified lock;
4. runs the complete tests, compile check, and CLI smoke check;
5. installs a stable launcher and atomically points `current` at the verified release;
6. records a full release digest outside the release tree and adds one marked PATH block
   to `.zshrc` or `.bashrc` when needed.

Re-running the same line updates LivemoreBio. Installation failures never replace the
working `current` release. The installer does not read, move, or delete runtime state or
keys under `~/.livemore/`.

The stable launcher also avoids Python's absolute console-script shebang limit when the
managed release directory has a long path. It always invokes the active release through
its own Python 3.11 environment.

## 2. Start the product

```bash
livemore start all
livemore status
livemore workspace
livemore open
```

`start` launches detached loopback services, waits for proved readiness for every
requested service, and creates a random operator token plus independent service-identity,
storage-encryption and internal patch-admission keys if they do not exist.
`livemore open` proves Aegle's identity before authenticating with the
operator token, writes a unique private HTML launch page under
`<data dir>/console-launch/`, and requests its file URI in your browser. The page
submits the single-use code by POST. The service consumes the code, sets a separate
in-memory session cookie with a per-port name, HttpOnly, SameSite=Strict and Path=/,
and returns a real HTML page that refreshes to the clean console URL. The command
says "launch requested in your browser"; this confirms launcher acceptance, not
that the browser read the file or established an authenticated session.
Run `livemore open` again after a server restart; bare navigation
and reload do not create a session. The browser has no token prompt
and stores no token in JavaScript-accessible storage.

`livemore token` remains an explicit secret-export diagnostic. The attached terminal,
SDK and first-party request helper read the owner-only launcher token directly and
prove the destination before sending it. Raw credentialed `curl` does not prove identity.
There is no external token provider, account page, or manual token-generation workflow.

### Service identity: provisioning, rotation and migration

File-managed stacks keep the independent random 32-byte key in
`<data dir>/service-identity.key`: an owner-only, single-link regular file containing
canonical padded URL-safe base64 followed by one newline. It is independent of
the bearer and both patch keys; do not copy it between stacks. `livemore start`
and `livemore up` provision a missing key before launch. `open`, attach/SDK reads,
status and doctor never create trust. A missing key, old service without proof,
wrong stack or failed proof refuses `SERVICE_IDENTITY_UNPROVEN` before sending
credentials. There is no insecure flag and no downgrade, including on quota
exhaustion. Public health alone is not identity: another process can return
plausible health JSON without holding this stack's key.

An environment-only stack supplies `LIVEMORE_SERVICE_IDENTITY_KEY` as the same
canonical base64 text without the newline. Presence takes precedence over files;
empty or malformed content refuses rather than falling back. An environment bearer
is not an identity key; provision both explicitly for an environment-only stack. To generate a new
environment key into a new 0600 file of your choosing, change the relative filename
below in an owner-only working directory. The key never reaches terminal output
or argv:

```bash
python3 -c 'import base64, os, secrets; fd = os.open("service-identity.new.key", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600); os.fchmod(fd, 0o600) if hasattr(os, "fchmod") else None; f = os.fdopen(fd, "w", encoding="utf-8", newline="\n"); f.write(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("ascii") + "\n"); f.close()'
```

Inject that file's contents, excluding the final newline, through your protected
deployment environment or secret manager. Keep the file private and out of source
control; do not print it or pass the key as a command argument.
On Windows, where `fchmod` may be unavailable, the generator skips that operation;
use a private directory protected by your Windows account permissions. Native
LivemoreBio still requires Docker Desktop or WSL2. The container provisioning
steps in [the business client guide, Step 2](BUSINESS_CLIENT_GUIDE.md#step-2--create-four-independent-secrets)
include the independent identity key and PowerShell commands.

The identity authority is an exact canonical origin for a fixed role; the dial
address is the endpoint used for the connection. Configure
`LIVEMORE_AEGLE_IDENTITY_AUTHORITY`, `LIVEMORE_LIFE_IDENTITY_AUTHORITY` and
`LIVEMORE_CENDOS_IDENTITY_AUTHORITY` as the published origins. Native loopback
services must use their own bind origins, and literal loopback clients must use
their exact dial origins. A mismatch refuses `SERVICE_IDENTITY_CONFIGURATION_INVALID`
before any send. Named dial hosts, including `localhost`, require explicit
authorities. When that authority is an IP literal, the connection goes to the
authority's own address: the dial uses the same port and resolves to a set containing
that literal address, or the request is refused before connecting. DNS authorities
retain their named-host behavior. The only exception is the fixed Compose peer
profile, whose bridge relay remains a named limitation. In Compose, internal clients dial `http://aegle:8850`,
`http://life:8851` and `http://cendos:8852`, while checking the explicitly configured
published loopback authorities; the host CLI dials the published loopback origins.
Do not infer an authority from a container bind address or a response. An
SSH-forwarded SDK must forward the same port number at both ends and retain the
matching authority profile; a different local port is refused.

For file-managed rotation, stop every service (`livemore stop all`, or
`livemore down` for Compose), run `livemore identity rotate`, then restart every
service and recreate long-lived shells/notebooks. Rotation also repairs exposed,
linked or malformed identity files without following a link to its target. It
refuses while launcher records show a recorded live process; it does not probe
ports or revoke unrecorded processes. Confirm those are stopped yourself. The
command prints the new SID's first 16 hex characters and restart instructions,
never the key. There is no dual-key grace. Replacing the file does not revoke
a running service: services retain their startup generation. A client with an
inherited environment key or an explicitly injected identity snapshot also keeps
that generation until recreated.
Environment-only operators stop, provision a new external key with the generator
above, update every service/client environment, and restart instead of using the
file rotation command. Keep bearer and patch keys; identity rotation changes no
stored research data or encryption key.

Existing-stack migration:

1. Stop the stack using its credential-free `stop` or `down`; do not query an old
   service to establish trust or send it a token to upgrade.
2. Upgrade launcher, services, SDK and tools together. Updated native start/up
   provisions the missing key before launch. Invalid files are not overwritten;
   use the stopped-stack rotation procedure to repair them.
3. Environment-only and direct Compose operators provision a new independent key
   and matching authority profile before launch. Required Compose interpolation
   refuses missing trust.
4. Restart all three services. New clients prove them; old services, stale keys or
   wrong authorities refuse with no credentials sent. Preserve bearer, patch keys
   and existing stores: this is not data migration or bearer rotation.
5. Recreate long-lived shells/notebooks and check every role and console flow on
   technical data. Old installed clients remain unsafe; upgrading a server cannot
   make an old client authenticate its destination.

The NEW-9 clean manual `/console/connect` URL and separate code stay unchanged.
Python mint/exchange proof does not authenticate the browser's later connection.

### Browser location and recovery

Automatic launch requires the CLI and browser to use the same filesystem and the
same loopback: run the CLI on the macOS or Linux desktop host whose browser opens
the file. This includes a host CLI reaching Compose's published loopback port.
Other topologies use the explicit `--print-url` exception:

- Docker Desktop, in-container CLI: run
  `docker compose exec aegle livemore open --print-url`, then open the clean
  connection page in the host browser and enter the separate code. The browser
  reaches the published loopback port. A file
  inside the container is not a host-browser launch path.
- SSH: from the operator's own machine run
  `ssh -L <port>:127.0.0.1:<port> <host>`, using the same Aegle port at both ends.
  In that SSH session run `livemore open --print-url`, then open the clean connection
  page in the browser on the operator's machine and enter the code. The exchange sees the forward's
  loopback peer. The local forwarded port must be available.
- WSL with a Windows browser, or a remote desktop's client-side browser: use the
  SSH forwarding recipe above, or run the CLI where the browser runs. A browser
  running inside the remote desktop can use automatic launch only if it shares
  that CLI's filesystem and loopback.

Peer, Host and Origin rules remain in force for every recipe. A networking setup
that fails those rules remains unsupported; do not weaken the checks.

`livemore open --print-url` prints three lines: the clean `<origin>/console/connect`
URL, a separate one-time code labeled `One-time code:`, and the lifetime
(the command prints its lifetime). Open that connection page and enter the code
into its masked form; it is submitted by POST. Never put the code in a command
argument, environment variable, URL query or fragment, or shell substitution.

This remains an explicit secret-output exception to your own terminal: terminal
scrollback, redirected output and terminal recordings may retain the live code
until its printed deadline. Browser URL history and ordinary URL access logs
receive clean paths; form/POST-body capture or compromised local software can
still disclose the code. A spent or expired code cannot establish another
session. A typo can be retried while the code is unspent and unexpired; expiry,
restart or prior consumption requires a fresh code. Ordinary `open` never prints
a code, including after a failed launch. Per-port cookie names and loopback
transport do not establish local service identity or isolate all local accounts.

On Linux without `DISPLAY` or `WAYLAND_DISPLAY`, or when no browser is found,
automatic `open` immediately refuses `CONSOLE_EXCHANGE_FAILED`, writes no launch
file, and directs you to `livemore open --print-url`. A false or raising browser
launcher removes its launch file and gives the same recovery. If a snap or
flatpak browser accepts the launch request but cannot read the file, use
`livemore open --print-url`; do not copy the live page into a public directory.

Launch files have mode `0600` inside an admitted owner-only `0700` directory.
Unsafe directory ownership, permissions or redirectable ancestors refuse
`CONSOLE_LAUNCH_DIRECTORY_UNSAFE` before a code is minted. A leftover launch file
contains a live code until it is spent or the session-code lifetime ends. Each `open` prunes
its own expired launch files. `down` and `stop Aegle` or `stop all` attempt the
same pruning without changing shutdown's result; stopping LIFE or Cendos alone
does not prune Aegle's launch files.

You can also double-click `Livemore Console.command` on macOS. Stop everything with:

```bash
livemore stop all
```

## 3. Confirm service health

```bash
curl -fsS http://127.0.0.1:8850/health
curl -fsS http://127.0.0.1:8851/health
curl -fsS http://127.0.0.1:8852/health
```

These public probes show liveness only. Use `livemore status` or `livemore doctor`
for proved stack readiness; a successful health response alone proves no ownership.

The OpenAPI schema is always available at:

- Aegle: <http://127.0.0.1:8850/openapi.json>
- LIFE: <http://127.0.0.1:8851/openapi.json>
- Cendos: <http://127.0.0.1:8852/openapi.json>

The read-only HTML reference at `/docs` and `/redoc` is opt-in: start the services
with `LIVEMORE_ENABLE_API_DOCS=1 livemore start`. Otherwise those paths return 404.

## 4. Walk every product page

### Executable multiscale Atlas, `/`

1. Run `livemore open` on every launch path to open <http://127.0.0.1:8850/> with a
   session. On Docker without the host CLI, run
   `docker compose exec aegle livemore open --print-url`, open the clean connection page
   and enter the separate code before it expires (the command prints its lifetime).
2. Confirm the page's data loads. A bare URL or reload does not create a session;
   without a session, protected reads return 401.
3. Traverse Whole Body → Cardiovascular → Heart → Ventricular Tissue → Cardiomyocyte
   → Ion Channel → Gene/Protein. Selection must update the anatomy focus, functional
   value, engine lineage, and evidence inspector together.
4. Run metformin. The action must visibly pass through queued, running, and completed;
   it executes a detached scenario and the selected workspace remains unchanged.
   Inspect the separate **ISOLATED SCENARIO** result for textual scalar comparisons
   of the captured baseline and scenario: mean glucose (mg/dL), heart rate (bpm),
   and APD90 (ms), with unavailable values labeled explicitly. The result identifies
   its source capture. Each scenario starts from the selected twin; the workspace
   traces and cross-scale mechanism continue to show the selected state.
5. Request a virtual Patch sample. The Observed tab must show its v2 observation against
   the virtual sensor prediction as an unqualified residual. It must not show physical
   hardware, person calibration, or clinical validation.
6. Inspect Reference. All 15 systems have formal variables, units, inputs, outputs,
   time scales, perturbations, and maturity. Systems without engines must say
   `UNAVAILABLE` and return no invented biological state.
7. Use the product rail to open the preserved surfaces. The previous Twin console is at
   <http://127.0.0.1:8850/legacy>.

### Digital twins, `/twins`

On `/twins` and `/cohorts`, the badge starts at `LOCAL`. It says
`LOCAL · AUTHENTICATED` only after the first authenticated records read succeeds;
a 401 says `NOT AUTHENTICATED · run livemore open`.

1. Select **Reference-grounded research person** for a non-person twin. Choose a governed
   population stratum and seed; the server, not the browser, creates the profile from
   `livemore-public-metabolic-reference-v1`. Confirm the record shows
   `REFERENCE_GROUNDED_SYNTHETIC`, the source release, member lineage, and an opaque
   `pseudonym-` subject identifier.
2. Activate it. Atlas, the virtual LIFE Patch, Cendos, terminal, and notebooks now resolve
   the same authoritative subject. Activation demotes the previously active record, so only
   one twin is authoritative. The pointer survives Aegle restarts.
3. Bind a virtual Patch and confirm the device contract appears on the twin record.
4. Select **Consented real-human data** only for a lawfully admitted person bundle. Provide
   explicit consent and purpose, chain of custody, and source records for the applicable
   EHR/FHIR, laboratory, medication, LIFE Patch or wearable, genomic, lifestyle, and
   environmental fields. The browser records bounded, pseudonymized summaries; do not enter
   names, medical-record numbers, raw notes, or exact locations.
5. Confirm `ADMITTED_COMPLETE` before activation. Declaring a source domain without admitting
   corresponding data does not count as coverage, and missing real-human values are not filled
   from a population prior without an explicit `REFERENCE_INITIALIZED` field provenance.
6. Physical Patch pairing is metadata admission only. It requires an active consented
   real-human twin, protocol `2.0`, hardware target `B0-EVT-target`, firmware version,
   current calibration, and an attestation reference. Telemetry remains
   `PENDING_SIGNED_ENVELOPE`; pairing does not prove hardware or human-use readiness.
7. One pseudonymous subject cannot be admitted as two twins, and one physical device cannot
   be paired to two subjects.

### Cohorts, `/cohorts`

1. Create a reference-grounded cohort with an explicit name, size, indication, seed, and
   one of the governed strata: `dpp-high-risk-metabolic`,
   `nhanes-diagnosed-diabetes-older`, or `pxr-reference`.
2. Confirm the record is `FROZEN` and shows the pinned source manifest, immutable member
   fingerprints, and varied member summaries. Repeating the same source/stratum/seed is
   deterministic; members within a cohort are not clones.
3. A real-human cohort accepts only explicitly listed, active real-human twin IDs. It never
   silently fills members from synthetic or reference records.
4. OpenMed is an optional local de-identification and clinical entity-intake processor. It is
   not a population dataset and cannot be selected as a cohort source. This release accepts no
   clinical note (`CLINICAL_NOTE_NOT_ACCEPTED`), since local de-identification is not operational.

### Biology, `/biology`

1. Open <http://127.0.0.1:8850/biology>.
2. Select an organ card and return to all organs.
3. If WebGL is available, rotate the anatomy, toggle labels, and test a cross-section.
4. If WebGL is unavailable, the page must say so and retain the organ/state drill-down.
   A blank or permanently loading page is a defect.
5. Reference anatomy is not executed organ function. Kidney, brain and adipose
   physiology remain unavailable; basal glucose, insulin sensitivity and responsivity
   are labeled model parameters with units, not invented cellular transport rates.
6. The Human-GEM run-specific view is an independent condition comparison with no
   biological-time animation. See the external guide for precise interpretation.

### LIFE Patch, `/patch`

1. Open <http://127.0.0.1:8850/patch>.
2. Pause/resume the timeline and change playback speed.
3. Select `virtual patch v2`. Confirm the B0 target, protocol version, sequence, and virtual
   connected badge appear. The observation cards remain separate from modeled traces.
4. Load a CGM demo and inspect provenance. Demo packets populate observed state only and may
   not claim person calibration, hardware presence, or clinical validation.
5. Pending channels stay pending. Fixed skin temperature remains marked nominal.

### Cendos Lab, `/cendos`

Cendos opens blank **Preparation** every time. **History** is
paged/searchable; **Recall** is read-only, and **Prepare rerun** requires a separate
Run to create a new parent-linked result. New experiment clears the view only.
Human-GEM oxygen/ATP conditions do not require or represent human cohorts.

1. Open <http://127.0.0.1:8850/cendos>. The page lists only cohorts eligible for each
   governed protocol.
2. For the metformin comparison, select one DPP high-risk cohort and one older
   diagnosed-diabetes cohort. Set the oral dose and OGTT load, then run the protocol.
   Inspect per-member baseline glucose, SLC22A1/OCT1 state, renal factor, modeled AUC/Cmax,
   OGTT deltas, decision, cohort mean, and within-cohort range.
3. For the plant-chemical workflow, select a `pxr-reference` cohort and run purified
   garcinoic acid at the displayed free-concentration series. Inspect 6P2B, receptor
   occupancy, individualized NR1I2-expression response, and the explicit
   `CYP3A4 NOT_QUANTIFIED` boundary. The whole seed or an extract is not represented.
4. Use **Download analysis CSV**, **Open Jupyter notebook**, and **Visualize this run in
   Biology**. Biology is run-scoped with `?run_id=...`; it does not silently display the
   most recent unrelated experiment.
5. Create an evidence package from a completed eligible run before leaving the page. The capture
   is awaited, so the button cannot race an unfinished handoff.
6. Open its tabs. Its claim state remains `model_only` until governed counterpart
   measurements and validation events exist.
7. Exporting locks the package and therefore uses authenticated `POST`, not a mutating GET.

These protocol runs are executable software calculations. The metformin output is
`MODELED_MECHANISTIC`; the garcinoic-acid output is
`STRUCTURE_AND_IN_VITRO_BACKED_MODEL`. Neither is an observed human reaction or a clinical
efficacy, safety, or dosing result.

### Scientific adapters, `/adapters`

1. Open <http://127.0.0.1:8850/adapters>.
2. Confirm the catalog summary shows 39/39 ELIXIR Core Data Resources and the NAR
   summary-entry snapshot. NAR reports 2,173 independent databases while its official
   alphabetical page contains multiple summary papers for updated resources; the product
   preserves that distinction instead of claiming false deduplication.
3. Click every workflow route. Only `workflow_wired` or
   `scientifically_qualified` sources may appear in a runtime route; catalog-only sources
   remain excluded and their count stays visible in the lifecycle funnel.
4. Review access, integration state, product consumer, capabilities, and source license.
5. Run bounded health probes. A reachable adapter is only operationally ready. It does not
   validate a model or evidence claim. Probes use authenticated `POST /api/adapters/probe`;
   ordinary registry reads use `GET /api/adapters` and never trigger network egress.
6. KEGG and GeneCards remain unavailable until commercial/licensed access is recorded. When
   enabled, query a gene through LIFE's authenticated `GET /reference/genes/{symbol}` and
   confirm the response remains labeled `reference_context_only`; it must not change a
   validation state. USDA
   FoodData Central remains credential-gated until `USDA_API_KEY` is set. Rosalind is an
   external governed-workbench handoff, not an in-process database.

## 5. Use the terminal product

Start an isolated research shell:

```bash
livemore shell
```

Attach the shell to the live browser twin:

```bash
livemore attach
```

Example isolated workflow:

```text
patient t2d
show workspace
action metformin dose=1
show workspace
patch sample
sources workflow=reactions_metabolism limit=10
cohort 12 seed=17
screen metformin mode=metformin n=12 seed=17 dose=1.0 grams=75
report livemore-screen-report.md
audit verify livemore-screen-report.audit.json
quit
```

Governed live subject operations use the attached shell:

```text
twin list
twin admit ./synthetic-twin.json key=admission-001
twin activate twin-... version=1
twin patch twin-... version=2 mode=virtual device=virtual-shell-001
cohort list
cohort create name='DPP cohort' size=24 seed=17 indication=type-2-diabetes source=REFERENCE_GROUNDED_SYNTHETIC stratum=dpp-high-risk-metabolic
cohort create name='Older T2D cohort' size=24 seed=18 indication=type-2-diabetes source=REFERENCE_GROUNDED_SYNTHETIC stratum=nhanes-diagnosed-diabetes-older
cohort create name='PXR cohort' size=24 seed=19 indication=pxr-research source=REFERENCE_GROUNDED_SYNTHETIC stratum=pxr-reference
protocol metformin cohort_a=cohort-... cohort_b=cohort-... dose=1000 grams=75
protocol garcinoic cohort=cohort-... concentrations=0.05,0.33,1.3,5.0
protocol latest
protocol history limit=10
models
protocol metabolic ./oxygen-capacity.json
protocol show protocol-REPLACE_WITH_RETURNED_ID
protocol prepare protocol-REPLACE_WITH_RETURNED_ID
protocol export protocol-REPLACE_WITH_RETURNED_ID notebook=./analysis.ipynb
```

Admit real-human bundles from a protected JSON file rather than typing observations or
identifiers into shell history. The browser and terminal call the same version-checked API.

Only the declared T2D-enriched/OGTT screen context is admitted in Phase 1. Unsupported
indications, cohorts, and assays fail closed instead of generating rankings.

For a compact read of the same live Atlas projection shown in the browser:

```bash
livemore workspace
livemore workspace --full > multiscale-workspace.json
livemore sources --workflow genome_variants --limit 20
livemore sources --collection elixir --lifecycle cataloged --limit 20
```

### Jupyter notebooks

Start the SDK workspace with one command:

```bash
livemore notebook
```

The launcher creates a fresh 0700 per-launch runtime under this stack's admitted
data directory, with a random Jupyter token in an exclusive 0600 file. It opens a
private 0600 HTML file by path. That page carries a one-time code to Jupyter, which
consumes it and sets its login cookie. The live token never goes in the browser's
address bar, launch arguments or printed instructions. The spent code can remain
in browser history. Treat an unopened launch file as private while its code lives.

For SSH or a headless machine:

```bash
livemore notebook --no-browser
```

Open the printed clean `http://127.0.0.1:8888/login?next=%2Flab` URL (the port follows
`--port`) and type the separate manual code into Jupyter's own Password or token
form. Each 16-character code expires after 120 s and allows single use. Wrong,
expired or consumed codes fail login. To obtain a new code for this stack's running
notebook session, use another terminal with the same stack data-directory setting:

```bash
livemore notebook-code
```

Keep manual codes and login setup outside terminal recordings and screen capture.
For SSH, forward the chosen Jupyter loopback port to the operator's browser using
that same port at both ends. A launch file on the SSH host is not a local browser
path; use the manual-code recipe there.

The child is bound to loopback with no port retries. Its effective token must match
the private file and cannot be disabled or replaced by ambient configuration. The
operator's other Jupyter configuration is kept; password changes through the login
form are disabled. The supported versions are jupyter-server 2.21.0 and jupyterlab
4.6.4; another installed version refuses startup. Jupyter's server-info and its own
browser-open files stay inside the private runtime, so ordinary `jupyter server list`
does not discover this session.

Keep the launching terminal open. Ctrl-C and SIGTERM are forwarded to the child;
after it exits, the launcher removes only the per-launch directory it created and
preserves the exit status. A crash can leave a private runtime. The next launch
checks launcher identity before removing a stale directory and always creates a
fresh runtime. A restart needs a fresh launch or manual code.

## 6. Call authenticated APIs

Mutation routes, selected PHI-like reads, adapter-registry reads, and scientific-source
reads require operator authentication. Use the first-party Python helper from the
installed source directory with that release's Python. It proves the service and
sends the bearer on the same connection; credentials come from the private file or
protected environment, never command arguments. Health and static manifests remain
public. These payloads are technical stand-ins:

```bash
./.venv/bin/python tools/stack_request.py --role aegle --url http://127.0.0.1:8850/api/screen --method POST \
  --json '{"compound":"metformin","mode":"metformin","n":4,"seed":17,"indication":"type-2-diabetes","cohort":"t2d-enriched","assay":"ogtt"}'
./.venv/bin/python tools/stack_request.py --role aegle --url http://127.0.0.1:8850/api/state
./.venv/bin/python tools/stack_request.py --role aegle --url http://127.0.0.1:8850/api/workspace
./.venv/bin/python tools/stack_request.py --role aegle --url 'http://127.0.0.1:8850/api/scientific-sources?workflow=proteins_structures&limit=20'
```

Do not paste patient identifiers, clinical notes, biomarkers, or other PHI into shell
history, test payloads, or any field of the product. The clinical-note intake routes refuse
every note; the other free-text fields are not screened for patient data (a few run a
best-effort check for some marks of a clinical note, which is not a gate).

The shell's only command-history store is `shell_history` inside `LIVEMORE_DATA_DIR`
(default `~/.livemore`). It keeps recognised commands and their arguments after
dispatch returns; `patient` lines, unknown or malformed command syntax, and lines
that raise a typed refusal are excluded. Recognised arguments are not
screened for patient data. Pipelines parse each line first and repeat only recognised
command words, never arguments or unknown text. On startup, the shell clears readline's
memory and filters loaded history by command recognition, excluding `patient` lines.
This does not screen arguments or erase the file immediately; the filtered history is
saved at normal exit. To erase all stored history, including recognised arguments,
exit all shells, then run
`: > "${LIVEMORE_DATA_DIR:-$HOME/.livemore}/shell_history"`.
Start a new shell with `LIVEMORE_SHELL_HISTORY=0 livemore shell` to turn history off:
readline's memory is cleared, no command history is read or written, and an existing
file is left unchanged.

## 7. Scientific adapter configuration

The default open retrieval paths are ChEMBL, PubChem, Open Targets, UniProt, RCSB PDB,
Reactome, GWAS Catalog, OLS, and the Human Reference Atlas. Their product usage and
licensing are visible in `/adapters`.

Every request to a third-party service passes one egress check (`livemorebio/egress.py`)
before it is sent. It may carry only identifiers in that service's own identifier form
(a ChEMBL id, an Ensembl gene id, an HGNC symbol and the like) or terms of the product's
own vocabularies (the reference conditions, drugs, compounds and foods it ships), plus the
operator's credential for a credential-gated service; pinned downloads go only to their
exact pinned addresses. Anything else, such as a compound name outside the vocabulary, is
refused with `EGRESS_VALUE_NOT_ALLOWED` before the request is made. In `/api/resolve` and the
screen, give a compound's ChEMBL id when its name is not in the vocabulary. The forms and
their sources are data in `livemorebio/egress_destinations.py`.

The versioned catalog contains metadata for the official NAR and ELIXIR collections.
Catalog records default to `cataloged` and `catalog_metadata_only`; they are not queried
until the evaluation, configuration, operation, and workflow-wiring gates are recorded.
Refresh the snapshot during a governed release process with:

```bash
python3 tools/refresh_scientific_source_catalog.py
python3 -m pytest -q livemorebio/tests/test_scientific_source_catalog.py
```

For a Neo4j evaluation environment, provide secrets externally:

```bash
export NEO4J_URI='neo4j+s://your-managed-instance'
export NEO4J_USERNAME='livemore-loader'
export NEO4J_PASSWORD='from-your-secret-manager'
export NEO4J_DATABASE='livemore-reference'
```

No Neo4j credentials are stored in source. The backend uses parameterized properties and
fails closed when configuration is incomplete. Production use still requires an approved
edition/topology, RBAC, backup/restore verification, and live integration qualification.

TuringDB remains an isolated evaluation option. Setting `TURINGDB_ENDPOINT` records only
configuration; it does not clear the commercial licence, durability, access-control, or
benchmark gates and does not make TuringDB workflow-wired.

This release has no operational local de-identification; OpenMed is not qualified as a
de-identifier. Every clinical-note intake path (the console's note intake,
`POST /api/ingest_note`, LIFE `POST /human` with a `note`, `patient(note=...)`, the shell's
`patient note` and `patient ... note=...`, `ClinicalExtractor` and `OpenMedNER`) refuses with
`CLINICAL_NOTE_NOT_ACCEPTED` before the note is used to build a twin, stored, logged or echoed.
The console sends the note over loopback; Aegle refuses it without reading the body.
LIFE decodes the JSON body before the gate. Pipelines parse each line first and repeat only
recognised command words. Use explicit structured fields for technical twins.
Other free-text fields are not screened for patient data, and this release is not a
patient-data environment: never enter patient data into it.

Optional credentials belong in the environment, never source control:

```bash
export USDA_API_KEY='your-key'
```

KEGG and GeneCards are intentionally fail-closed. After legal approval, configure the
entitlement and access environment variables documented in
[`LIFE_PATCH_CLOSED_LOOP.md`](LIFE_PATCH_CLOSED_LOOP.md). GeneCards uses a licensed JSON
gateway and never website scraping. KEGG uses its REST service only after a recorded
commercial entitlement. Adapter readiness is reference access, not experimental validation.
The combined, provenance-bearing lookup is:

```bash
./.venv/bin/python tools/stack_request.py --role life --url http://127.0.0.1:8851/reference/genes/TCF7L2
```

## 8. Docker mode

```bash
livemore up
livemore open
livemore token
livemore status
livemore logs aegle
livemore down
```

`livemore up` supplies the independent identity key and authority profile with the
operator token and patch keys to the containers. All three containers receive the
same identity generation and all peer authorities; in-container CLI/SDK and peer
sends dial service names while the host CLI dials published loopback origins.
If you call `docker compose` directly, provision `LIVEMORE_API_TOKEN`,
`LIVEMORE_PATCH_STORAGE_KEY`, `LIVEMORE_PATCH_ADMISSION_HMAC_KEY`,
and `LIVEMORE_SERVICE_IDENTITY_KEY` first or Compose will refuse to start. The
supplied profile explicitly configures the three published loopback authority
defaults. Override the matching `LIVEMORE_*_IDENTITY_AUTHORITY` variables when
using different published origins; each must match that role's published origin.
Each container resolves its own service name to loopback so its local CLI retains
the console peer boundary. Container healthchecks are public liveness, not proof
of stack ownership.

Run `livemore logs` on the host for all container logs, or add service names as in
`livemore logs aegle`. No credential files are read by `livemore down` or `livemore logs`;
both work from a fresh shell without credential or authority environment variables.
`livemore down` and `livemore logs` end with docker compose's own status;
only `refused [CODE]` lines are Livemore refusals. A failed wrapped Compose
command reports `docker compose ACTION ended with status N; its output is above.`

Open the console session with `livemore open` on the host compose path too, when
the CLI and desktop browser share the filesystem and loopback described above.

Without the host CLI (Windows): `docker compose exec aegle livemore open --print-url`, run from
the shell that ran `docker compose up`, then open the clean connection page and enter
the separate code within 120 seconds.
The printed lifetime comes from Aegle and cannot exceed the session-code limit.
`livemore open` exits zero only when a browser launch was requested or it printed
the requested connection instructions; all failures exit non-zero. If no browser can be launched,
use `livemore open --print-url`.

## 9. Runtime state and logs

Local runtime files live under `~/.livemore/`:

- `api-token`, owner-only local operator token
- `service-identity.key`, independent owner-only local service-identity key
- `patch-storage.key`, owner-only AES-256-GCM key for PHI-like local state
- `patch-admission.key`, owner-only key for LIFE-to-Aegle admission and manifest attestation
- `registry.json`, service discovery
- `subjects.sqlite3`, encrypted twin/cohort payloads plus opaque subject/device uniqueness indexes
- `cendos-protocol-runs/`, immutable run-scoped protocol JSON plus the latest-run pointer
- `cendos-protocol-runs/.index.sqlite3`, additive bounded History metadata index
- `models/`, owner-only pinned Human-GEM reference assets and integrity receipt (not patient data)
- `LIFE.log`, `Aegle.log`, `Cendos.log`, detached service logs
- `screen-runs/`, run-scoped screen artifacts
- `evidence.sqlite` and `evidence-exports/`, governed evidence package state
- `pipeline-audit.jsonl` and `livemore-sign-hmac.key`, local integrity records
- `patch-telemetry.jsonl`, encrypted admitted LIFE Patch v2 envelopes and evidence references
- `patch-telemetry.devices.json`, registered device manifests
- `patch-telemetry.commands.jsonl`, safe commands and device receipts

These files can contain research inputs or outputs. Treat them as PHI-like even in development.
Production mode refuses to generate storage or admission keys locally; inject externally
managed values from the deployment secret manager or KMS-backed workflow.

A stopped credential creator can leave `<name>.<pid>.<hex>.tmp` beside the
credential. Credentials must be regular files with exactly one link. When an
owner-only temporary file is confirmed to be the same inode, the
`STACK_CREDENTIAL_LINKED` refusal names it and prints a command to remove that
leftover while keeping the credential. If the credential is intentionally linked
to another stack, the refusal prints commands
using its full, shell-quoted path: `cp -- X X.own && mv -- X.own X` keeps this
stack's own copy; `rm -- X` removes only this stack's link and lets the launcher
make a new credential. For `patch-storage.key`, keep the existing key if this
stack has stored state: a newly generated key cannot read that state. For a
verified creator leftover, use only the printed temporary-file removal command,
then retry while keeping the credential. Nothing is removed automatically.
For `service-identity.key`, use the stopped-stack `livemore identity rotate`
procedure above to repair the entry, then restart every service and client.

The image creates its data directory with mode `0700` before declaring its volume.
Each service tightens its own directory before reading stored state, including
Aegle's selection restoration, so volumes from older images are corrected at
startup. This never adds permissions or changes another owner's directory.
When the data directory is a symbolic link, tightening follows it only to a
directory owned by the process; the subject registry still refuses that linked
storage path before creating its database.

On macOS, do not share the data directory through Finder's Sharing & Permissions.
The stack removes that extended ACL sharing from its owned directory and eligible
credential files and reports `STACK_CREDENTIAL_ACL_CLEARED` when another account
had access. Nine fixed local credential names are covered: `api-token`, `service-identity.key`, `patch-storage.key`,
`patch-admission.key`, `livemore-sign-hmac.key`, `evidence.sqlite.audit.key` and
`evidence-signing-ed25519.key`, plus the review runner's `patch-storage-key` and
`patch-admission-key`. The review runner admits its directory before reading or
creating any credential. The pass also inspects the configured subject database's
`<subject-db>.bootstrap-key`, `LIVEMORE_EVIDENCE_SIGNING_KEY_FILE`, and the configured
evidence database's `<evidence-db>.audit.key` when their resolved parents are inside
the admitted data directory, including its subdirectories. It resolves the parent
only and never follows a final credential symlink. Configured paths outside that
directory keep their existing behavior. Temporary secret leftovers remain covered
by the exposure walk only. The warning escapes configured names and gives separate
compromise/replacement advice for each exposed key; subject bootstrap keys have no
product rotation or re-signing procedure. Exposed directory ACLs also trigger one
filesystem walk (owned directories and single-link regular files, no symlinks or
mount crossings); its result and counts appear in the warning. Each multiply
linked regular entry is skipped and counted. Hard-linked credentials have their
ACL inspected without replacement and are reported exposed with replacement
guidance before the existing linked-credential refusal. Their ACLs, including
DENYs, remain unchanged to protect files outside the directory sharing the inode.
Linked-only exposure reports `STACK_CREDENTIAL_ACL_EXPOSED`. Owned-directory mode
tightening removes group/world bits before filesystem inspection, even when that
filesystem refuses new-secret creation. Missing secrets in the data directory
(including resolved subdirectories) or the default `~/.livemore` secret parent are created only after
owned-directory, filesystem ownership and empty-ACL checks succeed
(`STACK_DATA_DIR_UNSAFE` otherwise). Explicit external secret parents keep their
existing modes, ACLs and creation behavior; their new secret files remain 0600
and exclusively created.
`STACK_DATA_DIR_HOME` refuses a data directory equal to the home directory,
including through a directory symlink. `livemore doctor` checks mode 0700 and an
empty extended ACL without repairing the directory.

Each unconfigured local stack keeps its Ed25519 evidence-signing identity at
`<data-dir>/evidence-signing-ed25519.key`. The default data directory keeps the
same key, key ID, signing profile and export bytes. A custom data directory uses
its own key and does not inspect the default home signing directory. The actual
key parent is admitted before an export reads or creates the key.

A stack with no recorded or held exports creates its key on its first export.
When its own evidence store records an export or its export tree holds an export
but its key is missing, signing refuses
`EVIDENCE_SIGNING_IDENTITY_UNINITIALIZED`. Choose the identity change explicitly
with this one-time offline command, using the same `LIVEMORE_DATA_DIR` as the stack:

```bash
livemore evidence signing init
livemore evidence signing status
```

`init` refuses an existing stack key and reports its fingerprint. It creates only
the selected stack's key and prints its key ID, full fingerprint and base64 public
key, followed by the distinct issuer fingerprints from recorded directories and
immediate non-hidden held export directories in this stack's own export tree.
Missing, invalid or unreadable manifests are counted in a fixed summary and do not block
initialization; unavailable inventory is reported without paths. These fingerprints
are public inventory, not verification
or proof of issuer trust. Send recipients the new public key through an authenticated
channel; earlier exports keep verifying with the key that signed them. Preserve
those earlier public keys and export bytes. Recipients use the existing single-key
`verify_signed_export` with the public key for the export they are checking.

`status` prints only the source kind, key ID, full fingerprint and base64 public
key, and creates no missing key. Both commands run offline without a service,
token, health check or discovery. `init` inventories only the selected stack's
evidence database and export tree, including their configured path overrides.
Inline signing configuration takes
precedence over a configured key file; production still requires one of those
explicit sources. `init` refuses either signing-key override, so clear it before
initializing the stack key. An explicit key-ID override remains supported.

Unsafe registry storage returns HTTP 503 with `REGISTRY_STORAGE_UNAVAILABLE`.
A missing encryption key returns HTTP 503 with
`PATCH_STORAGE_KEY_UNAVAILABLE` before an encrypted-state mutation commits, and
on registry reads when production has no externally managed storage key.
If a mutation finds a linked or nonregular storage-key file, it returns HTTP 503
with `STACK_CREDENTIAL_LINKED`; run `livemore start` to see the local recovery
commands. HTTP errors name only the credential file, without private paths.

## 10. Troubleshooting

`401 authentication required` in the browser: run `livemore open` again to
establish a fresh console session. A bare URL or reload cannot authenticate.
For programmatic requests use the proved SDK or `tools/stack_request.py` with this
stack's private credentials and authority profile.

`SERVICE_IDENTITY_UNPROVEN`: This endpoint did not prove this stack's service
identity. No credential was sent. Stop this stack, check the configured identity
key and service authorities, then restart with the updated launcher. An occupied
port may belong to another process. Do not bypass this check.
This diagnostic describes refusal before the intended request; an ambiguous
failure after a mutation is sent must not be retried as if nothing was sent.
`SERVICE_IDENTITY_CONFIGURATION_INVALID` means the authority and dial/bind origins
do not satisfy the exact-origin rules above. Repair configuration, never disable
the proof. For exposed, linked or malformed identity files, use stopped-stack
`livemore identity rotate`; exposure permits stack impersonation until every
service and client restarts with the new generation.

`refused [CONSOLE_PEER_REFUSED]`: if Aegle was started without the compose file's
`LIVEMORE_CONSOLE_PEER` opt-in, rebuild with `livemore up` using the supplied compose file.
If that opt-in is already present, the host may not arrive from the bridge gateway
(for example, WSL2 or a Linux proxy setup). That networking is unsupported and fails
closed; a rebuild does not fix it.

`CONSOLE_PEER_UNRESOLVED` in Aegle's container log (run `livemore logs aegle` on the host):
the opt-in could not resolve
one RFC 1918 IPv4 default gateway in Docker; Aegle refuses to start.
If `livemore open` reports `Aegle is not running` after `livemore up`, check
Aegle's container log for this refusal or another startup failure. Use supported Docker bridge
networking, or run `livemore down` before switching to native `livemore start all`.
Do not run `livemore start Aegle` while LIFE and Cendos are running in containers.

`503 mutation API disabled`: the service was started outside `livemore start` without
`LIVEMORE_API_TOKEN`. Stop and restart the stack through the CLI.

Port already in use or old code still visible: run `livemore stop all`, confirm `livemore
status` shows all services down, then start again. Do not use broad `pkill` commands.

Biology says 3D unavailable: enable WebGL/hardware acceleration or use another browser. The
organ cards and state readouts must still work.

ChEMBL or another open adapter is degraded: retry later or use an already pinned successful
resolution. Never replace a failed source with fabricated targets.

Console-code minting reports typed reasons without echoing a listener's response:
`CONSOLE_ORIGIN_NOT_LOOPBACK`, `CONSOLE_CODE_UNAVAILABLE`, or `CONSOLE_PEER_REFUSED`.
A failed browser exchange reports `CONSOLE_EXCHANGE_FAILED`. A credential's own
refusal, such as `STACK_CREDENTIAL_LINKED`, reaches the operator unchanged.

`CONSOLE_EXCHANGE_GET_RETIRED` (HTTP 410): old one-time links no longer authorize
a session. Run `livemore open`, or rerun `livemore open --print-url`, open its clean
connection page and enter the fresh code there. Do not reuse the old link or move
its code into another URL. The refusal never consumes a code or sets a session.

`CONSOLE_CODE_ATTEMPTS_EXCEEDED` (HTTP 429): manual entry allows at most
20 submissions per sliding minute, process-wide. Wait for the attempt budget to
recover, then retry an unspent, unexpired code or mint a fresh one if needed.
The accepted local denial-of-service tradeoff is that another local process can
exhaust the budget. This budget does not apply to ordinary private-file and recorder codes.

## 12. Scientific and product boundary

LivemoreBio is being built toward a biological functional human-body replica, but this release
does not claim that outcome. Fifteen systems are architecturally registered and reference-backed;
the metabolic and cardiovascular contexts are the executable coupled models. No current system
is person-calibrated, context-validated, independently replicated, regulator-ready, or connected
to validated LIFE Patch hardware. The virtual v2 device proves software-contract parity only.
Research intended for human transfer still requires assay, model, context-of-use, validation,
quality, ethics, clinical, and regulatory gates. See the
[closed-loop guide](LIFE_PATCH_CLOSED_LOOP.md) for API operation and the
physical-equivalence artifact list.
