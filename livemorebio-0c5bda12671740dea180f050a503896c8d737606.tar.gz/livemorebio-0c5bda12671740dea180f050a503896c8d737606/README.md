# LivemoreBio

Core computational-biology infrastructure for biotech and drug development, built
toward a complete biological functional human-body replica. The product is three
connected systems: the LIFE measurement and device data plane, the Aegle
person-state and simulation plane, and the Cendos experiment and evidence plane.

The current release is not a complete living-human replica or clinical decision
system. It provides an all-system architecture contract plus executable,
model-only metabolic and cardiovascular contexts. Every other body system is
registered and reference-backed but refuses functional claims until an engine,
coupling, calibration, and context-specific validation actually exist.

Local service identity is checked before first-party programmatic clients send
credentials. It does not authenticate the browser's HTTP origin or encrypt local
traffic. On a native stack, a relay would have to hold the genuine service's own
bound address; the genuine service holds that address while running. The remaining
relay is the Compose case: depending on Docker's publishing mode, another account
can hold the published origin while the container remains reachable at its bridge
address. Run the local stack on a machine whose other accounts you trust. On a
shared workstation, or for real patient data, use the hosted deployment when it
exists. NEW-5b belongs to I2. This release does not support production PHI, and it is not a patient-data environment: never enter patient data into it, in a note or in any other field.
The private console launch channel keeps its code out of browser-launch arguments.
Saved screen reports at `/api/screen/{run_id}/report.md` and
`report.audit.json` are sensitive operator artifacts even when their inputs are
synthetic. They require the operator bearer or a valid console session, with
authentication checked before any run lookup, including unknown ids. Success and
refusal responses use `Cache-Control: no-store`. Same-origin console download links
send the HttpOnly session cookie; native SDK/tools use the bearer.
The bearer never belongs in browser JavaScript or a URL.

## Research capabilities

LivemoreBio is local, single-operator research software. Software execution does
not establish clinical validity, physical device performance or pharmaceutical
production readiness. See the [release notes](docs/STABLE_MAINTENANCE_RELEASE_NOTES.md),
[operating guide](docs/LAUNCH_GUIDE.md), [research workflows](docs/RESEARCH_VALIDATION_GUIDE.md)
and [scientific readiness boundaries](docs/PHARMA_READINESS_AND_ROADMAP.md).

Each unconfigured local stack's evidence-signing key lives in its own data directory at
`evidence-signing-ed25519.key`; the default stack retains its existing identity.
If a key is missing after this stack has recorded or held exports, signing refuses
`EVIDENCE_SIGNING_IDENTITY_UNINITIALIZED` until the operator runs the offline
`livemore evidence signing init`. Use `livemore evidence signing status` to inspect
public signing metadata. Send recipients the new public key through an authenticated
channel; earlier exports keep verifying with the key that signed them. See the
[operating guide](docs/LAUNCH_GUIDE.md) for the one-time procedure.

The reference seed uses Disease Ontology identities and current Open Targets
associations. An association is not a causal effect or a person's risk estimate.
The eleven-locus research score retains the four supported axes' numerical
outputs; other axes refuse explicitly. Its inherited scientific limitations are
listed in the release notes. Free-text recognition uses a reviewed vocabulary;
it does not infer clinical diagnosis or perform general negation analysis.

- **Whole-human capability manifest** — all 15 systems in the canonical anatomy
  ontology are exposed with independent maturity claims: registered,
  reference-backed, modeled, coupled, person-calibrated, context-validated,
  independently replicated, and device-connected. Architectural inclusion never
  promotes scientific maturity.
- **Pinned Human-GEM reference metabolism** — Human2 v2.0.0 provides 12,931 reactions,
  8,461 metabolites and 2,848 genes. Cendos executes explicit glucose/oxygen-limited
  ATP-capacity conditions and complete GPR-aware gene knockouts in an isolated GLPK
  worker. Negative controls, conservation/bound checks, source/software digests,
  directed reference annotations, CSV and executable notebooks travel with every run.
  This is steady-state reference-network computation, not person physiology or a new
  arbitrary-drug reaction engine. Recon3D remains commercially restricted.
- **Clean research workflow** — a fresh data directory has no twins, cohorts or runs,
  and starts with an unregistered healthy reference preview. Cendos opens Preparation;
  searchable/paged History supports recall and explicit parent-linked reruns without
  overwriting originals. Twin/cohort lists are paged and searchable. Biology data loads
  independently of graphics, with visible retry and unavailable-organ boundaries.
- **Metabolic engine** — executable **glucose–insulin** ODEs (reduced Bergman model,
  SciPy/LSODA). Output depends on explicitly recorded model parameters; diagnostic
  labels and gene associations no longer inject arbitrary physiological multipliers.
  Reproducing a numerical reference pattern is not human validation.
- **Cardiac engine** — the published **O'Hara–Rudy CiPA 2017** human ventricular
  myocyte (49 states) hosted natively via Myokit/CVODE from its CellML source.
  Physiologic AP: rest ≈ −88 mV, peak ≈ +41 mV, APD90 ≈ 268 ms. IKr block
  (drug or coupling) prolongs APD — the hERG/QT mechanism (50% block → +100 ms).
- **Cross-scale coupling** — explicit reduced-model coupling experiments connect
  metabolic and cardiac parameters. Their coupling laws require independent validation;
  they are not established individual human causal transfer functions.
- **Executable multiscale workspace** — the default Aegle surface binds formal
  all-system contracts to the first deep executable path: SLC22A1/OCT1 and drug
  exposure → hepatocyte/liver glucose output → endocrine dynamics → IKr,
  cardiomyocyte, ventricular tissue, heart, and whole-body readouts. Baseline and
  treated traces, biological time, person parameters, engine lineage, and evidence
  state travel together. Systems without executable models expose contracts and an
  explicit unavailable state rather than invented output.
- **Governed twin and cohort lifecycle** — `/twins` admits either a consented real-human
  profile with field-level EHR, laboratory, device, medication, genomic, lifestyle, and
  environmental provenance, or a non-person research twin generated server-side from a
  pinned population manifest and stratum. Missing real-human domains remain missing;
  caller-entered values cannot masquerade as reference data. `/cohorts` materializes and
  freezes heterogeneous member profiles, seeds, source lineage, and fingerprints. Exactly
  one twin is authoritative across Atlas, LIFE Patch, Cendos, terminal, and notebooks.
  Physical Patch pairing additionally requires an active consented real-human twin,
  B0/protocol metadata, current calibration, device attestation, and device uniqueness.
- **Patch-to-twin reconciliation** — physical and virtual v2 observations share one
  device contract. The workspace computes observed-versus-virtual residuals only
  when signal units and quality gates agree; it never silently updates model
  parameters or authorizes calibration.
- **Cendos translation gate** — frozen prediction/measurement counterparts are bound
  by subject, endpoint, unit, protocol, timing window, population, intervention, and
  dose. A passing tolerance creates a proposed validation event for EvidenceService
  review, not self-validation and never automatic calibration.
- **Cendos computational assay** — evaluate supported protocols against their frozen
  baseline without mutating a live twin. Metformin uses an individualized one-compartment
  PK path and declared heuristic PD assumptions. Unknown compounds and arbitrary
  user-entered plant benefit multipliers now fail closed.
- **Governed cohort protocols** — the first bounded workflows compare individualized
  metformin PK→PD→OGTT responses across two pinned metabolic strata and evaluate purified
  garcinoic-acid engagement of human PXR from the 6P2B co-crystal plus published Kd/EC50
  inputs. Each run is durable and run-scoped, exports CSV and a Jupyter notebook, and can
  be projected into Biology. Both remain modeled and not qualified until their required
  physical Cendos or human counterpart measurements pass the evidence gate.
- **Pharma cohort screen** — an explicit T2D-enriched synthetic cohort, OGTT assay,
  dose→exposure→effect metformin path, pinned ChEMBL resolution, per-run durable
  reports, and a local integrity record that binds the complete ranking.
- **Scientific adapter registry** — active retrieval paths, bounded health probes,
  license links, credential gates, and hard blocks for commercially restricted
  sources. Adapter readiness never upgrades scientific maturity.
- **Governed NAR/ELIXIR catalog** — a versioned metadata snapshot contains all 39
  current ELIXIR Core Data Resources and every discoverable entry on the official NAR
  alphabetical collection page. The NAR snapshot contains 2,594 summary-paper entries
  while preserving the collection's reported 2,173 independent-database count and its
  update/duplicate distinction. Runtime use requires the explicit lifecycle
  `cataloged → evaluated → configured → operational → workflow_wired →
  scientifically_qualified`; catalog-only sources are never queried by experiments.
- **Mechanistic acceptance tests pass.** _Not clinically validated; parameters are
  literature-typical, not cohort-fitted._

- **Research comparison workspace**, `/research` — freeze endpoint tolerances, member
  mappings and saved prediction hashes; admit raw measurement CSV with custody/QC;
  compare matched endpoints. Technical fixtures cannot become physical evidence, and
  no comparison authorizes calibration automatically.
- **Treatment-free resilience** — predeclare all five cure operations, individual healthy
  ranges, independent subjects, washout, post-washout follow-up and stress conditions.
  Evaluate admitted measurements with a one-sided confidence bound; missing evidence
  remains missing. This is an assessment contract, not a cure claim or therapy optimizer.
- **Continuous biological learning** — versioned proposals across eight biological scales
  record primary sources, counterevidence, applicability and tests. Proposals do not alter
  active twins or create a reinforcement-learning system by themselves.

- **LIFE Patch v2 closed loop** — one manifest, telemetry, quality, command, and receipt
  contract shared by the physical gateway and virtual patch. LIFE registers devices,
  rejects invalid/replayed data, journals admitted envelopes, forwards observations to
  Aegle, and exposes the same immutable references to Cendos. The B0 software target uses
  MAX86141 over SPI, AD5940 without redundant LMP91000, isolated authenticated pods, and
  QSPI storage. Telemetry updates observed state only; calibration requires released
  evidence authorization. Physical firmware and analytical equivalence remain pending.

## Research programs

The exogenous-insulin engine implements the published Hovorka system with
per-parameter source lineage. Six research programs are available through the
terminal, SDK, API and Jupyter. Programs with missing or inconsistent source
measurements report that missingness instead of producing a plausible value.

**Validation status is unchanged: 0/6 validated in vivo.** Execution is not
validation, and nothing in these programs is dosing guidance.

```
livemore doctor            # fresh-machine readiness; exit 1 when a required check fails
livemore programs list     # the six programs and whether each can be executed
livemore programs run LBHR-030 --dose-mg 400
livemore notebook          # Jupyter Lab workspace with the SDK pre-wired
```

`livemore notebook` is the one-step Jupyter launch for this stack. It opens a private
launch file carrying a one-time code; the live Jupyter token stays in a private
per-launch runtime. For SSH or a headless machine, run `livemore notebook --no-browser`,
open the printed clean `/login?next=%2Flab` URL, and type the separate code into
Jupyter's login form. Codes expire after 120 s and allow single use. Run
`livemore notebook-code` to print a fresh manual code for this stack's running
notebook session. Keep code entry outside recordings and stop Jupyter with Ctrl-C
in the launching terminal. See [the launch guide](docs/LAUNCH_GUIDE.md), section Jupyter notebooks,
for runtime isolation and supported versions.

In the shell or a pipeline file:

```
program list
program show LBHR-129
program run LBHR-030 dose_mg=400 cohort=10 seed=1 output=run.json
insulin products
insulin run units=4 meal=60 cohort=12 seed=1
```

The shell's only command-history store is `shell_history` inside `LIVEMORE_DATA_DIR`
(default `~/.livemore`). It keeps recognised commands and their arguments after
dispatch returns; `patient` lines, unknown or malformed command syntax, and lines
that raise a typed refusal are excluded. Recognised arguments are not
screened for patient data. Pipelines parse each line first and repeat only recognised
command words, never arguments or unknown text. On startup, the shell clears readline's
memory and filters loaded history by command recognition, excluding `patient` lines.
This does not screen arguments or erase the file immediately; the filtered history is
saved at normal exit. To erase all stored history, including recognised arguments,
exit all shells, then run
`: > "${LIVEMORE_DATA_DIR:-$HOME/.livemore}/shell_history"`.
Start a new shell with `LIVEMORE_SHELL_HISTORY=0 livemore shell` to turn history off:
readline's memory is cleared, no command history is read or written, and an existing
file is left unchanged.

## Supported platforms

The product enforces local confidentiality of PHI-like state with POSIX file
semantics: 32 owner-only checks across the registry, execution store, evidence
store, protocol runs, model assets, anatomy cache and the LIFE Patch journal.

| Platform | Status |
|---|---|
| macOS, Linux | Supported natively; use the verified installer |
| Windows via Docker Desktop | Supported; `docker compose up`, then `docker compose exec aegle livemore open --print-url`, open the clean connection page and enter the separate code. The WSL2 port proxy is untested |
| Windows via WSL2 | Supported inside the distribution; a Windows browser uses the SSH-forwarding recipe below or a CLI where the browser runs |
| Windows natively | Refused with guidance, because it cannot express the owner-only guarantees the product depends on |

Clients build the image from the public release, unpacking its source archive
before running `docker compose`. Images built from a private checkout are for private use only
and must not be distributed: they contain research tools, tests and records
excluded by the public publisher. The `Platforms` workflow separately builds
and health-checks the public release container path and the private checkout path.

For Bash archive acquisition, verify before extracting:

Ask the release author for the expected SHA-256 through a separately verified
channel. Set `LIVEMORE_SHA256` to that independently supplied 64-character digest
(`export LIVEMORE_SHA256='...'` in Bash, `$env:LIVEMORE_SHA256 = '...'` in
PowerShell). Do not derive it from the archive or a checksum served by the
same download origin. Start in a new empty directory; stop if verification
fails. A matching checksum binds the archive to your chosen digest; it does
not authenticate the download instructions or establish a signing identity.

```bash
(
  set -euo pipefail
  : "${LIVEMORE_SHA256:?Set LIVEMORE_SHA256 to the independently supplied release digest.}"
  [[ $LIVEMORE_SHA256 =~ ^[0-9a-fA-F]{64}$ ]] || { printf '%s\n' 'Invalid release digest.' >&2; exit 1; }
  archive=livemorebio-stable.tar.gz
  curl -fsSL https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/main/livemorebio-stable.tar.gz -o "$archive" || exit $?
  if command -v sha256sum >/dev/null 2>&1; then
    actual=$(sha256sum < "$archive") || exit $?
  else
    actual=$(shasum -a 256 < "$archive") || exit $?
  fi
  expected=$(printf '%s' "$LIVEMORE_SHA256" | tr 'A-F' 'a-f') || exit $?
  [[ ${actual%% *} == "$expected" ]] || { printf '%s\n' 'Archive checksum mismatch; refusing extraction.' >&2; exit 1; }
  tar -xzf "$archive" || exit $?
) && cd livemorebio-*/
```

On Windows PowerShell:

```powershell
$ErrorActionPreference = 'Stop'
if ($env:LIVEMORE_SHA256 -notmatch '\A[0-9a-fA-F]{64}\z') { throw 'Set LIVEMORE_SHA256 to the independently supplied release digest.' }
curl.exe -fsSL https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/main/livemorebio-stable.tar.gz -o livemorebio-stable.tar.gz
if ($LASTEXITCODE -ne 0) { throw 'Archive download failed.' }
$actual = (Get-FileHash -LiteralPath livemorebio-stable.tar.gz -Algorithm SHA256).Hash
if ($actual -cne $env:LIVEMORE_SHA256.ToUpperInvariant()) { throw 'Archive checksum mismatch; refusing extraction.' }
tar -xzf livemorebio-stable.tar.gz
if ($LASTEXITCODE -ne 0) { throw 'Archive extraction failed.' }
cd (Get-ChildItem -Directory livemorebio-*)[0]
```

After successful verification, follow [the container guide](docs/BUSINESS_CLIENT_GUIDE.md)
for secret provisioning and startup; that guide also gives the PowerShell
verification commands.

The container image builds for `linux/amd64` only. The Dockerfile names no
architecture, but the hash-locked dependency set pins libroadrunner 2.10.0,
which publishes no Linux wheel for arm64 and no source distribution. On an
arm64 host, which includes Apple Silicon and Windows on Arm, Docker builds
`linux/arm64` by default, and `docker compose up` stops at the dependency
install. On Apple Silicon use the native installer. Running the `linux/amd64`
image under emulation on an arm64 host has not been tested.

`livemore doctor` reports the platform and exits non-zero when a required check
fails. Both container jobs in the `Platforms` workflow drive an insulin run with
controls through the container API. The private checkout job also checks a botanical
run and a refused program.
See the operating guide for prerequisites and troubleshooting.

## Running it — terminal-launched infrastructure

LivemoreBio is infrastructure, not a web app. The three infrastructures run as independent
services that discover each other through a shared registry (`~/.livemore/registry.json`)
and cooperate in real time:

### Verify and install

The public installer needs Python 3.11, Bash, `curl`, and `tar`; no GitHub login
is required. Verify the release values and run this block:

At each release go, the author publishes the installer SHA-256, archive SHA-256
and distribution commit on both a release in the **Livemore-Biosciences
organisation on GitHub** and a page on **livemorebiosciences.com**. These channels
must be independently administered from the GitHub account that owns the
download repository. Users may check either channel; the installer and archive
digests must match on both, as must the distribution commit. Stop if they differ.

The author fills the five placeholders below at the go in externally served
guides and the weekly workflow. For a bundled guide, replace the placeholders
with the published URLs and values before installation. Confirm the release
values against either channel before running this block. Do not take the expected
digests from the installer, archive or `stable.json` on the download host.
Unfilled placeholders, download failures and checksum mismatches stop before
the installer runs. L0 uses these digests without release signing (F-06).

```bash
(
  set -euo pipefail
  org_release_url='{ORG_RELEASE_URL}'
  livemorebiosciences_url='{LIVEMOREBIOSCIENCES_URL}'
  installer_sha256='{INSTALLER_SHA256}'
  archive_sha256='{ARCHIVE_SHA256}'
  dist_commit='{DIST_COMMIT}'
  [[ $org_release_url == https://github.com/Livemore-Biosciences/*/releases/* && $org_release_url != *'{'* && $org_release_url != *'}'* ]] || { printf '%s\n' 'Set the Livemore-Biosciences GitHub release URL.' >&2; exit 1; }
  [[ $livemorebiosciences_url == https://livemorebiosciences.com/* && $livemorebiosciences_url != *'{'* && $livemorebiosciences_url != *'}'* ]] || { printf '%s\n' 'Set the livemorebiosciences.com release page URL.' >&2; exit 1; }
  [[ $installer_sha256 =~ ^[0-9a-fA-F]{64}$ && $archive_sha256 =~ ^[0-9a-fA-F]{64}$ ]] || { printf '%s\n' 'Set both published SHA-256 digests.' >&2; exit 1; }
  [[ $dist_commit =~ ^[0-9a-f]{40}$ ]] || { printf '%s\n' 'Set the published distribution commit.' >&2; exit 1; }
  archive_sha256=$(printf '%s' "$archive_sha256" | tr 'A-F' 'a-f') || exit $?
  installer_file=$(mktemp) || exit $?
  trap 'rm -f "$installer_file"' EXIT
  curl -fsSL --connect-timeout 15 --max-time 120 --retry 3 \
    "https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/$dist_commit/install.sh" >"$installer_file" || exit $?
  test -s "$installer_file" || { printf '%s\n' 'Empty installer; refusing execution.' >&2; exit 1; }
  if command -v sha256sum >/dev/null 2>&1; then
    actual=$(sha256sum < "$installer_file") || exit $?
  else
    actual=$(shasum -a 256 < "$installer_file") || exit $?
  fi
  actual=${actual%% *}
  expected=$(printf '%s' "$installer_sha256" | tr 'A-F' 'a-f') || exit $?
  [[ $actual == "$expected" ]] || { printf '%s\n' 'Installer checksum mismatch; refusing execution.' >&2; exit 1; }
  LIVEMORE_SHA256="$archive_sha256" bash "$installer_file"
)
```

It downloads the published archive, verifies its release checksum, installs the
hash-locked scientific, server, notebook,
and test dependency set, runs the full test and compile gates, and makes `livemore`
available in new terminals. Each release is built while inactive and the `current`
pointer changes only after verification, so a failed update leaves the previous
installation working. Reused releases are checked against an external full-tree digest.

After installation:

```
livemore start all        # or: livemore start LIFE / Aegle / Cendos
livemore status           # proved readiness, distinct from reachable HTTP health
livemore models check human-gem  # verified model readiness, separate from HTTP health
livemore models restore human-gem  # finish a model install that was interrupted or refused; deletes only what it made
livemore manifest         # all human systems + honest maturity and integration state
livemore workspace        # compact live multiscale projection from the running product
livemore sources --workflow reactions_metabolism  # only runtime-wired sources for this workflow
livemore open             # open the Aegle console in the browser
livemore open --print-url # print the clean connection URL and a separate one-time code
livemore logs aegle       # show Aegle's container logs after livemore up
livemore attach           # operate the same live twin, cohorts, Patch, and assays in terminal
livemore stop all
```

The same manifest is available to scripts and notebooks through
`from livemorebio import whole_human_manifest` or `Platform().manifest()`, and
to services through `GET http://127.0.0.1:8850/api/system-manifest`.

- **LIFE** (:8851) — the population/reference substrate plus the LIFE Patch v2 device
  gateway (`/patch/devices`, `/patch/telemetry`, `/patch/virtual/sample`, `/patch/commands`).
- **Aegle** (:8850) — the living-twin console + reactive API; shows all three services live at the bottom.
- **Cendos** (:8852) — supported computational protocols and compound identity lookup.
  A database hit is not a batch composition, purity assay, bioavailability estimate or causal model;
  mixtures such as botanical extracts cannot be represented by an invented single molecule.

Start the stack with `livemore start all`, then run `livemore open`. The launcher
proves Aegle's identity before sending the operator token, writes a unique owner-only launch page in
`<data dir>/console-launch/`, and requests its file URI in the browser. The page
POSTs a single-use code. The server exchanges it for a separate in-memory,
HttpOnly, SameSite=Strict session cookie with a per-port name and returns an HTML
page that refreshes to the clean console URL. "Launch requested in your browser"
confirms the launcher accepted the request; authentication still depends on the
browser completing the exchange. After a server restart, run `livemore open`
again; a bare console URL does not establish authorization. There is no token
prompt. Failures exit non-zero and never print an unrequested code.

Automatic launch requires the same filesystem and the same loopback for the CLI
and browser: a macOS or Linux desktop host CLI, including a host CLI reaching
Compose's published port. Use these recipes elsewhere:

- Docker Desktop with an in-container CLI: run
  `docker compose exec aegle livemore open --print-url`, open its clean connection
  page in the host browser at the published loopback port, then enter the code.
- SSH: from your own machine run `ssh -L <port>:127.0.0.1:<port> <host>` with the
  same Aegle port at both ends; run `livemore open --print-url` in that session
  and open its clean connection page in your machine's browser, then enter the code.
  The exchange sees the forward's
  loopback peer.
- WSL with a Windows browser and remote desktops with a client-side browser:
  use that SSH recipe or run the CLI where the browser runs. A browser within
  the remote desktop can launch automatically only with the shared filesystem
  and loopback above.

Peer, Host and Origin checks stay unchanged. On Linux without `DISPLAY` or
`WAYLAND_DISPLAY`, or when no browser is found, automatic launch refuses
`CONSOLE_EXCHANGE_FAILED` before writing a file. If a snap or flatpak browser
cannot read an accepted file launch, use `livemore open --print-url`.

`livemore open --print-url` prints three lines: the clean `<origin>/console/connect`
URL, a separate one-time code labeled `One-time code:`, and the lifetime
(the command prints its lifetime). Open the clean connection page and enter the code
into its masked form; it is submitted by POST. Never put the code in a command
argument, environment variable, URL query or fragment, or shell substitution.

`--print-url` remains an explicit secret-output exception: terminal scrollback,
redirected output and terminal recordings may retain the live code until its
printed deadline. Browser URL history and ordinary URL access logs receive clean
paths; form/POST-body capture or compromised local software can still disclose
the code. A leftover private launch file also contains a live code until it is
spent or the session-code lifetime ends. A spent or expired code cannot establish
another session; run `livemore open` again for a new one. A typo can be retried
while the code remains unspent and unexpired. Per-port cookie names and loopback
transport do not establish local service identity or isolate all local accounts.
Ordinary launch never prints a code, even on failure. Expired private launch files are pruned by
`open`, `down`, and stopping Aegle or all services, with shutdown pruning best
effort.

`CONSOLE_EXCHANGE_GET_RETIRED` means old one-time links no longer authorize a
session. Run `livemore open`, or rerun `livemore open --print-url`, open the clean
connection page and enter the fresh code there. Do not reuse the old link or move
its code into another URL.
For container startup and networking refusals, see the
troubleshooting section of the [launch guide](docs/LAUNCH_GUIDE.md).
The launcher still generates an owner-only operator token
at `~/.livemore/api-token` for terminal/SDK and explicit API clients. `livemore token` is an
optional diagnostic/export command for `curl`, not a browser setup step or external account.
Prefer the proved SDK or the first-party Python request helper in the launch guide
for programmatic calls; raw credentialed `curl` does not perform this identity check.
Read the full [launch guide](docs/LAUNCH_GUIDE.md) for installation, page-by-page
operation, Docker, terminal workflows, and troubleshooting. The
[closed-loop operating contract](docs/LIFE_PATCH_CLOSED_LOOP.md) documents the device,
telemetry, command, laboratory-counterpart, and scientific-reference interfaces.

The [external tester guide](docs/EXTERNAL_TESTER_GUIDE.md) covers verified
Human-GEM assets, isolated evaluation and model-execution checks. Existing runtime
records are preserved; an empty workspace requires a new data directory.

The console itself is served from **http://127.0.0.1:8850** by the running Aegle
service. The private file opened by `livemore open` is only its one-use launch
page; opening a console source HTML file directly cannot reach the API. Connection
failures appear in a red banner.

### Local service identity and existing-stack migration

Native `start` and Compose `up` provision an independent random 32-byte identity
key in the admitted data directory's owner-only `service-identity.key`, separate
from the bearer and patch keys. For an environment-only deployment,
`LIVEMORE_SERVICE_IDENTITY_KEY` supplies canonical padded URL-safe base64 without
a newline; an explicitly empty or malformed value refuses and never falls back
to a file. Services and attached clients read existing trust; they never create
it. A missing key refuses `SERVICE_IDENTITY_UNPROVEN` before credentials are sent.
There is no insecure flag and no downgrade. Public health alone is not identity:
another process can return a plausible `/health` response.

The configured identity authority is the exact origin for a role; the dial address
names the endpoint. Native loopback authorities must match their bind
and literal dial origins. A mismatch refuses `SERVICE_IDENTITY_CONFIGURATION_INVALID`.
For a named dial such as `localhost` with an IP-literal authority, the connection
goes to the authority's own address: the dial uses the same port and resolves to a
set containing that literal address, or the request is refused before connecting.
DNS authorities retain their named-host behavior. The only exception is the fixed
Compose peer profile; its bridge relay remains a named limitation.
Compose clients dial `http://aegle:8850`, `http://life:8851` or
`http://cendos:8852`, while comparing explicitly published loopback authorities
from `LIVEMORE_AEGLE_IDENTITY_AUTHORITY`, `LIVEMORE_LIFE_IDENTITY_AUTHORITY` and
`LIVEMORE_CENDOS_IDENTITY_AUTHORITY`. Host clients dial those published loopback
origins. An SSH-forwarded SDK must forward the same port number at both ends.

Rotation is stop, rotate, restart with no dual-key grace: stop every service,
run `livemore identity rotate`, restart all services, then recreate long-lived
shells/notebooks. The command also repairs exposed, linked or malformed identity
files without following their links. It refuses recorded live processes, does
not revoke unrecorded processes, and does not probe ports. It prints only the new
SID's first 16 hex characters, never the key. Environment-only operators replace
their external key instead; the launch guide provides a private-file generator.

For an existing stack: stop it first; upgrade launcher, services, SDK and tools
together; start/up provisions the missing key before launch. Environment-only
and direct Compose operators provision a new independent key and matching
authorities before starting. Restart every service and recreate long-lived
shells/notebooks, then check all roles using technical data. Preserve bearer,
patch keys and existing stores; identity provisioning is not data migration.
Old services, stale keys and mismatched authorities refuse; old installed
clients remain unsafe. The NEW-9 clean manual `/console/connect` URL and separate
code are unchanged. Read the [migration and rotation procedure](docs/LAUNCH_GUIDE.md)
before updating an existing stack.

## LIFE System — measured-human data plane and reference population

The LIFE System is the boundary where lawful measured-human data, external clinical
and laboratory sources, the virtual LIFE Patch, and eventually the physical LIFE
Patch enter Livemore. Its reference population uses curated anatomy, disease,
pathway, gene, and atlas records to create synthetic model inputs. Those inputs are
not a person's biology and synthetic output is not measured-human data.

Commercial reference sources are governed separately. KEGG requires recorded commercial
entitlement for this product and GeneCards requires a licensed API/export path; neither is
scraped or silently embedded. Their connectors fail closed and expose only an audit-safe
entitlement fingerprint. When configured, `GET /reference/genes/{symbol}` combines their
licensed gene records into hashed reference context without promoting any evidence claim.
The NAR database collection is a discovery index, not a blanket license for its linked
databases.

When physical LIFE Patch hardware is validated, its packets can use the same signal
schema. Cloud or Aegle commands may never bypass a physical device's local safety
controller.

Reference cohorts are heterogeneous prior-generated research inputs, not recruited humans
or measured individual records from NHANES/DPP. Diagnosis and gene annotations alone do not
establish quantitative physiology. Actual onboarding must preserve measured values, units,
identity, timing, lawful use and missingness; omitted fields remain explicitly reference-initialized.

`data origin` (synthetic-model vs measured observation) — **not** sensor "claim/trust" — is
the meaningful distinction; claim classes belong to the physical instrument alone.

## Knowledge graph, retrieval & clinical extraction

The substrate offers three interfaces with different operational maturity:

- **Graph** (`graph.py`) — the biology as a NetworkX property graph (Gene ↔ Disease ↔ Pathway ↔ Organ ↔ Drug): neighbours, subgraphs, and reference association paths (e.g. `TCF7L2 → Type 2 diabetes → pancreas`). Neo4j loading now uses explicit environment credentials and parameterized writes. Production still requires Enterprise-grade RBAC, backup/restore, and a live integration qualification; no default password exists.
- **Retrieval** (`retrieval.py`) — a numpy TF-IDF/cosine `SubstrateIndex`: natural-language queries ("insulin resistance") rank relevant diseases, genes, and pathways. TuringDB is an isolated evaluation option, not a production path; commercial clearance, durability, access control, and benchmarks remain hard gates.
- **Clinical extraction** (`extract.py`) — This release has no operational local de-identification. Its clinical-note intake routes refuse every note: the console's note intake, `POST /api/ingest_note`, LIFE `POST /human` with a `note`, the SDK's `patient(note=...)`, the shell's `patient note` and `patient ... note=...`, and the extractor's own `extract`, `to_synthetic_human` and `OpenMedNER.extract` all refuse with `CLINICAL_NOTE_NOT_ACCEPTED` ("this release does not accept clinical notes; local de-identification is not operational") before the note is used to build a twin, stored, logged or echoed. The console sends the note over loopback; Aegle refuses it without reading the body. LIFE decodes the JSON body before the gate. Pipelines parse each line first and repeat only recognised command words. Build a technical twin from explicit structured fields instead; those fields take technical values only (an `id` from a closed grammar such as `LMB-CUSTOM`, `sex` F or M, `conditions` and `genome` from the reference vocabulary at `GET /api/vocab`), and an undefined key is refused. Other free-text fields (twin labels and custody text, research records, imports and uploads, protocol, qualification and lab-result fields, telemetry fields, the search query, and recognised shell arguments kept in `shell_history`) are not screened for patient data. Some of them run a best-effort check for a few marks of a clinical note and refuse with the same code; that check is not a gate, and a note written without those marks passes. This release is not a patient-data environment: never enter patient data into it. No free text leaves the machine: a request to a third-party service carries only identifiers in that service's own identifier form (a ChEMBL id, an Ensembl gene id, an HGNC symbol and the like) or terms of the product's own vocabularies, plus the operator's credential for a credential-gated service, and anything else is refused with `EGRESS_VALUE_NOT_ALLOWED` before the request is made (`livemorebio/egress.py`, with the forms and their sources in `livemorebio/egress_destinations.py`). OpenMed is clinical intake, never the biological-reaction engine.

The catalog is queryable from the web (`/adapters`), API
(`GET /api/scientific-sources`), SDK (`Platform().scientific_sources(...)`), and
terminal (`livemore sources`). Refresh metadata from the authoritative pages with:

```bash
python3 tools/refresh_scientific_source_catalog.py
```

The refresh downloads metadata only; it never downloads a scientific dataset or advances
any source beyond `cataloged`.

## Simulation kernels installed and verified
libRoadRunner (SBML) · libSBML · libCellML (Physiome native format) · COPASI/BasiCO
· Myokit/CVODE (cardiac). These host published Physiome / BioModels / CellML organ
& cell models. LivemoreBio owns the cross-scale **state engine** and **coupling**
that bind implemented contexts into the evolving whole-human architecture.

## Architecture (direction)
LIFE System (DNA → RNA → protein → cell → organ → … → environment) → **Aegle**
twin (state engine + cross-scale coupler) → **Cendos** computational protocols and
physical counterpart intake → run-bound visualisation. Heavy engines (PhysiCell,
BioDynaMo, AlphaFold/ESM/Evo, SimVascular/OpenFOAM) are options, not evidence of
installed, wired or scientifically qualified functions in this release.

## Manual developer installation

The verified installer above is the supported product path. Contributors who need an
editable checkout can still install manually:

    python3.11 -m venv .venv
    ./.venv/bin/python -m pip install --require-hashes -r requirements-python311.lock
    ./.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
    ./.venv/bin/python -m pytest -q
    ./.venv/bin/python -m compileall livemorebio

Release authors must also run the real installer from the committed release's
own archive before each L0.n go/no-go:

    ./.venv/bin/python tools/installer_gate.py --ref HEAD --audience public --output /absolute/new/gate-output

The output directory must not exist. This runs the default model acquisition,
complete verification suite and activation in an empty HOME, checks the activated
command, retains evidence, and deletes its disposable state. It needs an
unrestricted test host; dependencies and models may require network access.
The gate uses `LIVEMORE_ARCHIVE` with a normalized absolute archive path, a full
commit in `LIVEMORE_REF`, and mandatory `LIVEMORE_SHA256`; local source bytes still
pass all normal installer checks. Guarded runs use `--guard-dir` and `--guard-log`
to load the supplied network guard in the new venv, including isolated Python.


## Launch the Aegle living console

    ./.venv/bin/livemore start all
    ./.venv/bin/livemore open
    # or double-click "Livemore Console.command"

Whole-body twin: the cardiac context executes the O'Hara–Rudy action-potential and
calcium model; the metabolic context executes its glucose–insulin equations; controls
apply declared model perturbations (hERG blocker / metformin / meal / lifestyle) and
recompute the connected state. These are executable model outputs, not observed human
reactions. Systems without an engine are marked *pending*, never faked.

The default `/` page is the merged Atlas workspace. Governed subject onboarding is at
`/twins`, cohort definition is at `/cohorts`, and the previous Aegle console remains at
`/legacy`. Biology, LIFE Patch, Cendos, and Adapters remain first-class linked surfaces.

## Honest boundaries (no fakes)
Capital-intensive components — physical lab instruments, wet biology, GPU-scale
simulation — are built as real interfaces/repos, never stubbed as if running
locally. Auditable ≠ validated.

The current services are loopback-only research infrastructure. Mutation routes and
selected PHI-like reads require operator authentication. Local patch journals, bus events,
and snapshots are encrypted with an owner-only AES-256-GCM key generated by the launcher.
The platform is not tenant-isolated and is not approved for production PHI or
partner-confidential inputs; it is not a patient-data environment, so never enter patient data. Read-only screen reports are scoped to a unique run id
and require operator authentication; evidence export is an authenticated lifecycle mutation.

## Public archive reference data

Public maintenance archives omit internal research notes, historical trial artifacts
and the book-derived plant catalog. Discovery code reports
`REFERENCE_DATA_NOT_DISTRIBUTED` when that catalog is unavailable; it does not
return an empty successful shortlist. Tests requiring private source evidence
report explicit skips. The reference seed remains bundled in both supported paths.

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for retained source attribution
and source-specific terms. The repository MIT license does not relicense
third-party assets.
