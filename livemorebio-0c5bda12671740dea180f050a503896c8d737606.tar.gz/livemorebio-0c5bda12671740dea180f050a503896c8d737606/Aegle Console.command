#!/bin/zsh
# Double-click to launch the Aegle living-twin console.
cd "$(dirname "$0")" || exit 1
./.venv/bin/livemore start Aegle
./.venv/bin/livemore open
