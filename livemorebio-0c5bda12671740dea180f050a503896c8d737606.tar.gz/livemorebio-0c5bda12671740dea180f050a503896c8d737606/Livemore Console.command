#!/bin/zsh
# Double-click → start LIFE :8851, Aegle :8850, Cendos :8852 and open the web console.
cd "$(dirname "$0")" || exit 1
clear
echo "Starting the LivemoreBio infrastructure (LIFE :8851 · Aegle :8850 · Cendos :8852)…"
./.venv/bin/livemore start
./.venv/bin/livemore open
echo
echo "Console: http://127.0.0.1:8850   (services keep running when this window closes)"
echo "To restore browser authorization after a restart, run ./.venv/bin/livemore open."
echo "Stop with: ./.venv/bin/livemore stop   — or use 'Livemore Stop.command'."
echo "Press Return to close this window."
read
